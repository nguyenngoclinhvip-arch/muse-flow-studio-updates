const state = {
  license: null,
  skills: [],
  filmGenres: [],
  skillPromptRunning: false,
  filmStoryboardRunning: false,
  lastExportedMovie: null,
  accounts: [],
  activeAccountId: null,
  activeAccount: null,
  batchStats: null,
  chromePath: null,
  statusFilter: 'all',
  selectedRows: new Set()
};

const capcutState = {
  clips: [],
  activeClipId: null,
  playingAll: false,
  singleRowTarget: null,
  lastExportedResult: null,
  draggedClipId: null
};

const paymentState = {
  selectedPlanId: null,
  currentOrder: null,
  pollTimer: null,
  checking: false
};

let countdownIntervalId = null;
const promptSaveTimers = new Map();
const dialogueSaveTimers = new Map();
const sceneTitleSaveTimers = new Map();
let voiceNoteSaveTimer = null;
let filmWorldSaveTimer = null;
let filmCustomStyleSaveTimer = null;
let filmNarratorNoteSaveTimer = null;

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.3s ease';
    setTimeout(() => el.remove(), 300);
  }, 3800);
}

async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json().catch(() => ({ ok: false, error: 'Phản hồi không hợp lệ từ Server' }));
  if (data && data.licenseRequired && data.license) {
    state.license = data.license;
    renderLicenseUI(true);
  }
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

function formatCountdownShort(ms) {
  const safeMs = Math.max(0, Number(ms) || 0);
  const totalSec = Math.floor(safeMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const hh = String(hours).padStart(2, '0');
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return days > 0 ? `${days}n ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
}

function formatCountdownLong(ms) {
  const safeMs = Math.max(0, Number(ms) || 0);
  const totalSec = Math.floor(safeMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const hh = String(hours).padStart(2, '0');
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return days > 0 ? `${days} ngày ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
}

function startLicenseCountdownTimer() {
  if (countdownIntervalId) clearInterval(countdownIntervalId);
  countdownIntervalId = setInterval(async () => {
    const lic = state.license;
    if (!lic) return;

    const topText = document.getElementById('topLicenseBadgeText');
    const remEl = document.getElementById('licDaysRemaining');

    if (!lic.valid) {
      if (topText) topText.textContent = 'Hết hạn • Kích hoạt';
      if (remEl) remEl.textContent = 'Đã hết hạn';
      return;
    }

    if (!lic.expiresAtMs || lic.expiresAtMs === 0) {
      if (topText) topText.textContent = 'Vĩnh viễn';
      if (remEl) remEl.textContent = 'Vĩnh viễn';
      return;
    }

    const remMs = lic.expiresAtMs - Date.now();
    if (remMs <= 0) {
      try {
        const res = await apiFetch('/api/license/status');
        state.license = res.license;
        renderLicenseUI(!state.license?.valid);
      } catch (_) {}
      return;
    }

    const shortTxt = formatCountdownShort(remMs);
    if (topText) {
      topText.textContent = lic.isTrial ? `Dùng thử: ${shortTxt}` : `Còn ${shortTxt}`;
    }
    if (remEl) {
      remEl.textContent = formatCountdownLong(remMs);
    }
  }, 1000);
}

async function loadAppState() {
  try {
    const data = await apiFetch('/api/state');
    state.version = data.version || '3.0';
    const verBadge = document.getElementById('topVersionBadge');
    if (verBadge && data.version) {
      verBadge.textContent = `v${data.version}`;
    }
    state.license = data.license || null;
    state.skills = data.skills || [];
    state.filmGenres = data.filmGenres || [];
    state.accounts = data.accounts || [];
    state.activeAccountId = data.activeAccountId;
    state.activeAccount = data.activeAccount;
    state.batchStats = data.batchStats;
    state.chromePath = data.chromePath;
    renderAll();
    renderLicenseUI(!state.license?.valid);
    startLicenseCountdownTimer();
  } catch (err) {
    showToast(`Lỗi tải trạng thái: ${err.message}`, 'error');
  }
}

function stopPaymentPolling() {
  if (paymentState.pollTimer) {
    clearInterval(paymentState.pollTimer);
    paymentState.pollTimer = null;
  }
}

async function pollPaymentOrderOnce(manualClick = false) {
  if (!paymentState.currentOrder || paymentState.checking) return;
  paymentState.checking = true;
  const statusEl = document.getElementById('paymentWatchStatusText');
  if (manualClick && statusEl) {
    statusEl.textContent = 'Đang đối soát giao dịch chuyển khoản...';
  }

  try {
    const res = await apiFetch('/api/license/payment/check', {
      method: 'POST',
      body: JSON.stringify({
        planId: paymentState.currentOrder.plan.id,
        orderCode: paymentState.currentOrder.orderCode
      })
    });

    if (res.paid && res.license) {
      stopPaymentPolling();
      state.license = res.license;
      document.getElementById('paymentQrPanel')?.classList.add('hidden');
      renderLicenseUI(false);
      startLicenseCountdownTimer();
      showToast(res.message || '🎉 Chuyển khoản thành công! Đã tự động kích hoạt bản quyền.', 'success');
      await loadAppState();
      return;
    }

    if (statusEl) {
      statusEl.textContent = res.message || 'Đang chờ nhận chuyển khoản để tự động kích hoạt...';
    }
    if (manualClick) {
      showToast('Hệ thống chưa ghi nhận giao dịch mới, vui lòng đợi vài giây sau khi chuyển khoản!', 'info');
    }
  } catch (err) {
    if (manualClick) {
      showToast(err.message, 'error');
    }
  } finally {
    paymentState.checking = false;
  }
}

async function selectPricingPlan(planId) {
  paymentState.selectedPlanId = planId;
  document.querySelectorAll('#pricingPlansGrid .pricing-card').forEach((card) => {
    card.classList.toggle('active', card.dataset.plan === planId);
  });

  try {
    const res = await apiFetch('/api/license/payment/create-order', {
      method: 'POST',
      body: JSON.stringify({ planId })
    });
    const order = res.order;
    paymentState.currentOrder = order;

    const qrPanel = document.getElementById('paymentQrPanel');
    const qrImg = document.getElementById('paymentQrImg');
    const accNumEl = document.getElementById('payAccNum');
    const holderEl = document.getElementById('payAccHolder');
    const amountEl = document.getElementById('payAmountText');
    const contentEl = document.getElementById('payTransferContent');
    const watchEl = document.getElementById('paymentWatchStatusText');

    if (qrImg) qrImg.src = order.qrUrl;
    if (accNumEl) accNumEl.textContent = order.accountNumber;
    if (holderEl) holderEl.textContent = order.accountHolder;
    if (amountEl) {
      amountEl.textContent = order.amountFormatted;
      amountEl.dataset.rawAmount = String(order.amount);
    }
    if (contentEl) {
      contentEl.textContent = order.transferDisplay;
      contentEl.dataset.copyValue = order.transferContent;
    }
    if (watchEl) {
      watchEl.textContent = `Quét mã QR chuyển ${order.amountFormatted} — Tự động kích hoạt ngay khi thành công`;
    }
    if (qrPanel) {
      qrPanel.classList.remove('hidden');
    }

    stopPaymentPolling();
    paymentState.pollTimer = setInterval(() => {
      const modal = document.getElementById('licenseModal');
      if (!modal || modal.classList.contains('hidden')) {
        stopPaymentPolling();
        return;
      }
      pollPaymentOrderOnce(false);
    }, 5000);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function renderLicenseUI(forceOpenModal = false) {
  const lic = state.license;
  if (!lic) return;

  const topPill = document.getElementById('btnOpenLicenseModal');
  const topText = document.getElementById('topLicenseBadgeText');
  const modal = document.getElementById('licenseModal');
  const closeBtn = document.getElementById('btnCloseLicenseModal');
  const banner = document.getElementById('licenseStatusBanner');
  const titleEl = document.getElementById('licenseStatusTitle');
  const reasonEl = document.getElementById('licenseStatusReason');
  const hwidInput = document.getElementById('inputMachineHwid');
  const inlineHwid = document.getElementById('licInlineHwid');
  const deactivateBtn = document.getElementById('btnDeactivateLicense');
  const planEl = document.getElementById('licPlanName');
  const remEl = document.getElementById('licDaysRemaining');
  const expEl = document.getElementById('licExpiresAt');

  if (hwidInput) hwidInput.value = lic.hwid || '';
  if (inlineHwid) inlineHwid.textContent = lic.hwid || '';

  if (lic.valid) {
    if (topPill) {
      topPill.classList.remove('unlicensed');
      topPill.classList.toggle('trial-pill', Boolean(lic.isTrial));
    }

    const remMs = lic.expiresAtMs > 0 ? Math.max(0, lic.expiresAtMs - Date.now()) : 0;
    if (topText) {
      topText.textContent =
        lic.expiresAtMs === 0
          ? 'Vĩnh viễn'
          : lic.isTrial
          ? `Dùng thử: ${formatCountdownShort(remMs)}`
          : `Còn ${formatCountdownShort(remMs)}`;
    }

    if (closeBtn) closeBtn.classList.remove('hidden');
    if (deactivateBtn) {
      deactivateBtn.classList.toggle('hidden', Boolean(lic.isTrial));
    }

    if (banner) {
      banner.classList.remove('status-locked');
      banner.classList.add('status-unlocked');
    }
    if (titleEl) {
      titleEl.textContent = lic.isTrial
        ? '🎁 ĐANG DÙNG THỬ MIỄN PHÍ 2 NGÀY'
        : '✅ BẢN QUYỀN CHÍNH HÃNG ĐANG HOẠT ĐỘNG';
    }
    if (reasonEl) {
      reasonEl.textContent = lic.isTrial
        ? 'Bạn có thể chọn gói bên dưới để nâng cấp tự động qua QR hoặc nhập Key bất cứ lúc nào.'
        : `Máy [${lic.hwid}] đã kích hoạt bản quyền chính hãng.`;
    }

    if (planEl) planEl.textContent = lic.planName || 'Chính hãng';
    if (remEl) {
      remEl.className = 'text-emerald';
      remEl.textContent = lic.expiresAtMs === 0 ? 'Vĩnh viễn' : formatCountdownLong(remMs);
    }
    if (expEl) expEl.textContent = lic.expiresAtFormatted || 'Vĩnh viễn';

    if (modal) {
      if (forceOpenModal) {
        modal.classList.remove('hidden');
      } else {
        modal.classList.add('hidden');
        stopPaymentPolling();
      }
    }
  } else {
    if (topPill) {
      topPill.classList.add('unlicensed');
      topPill.classList.remove('trial-pill');
    }
    if (topText) topText.textContent = 'Hết hạn • Kích hoạt';
    if (closeBtn) closeBtn.classList.add('hidden');
    if (deactivateBtn) deactivateBtn.classList.toggle('hidden', Boolean(lic.isTrial));

    if (banner) {
      banner.classList.add('status-locked');
      banner.classList.remove('status-unlocked');
    }
    if (titleEl) {
      titleEl.textContent = lic.tampered
        ? '🚨 CẢNH BÁO BẢN QUYỀN THƯƠNG HIỆU'
        : lic.isTrial
        ? '⏰ ĐÃ HẾT 2 NGÀY DÙNG THỬ MIỄN PHÍ'
        : '🔒 BẢN QUYỀN ĐÃ HẾT HẠN';
    }
    if (reasonEl) {
      reasonEl.textContent =
        lic.reason || 'Chọn gói bản quyền bên dưới để chuyển khoản kích hoạt tự động hoặc nhập mã Key.';
    }

    if (planEl) planEl.textContent = lic.planName || 'Chưa kích hoạt';
    if (remEl) {
      remEl.className = 'text-rose';
      remEl.textContent = 'Đã hết hạn';
    }
    if (expEl) expEl.textContent = lic.expiresAtFormatted || '--';

    if (modal) {
      modal.classList.remove('hidden');
    }
  }
}

function connectWebSocket() {
  const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const ws = new WebSocket(`${proto}//${window.location.host}`);

  ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      handleRealtimeEvent(msg.event, msg.payload);
    } catch (_) {}
  };

  ws.onclose = () => {
    setTimeout(connectWebSocket, 2500);
  };
}

function handleRealtimeEvent(event, payload) {
  if (!payload) return;

  if (event === 'update_progress') {
    const statusEl = document.getElementById('updateProgressStatus');
    if (statusEl && payload.message) {
      statusEl.textContent = payload.message;
    }
    return;
  }

  if (event === 'license_updated') {
    state.license = payload.license;
    if (state.license?.valid) stopPaymentPolling();
    renderLicenseUI(!state.license?.valid);
    startLicenseCountdownTimer();
    return;
  }

  if (event === 'account_connected' || event === 'account_status_changed') {
    const updatedAcc = payload.account;
    if (updatedAcc) {
      const idx = state.accounts.findIndex((a) => a.id === updatedAcc.id);
      if (idx !== -1) {
        state.accounts[idx] = {
          ...state.accounts[idx],
          connected: updatedAcc.connected,
          loginVerified: updatedAcc.loginVerified,
          savedAccount: updatedAcc.savedAccount,
          proxy: updatedAcc.proxy || '',
          proxyLabel: updatedAcc.proxyLabel || '',
          accountInfo: updatedAcc.accountInfo
        };
      }
      if (state.activeAccount && state.activeAccount.id === updatedAcc.id) {
        state.activeAccount.connected = updatedAcc.connected;
        state.activeAccount.loginVerified = updatedAcc.loginVerified;
        state.activeAccount.savedAccount = updatedAcc.savedAccount;
        state.activeAccount.proxy = updatedAcc.proxy || '';
        state.activeAccount.proxyLabel = updatedAcc.proxyLabel || '';
        state.activeAccount.accountInfo = updatedAcc.accountInfo;
        renderTopbarAndAccountStatus();
      }
      if (payload.justLoggedIn) {
        showToast('🎉 Đăng nhập thành công! Tài khoản đã lưu & tự động chuyển sang chạy ngầm.', 'success');
      }
      if (
        inAppLoginUiState.open &&
        inAppLoginUiState.accountId === updatedAcc.id &&
        updatedAcc.loginVerified
      ) {
        inAppLoginUiState.busy = false;
        inAppLoginUiState.account = updatedAcc;
        inAppLoginUiState.loginState = {
          step: 'logged_in',
          isLoggedIn: true,
          heading: 'Đã đăng nhập thành công!',
          description: 'Phiên đăng nhập đã được lưu an toàn và chạy ngầm 100%.'
        };
        renderInAppLoginModal();
      }
    }
    renderAccountSelect();
    renderAccountsModalList();
  } else if (event === 'row_updated') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id && payload.row) {
      const rIdx = state.activeAccount.rows.findIndex((r) => r.index === payload.row.index);
      if (rIdx !== -1) {
        state.activeAccount.rows[rIdx] = payload.row;
        updateSingleRowDom(payload.row);
        renderRowCountsAndFilterVisibility();
        updateSampleVideoStatusBadgeOnly();
        updateFilmRibbonBadgesOnly();
      }
    }
  } else if (event === 'row_error_skipped') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      showToast(`Hàng #${payload.rowIndex} lỗi, đã tự động bỏ qua!`, 'error');
    }
  } else if (event === 'batch_progress') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.batchStats = payload.stats;
      renderBatchMonitor();
    }
  } else if (event === 'settings_updated') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.activeAccount.settings = payload.settings;
      if (Array.isArray(payload.characters)) {
        state.activeAccount.characters = payload.characters;
      }
      if (Array.isArray(payload.rows)) {
        state.activeAccount.rows = payload.rows;
      }
      renderSidebarSettings();
      renderBatchMonitor();
      renderFlowRows();
      renderFilmCharactersModalList();
    }
  } else if (event === 'accounts_updated') {
    loadAppState();
  } else if (event === 'skills_updated') {
    state.skills = payload.skills || [];
    renderSkillSelectorAndBadge();
    renderSkillsModalList();
  } else if (event === 'skill_prompt_progress') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.skillPromptRunning = Boolean(payload.running);
      renderSkillAutoPromptButtons(payload);
    }
  } else if (event === 'film_storyboard_progress') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.filmStoryboardRunning = Boolean(payload.running);
      const box = document.getElementById('sbProgressBox');
      const txt = document.getElementById('sbProgressText');
      if (box) box.classList.toggle('hidden', !payload.running);
      if (txt && payload.message) txt.textContent = payload.message;
    }
  }
}

function renderAll() {
  renderAccountSelect();
  renderTopbarAndAccountStatus();
  renderSidebarSettings();
  renderSkillSelectorAndBadge();
  renderBatchMonitor();
  renderFlowRows();
  renderAccountsModalList();
  renderSkillsModalList();
  renderFilmCharactersModalList();
  updateCapcutRibbonButtonLabel();
}

function buildClientCharacterTagSuggestion(rawName) {
  const clean = String(rawName || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .replace(/[^a-zA-Z0-9\s_]/g, ' ')
    .trim();
  if (!clean) return '';
  const camel = clean
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('')
    .slice(0, 26);
  return camel ? `@${camel}` : '';
}

async function saveFilmConfigPatch(patch) {
  if (!state.activeAccount || !patch) return;
  const curCfg = state.activeAccount.settings?.filmConfig || {};
  const nextCfg = { ...curCfg, ...patch };
  state.activeAccount.settings.filmConfig = nextCfg;
  await saveSidebarSettings({ filmConfig: nextCfg });
}

function resetFilmCharacterForm() {
  const setVal = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.value = v;
  };
  setVal('filmCharEditId', '');
  setVal('inputFilmCharName', '');
  setVal('inputFilmCharTag', '');
  setVal('selectFilmCharRole', 'character');
  setVal('selectFilmCharVoice', 'auto');
  setVal('inputFilmCharVoiceNote', '');
  setVal('inputFilmCharDna', '');
  const tagInp = document.getElementById('inputFilmCharTag');
  if (tagInp) tagInp.dataset.manualEdited = '';
  const heading = document.getElementById('filmCharFormHeading');
  if (heading) heading.textContent = '➕ Thêm Nhân Vật Mới';
  document.getElementById('btnCancelEditFilmChar')?.classList.add('hidden');
}

function getVoiceFriendlyLabelClient(voiceId) {
  const map = {
    auto: 'Tự khớp nhân vật',
    vi_male_north_warm: 'Nam Bắc trầm ấm',
    vi_male_north_energetic: 'Nam Bắc năng động',
    vi_male_south_friendly: 'Nam Nam hào sảng',
    vi_female_north_young: 'Nữ Bắc trẻ trung',
    vi_female_north_warm: 'Nữ Bắc dịu dàng',
    vi_female_south_sweet: 'Nữ Nam ngọt ngào',
    vi_female_south_energetic: 'Nữ Nam sắc sảo',
    vi_female_central_gentle: 'Nữ Trung sâu lắng',
    vi_storyteller_cinema: 'Giọng Kể chuyện điện ảnh',
    vi_mc_professional: 'Giọng Thuyết minh BTV',
    en_male_international: 'Tiếng Anh (Nam)',
    en_female_international: 'Tiếng Anh (Nữ)',
    custom: 'Giọng tùy chỉnh riêng'
  };
  return map[voiceId] || 'Tự khớp nhân vật';
}

function renderFilmCharactersModalList() {
  const container = document.getElementById('filmCharactersListContainer');
  updateFilmRibbonBadgesOnly();
  if (!container) return;

  const chars = Array.isArray(state.activeAccount?.characters) ? state.activeAccount.characters : [];
  if (chars.length === 0) {
    container.innerHTML = `
      <div class="pane-sub-hint" style="grid-column:1/-1; padding:26px 16px; text-align:center; border:1.5px dashed var(--border-strong); border-radius:10px;">
        🎭 Chưa có diễn viên nào trong bộ phim này.<br/>
        Hãy thêm nhân vật ở khung bên trái (hoặc dùng nút <strong>📖 Kịch Bản &amp; Phân Cảnh ➔ 🎬 AI Đạo Diễn</strong> để AI tự động trích xuất toàn bộ nhân vật từ câu chuyện!).
      </div>
    `;
    return;
  }

  container.innerHTML = chars
    .map((ch) => {
      const imgs = Array.isArray(ch.referenceImages) ? ch.referenceImages : [];
      const img0 = imgs[0] && imgs[0].publicUrl ? imgs[0] : null;
      const img1 = imgs[1] && imgs[1].publicUrl ? imgs[1] : null;
      const isNarrator = ch.roleType === 'narrator';
      const roleBadge = isNarrator ? '🎙️ Người dẫn chuyện' : '🧑 Diễn viên xuất hiện';
      const voiceLabel = getVoiceFriendlyLabelClient(ch.voicePreset || 'auto');

      const renderSlot = (im, slotIdx, slotTitle) => {
        if (im) {
          return `
            <div class="film-char-img-slot" data-char-act="pick-img" data-char-id="${escapeAttr(ch.id)}" data-slot="${slotIdx}" title="Click để đổi ${slotTitle}">
              <img src="${escapeAttr(im.publicUrl)}" alt="${escapeAttr(ch.name)}" />
              <button type="button" class="film-char-img-del" data-char-act="del-img" data-char-id="${escapeAttr(ch.id)}" data-slot="${slotIdx}" title="Xóa ảnh này">×</button>
            </div>
          `;
        }
        return `
          <div class="film-char-img-slot" data-char-act="pick-img" data-char-id="${escapeAttr(ch.id)}" data-slot="${slotIdx}" title="Tải ${slotTitle} cho ${escapeAttr(ch.name)}">
            <span style="font-size:18px; color:var(--accent-cyan);">+</span>
            <span style="font-size:10.5px; font-weight:700; color:var(--text-sub);">${slotTitle}</span>
          </div>
        `;
      };

      const slotsSection = isNarrator
        ? `<div class="film-char-dna-preview">🎙️ Nhân vật dẫn chuyện (Voiceover) — chỉ đọc thuyết minh nền, không bắt buộc tải ảnh mặt.</div>`
        : `
          <div class="film-char-slots">
            ${renderSlot(img0, 0, 'Ảnh 1: Cận mặt')}
            ${renderSlot(img1, 1, 'Ảnh 2: Toàn thân')}
          </div>
        `;

      const dnaText = ch.appearanceDna
        ? escapeHtml(ch.appearanceDna)
        : '<em style="opacity:0.75;">Chưa có mô tả DNA ngoại hình cố định (Nên tải ảnh rồi bấm "✨ AI Khóa Ngoại Hình" hoặc tự nhập).</em>';

      return `
        <div class="film-char-card">
          <div class="film-char-card-top">
            <div>
              <div class="film-char-name">${escapeHtml(ch.name)}</div>
              <span class="film-char-tag-pill">${escapeHtml(ch.tag)}</span>
              <span style="font-size:11px; color:var(--text-sub); margin-left:5px;">${roleBadge}</span>
            </div>
            <div style="display:flex; gap:5px;">
              <button type="button" class="btn-sample-act" data-char-act="edit" data-char-id="${escapeAttr(ch.id)}" title="Sửa thông tin nhân vật">✎ Sửa</button>
              <button type="button" class="btn-sample-act btn-sample-del" data-char-act="delete" data-char-id="${escapeAttr(ch.id)}" title="Xóa nhân vật">🗑</button>
            </div>
          </div>

          <div style="font-size:11.5px; font-weight:600; color:var(--color-title);">
            🔊 Giọng khóa: ${escapeHtml(voiceLabel)}${ch.voiceCustomNote ? ` • "${escapeHtml(ch.voiceCustomNote)}"` : ''}
          </div>

          ${slotsSection}

          <div class="film-char-dna-preview" title="Đặc điểm ngoại hình & trang phục khóa xuyên suốt phim">${dnaText}</div>

          ${
            !isNarrator
              ? `
                <div class="film-char-card-actions">
                  <button type="button" class="btn-char-ai-dna" data-char-act="ai-dna" data-char-id="${escapeAttr(ch.id)}" title="Nhờ AI trên Muse.ai đọc ảnh chân dung và trích xuất mô tả ngoại hình khóa cứng">
                    ✨ AI Đọc Ảnh Khóa Ngoại Hình
                  </button>
                </div>
              `
              : ''
          }
        </div>
      `;
    })
    .join('');
}

function openFilmCharactersModal() {
  resetFilmCharacterForm();
  renderFilmCharactersModalList();
  document.getElementById('filmCharactersModal')?.classList.remove('hidden');
}

async function uploadFilmCharacterImageSlot(characterId, slotIndex, file) {
  if (!state.activeAccount || !characterId || !file) return;
  const formData = new FormData();
  formData.append('image', file);
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/film/characters/${encodeURIComponent(characterId)}/image/${Number(slotIndex) || 0}`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.account) {
      state.activeAccount = res.account;
      renderFilmCharactersModalList();
      renderFlowRows();
    }
    showToast(`📸 Đã lưu ảnh mẫu cho diễn viên "${res.character?.name || ''}"!`, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openFilmCharSlotFilePicker(characterId, slotIndex = 0) {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.onchange = async () => {
    const file = inp.files?.[0];
    if (file) {
      await uploadFilmCharacterImageSlot(characterId, slotIndex, file);
    }
  };
  inp.click();
}

async function deleteFilmCharacterImageSlot(characterId, slotIndex = 0) {
  if (!state.activeAccount || !characterId) return;
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/film/characters/${encodeURIComponent(characterId)}/image/${Number(slotIndex) || 0}`,
      { method: 'DELETE' }
    );
    if (res.account) {
      state.activeAccount = res.account;
      renderFilmCharactersModalList();
      renderFlowRows();
    }
    showToast('Đã xóa ảnh mẫu của diễn viên.', 'info');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function getStoryboardSelectedSeconds() {
  const sel = document.getElementById('sbSelectTargetDuration');
  const customMinInp = document.getElementById('sbInputCustomMinutes');
  if (!sel) return 180;
  if (sel.value === 'custom') {
    const mins = Math.max(0.5, Math.min(120, parseFloat(customMinInp?.value || '5') || 5));
    return Math.round(mins * 60);
  }
  return Math.max(20, Math.min(7200, Number(sel.value) || 180));
}

function updateStoryboardSceneEstimate() {
  const totalSec = getStoryboardSelectedSeconds();
  const sceneSec = Math.max(5, Number(document.getElementById('sbSelectSceneSec')?.value || 10));
  const estScenes = Math.max(2, Math.min(200, Math.round(totalSec / sceneSec)));
  const badge = document.getElementById('sbEstimatedScenesBadge');
  if (badge) {
    const mins = Math.floor(totalSec / 60);
    const rem = totalSec % 60;
    const durLabel = mins > 0 ? `${mins} phút${rem ? ` ${rem}s` : ''}` : `${totalSec} giây`;
    badge.textContent = `Ước tính: ~${estScenes} phân cảnh × ${sceneSec}s = ${durLabel}`;
  }
}

function openFilmStoryboardModal() {
  const acc = state.activeAccount;
  if (!acc) return;
  const fc = acc.settings?.filmConfig || {};

  const genreSel = document.getElementById('sbSelectGenre');
  if (genreSel) genreSel.value = fc.genreId || '3d_pixar';

  const audioSel = document.getElementById('sbSelectAudioMode');
  if (audioSel) audioSel.value = fc.audioMode || 'mixed';

  const worldInp = document.getElementById('sbInputWorldLock');
  if (worldInp) worldInp.value = fc.worldLock || '';

  const storyInp = document.getElementById('sbTextareaStory');
  if (storyInp && !storyInp.value.trim() && fc.storyDraft) {
    storyInp.value = fc.storyDraft;
  }

  const targetSel = document.getElementById('sbSelectTargetDuration');
  const customInp = document.getElementById('sbInputCustomMinutes');
  const savedTargetSec = Number(fc.targetMovieSeconds) || 180;
  if (targetSel) {
    const hasPreset = Array.from(targetSel.options).some((o) => Number(o.value) === savedTargetSec);
    if (hasPreset) {
      targetSel.value = String(savedTargetSec);
      customInp?.classList.add('hidden');
    } else {
      targetSel.value = 'custom';
      if (customInp) {
        customInp.value = Number((savedTargetSec / 60).toFixed(1));
        customInp.classList.remove('hidden');
      }
    }
  }

  const sceneSecSel = document.getElementById('sbSelectSceneSec');
  if (sceneSecSel) {
    const curSceneSec = Number(fc.sceneDurationSeconds) || 10;
    if (Array.from(sceneSecSel.options).some((o) => Number(o.value) === curSceneSec)) {
      sceneSecSel.value = String(curSceneSec);
    } else {
      sceneSecSel.value = '10';
    }
  }

  updateStoryboardSceneEstimate();
  document.getElementById('filmStoryboardModal')?.classList.remove('hidden');
}

function openFilmExportModal() {
  const acc = state.activeAccount;
  if (!acc) return;

  const allRows = acc.rows || [];
  const completedRows = allRows.filter((r) => r && r.videoUrl);
  const perSceneSec = parseDurationToSeconds(acc.settings?.duration || '10s');
  const estTotalSec = completedRows.length * perSceneSec;
  const mins = Math.floor(estTotalSec / 60);
  const rem = estTotalSec % 60;
  const timeTxt = mins > 0 ? `${mins} phút ${rem}s` : `${estTotalSec} giây`;

  const summaryEl = document.getElementById('filmExportSummaryBox');
  if (summaryEl) {
    if (completedRows.length === 0) {
      summaryEl.innerHTML = `⚠️ Hiện chưa có phân cảnh nào hoàn tất video (0/${allRows.length} cảnh). Hãy bấm <strong>CHẠY TẤT CẢ</strong> để công cụ tạo các phân cảnh trước khi ghép thành bộ phim hoàn chỉnh!`;
    } else {
      summaryEl.innerHTML = `✅ Sẵn sàng ghép <strong>${completedRows.length}/${allRows.length} phân cảnh</strong> đã hoàn tất theo đúng trình tự kịch bản (Ước tính bộ phim dài khoảng <strong>~${timeTxt}</strong>).`;
    }
  }

  const titleInp = document.getElementById('inputFilmExportTitle');
  if (titleInp && (!titleInp.value || titleInp.value === 'Bo_Phim_Hoan_Chinh')) {
    const safeProj = String(acc.name || 'Bo_Phim_Hoan_Chinh')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .replace(/^_+|_+$/g, '');
    if (safeProj) titleInp.value = `Phim_${safeProj}`;
  }

  document.getElementById('filmExportModal')?.classList.remove('hidden');
}

function getAccountDisplayLoginAndUsage(acc) {
  if (!acc) {
    return {
      loginName: 'Chưa đăng nhập',
      usedText: '--',
      remainingText: '--',
      usedPct: 0,
      remPct: 0,
      hasUsage: false
    };
  }

  const info = acc.accountInfo || {};
  const tu = info.tokenUsage && typeof info.tokenUsage === 'object' ? info.tokenUsage : null;

  const rawCand =
    info.customLoginName ||
    info.loginName ||
    info.agentName ||
    (info.displayName &&
    !/chưa kết nối|tài khoản muse\.ai đã lưu|đang chờ đăng nhập/i.test(info.displayName) &&
    info.displayName !== acc.name
      ? info.displayName
      : '');

  const loginName = rawCand
    ? String(rawCand).trim()
    : acc.loginVerified
    ? 'Đã đăng nhập'
    : 'Chưa đăng nhập';

  if (!tu) {
    return {
      loginName,
      usedText: '--',
      remainingText: '--',
      usedPct: 0,
      remPct: 0,
      hasUsage: false
    };
  }

  const usedPct = typeof tu.tokensUsedPercent === 'number' ? Math.min(100, Math.max(0, tu.tokensUsedPercent)) : 0;
  const remPct =
    typeof tu.tokensRemainingPercent === 'number'
      ? Math.min(100, Math.max(0, tu.tokensRemainingPercent))
      : Math.max(0, 100 - usedPct);

  let usedText = '--';
  let remainingText = '--';

  if (tu.hasTokenPool) {
    usedText = `${tu.tokensUsedFormatted || '0'} (${usedPct}%)`;
    remainingText = `${tu.tokensRemainingFormatted || '0'} (${remPct}%)`;
  } else {
    usedText = tu.tokensUsedFormatted || `${usedPct}%`;
    remainingText = tu.tokensRemainingFormatted || `${remPct}%`;
  }

  return {
    loginName,
    usedText,
    remainingText,
    usedPct,
    remPct,
    hasUsage: true
  };
}

async function syncAccountQuotaFromUi(accountId, btnEl = null) {
  const targetId = accountId || state.activeAccount?.id;
  if (!targetId) return;
  if (btnEl) {
    btnEl.disabled = true;
    btnEl.classList.add('spinning');
  }
  try {
    showToast('🔄 Đang đọc tên tài khoản & số dư Token trực tiếp từ Muse.ai...', 'info');
    const res = await apiFetch(`/api/accounts/${targetId}/sync-usage`, {
      method: 'POST',
      body: JSON.stringify({ forceConnect: true })
    });
    await loadAppState();
    showToast(res.message || 'Đã cập nhật thông tin tài khoản & Token!', 'success');
  } catch (err) {
    showToast(`Không thể cập nhật Token: ${err.message}`, 'error');
  } finally {
    if (btnEl) {
      btnEl.disabled = false;
      btnEl.classList.remove('spinning');
    }
  }
}

function renderAccountSelect() {
  const sel = document.getElementById('accountSelect');
  if (!sel || !state.activeAccount) return;

  sel.innerHTML = '';
  state.accounts.forEach((acc) => {
    const opt = document.createElement('option');
    opt.value = acc.id;
    const statusDot = acc.loginVerified ? '🟢' : '🔴';
    const meta = getAccountDisplayLoginAndUsage(acc);
    const userSuffix =
      acc.loginVerified && meta.loginName && !/^đã đăng nhập/i.test(meta.loginName)
        ? ` — ${meta.loginName}`
        : '';
    opt.textContent = `${statusDot} ${acc.name}${userSuffix}`;
    if (acc.id === state.activeAccount.id) {
      opt.selected = true;
    }
    sel.appendChild(opt);
  });
}

function renderTopbarAndAccountStatus() {
  const acc = state.activeAccount;
  if (!acc) return;

  const quotaPill = document.getElementById('topAccountQuotaPill');
  const statusDot = document.getElementById('topQuotaStatusDot');
  const loginNameEl = document.getElementById('topQuotaLoginName');
  const usedEl = document.getElementById('topQuotaUsedText');
  const remEl = document.getElementById('topQuotaRemainingText');

  if (quotaPill && loginNameEl && usedEl && remEl) {
    const meta = getAccountDisplayLoginAndUsage(acc);
    if (statusDot) {
      statusDot.className = `status-led ${acc.loginVerified ? 'led-green' : 'led-red'}`;
    }
    loginNameEl.textContent = acc.loginVerified ? meta.loginName : 'Đăng nhập tài khoản';
    usedEl.textContent = meta.usedText;
    remEl.textContent = meta.remainingText;
    quotaPill.classList.toggle('is-logged-in', Boolean(acc.loginVerified));
    quotaPill.classList.toggle('is-low-token', Boolean(meta.hasUsage && meta.remPct <= 15));
    quotaPill.title = acc.loginVerified
      ? `${acc.name} • ${meta.loginName}\nToken đã sử dụng: ${meta.usedText}\nToken còn lại: ${meta.remainingText}\n(Bấm để quản lý tài khoản)`
      : `${acc.name} — Chưa đăng nhập (Bấm để đăng nhập & quản lý tài khoản)`;
  }
}

function parseDurationToSeconds(rawVal) {
  if (rawVal === null || rawVal === undefined) return 10;
  const str = String(rawVal).trim().toLowerCase();
  if (!str) return 10;
  const colon = str.match(/^(\d+)\s*:\s*(\d{1,2})$/);
  if (colon) {
    const t = (Number(colon[1]) || 0) * 60 + (Number(colon[2]) || 0);
    return Math.max(5, Math.min(3600, Math.round(t || 10)));
  }
  const minMatch = str.match(/^(\d+(?:[.,]\d+)?)\s*(?:m|min|p|phut|phút)\s*(\d+)?/i);
  if (minMatch) {
    const m = parseFloat(minMatch[1].replace(',', '.')) || 0;
    const extraS = minMatch[2] ? Number(minMatch[2]) || 0 : 0;
    return Math.max(5, Math.min(3600, Math.round(m * 60 + extraS)));
  }
  const num = parseFloat(str.replace(',', '.'));
  if (!Number.isFinite(num) || num <= 0) return 10;
  return Math.max(5, Math.min(3600, Math.round(num)));
}

function formatDurationBadgeSummary(sec) {
  const n = Math.max(5, Math.min(3600, Math.round(Number(sec) || 10)));
  const parts = n > 10 ? Math.ceil(n / 10) : 1;
  if (n < 60) {
    return `${n}s • ${parts} phần`;
  }
  const mins = Math.floor(n / 60);
  const rem = n % 60;
  const timeText = rem === 0 ? `${mins} phút (${n}s)` : `${mins}p${String(rem).padStart(2, '0')}s (${n}s)`;
  return `${timeText} • ${parts} phần`;
}

function isFilmmakingMode() {
  return state.activeAccount?.settings?.studioMode === 'filmmaking';
}

function getMaxAllowedRowDurationSec() {
  return isFilmmakingMode() ? 3600 : 60;
}

function updateFilmRibbonBadgesOnly() {
  const acc = state.activeAccount;
  if (!acc) return;
  const charCount = Array.isArray(acc.characters) ? acc.characters.length : 0;
  const completedRows = (acc.rows || []).filter((r) => r && r.videoUrl).length;
  const totalRows = (acc.rows || []).length;

  const ribbonCast = document.getElementById('filmRibbonCastSub');
  if (ribbonCast) ribbonCast.textContent = `${charCount} nhân vật`;

  const sideCast = document.getElementById('sidebarCastCount');
  if (sideCast) sideCast.textContent = String(charCount);

  const modalCast = document.getElementById('filmModalCastCount');
  if (modalCast) modalCast.textContent = String(charCount);

  const ribbonExport = document.getElementById('filmRibbonExportSub');
  if (ribbonExport) {
    ribbonExport.textContent =
      completedRows > 0 ? `${completedRows}/${totalRows} cảnh sẵn sàng` : 'Ghép Full + Nhạc nền';
  }

  const filmBadge = document.getElementById('filmSceneSummaryBadge');
  if (filmBadge) {
    const perSceneSec = parseDurationToSeconds(acc.settings?.duration || '10s');
    const estTotalSec = totalRows * perSceneSec;
    const estMinText =
      estTotalSec >= 60
        ? `${Math.floor(estTotalSec / 60)}p${estTotalSec % 60 ? `${estTotalSec % 60}s` : ''}`
        : `${estTotalSec}s`;
    filmBadge.textContent = `${totalRows} cảnh (~${estMinText})`;
  }
}

function renderStudioModeAndFilmSidebar() {
  const acc = state.activeAccount;
  if (!acc || !acc.settings) return;
  const s = acc.settings;
  const filmOn = s.studioMode === 'filmmaking';

  document.querySelectorAll('#studioModeSwitcher .mode-switch-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.studioMode === (filmOn ? 'filmmaking' : 'affiliate'));
  });

  document.querySelectorAll('.film-mode-only').forEach((el) => {
    el.classList.toggle('hidden', !filmOn);
  });

  const filmCard = document.getElementById('filmModeSidebarCard');
  if (filmCard) {
    filmCard.classList.toggle('hidden', !filmOn);
  }

  document.querySelectorAll('.film-only-dur-pill').forEach((pill) => {
    pill.classList.toggle('hidden', !filmOn);
  });

  const durLabel = document.getElementById('durationControlLabel');
  if (durLabel) {
    durLabel.textContent = filmOn ? 'Thời lượng mỗi phân cảnh' : 'Thời lượng video (≤ 60s)';
  }

  const durHint = document.getElementById('durationCustomHint');
  if (durHint) {
    durHint.textContent = filmOn
      ? 'Chế độ Làm Phim: Khuyên dùng 8s – 15s / phân cảnh để ghép thành bộ phim dài'
      : 'Affiliate TikTok & Shopee: Tối đa 60 giây (1 phút) • Nhập 5s ➔ 60s';
  }

  const inputCustomDur = document.getElementById('inputCustomDuration');
  if (inputCustomDur) {
    inputCustomDur.max = filmOn ? '3600' : '60';
  }

  const colIdxTitle = document.getElementById('colHeadIdxTitle');
  const colRefsTitle = document.getElementById('colHeadRefsTitle');
  const colRefsSub = document.getElementById('colHeadRefsSub');
  const colPromptTitle = document.getElementById('colHeadPromptTitle');
  const colPromptSub = document.getElementById('colHeadPromptSub');

  if (colIdxTitle) colIdxTitle.textContent = filmOn ? 'CẢNH' : 'HÀNG';
  if (colRefsTitle) colRefsTitle.textContent = filmOn ? '1. DIỄN VIÊN & ẢNH' : '1. ĐẦU VÀO';
  if (colRefsSub) {
    colRefsSub.textContent = filmOn ? 'Tự nạp ảnh Diễn viên + Ảnh cảnh' : '1–5 Ảnh & Video mẫu';
  }
  if (colPromptTitle) {
    colPromptTitle.textContent = filmOn
      ? '2. PHÂN CẢNH PHIM, ĐẠO DIỄN & THOẠI ĐA NHÂN VẬT'
      : '2. PROMPT CHUYỂN ĐỘNG & LỜI THOẠI';
  }
  if (colPromptSub) {
    colPromptSub.textContent = filmOn
      ? 'Gắn @NhânVật xuất hiện trong cảnh • Thoại phân vai [Dẫn chuyện]: ... / [@Tag]: ...'
      : 'Khung hành động bối cảnh • Khung thoại "..." cắt theo nhịp 10s';
  }

  const fc = s.filmConfig || {};
  const genreSel = document.getElementById('selectFilmGenre');
  if (genreSel && Array.isArray(state.filmGenres) && state.filmGenres.length > 0 && genreSel.dataset.loaded !== '1') {
    genreSel.innerHTML = state.filmGenres
      .map((g) => `<option value="${escapeAttr(g.id)}">${escapeHtml(g.name)}</option>`)
      .join('');
    genreSel.dataset.loaded = '1';
  }
  if (genreSel) {
    genreSel.value = fc.genreId || '3d_pixar';
  }

  const sbGenreSel = document.getElementById('sbSelectGenre');
  if (sbGenreSel && Array.isArray(state.filmGenres) && state.filmGenres.length > 0 && sbGenreSel.dataset.loaded !== '1') {
    sbGenreSel.innerHTML = state.filmGenres
      .map((g) => `<option value="${escapeAttr(g.id)}">${escapeHtml(g.name)}</option>`)
      .join('');
    sbGenreSel.dataset.loaded = '1';
  }

  const customWrap = document.getElementById('filmCustomStyleWrap');
  if (customWrap) {
    customWrap.classList.toggle('hidden', (fc.genreId || '3d_pixar') !== 'custom_cinema');
  }
  const customInp = document.getElementById('inputFilmCustomStyle');
  if (customInp && document.activeElement !== customInp) {
    customInp.value = fc.customStylePrompt || '';
  }

  const worldInp = document.getElementById('inputFilmWorldLock');
  if (worldInp && document.activeElement !== worldInp) {
    worldInp.value = fc.worldLock || '';
  }

  const audioModeSel = document.getElementById('selectFilmAudioMode');
  if (audioModeSel) {
    audioModeSel.value = fc.audioMode || 'mixed';
  }
  const narratorBox = document.getElementById('filmNarratorVoiceBox');
  if (narratorBox) {
    narratorBox.classList.toggle('hidden', fc.audioMode === 'dialogue' || fc.audioMode === 'ambient_only');
  }

  const narVoiceSel = document.getElementById('selectFilmNarratorVoice');
  if (narVoiceSel) {
    narVoiceSel.value = fc.narratorVoicePreset || 'vi_storyteller_cinema';
  }
  const narNoteInp = document.getElementById('inputFilmNarratorNote');
  if (narNoteInp && document.activeElement !== narNoteInp) {
    narNoteInp.value = fc.narratorVoiceNote || '';
  }

  const contSel = document.getElementById('selectFilmContinuityMode');
  if (contSel) {
    contSel.value = fc.continuityMode || 'parallel_fast';
  }

  updateFilmRibbonBadgesOnly();
}

function renderSidebarSettings() {
  const acc = state.activeAccount;
  if (!acc || !acc.settings) return;
  const s = acc.settings;

  renderStudioModeAndFilmSidebar();

  document.querySelectorAll('#aspectRatioGroup .ratio-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.ratio === s.aspectRatio);
  });

  const maxDurSec = getMaxAllowedRowDurationSec();
  const curDurSec = Math.min(maxDurSec, parseDurationToSeconds(s.duration || '10s'));
  const normDurStr = `${curDurSec}s`;
  let matchedDurationPreset = false;
  document.querySelectorAll('#durationGroup .pill-btn').forEach((btn) => {
    const isMatch = btn.dataset.duration === normDurStr;
    if (isMatch) matchedDurationPreset = true;
    btn.classList.toggle('active', isMatch);
  });

  const durBadge = document.getElementById('durationSummaryBadge');
  if (durBadge) {
    durBadge.textContent = formatDurationBadgeSummary(curDurSec);
  }
  const customDurBox = document.getElementById('customDurationBox');
  if (customDurBox) {
    customDurBox.classList.toggle('custom-active', !matchedDurationPreset);
  }
  const inputCustomDur = document.getElementById('inputCustomDuration');
  const selectDurUnit = document.getElementById('selectDurationUnit');
  if (inputCustomDur && selectDurUnit && document.activeElement !== inputCustomDur) {
    if (selectDurUnit.value === 'min') {
      inputCustomDur.value = Number((curDurSec / 60).toFixed(2));
    } else {
      inputCustomDur.value = curDurSec;
    }
  }

  document.getElementById('selectResolution').value = s.resolution || '720p';
  document.getElementById('selectCameraMotion').value = s.cameraMotion || 'Auto';

  const transSelect = document.getElementById('selectTransitionEffect');
  if (transSelect) {
    transSelect.value = s.transitionEffect || 'fade';
  }

  document.getElementById('chkBackgroundMode').checked = s.backgroundMode !== false;
  document.getElementById('chkNativeAudio').checked = Boolean(s.nativeAudio);
  if (document.getElementById('chkEnableDialogue')) {
    document.getElementById('chkEnableDialogue').checked = Boolean(s.enableDialogue);
  }
  const voiceSel = document.getElementById('selectVoicePreset');
  if (voiceSel) {
    voiceSel.value = s.voicePreset || 'auto';
  }
  const voiceNoteInp = document.getElementById('inputVoiceCustomNote');
  if (voiceNoteInp) {
    if (document.activeElement !== voiceNoteInp) {
      voiceNoteInp.value = s.voiceCustomNote || '';
    }
    voiceNoteInp.placeholder =
      s.voicePreset === 'custom'
        ? 'Mô tả chất giọng riêng (VD: Giọng nữ Hà Nội 24 tuổi trong trẻo, nói ấm áp...)'
        : 'Ghi chú giọng chung (VD: nói chậm rãi, giọng cô giáo 25 tuổi...)';
  }
  document.getElementById('chkInjectParams').checked = s.injectParamsIntoPrompt !== false;

  const concurrency = Math.max(1, Math.min(20, Number(s.concurrency) || 6));
  const inputConc = document.getElementById('inputConcurrency');
  if (inputConc) inputConc.value = concurrency;
  const badgeConc = document.getElementById('concurrencyBadgeLabel');
  if (badgeConc) badgeConc.textContent = `${concurrency} luồng`;
  document.querySelectorAll('#concurrencyPresetGroup .preset-chip').forEach((chip) => {
    btnToggleActive(chip, Number(chip.dataset.threads) === Number(concurrency));
  });

  const runAllTitle = document.getElementById('runAllBtnTitle');
  if (runAllTitle) {
    runAllTitle.textContent = `CHẠY TẤT CẢ (${concurrency} LUỒNG)`;
  }

  const rowCount = acc.rows?.length || s.rowCount || 10;
  document.getElementById('inputRowCount').value = rowCount;
  document.querySelectorAll('#rowPresetGroup .preset-chip').forEach((chip) => {
    btnToggleActive(chip, Number(chip.dataset.rows) === Number(rowCount));
  });

  document.getElementById('inputTargetUrl').value = s.targetUrl || 'https://muse.ai';
  document.getElementById('inputSelFile').value = s.customSelectors?.fileInput || '';
  document.getElementById('inputSelPrompt').value = s.customSelectors?.promptInput || '';
  document.getElementById('inputSelSubmit').value = s.customSelectors?.submitButton || '';
  renderSkillSelectorAndBadge();
  renderSampleVideoSidebar();
}

function updateSampleVideoStatusBadgeOnly() {
  const badgeEl = document.getElementById('sampleVideoStatusBadge');
  if (!badgeEl || !state.activeAccount) return;

  const s = state.activeAccount.settings || {};
  const hasAnyLearnChecked =
    s.sampleLearnMotion !== false || s.sampleLearnCamera !== false || s.sampleLearnScene !== false;
  const globalSample = s.sampleVideo && s.sampleVideo.publicUrl ? s.sampleVideo : null;
  const rowSampleCount = (state.activeAccount.rows || []).filter(
    (r) => r.sampleVideo && r.sampleVideo.publicUrl
  ).length;

  if (!hasAnyLearnChecked && (globalSample || rowSampleCount > 0)) {
    badgeEl.textContent = 'Tạm tắt lọc';
    badgeEl.classList.remove('sample-active-badge');
  } else if (globalSample && rowSampleCount > 0) {
    badgeEl.textContent = `Chung + ${rowSampleCount} hàng`;
    badgeEl.classList.add('sample-active-badge');
  } else if (globalSample) {
    badgeEl.textContent = 'Đang bật (Chung)';
    badgeEl.classList.add('sample-active-badge');
  } else if (rowSampleCount > 0) {
    badgeEl.textContent = `Đang bật (${rowSampleCount} hàng)`;
    badgeEl.classList.add('sample-active-badge');
  } else {
    badgeEl.textContent = 'Tắt';
    badgeEl.classList.remove('sample-active-badge');
  }
}

function renderSampleVideoSidebar() {
  const acc = state.activeAccount;
  if (!acc || !acc.settings) return;
  const s = acc.settings;

  const chkMotion = document.getElementById('chkSampleLearnMotion');
  const chkCamera = document.getElementById('chkSampleLearnCamera');
  const chkScene = document.getElementById('chkSampleLearnScene');
  const hintEl = document.getElementById('sampleSceneModeHint');

  const learnMotion = s.sampleLearnMotion !== false;
  const learnCamera = s.sampleLearnCamera !== false;
  const learnScene = s.sampleLearnScene !== false;

  if (chkMotion) chkMotion.checked = learnMotion;
  if (chkCamera) chkCamera.checked = learnCamera;
  if (chkScene) chkScene.checked = learnScene;

  if (hintEl) {
    if (!learnMotion && !learnCamera && !learnScene) {
      hintEl.textContent = '⚠️ Bạn đã bỏ tích cả 3 ô — Video mẫu sẽ tạm không áp dụng';
    } else if (learnScene) {
      hintEl.textContent = 'Giữ 100% mặt & trang phục ảnh gốc • Đổi bối cảnh theo video mẫu';
    } else {
      hintEl.textContent = 'Giữ 100% mặt, trang phục & NỀN GỐC của ảnh (chỉ học cử chỉ/camera)';
    }
  }

  updateSampleVideoStatusBadgeOnly();

  const boxEl = document.getElementById('globalSampleVideoBox');
  if (!boxEl) return;

  const globalSample = s.sampleVideo && s.sampleVideo.publicUrl ? s.sampleVideo : null;
  const nextUrlKey = globalSample ? `${globalSample.publicUrl}|${globalSample.fileName || ''}` : '__EMPTY__';
  if (boxEl.dataset.loadedSampleKey === nextUrlKey) {
    return;
  }
  boxEl.dataset.loadedSampleKey = nextUrlKey;

  if (globalSample) {
    const durTag =
      globalSample.durationSec && Number(globalSample.durationSec) > 0
        ? `<span class="sample-video-dur-tag">${Number(globalSample.durationSec).toFixed(1)}s</span>`
        : '';
    boxEl.innerHTML = `
      <div class="sample-video-preview-card">
        <div class="sample-video-stage" data-sample-global="preview" title="Rê chuột xem thử • Click để phóng to Video mẫu chung">
          <video class="sample-video-thumb" src="${escapeAttr(globalSample.publicUrl)}" muted loop playsinline preload="metadata"></video>
          ${durTag}
        </div>
        <div class="sample-video-meta-bar">
          <span class="sample-video-fname" title="${escapeAttr(globalSample.fileName || 'Video mẫu chung')}">🎬 ${escapeHtml(globalSample.fileName || 'Video mẫu chung')}</span>
          <div class="sample-video-actions">
            <button type="button" class="btn-sample-act" data-sample-global="preview" title="Phóng to xem video mẫu">👁</button>
            <button type="button" class="btn-sample-act" data-sample-global="pick" title="Đổi sang video mẫu chung khác">Đổi</button>
            <button type="button" class="btn-sample-act btn-sample-del" data-sample-global="remove" title="Gỡ video mẫu chung">×</button>
          </div>
        </div>
      </div>
    `;
    const stageEl = boxEl.querySelector('.sample-video-stage');
    const vidEl = boxEl.querySelector('video.sample-video-thumb');
    if (stageEl && vidEl) {
      stageEl.addEventListener('mouseenter', () => {
        vidEl.play().catch(() => {});
      });
      stageEl.addEventListener('mouseleave', () => {
        vidEl.pause();
      });
    }
  } else {
    boxEl.innerHTML = `
      <div class="sample-video-dropzone" data-sample-global="pick">
        <span class="sample-drop-icon">🎬</span>
        <span class="sample-drop-title">+ Tải Video Mẫu Chung</span>
        <span class="sample-drop-sub">Click hoặc kéo thả video mẫu (.mp4, .mov, .webm)</span>
      </div>
    `;
  }
}

function renderSkillSelectorAndBadge() {
  const selectEl = document.getElementById('selectActiveSkill');
  const badgeEl = document.getElementById('skillStatusBadge');
  const summaryEl = document.getElementById('activeSkillSummaryText');
  if (!selectEl) return;

  const activeSkillId = state.activeAccount?.settings?.activeSkillId || '';
  selectEl.innerHTML = `<option value="">— Không dùng Skill —</option>`;

  (state.skills || []).forEach((sk) => {
    const opt = document.createElement('option');
    opt.value = sk.id;
    opt.textContent = sk.name;
    if (sk.id === activeSkillId) {
      opt.selected = true;
    }
    selectEl.appendChild(opt);
  });

  const currentSkill = (state.skills || []).find((sk) => sk.id === activeSkillId) || null;
  if (badgeEl) {
    if (currentSkill) {
      badgeEl.textContent = 'Đang bật';
      badgeEl.classList.add('skill-active-badge');
    } else {
      badgeEl.textContent = 'Tắt';
      badgeEl.classList.remove('skill-active-badge');
    }
  }

  if (summaryEl) {
    if (currentSkill && currentSkill.summary) {
      summaryEl.textContent = currentSkill.summary;
      summaryEl.classList.remove('hidden');
    } else {
      summaryEl.textContent = '';
      summaryEl.classList.add('hidden');
    }
  }
}

function renderSkillAutoPromptButtons(progress = null) {
  const btnGen = document.getElementById('btnGeneratePromptsBySkill');
  const btnStop = document.getElementById('btnStopSkillPrompts');
  if (!btnGen || !btnStop) return;

  if (state.skillPromptRunning) {
    btnGen.disabled = true;
    const comp = progress?.completed ?? 0;
    const tot = progress?.total ?? 0;
    btnGen.textContent = tot > 0 ? `⏳ Đang viết Prompt (${comp}/${tot})...` : '⏳ AI đang viết Prompt...';
    btnStop.classList.remove('hidden');
  } else {
    btnGen.disabled = false;
    btnGen.textContent = '✨ Viết Prompt Theo Skill';
    btnStop.classList.add('hidden');
  }
}

function resetSkillEditorForm() {
  const idEl = document.getElementById('editSkillId');
  const nameEl = document.getElementById('inputSkillName');
  const sumEl = document.getElementById('inputSkillSummary');
  const instEl = document.getElementById('inputSkillInstructions');
  const headEl = document.getElementById('skillFormHeading');
  const clearBtn = document.getElementById('btnClearSkillForm');

  if (idEl) idEl.value = '';
  if (nameEl) nameEl.value = '';
  if (sumEl) sumEl.value = '';
  if (instEl) instEl.value = '';
  if (headEl) headEl.textContent = 'Tạo / Dán Nội Dung Skill Mới';
  if (clearBtn) clearBtn.classList.add('hidden');
}

function renderSkillsModalList() {
  const container = document.getElementById('skillsModalList');
  const countLabel = document.getElementById('skillTotalCountLabel');
  if (!container) return;

  const skills = state.skills || [];
  if (countLabel) countLabel.textContent = String(skills.length);

  const activeSkillId = state.activeAccount?.settings?.activeSkillId || '';
  container.innerHTML = '';

  if (skills.length === 0) {
    container.innerHTML = `<div class="acc-sub-note">Thư viện đang trống. Hãy nhập file SKILL.md hoặc bấm khôi phục Skill mẫu.</div>`;
    return;
  }

  skills.forEach((sk) => {
    const isApplied = sk.id === activeSkillId;
    const item = document.createElement('div');
    item.className = `account-list-item ${isApplied ? 'active-acc' : ''}`;

    const typeBadge = sk.isBuiltIn
      ? `<span class="banner-badge badge-proxy">Mẫu cài sẵn</span>`
      : `<span class="banner-badge badge-amber">Tự nhập</span>`;

    const activeBadge = isApplied
      ? `<span class="banner-badge badge-green">✓ Đang áp dụng</span>`
      : '';

    item.innerHTML = `
      <div class="acc-item-top">
        <div class="acc-item-head-left">
          <span class="acc-item-name">${escapeHtml(sk.name)}</span>
          ${typeBadge}
          ${activeBadge}
        </div>
        <div class="acc-item-actions">
          <button type="button" class="btn-mini" data-skill-action="apply" data-id="${escapeAttr(sk.id)}">
            ${isApplied ? 'Bỏ chọn' : 'Áp dụng'}
          </button>
          <button type="button" class="btn-mini" data-skill-action="edit" data-id="${escapeAttr(sk.id)}">
            ✎ Sửa / Xem
          </button>
          <button type="button" class="btn-mini" data-skill-action="export" data-id="${escapeAttr(sk.id)}">
            ⬇ Xuất .md
          </button>
          <button type="button" class="btn-mini btn-danger-soft" data-skill-action="delete" data-id="${escapeAttr(sk.id)}" data-name="${escapeAttr(sk.name)}">
            🗑 Xóa
          </button>
        </div>
      </div>
      <div class="skill-item-summary">${escapeHtml(sk.summary || '')}</div>
    `;
    container.appendChild(item);
  });
}

function btnToggleActive(el, active) {
  if (el) el.classList.toggle('active', Boolean(active));
}

function renderBatchMonitor() {
  const stats = state.batchStats;
  const pill = document.getElementById('batchMonitorBar');
  const pillText = document.getElementById('batchMonitorText');
  const btnStop = document.getElementById('btnStopBatch');
  const subLabel = document.getElementById('batchStatusSub');
  const concurrency = Math.max(1, Math.min(20, Number(state.activeAccount?.settings?.concurrency) || 6));

  if (stats && stats.running) {
    pill.classList.remove('hidden');
    btnStop.classList.remove('hidden');
    const errText = stats.totalFailed > 0 ? ` • Lỗi: ${stats.totalFailed}` : '';
    pillText.textContent = `${stats.activeThreads}/${stats.batchSize || concurrency} luồng • Xong ${stats.totalCompleted}/${stats.totalTargetRows}${errText}`;
    subLabel.textContent = `Xong ${stats.totalCompleted}/${stats.totalTargetRows}${errText}`;
  } else {
    pill.classList.add('hidden');
    btnStop.classList.add('hidden');
    subLabel.textContent = `Tự bỏ qua nếu lỗi`;
  }
}

function getRowFilterCategory(status) {
  if (status === 'completed') return 'completed';
  if (status === 'error') return 'error';
  if (['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(status)) {
    return 'running';
  }
  return 'ready';
}

function renderRowCountsAndFilterVisibility() {
  const rows = state.activeAccount?.rows || [];
  let ready = 0;
  let running = 0;
  let completed = 0;
  let error = 0;

  rows.forEach((r) => {
    const cat = getRowFilterCategory(r.status);
    if (cat === 'completed') completed++;
    else if (cat === 'error') error++;
    else if (cat === 'running') running++;
    else ready++;

    const el = document.getElementById(`flow-row-${r.index}`);
    if (el) {
      const shouldShow = state.statusFilter === 'all' || state.statusFilter === cat;
      el.classList.toggle('hidden', !shouldShow);
    }
  });

  const setTxt = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = String(val);
  };
  setTxt('countAll', rows.length);
  setTxt('countReady', ready);
  setTxt('countRunning', running);
  setTxt('countCompleted', completed);
  setTxt('countError', error);
}

function updateCapcutRibbonButtonLabel() {
  const sub = document.getElementById('capcutBtnSub');
  const title = document.getElementById('capcutBtnTitle');
  if (!sub || !title) return;
  const count = state.selectedRows.size;
  if (count > 0) {
    title.textContent = `Cắt & Nối (${count})`;
    sub.textContent = `Nối ${count} hàng đã chọn`;
  } else {
    title.textContent = 'Cắt & Nối';
    sub.textContent = 'Bàn dựng video';
  }
}

function renderFlowRows() {
  const container = document.getElementById('flowRowsContainer');
  if (!container || !state.activeAccount) return;

  const rows = state.activeAccount.rows || [];
  container.innerHTML = '';

  rows.forEach((row) => {
    const rowEl = createRowElement(row);
    container.appendChild(rowEl);
  });

  renderRowCountsAndFilterVisibility();
  updateCapcutRibbonButtonLabel();
}

function getRowStateBadgeInfo(status) {
  switch (status) {
    case 'queued':
      return { cls: 'state-queued', label: 'Đang chờ', rowCls: '' };
    case 'connecting':
    case 'uploading':
    case 'submitting':
    case 'rendering':
    case 'downloading':
      return { cls: 'state-running', label: 'Đang tạo', rowCls: 'row-running' };
    case 'completed':
      return { cls: 'state-completed', label: 'Hoàn tất', rowCls: 'row-completed' };
    case 'error':
      return { cls: 'state-error', label: 'Lỗi', rowCls: 'row-error' };
    default:
      return { cls: 'state-idle', label: 'Sẵn sàng', rowCls: '' };
  }
}

function extractQuotedListClient(rawText) {
  if (!rawText) return [];
  const norm = String(rawText)
    .replace(/[“”«»„‟]/g, '"')
    .trim();
  if (!norm) return [];
  const list = [];
  const re = /"([^"]+)"/g;
  let m;
  while ((m = re.exec(norm)) !== null) {
    const clean = m[1].replace(/\s+/g, ' ').trim();
    if (clean) list.push(clean);
  }
  return list;
}

function countSpeechWordsClient(text) {
  const s = String(text || '').trim();
  if (!s) return 0;
  return s.split(/\s+/).filter(Boolean).length;
}

function splitLongSpeechChunksClient(rawText, maxChunks = 1, targetWords = 22) {
  const clean = String(rawText || '')
    .replace(/[“”«»„‟"]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) return [];
  if (maxChunks <= 1) return [clean];

  const atomic = clean
    .split(/(?<=[.!?;|])\s+/)
    .map((u) => u.replace(/^[|]+|[|]+$/g, '').trim())
    .filter(Boolean);

  const refined = [];
  for (const unit of atomic) {
    if (countSpeechWordsClient(unit) > Math.round(targetWords * 1.35) && unit.includes(',')) {
      refined.push(
        ...unit
          .split(/(?<=,)\s+/)
          .map((sp) => sp.trim())
          .filter(Boolean)
      );
    } else {
      refined.push(unit);
    }
  }

  if (refined.length === 1 && countSpeechWordsClient(refined[0]) > Math.round(targetWords * 1.3)) {
    const words = refined[0].split(/\s+/).filter(Boolean);
    const needed = Math.min(maxChunks, Math.max(2, Math.ceil(words.length / targetWords)));
    const per = Math.ceil(words.length / needed);
    const out = [];
    for (let i = 0; i < words.length; i += per) {
      out.push(words.slice(i, i + per).join(' '));
    }
    return out;
  }

  const totalWords = countSpeechWordsClient(clean);
  const desired = Math.min(maxChunks, Math.max(1, Math.min(refined.length, Math.ceil(totalWords / targetWords))));
  if (desired <= 1) return [clean];

  const ideal = totalWords / desired;
  const result = [];
  let buf = [];
  let curW = 0;

  for (let i = 0; i < refined.length; i++) {
    const u = refined[i];
    const w = countSpeechWordsClient(u);
    const remUnits = refined.length - i;
    const remSlots = desired - result.length;
    if (buf.length > 0 && remSlots > 1 && (curW + w > ideal * 1.28 || remUnits < remSlots)) {
      result.push(buf.join(' ').trim());
      buf = [u];
      curW = w;
    } else {
      buf.push(u);
      curW += w;
    }
  }
  if (buf.length > 0) result.push(buf.join(' ').trim());
  return result;
}

function formatDialogueIntoQuotedParts(rawText, totalParts = 1) {
  const parts = Math.max(1, Number(totalParts) || 1);
  const trimmed = String(rawText || '').trim();
  if (!trimmed) {
    if (parts <= 1) {
      return '"Nhập câu thoại (~20 chữ) tại đây..."';
    }
    const tpl = [];
    for (let i = 1; i <= parts; i++) {
      const sSec = (i - 1) * 10;
      const eSec = i * 10;
      tpl.push(`"Lời thoại phần ${i} (${sSec}s-${eSec}s)..."`);
    }
    return tpl.join('\n');
  }

  const existingQuotes = extractQuotedListClient(trimmed);
  let chunks = [];
  if (existingQuotes.length >= 2) {
    if (existingQuotes.length <= parts) {
      chunks = existingQuotes;
    } else {
      for (let p = 0; p < parts; p++) {
        const s = Math.floor((p * existingQuotes.length) / parts);
        const e = Math.floor(((p + 1) * existingQuotes.length) / parts);
        chunks.push(existingQuotes.slice(s, e).join(' '));
      }
    }
  } else {
    const plainSource = existingQuotes.length === 1 ? existingQuotes[0] : trimmed;
    const lines = plainSource
      .split(/\r?\n|\s*\|\|\s*|\s+\|\s+/)
      .map((l) => l.replace(/^(?:phần|part|đoạn|nhịp|p)\s*\d+\s*[:.-]\s*/i, '').trim())
      .filter(Boolean);
    if (lines.length >= 2 && lines.length <= parts) {
      chunks = lines;
    } else {
      chunks = splitLongSpeechChunksClient(plainSource, parts, 22);
    }
  }

  return chunks.map((c) => `"${c.replace(/"/g, '').trim()}"`).join('\n');
}

function getDialogueLiveBadgeMeta(rawDialogue, durationSec = 10, enableDialogue = false) {
  const clean = String(rawDialogue || '').trim();
  const dur = Math.max(5, Number(durationSec) || 10);
  const totalParts = dur > 10 ? Math.ceil(dur / 10) : 1;

  if (!clean) {
    return {
      cls: '',
      text: totalParts > 1 ? `Trống • Hỗ trợ ${totalParts} câu "..."` : 'Trống (Không thoại)',
      mutedWarn: false
    };
  }

  if (!enableDialogue) {
    return {
      cls: 'pill-warn',
      text: '🔇 Đang tắt công tắc Lời thoại ở Sidebar',
      mutedWarn: true
    };
  }

  const qList = extractQuotedListClient(clean);
  if (totalParts <= 1) {
    const spoken = qList.length > 0 ? qList.join(' ') : clean;
    const wCount = countSpeechWordsClient(spoken);
    const maxRec = Math.max(10, Math.round(dur * 2.5));
    if (wCount <= maxRec) {
      return { cls: 'pill-ok', text: `✓ ${wCount} chữ • Khớp ${dur}s`, mutedWarn: false };
    }
    return {
      cls: 'pill-warn',
      text: `⚠️ ${wCount} chữ (Nên ≤${maxRec} chữ/${dur}s)`,
      mutedWarn: false
    };
  }

  if (qList.length === totalParts) {
    return {
      cls: 'pill-ok',
      text: `✓ Đã cắt ${qList.length}/${totalParts} câu "..." (10s/phần)`,
      mutedWarn: false
    };
  }
  if (qList.length === 1 && countSpeechWordsClient(qList[0]) > 28) {
    const autoCount = splitLongSpeechChunksClient(qList[0], totalParts, 22).length;
    return {
      cls: 'pill-info',
      text: `⚡ Tự chia ${autoCount}/${totalParts} nhịp 10s`,
      mutedWarn: false
    };
  }
  if (qList.length > 0 && qList.length < totalParts) {
    return {
      cls: 'pill-info',
      text: `🎙️ ${qList.length}/${totalParts} câu "..." (${totalParts - qList.length} phần cuối im lặng)`,
      mutedWarn: false
    };
  }
  if (qList.length > totalParts) {
    return {
      cls: 'pill-info',
      text: `🎙️ ${qList.length} câu "..." ➔ Gộp vào ${totalParts} phần 10s`,
      mutedWarn: false
    };
  }

  const autoSegs = splitLongSpeechChunksClient(clean, totalParts, 22);
  return {
    cls: 'pill-info',
    text: `⚡ Tự chia ${autoSegs.length}/${totalParts} nhịp 10s`,
    mutedWarn: false
  };
}

function refreshRowDialogueBadge(rowIndex, rawDialogueVal) {
  const pillEl = document.getElementById(`row-dialogue-pill-${rowIndex}`);
  const wrapEl = document.getElementById(`row-dialogue-wrap-${rowIndex}`);
  const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
  if (!pillEl || !state.activeAccount) return;
  const durSec = parseDurationToSeconds(state.activeAccount.settings?.duration || '10s');
  const totalParts = durSec > 10 ? Math.ceil(durSec / 10) : 1;
  const enableDlg = Boolean(state.activeAccount.settings?.enableDialogue);
  const meta = getDialogueLiveBadgeMeta(rawDialogueVal, durSec, enableDlg);
  pillEl.className = `dialogue-live-pill ${meta.cls}`.trim();
  pillEl.textContent = meta.text;
  pillEl.title = meta.text;
  if (wrapEl) {
    wrapEl.classList.toggle('dialogue-muted-warning', Boolean(meta.mutedWarn));
  }
  if (dlgEl) {
    dlgEl.placeholder =
      totalParts > 1
        ? `Nhập lời thoại cho Hàng #${rowIndex} (${totalParts} phần x 10s): đặt mỗi câu trong "..." để tự gán riêng từng nhịp 10s. VD: "Câu phần 1..." "Câu phần 2..."`
        : `Nhập lời thoại nhân vật nói cho Hàng #${rowIndex} (để trống nếu không nói)...`;
  }
}

function refreshAllRowDialogueBadges() {
  const rows = state.activeAccount?.rows || [];
  rows.forEach((r) => {
    const el = document.getElementById(`row-dialogue-${r.index}`);
    const val = el ? el.value : r.dialogue || '';
    refreshRowDialogueBadge(r.index, val);
  });
}

function resolveClientRowMultiRefMode(row) {
  const explicit = row?.multiRefMode;
  if (explicit === 'multi_angle') return 'multi_angle';
  if (explicit === 'multi_outfit') return 'multi_outfit';

  const activeSkillId = state.activeAccount?.settings?.activeSkillId || '';
  if (activeSkillId) {
    const sk = (state.skills || []).find((s) => s.id === activeSkillId);
    if (sk) {
      const sid = String(sk.id || '').toLowerCase();
      const shead = `${sk.name || ''} ${sk.summary || ''}`;
      if (
        sid.includes('fan_wipe') ||
        sid.includes('glowup') ||
        /biến\s*hình|thay\s*(?:nhiều\s*)?(?:bộ\s*)?đồ|thay\s*\d+\s*[–-]\s*\d+\s*bộ|multi[\s-]*outfit|fan[\s-]*wipe|glow[\s-]*up/i.test(
          shead
        )
      ) {
        return 'multi_outfit';
      }
    }
  }

  const rowPrompt = String(row?.prompt || '');
  if (
    /biến\s*hình|thay\s*(?:nhiều\s*)?(?:bộ\s*)?đồ|thay\s*trang\s*phục|đổi\s*trang\s*phục|che\s*quạt\s*(?:đổi|thay|biến)/i.test(
      rowPrompt
    )
  ) {
    return 'multi_outfit';
  }

  return 'multi_angle';
}

function getClientActiveCharactersForRow(row) {
  const chars = Array.isArray(state.activeAccount?.characters) ? state.activeAccount.characters : [];
  if (chars.length === 0 || !row) return [];
  const explicitSet = new Set(Array.isArray(row.sceneCharacterIds) ? row.sceneCharacterIds : []);
  const combinedTxt = `${row.prompt || ''}\n${row.dialogue || ''}`.toLowerCase();

  return chars.filter((ch) => {
    if (explicitSet.has(ch.id)) return true;
    const tagLower = String(ch.tag || '').toLowerCase();
    if (tagLower && combinedTxt.includes(tagLower)) return true;
    const nameLower = String(ch.name || '').trim().toLowerCase();
    if (nameLower.length >= 2 && combinedTxt.includes(nameLower)) return true;
    return false;
  });
}

function createRowElement(row) {
  const badgeInfo = getRowStateBadgeInfo(row.status);
  const isBusy = ['connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(row.status);
  const isSelected = state.selectedRows.has(row.index);

  const cat = getRowFilterCategory(row.status);
  const hiddenCls = state.statusFilter !== 'all' && state.statusFilter !== cat ? 'hidden' : '';
  const selectedCls = isSelected ? 'row-selected-merge' : '';

  const rowEl = document.createElement('div');
  rowEl.className = `flow-row ${badgeInfo.rowCls} ${selectedCls} ${hiddenCls}`.trim();
  rowEl.id = `flow-row-${row.index}`;
  rowEl.dataset.index = row.index;

  const curDurSecForRow = parseDurationToSeconds(state.activeAccount?.settings?.duration || '10s');
  const totalPartsForRow = curDurSecForRow > 10 ? Math.ceil(curDurSecForRow / 10) : 1;
  const dlgMeta = getDialogueLiveBadgeMeta(
    row.dialogue || '',
    curDurSecForRow,
    Boolean(state.activeAccount?.settings?.enableDialogue)
  );
  const dialoguePlaceholder =
    totalPartsForRow > 1
      ? `Nhập lời thoại cho Hàng #${row.index} (${totalPartsForRow} phần x 10s): đặt mỗi câu trong "..." để tự gán riêng từng nhịp 10s. VD: "Câu phần 1..." "Câu phần 2..."`
      : `Nhập lời thoại nhân vật nói cho Hàng #${row.index} (để trống nếu không nói)...`;

  const validImgs = Array.isArray(row.referenceImages)
    ? row.referenceImages.filter((im) => im && im.publicUrl)
    : [];
  let refsHtml = '';

  if (validImgs.length === 0) {
    refsHtml = `
      <div class="ref-slot" data-action="pick-ref" data-row="${row.index}" data-slot="0" title="Click hoặc kéo thả 1–5 ảnh góc nhìn sản phẩm / nhân vật vào Hàng #${row.index}">
        <div class="ref-slot-empty">
          <span class="ref-slot-plus">+</span>
          <span>Thêm 1–5 ảnh</span>
        </div>
      </div>
    `;
  } else if (validImgs.length === 1) {
    const img = validImgs[0];
    refsHtml = `
      <div class="ref-single-split">
        <div class="ref-slot has-image" data-action="replace-ref" data-row="${row.index}" data-slot="0" title="Ảnh gốc #1 (${escapeAttr(img.fileName || '')}) • Click để đổi ảnh này">
          <img src="${escapeAttr(img.publicUrl)}" class="ref-thumb" alt="Hàng #${row.index}" />
          <span class="ref-filename-tag">${escapeHtml(img.fileName || `Ảnh #${row.index}`)}</span>
          <button type="button" class="ref-remove-btn" data-action="remove-ref" data-row="${row.index}" data-slot="0" title="Xóa ảnh">×</button>
        </div>
        <button type="button" class="ref-add-more-tile" data-action="append-row-refs" data-row="${row.index}" title="Thêm ảnh góc nhìn thứ 2..5 vào Hàng #${row.index} để AI hiểu rõ nhiều mặt của sản phẩm / nhân vật (tối đa 5 ảnh/hàng)">
          <span class="ref-add-more-plus">+</span>
          <span class="ref-add-more-txt">Thêm<br/>góc 2..5</span>
        </button>
      </div>
    `;
  } else {
    const effectiveMode = resolveClientRowMultiRefMode(row);
    const isOutfitMode = effectiveMode === 'multi_outfit';
    const slotPrefix = isOutfitMode ? 'Bộ' : 'Góc';
    const curDurSec = curDurSecForRow;
    const recSec = validImgs.length * 10;
    const cardsHtml = validImgs
      .map(
        (im, sIdx) => `
          <div class="ref-mini-card" data-action="replace-ref" data-row="${row.index}" data-slot="${sIdx}" title="${slotPrefix} #${sIdx + 1}: ${escapeAttr(im.fileName || '')} • Click để đổi ảnh này">
            <img src="${escapeAttr(im.publicUrl)}" alt="${slotPrefix} ${sIdx + 1}" />
            <span class="ref-slot-num-badge ${isOutfitMode ? '' : 'is-angle'}">${slotPrefix} ${sIdx + 1}</span>
            <button type="button" class="ref-mini-remove-btn" data-action="remove-ref" data-row="${row.index}" data-slot="${sIdx}" title="Xóa ${slotPrefix} #${sIdx + 1}">×</button>
          </div>
        `
      )
      .join('');
    const addTileHtml =
      validImgs.length < 5
        ? `
          <button type="button" class="ref-mini-add-btn ${isOutfitMode ? '' : 'is-angle'}" data-action="append-row-refs" data-row="${row.index}" title="Thêm ảnh ${slotPrefix} #${validImgs.length + 1} (tối đa 5 ảnh/hàng)">
            <span style="font-size:14px;line-height:1;">+</span>
            <span>${slotPrefix} ${validImgs.length + 1}</span>
          </button>
        `
        : '';
    const durSuggestHtml =
      isOutfitMode && curDurSec < validImgs.length * 8
        ? `<button type="button" class="ref-dur-suggest-btn" data-action="apply-recommended-dur" data-sec="${recSec}" title="Gợi ý đặt ${recSec}s (${validImgs.length} phần x 10s) để mỗi bộ trang phục có trọn ~10s biến hình mượt nhất!">⚡ ${recSec}s</button>`
        : '';

    const modeSwitchBtnHtml = isOutfitMode
      ? `<button type="button" class="ref-mode-switch-btn is-outfit" data-action="toggle-multi-ref-mode" data-row="${row.index}" title="Đang bật Biến hình thay đồ. Bấm để đổi sang Đa góc nhìn (AI hiểu nhiều góc của cùng 1 sản phẩm/nhân vật, không biến hình)">⇄ Đa góc</button>`
      : `<button type="button" class="ref-mode-switch-btn" data-action="toggle-multi-ref-mode" data-row="${row.index}" title="Đang bật Đa góc nhìn (AI hiểu nhiều mặt sản phẩm/nhân vật, KHÔNG biến hình). Bấm nếu muốn chuyển hàng này sang Biến hình thay đồ">⇄ Biến hình</button>`;

    refsHtml = `
      <div class="ref-multi-wrap">
        <div class="ref-multi-grid">
          ${cardsHtml}
          ${addTileHtml}
        </div>
        <div class="ref-multi-hint-bar ${isOutfitMode ? '' : 'is-multi-angle'}">
          <span>${isOutfitMode ? `🪭 ${validImgs.length} ảnh biến hình` : `📐 ${validImgs.length} góc SP/NV`}</span>
          <div class="ref-multi-hint-actions">
            ${durSuggestHtml}
            ${modeSwitchBtnHtml}
          </div>
        </div>
      </div>
    `;
  }

  const rowSample = row.sampleVideo && row.sampleVideo.publicUrl ? row.sampleVideo : null;
  const globalSample =
    state.activeAccount?.settings?.sampleVideo?.publicUrl ? state.activeAccount.settings.sampleVideo : null;

  let rowSampleHtml = '';
  if (rowSample) {
    const durSuffix =
      rowSample.durationSec && Number(rowSample.durationSec) > 0
        ? ` (${Number(rowSample.durationSec).toFixed(1)}s)`
        : '';
    rowSampleHtml = `
      <div class="row-sample-bar has-row-sample">
        <button type="button" class="row-sample-main-btn" data-action="preview-row-sample" data-row="${row.index}" title="Xem Video mẫu riêng của Hàng #${row.index}: ${escapeAttr(rowSample.fileName || '')}">
          <span>🎬 ${escapeHtml(rowSample.fileName || 'Mẫu riêng')}${durSuffix}</span>
        </button>
        <button type="button" class="row-sample-mini-btn" data-action="pick-row-sample" data-row="${row.index}" title="Đổi Video mẫu riêng cho Hàng #${row.index}">🔄</button>
        <button type="button" class="row-sample-mini-btn sample-mini-del" data-action="remove-row-sample" data-row="${row.index}" title="Gỡ Video mẫu riêng của Hàng #${row.index}">×</button>
      </div>
    `;
  } else if (globalSample) {
    rowSampleHtml = `
      <div class="row-sample-bar using-global-sample">
        <button type="button" class="row-sample-main-btn" data-action="pick-row-sample" data-row="${row.index}" title="Đang dùng Video mẫu chung (${escapeAttr(globalSample.fileName || '')}) • Bấm để gắn Video mẫu riêng cho Hàng #${row.index}">
          <span>🎞 Theo mẫu chung • Đổi riêng</span>
        </button>
      </div>
    `;
  } else {
    rowSampleHtml = `
      <div class="row-sample-bar empty-sample">
        <button type="button" class="row-sample-main-btn" data-action="pick-row-sample" data-row="${row.index}" title="Chọn hoặc kéo thả Video mẫu riêng cho Hàng #${row.index}">
          <span>🎞 + Video mẫu riêng</span>
        </button>
      </div>
    `;
  }

  let videoBoxHtml = '';
  if (row.videoUrl) {
    videoBoxHtml = `<video class="row-video-player" src="${escapeAttr(row.videoUrl)}" controls preload="metadata"></video>`;
  } else if (isBusy) {
    videoBoxHtml = `
      <div class="video-placeholder">
        <div class="cdp-spinner"></div>
        <span class="placeholder-active">Đang tạo video...</span>
      </div>
    `;
  } else if (row.status === 'error') {
    videoBoxHtml = `
      <div class="video-placeholder">
        <span class="placeholder-err-title">⚠️ Đã bỏ qua</span>
        <span class="placeholder-err-desc">${escapeHtml(row.error || row.statusMessage || 'Lỗi tạo video')}</span>
      </div>
    `;
  } else {
    videoBoxHtml = `
      <div class="video-placeholder">
        <span>Chưa có video</span>
      </div>
    `;
  }

  const filmMode = isFilmmakingMode();
  const allFilmChars = filmMode && Array.isArray(state.activeAccount?.characters) ? state.activeAccount.characters : [];
  const activeRowChars = filmMode ? getClientActiveCharactersForRow(row) : [];
  const activeRowCharIdSet = new Set(activeRowChars.map((c) => c.id));

  let castAutoStripHtml = '';
  if (filmMode && activeRowChars.length > 0) {
    const castImgs = [];
    activeRowChars.forEach((ch) => {
      if (ch.roleType === 'narrator') return;
      const im = Array.isArray(ch.referenceImages) ? ch.referenceImages.find((x) => x && x.publicUrl) : null;
      if (im && castImgs.length < 5) {
        castImgs.push({ url: im.publicUrl, tag: ch.tag, name: ch.name });
      }
    });
    if (castImgs.length > 0) {
      castAutoStripHtml = `
        <div class="row-cast-auto-strip" title="Công cụ tự động đính kèm ảnh chân dung chuẩn của ${castImgs.map((x) => x.name).join(', ')} vào cảnh này">
          <div class="row-cast-auto-thumbs">
            ${castImgs.map((ci) => `<img src="${escapeAttr(ci.url)}" alt="${escapeAttr(ci.tag)}" />`).join('')}
          </div>
          <span>🎭 +${castImgs.length} ảnh Diễn viên</span>
        </div>
      `;
    }
  }

  let filmPromptTopHtml = '';
  if (filmMode) {
    const globalSequential = state.activeAccount?.settings?.filmConfig?.continuityMode === 'sequential_chain';
    const isChained = row.index > 1 && (Boolean(row.continueFromPrevScene) || globalSequential);
    const chainToggleHtml =
      row.index > 1
        ? `
          <label class="row-chain-prev-label ${isChained ? 'is-chained' : ''}" title="Lấy khung hình cuối cùng của Cảnh #${row.index - 1} làm điểm xuất phát mượt cho Cảnh #${row.index}">
            <input type="checkbox" class="row-chain-prev-chk" data-row="${row.index}" ${isChained ? 'checked' : ''} ${globalSequential ? 'disabled' : ''} />
            <span>🔗 Nối tiếp Cảnh #${row.index - 1}</span>
          </label>
        `
        : '';

    const castChipsHtml = allFilmChars
      .map((ch) => {
        const isOn = activeRowCharIdSet.has(ch.id);
        const firstImg = Array.isArray(ch.referenceImages) ? ch.referenceImages.find((x) => x && x.publicUrl) : null;
        const avatarHtml = firstImg
          ? `<img src="${escapeAttr(firstImg.publicUrl)}" class="row-cast-chip-avatar" alt="" />`
          : `<span>${ch.roleType === 'narrator' ? '🎙️' : '🧑'}</span>`;
        return `
          <button
            type="button"
            class="row-cast-chip ${isOn ? 'active' : ''}"
            data-action="toggle-row-cast-char"
            data-row="${row.index}"
            data-char-id="${escapeAttr(ch.id)}"
            data-char-tag="${escapeAttr(ch.tag)}"
            title="Bấm để bật/tắt ${escapeAttr(ch.name)} (${escapeAttr(ch.tag)}) xuất hiện trong Cảnh #${row.index} • Giữ phím Shift + Bấm để chèn [${escapeAttr(ch.tag)}]: vào ô Lời thoại"
          >
            ${avatarHtml}
            <span>${escapeHtml(ch.name)}</span>
          </button>
        `;
      })
      .join('');

    filmPromptTopHtml = `
      <div class="row-film-header-bar">
        <div class="row-scene-title-wrap">
          <span class="row-scene-badge">🎬 Cảnh #${String(row.index).padStart(2, '0')}</span>
          <input
            type="text"
            class="row-scene-title-input"
            id="row-scene-title-${row.index}"
            data-row="${row.index}"
            value="${escapeAttr(row.sceneTitle || `Cảnh ${row.index}`)}"
            placeholder="Tiêu đề phân cảnh..."
          />
        </div>
        ${chainToggleHtml}
      </div>
      <div class="row-cast-selector-bar">
        <span class="row-cast-bar-label">🎭 Diễn viên:</span>
        ${castChipsHtml}
        <button type="button" class="row-cast-chip row-cast-add-mini" data-action="open-film-cast-from-row" data-row="${row.index}" title="Mở Hồ sơ Diễn viên để thêm nhân vật mới hoặc tải ảnh mặt nhân vật">
          + Quản lý diễn viên
        </button>
      </div>
    `;
  }

  const promptBoxTitle = filmMode ? '🎥 Góc máy, Bối cảnh & Diễn xuất cảnh này' : '🎬 Chuyển động &amp; Bối cảnh';
  const promptBoxPlaceholder = filmMode
    ? `Mô tả hành động & bối cảnh cho Cảnh #${row.index} (VD: Toàn cảnh bến sông sương mù, @TranHungDao đứng mũi thuyền chỉ kiếm về phía trước)...`
    : `Nhập mô tả cử chỉ, hành động, góc máy cho Hàng #${row.index}...`;
  const dialogueBoxTitle = filmMode
    ? '🎙️ Thoại Phân Vai / Dẫn Chuyện ([Dẫn chuyện]: ... / [@Tag]: ...)'
    : '🎙️ Lời thoại nhân vật';
  const effectiveDlgPlaceholder = filmMode
    ? `VD:\n[Dẫn chuyện]: Đêm xuống trên dòng sông lịch sử...\n[@NhanVat1]: Chúng ta quyết giữ vững thành trì!`
    : dialoguePlaceholder;

  rowEl.innerHTML = `
    <div class="row-col-index">
      <label class="row-idx-top" title="Chọn ${filmMode ? 'Cảnh' : 'Hàng'} #${row.index} để nối video">
        <input type="checkbox" class="row-select-chk" data-row="${row.index}" ${isSelected ? 'checked' : ''} />
        <span class="row-num">#${String(row.index).padStart(2, '0')}</span>
      </label>
      <span class="row-state-badge ${badgeInfo.cls}" id="row-badge-${row.index}">${badgeInfo.label}</span>
    </div>

    <div class="row-col-refs" id="row-refs-${row.index}">
      ${refsHtml}
      ${castAutoStripHtml}
      ${rowSampleHtml}
    </div>

    <div class="row-col-prompt">
      ${filmPromptTopHtml}
      <div class="prompt-dialogue-split">
        <div class="motion-box-wrap">
          <div class="subbox-mini-header">
            <span class="subbox-mini-title">${promptBoxTitle}</span>
          </div>
          <textarea
            class="prompt-textarea"
            id="row-prompt-${row.index}"
            data-row="${row.index}"
            placeholder="${escapeAttr(promptBoxPlaceholder)}"
          >${escapeHtml(row.prompt || '')}</textarea>
        </div>

        <div class="dialogue-box-wrap ${dlgMeta.mutedWarn ? 'dialogue-muted-warning' : ''}" id="row-dialogue-wrap-${row.index}">
          <div class="subbox-mini-header">
            <span class="subbox-mini-title">${dialogueBoxTitle}</span>
            <div class="dialogue-header-right">
              <span class="dialogue-live-pill ${dlgMeta.cls}" id="row-dialogue-pill-${row.index}" title="${escapeAttr(dlgMeta.text)}">${escapeHtml(dlgMeta.text)}</span>
              <button
                type="button"
                class="btn-dialogue-split-helper"
                data-action="auto-quote-dialogue"
                data-row="${row.index}"
                title="Tự động chia đoạn văn bản dài thành từng câu trong ngoặc kép &quot;...&quot; (~20-22 chữ/câu) khớp với từng phân đoạn 10s"
              >✂️ Tự chia &quot;...&quot;</button>
            </div>
          </div>
          <textarea
            class="dialogue-textarea"
            id="row-dialogue-${row.index}"
            data-row="${row.index}"
            placeholder="${escapeAttr(effectiveDlgPlaceholder)}"
          >${escapeHtml(row.dialogue || '')}</textarea>
        </div>
      </div>

      <div class="prompt-footer-bar">
        <span class="prompt-live-status" id="row-status-msg-${row.index}" title="${escapeAttr(row.statusMessage || '')}">
          ${escapeHtml(row.statusMessage || 'Sẵn sàng')}
        </span>
      </div>
    </div>

    <div class="row-col-video" id="row-video-box-${row.index}">
      ${videoBoxHtml}
    </div>

    <div class="row-col-actions">
      <button type="button" class="row-btn btn-run-single" data-action="run-row" data-row="${row.index}" ${isBusy ? 'disabled' : ''}>
        ▶ Chạy
      </button>
      <button type="button" class="row-btn btn-edit-capcut" data-action="edit-capcut-row" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        ✂️ Sửa
      </button>
      <button type="button" class="row-btn btn-download" data-action="download-video" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        ⬇ Tải
      </button>
      <button type="button" class="row-btn btn-preview" data-action="preview-video" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        👁 Xem
      </button>
      <button type="button" class="row-btn btn-regen" data-action="regen-row" data-row="${row.index}" ${isBusy ? 'disabled' : ''}>
        ↻ Lại
      </button>
    </div>
  `;

  const sceneTitleInput = rowEl.querySelector(`#row-scene-title-${row.index}`);
  if (sceneTitleInput) {
    sceneTitleInput.addEventListener('input', (e) => {
      const val = e.target.value;
      row.sceneTitle = val;
      if (sceneTitleSaveTimers.has(row.index)) {
        clearTimeout(sceneTitleSaveTimers.get(row.index));
      }
      sceneTitleSaveTimers.set(
        row.index,
        setTimeout(() => {
          saveRowFields(row.index, { sceneTitle: val });
        }, 400)
      );
    });
  }

  const chainPrevChk = rowEl.querySelector('.row-chain-prev-chk');
  if (chainPrevChk) {
    chainPrevChk.addEventListener('change', async (e) => {
      const nextVal = Boolean(e.target.checked);
      row.continueFromPrevScene = nextVal;
      chainPrevChk.closest('.row-chain-prev-label')?.classList.toggle('is-chained', nextVal);
      await saveRowFields(row.index, { continueFromPrevScene: nextVal });
    });
  }

  const chk = rowEl.querySelector('.row-select-chk');
  if (chk) {
    chk.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.selectedRows.add(row.index);
        rowEl.classList.add('row-selected-merge');
      } else {
        state.selectedRows.delete(row.index);
        rowEl.classList.remove('row-selected-merge');
      }
      updateCapcutRibbonButtonLabel();
    });
  }

  const textarea = rowEl.querySelector(`#row-prompt-${row.index}`);
  textarea.addEventListener('input', (e) => {
    const val = e.target.value;
    row.prompt = val;
    if (promptSaveTimers.has(row.index)) {
      clearTimeout(promptSaveTimers.get(row.index));
    }
    promptSaveTimers.set(
      row.index,
      setTimeout(() => {
        saveRowFields(row.index, { prompt: val });
      }, 350)
    );
  });

  const dialogueTextarea = rowEl.querySelector(`#row-dialogue-${row.index}`);
  if (dialogueTextarea) {
    dialogueTextarea.addEventListener('input', (e) => {
      const val = e.target.value;
      row.dialogue = val;
      refreshRowDialogueBadge(row.index, val);
      if (dialogueSaveTimers.has(row.index)) {
        clearTimeout(dialogueSaveTimers.get(row.index));
      }
      dialogueSaveTimers.set(
        row.index,
        setTimeout(() => {
          saveRowFields(row.index, { dialogue: val });
        }, 350)
      );
    });
  }

  const refsColEl = rowEl.querySelector(`#row-refs-${row.index}`);
  const slotEl = rowEl.querySelector('.ref-slot');
  if (refsColEl) {
    refsColEl.addEventListener('dragover', (e) => {
      e.preventDefault();
      slotEl?.classList.add('drag-over');
      refsColEl.classList.add('drag-over-video');
    });
    refsColEl.addEventListener('dragleave', (e) => {
      if (!refsColEl.contains(e.relatedTarget)) {
        slotEl?.classList.remove('drag-over');
        refsColEl.classList.remove('drag-over-video');
      }
    });
    refsColEl.addEventListener('drop', async (e) => {
      e.preventDefault();
      slotEl?.classList.remove('drag-over');
      refsColEl.classList.remove('drag-over-video');
      const allDropped = Array.from(e.dataTransfer?.files || []);
      const imgFiles = allDropped.filter((f) => isImageFileObj(f));
      const vidFiles = allDropped.filter((f) => isVideoFileObj(f));
      if (imgFiles.length > 0) {
        await uploadFilesToRowSlots(row.index, 0, imgFiles);
      }
      if (vidFiles.length > 0) {
        await uploadRowSampleVideo(row.index, vidFiles[0]);
      }
    });
  }

  return rowEl;
}

function updateSingleRowDom(row) {
  const existingEl = document.getElementById(`flow-row-${row.index}`);
  if (!existingEl) return;

  const activeId = document.activeElement?.id;
  const isFocusedEditor =
    activeId === `row-prompt-${row.index}` ||
    activeId === `row-dialogue-${row.index}` ||
    activeId === `row-scene-title-${row.index}`;

  if (isFocusedEditor) {
    const badgeInfo = getRowStateBadgeInfo(row.status);
    const cat = getRowFilterCategory(row.status);
    const hiddenCls = state.statusFilter !== 'all' && state.statusFilter !== cat ? 'hidden' : '';
    const selectedCls = state.selectedRows.has(row.index) ? 'row-selected-merge' : '';
    existingEl.className = `flow-row ${badgeInfo.rowCls} ${selectedCls} ${hiddenCls}`.trim();
    const badgeEl = document.getElementById(`row-badge-${row.index}`);
    if (badgeEl) {
      badgeEl.className = `row-state-badge ${badgeInfo.cls}`;
      badgeEl.textContent = badgeInfo.label;
    }
    const msgEl = document.getElementById(`row-status-msg-${row.index}`);
    if (msgEl) {
      msgEl.textContent = row.statusMessage || '';
    }
    return;
  }

  const newEl = createRowElement(row);
  existingEl.replaceWith(newEl);
}

async function saveRowFields(rowIndex, patch) {
  if (!state.activeAccount || !patch) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}`, {
      method: 'PUT',
      body: JSON.stringify(patch)
    });
    if (res && res.autoEnabledDialogue && res.settings) {
      state.activeAccount.settings = res.settings;
      const chkDlg = document.getElementById('chkEnableDialogue');
      if (chkDlg) chkDlg.checked = Boolean(res.settings.enableDialogue);
      refreshAllRowDialogueBadges();
      showToast('🎙️ Đã tự động bật Lời thoại nhân vật!', 'info');
    }
  } catch (_) {}
}

async function saveRowPrompt(rowIndex, promptText) {
  await saveRowFields(rowIndex, { prompt: promptText });
}

async function uploadBulkImagesOnePerRow(files, startRowIndex = 1) {
  if (!state.activeAccount || !files || files.length === 0) return;

  const sortedFiles = Array.from(files).sort((a, b) =>
    (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' })
  );

  const formData = new FormData();
  formData.append('startRowIndex', String(startRowIndex));
  sortedFiles.forEach((f) => {
    formData.append('images', f);
  });

  try {
    showToast(`Đang tải ${sortedFiles.length} ảnh...`, 'info');
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/bulk-images`, {
      method: 'POST',
      body: formData
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || `Đã chia ${sortedFiles.length} ảnh vào các hàng!`, 'success');
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

function openBulkImagePicker(startRowIndex = 1) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await uploadBulkImagesOnePerRow(files, startRowIndex);
    }
  };
  input.click();
}

async function appendImagesToSingleRow(rowIndex, files, { replaceAll = false } = {}) {
  if (!state.activeAccount || !files || files.length === 0) return;

  const sortedFiles = Array.from(files)
    .slice(0, 5)
    .sort((a, b) => (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' }));

  const formData = new FormData();
  if (replaceAll) {
    formData.append('replaceAll', 'true');
  }
  sortedFiles.forEach((f) => {
    formData.append('images', f);
  });

  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/images`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
    if (res.totalOnRow >= 2) {
      const effectiveMode = resolveClientRowMultiRefMode(res.row);
      if (effectiveMode === 'multi_outfit') {
        const curDurSec = parseDurationToSeconds(state.activeAccount?.settings?.duration || '10s');
        const recSec = res.totalOnRow * 10;
        const durTip = curDurSec < res.totalOnRow * 8 ? ` • Gợi ý bấm "⚡ ${recSec}s" để chia đều ${res.totalOnRow} bộ!` : '';
        showToast(`🪭 Hàng #${rowIndex}: Đã gắn ${res.totalOnRow} ảnh biến hình${durTip}`, 'success');
      } else {
        showToast(
          `📐 Hàng #${rowIndex}: Đã gắn ${res.totalOnRow} ảnh đa góc nhìn (AI tự tổng hợp sản phẩm & nhân vật, không biến hình)!`,
          'success'
        );
      }
    } else if (res.message) {
      showToast(res.message, 'success');
    }
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

async function uploadFilesToRowSlots(rowIndex, startSlot, files) {
  if (!state.activeAccount || !files || files.length === 0) return;

  // Nếu kéo thả > 5 ảnh cùng lúc ➔ Tự động chia 1 ảnh / 1 hàng như Thêm Ảnh Hàng Loạt
  if (files.length > 5) {
    await uploadBulkImagesOnePerRow(files, Number(rowIndex));
    return;
  }

  // Nếu chọn/kéo thả 2–5 ảnh vào 1 hàng ➔ Gắn thành chuỗi bộ đồ biến hình trên chính hàng đó!
  if (files.length >= 2) {
    await appendImagesToSingleRow(rowIndex, files, { replaceAll: false });
    return;
  }

  const targetSlot = Math.max(0, Math.min(4, Number(startSlot) || 0));
  const formData = new FormData();
  formData.append('image', files[0]);
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/image/${targetSlot}`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

function openFilePickerForSlot(rowIndex, slotIndex = 0) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await uploadFilesToRowSlots(rowIndex, Number(slotIndex), files);
    }
  };
  input.click();
}

function openReplaceSingleSlotPicker(rowIndex, slotIndex = 0) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = false;
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadFilesToRowSlots(rowIndex, Number(slotIndex), [file]);
    }
  };
  input.click();
}

function openAppendRowImagesPicker(rowIndex) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await appendImagesToSingleRow(rowIndex, files, { replaceAll: false });
    }
  };
  input.click();
}

async function removeReferenceImage(rowIndex, slotIndex = 0) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/image/${slotIndex}`,
      { method: 'DELETE' }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
  } catch (err) {
    showToast(`Lỗi xóa ảnh: ${err.message}`, 'error');
  }
}

function isImageFileObj(file) {
  if (!file) return false;
  if (file.type && file.type.startsWith('image/')) return true;
  return /\.(png|jpe?g|webp|gif|bmp)$/i.test(file.name || '');
}

function isVideoFileObj(file) {
  if (!file) return false;
  if (file.type && file.type.startsWith('video/')) return true;
  return /\.(mp4|mov|webm|mkv|avi|m4v)$/i.test(file.name || '');
}

function previewSampleVideoModal(videoMeta, titleLabel = '🎬 VIDEO MẪU THAM CHIẾU') {
  if (!videoMeta || !videoMeta.publicUrl) return;
  const modal = document.getElementById('videoPreviewModal');
  const player = document.getElementById('previewModalPlayer');
  const title = document.getElementById('previewModalTitle');
  const meta = document.getElementById('previewModalMeta');
  if (!modal || !player) return;

  if (title) title.textContent = titleLabel;
  player.src = `${videoMeta.publicUrl}?t=${Date.now()}`;
  if (meta) {
    const durTxt =
      videoMeta.durationSec && Number(videoMeta.durationSec) > 0
        ? ` • Thời lượng gốc: ${Number(videoMeta.durationSec).toFixed(1)}s`
        : '';
    const sizeMb =
      videoMeta.size && Number(videoMeta.size) > 0
        ? ` • ${(Number(videoMeta.size) / (1024 * 1024)).toFixed(2)} MB`
        : '';
    meta.textContent = `${videoMeta.fileName || 'Video mẫu'}${durTxt}${sizeMb}`;
  }
  modal.classList.remove('hidden');
}

async function uploadGlobalSampleVideo(file) {
  if (!state.activeAccount || !file) return;
  if (!isVideoFileObj(file)) {
    showToast('Vui lòng chọn tệp video hợp lệ (.mp4, .mov, .webm, .mkv, .avi, .m4v)!', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('video', file);
  try {
    showToast(`Đang tải Video mẫu chung "${file.name}"...`, 'info');
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/sample-video`, {
      method: 'POST',
      body: formData
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || 'Đã gắn Video mẫu chung thành công!', 'success');
  } catch (err) {
    showToast(`Lỗi tải Video mẫu chung: ${err.message}`, 'error');
  }
}

async function removeGlobalSampleVideo() {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/sample-video`, {
      method: 'DELETE'
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || 'Đã gỡ Video mẫu chung.', 'info');
  } catch (err) {
    showToast(`Lỗi gỡ Video mẫu chung: ${err.message}`, 'error');
  }
}

function openGlobalSampleVideoPicker() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'video/mp4,video/quicktime,video/webm,video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v';
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadGlobalSampleVideo(file);
    }
  };
  input.click();
}

async function uploadRowSampleVideo(rowIndex, file) {
  if (!state.activeAccount || !file) return;
  if (!isVideoFileObj(file)) {
    showToast('Vui lòng chọn tệp video hợp lệ (.mp4, .mov, .webm, .mkv, .avi, .m4v)!', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('video', file);
  try {
    showToast(`Đang tải Video mẫu riêng cho Hàng #${rowIndex}...`, 'info');
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/sample-video`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
      updateSampleVideoStatusBadgeOnly();
    }
    showToast(res.message || `Đã gắn Video mẫu riêng cho Hàng #${rowIndex}!`, 'success');
  } catch (err) {
    showToast(`Lỗi tải Video mẫu Hàng #${rowIndex}: ${err.message}`, 'error');
  }
}

async function removeRowSampleVideo(rowIndex) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/sample-video`,
      { method: 'DELETE' }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
      updateSampleVideoStatusBadgeOnly();
    }
    showToast(res.message || `Đã gỡ Video mẫu riêng của Hàng #${rowIndex}.`, 'info');
  } catch (err) {
    showToast(`Lỗi gỡ Video mẫu Hàng #${rowIndex}: ${err.message}`, 'error');
  }
}

function openRowSampleVideoPicker(rowIndex) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'video/mp4,video/quicktime,video/webm,video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v';
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadRowSampleVideo(rowIndex, file);
    }
  };
  input.click();
}

async function saveSidebarSettings(partial) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/settings`, {
      method: 'PUT',
      body: JSON.stringify(partial)
    });
    state.activeAccount = res.account;
    renderSidebarSettings();
    renderFlowRows();
  } catch (err) {
    showToast(`Lỗi lưu cấu hình: ${err.message}`, 'error');
  }
}

async function confirmAndResetAccount(accountId, accountName) {
  const ok = window.confirm(`Xóa phiên đăng nhập cũ của "${accountName}" để đăng nhập tài khoản mới?`);
  if (!ok) return;

  try {
    showToast('Đang xóa phiên cũ...', 'info');
    const res = await apiFetch(`/api/accounts/${accountId}/reset-account`, {
      method: 'POST',
      body: JSON.stringify({ openLoginNow: false })
    });
    await loadAppState();
    showToast(res.message || 'Đã xóa phiên cũ!', 'success');
    if (res.activeAccount?.id) {
      openInAppLoginModal(res.activeAccount.id, { resetToStart: true });
    }
  } catch (err) {
    showToast(`Lỗi xóa tài khoản: ${err.message}`, 'error');
  }
}

// ============================================================================
// ĐĂNG NHẬP TRỰC TIẾP NGAY TRONG GIAO DIỆN PHẦN MỀM (CHẠY NGẦM 100%)
// ============================================================================

const inAppLoginUiState = {
  open: false,
  accountId: null,
  account: null,
  busy: false,
  busyMessage: 'Đang kết nối bảo mật tới Muse.ai...',
  showPassword: false,
  draftIdentifier: '',
  loginState: null
};

function closeInAppLoginModal() {
  inAppLoginUiState.open = false;
  document.getElementById('inAppLoginModal')?.classList.add('hidden');
}

async function openInAppLoginModal(accountId, { resetToStart = false } = {}) {
  const targetId = accountId || state.activeAccount?.id;
  if (!targetId) return;

  const acc = state.accounts.find((a) => a.id === targetId) || state.activeAccount;
  inAppLoginUiState.open = true;
  inAppLoginUiState.accountId = targetId;
  inAppLoginUiState.account = acc;
  inAppLoginUiState.busy = true;
  inAppLoginUiState.busyMessage = 'Đang khởi tạo kênh bảo mật ngầm tới Muse.ai...';
  inAppLoginUiState.loginState = { step: 'loading' };

  document.getElementById('inAppLoginModal')?.classList.remove('hidden');
  renderInAppLoginModal();

  try {
    const res = await apiFetch(`/api/accounts/${targetId}/inapp-login/inspect`, {
      method: 'POST',
      body: JSON.stringify({ resetToStart })
    });
    inAppLoginUiState.account = res.account || acc;
    inAppLoginUiState.loginState = res.loginState || { step: 'identifier' };
    if (res.loginState?.rememberedIdentifier && !inAppLoginUiState.draftIdentifier) {
      inAppLoginUiState.draftIdentifier = res.loginState.rememberedIdentifier;
    }
    await loadAppState();
  } catch (err) {
    inAppLoginUiState.loginState = {
      step: 'challenge',
      heading: 'Không thể kết nối tới Muse.ai',
      description: 'Vui lòng kiểm tra lại kết nối mạng hoặc Proxy của dự án rồi bấm "↻ Thử lại" bên dưới.',
      errorText: err.message
    };
  } finally {
    inAppLoginUiState.busy = false;
    renderInAppLoginModal();
  }
}

async function submitInAppLoginAction(action, extraPayload = {}) {
  const targetId = inAppLoginUiState.accountId || state.activeAccount?.id;
  if (!targetId || inAppLoginUiState.busy) return;

  inAppLoginUiState.busy = true;
  if (action === 'submit_identifier') {
    inAppLoginUiState.busyMessage = 'Đang kiểm tra tài khoản & yêu cầu mã xác thực từ Muse.ai...';
  } else if (action === 'submit_otp') {
    inAppLoginUiState.busyMessage = 'Đang xác minh mã bảo mật & đồng bộ số dư Token...';
  } else if (action === 'submit_password') {
    inAppLoginUiState.busyMessage = 'Đang xác thực mật khẩu & đồng bộ số dư Token...';
  } else if (action === 'request_otp_instead') {
    inAppLoginUiState.busyMessage = 'Đang yêu cầu Muse.ai gửi mã xác thực 6 số về Email/SĐT...';
  } else {
    inAppLoginUiState.busyMessage = 'Đang xử lý bước đăng nhập trên Muse.ai...';
  }
  renderInAppLoginModal();

  try {
    const res = await apiFetch(`/api/accounts/${targetId}/inapp-login/submit`, {
      method: 'POST',
      body: JSON.stringify({
        action,
        ...extraPayload
      })
    });
    inAppLoginUiState.account = res.account || inAppLoginUiState.account;
    inAppLoginUiState.loginState = res.loginState || inAppLoginUiState.loginState;
    if (res.loginState?.rememberedIdentifier) {
      inAppLoginUiState.draftIdentifier = res.loginState.rememberedIdentifier;
    }
    await loadAppState();
    if (res.loginState?.step === 'logged_in') {
      showToast('🎉 Đã đăng nhập & đồng bộ số dư Token thành công!', 'success');
    } else if (action === 'resend_code') {
      showToast('📩 Đã yêu cầu Muse.ai gửi lại mã xác thực mới!', 'info');
    }
  } catch (err) {
    if (inAppLoginUiState.loginState) {
      inAppLoginUiState.loginState.errorText = err.message;
    }
    showToast(err.message, 'error');
  } finally {
    inAppLoginUiState.busy = false;
    renderInAppLoginModal();
  }
}

function renderInAppLoginModal() {
  const modal = document.getElementById('inAppLoginModal');
  const area = document.getElementById('inAppLoginDynamicArea');
  const subTarget = document.getElementById('inAppLoginSubTarget');
  const dot1 = document.getElementById('inAppStepDot1');
  const dot2 = document.getElementById('inAppStepDot2');
  const dot3 = document.getElementById('inAppStepDot3');
  if (!modal || !area) return;

  const acc =
    state.accounts.find((a) => a.id === inAppLoginUiState.accountId) ||
    inAppLoginUiState.account ||
    state.activeAccount;
  const st = inAppLoginUiState.loginState || { step: 'loading' };
  const step = st.step || 'loading';

  if (subTarget && acc) {
    const proxyNote = acc.proxyLabel ? ` • 🌐 Proxy: ${acc.proxyLabel}` : '';
    subTarget.textContent = `${acc.name}${proxyNote} — Kết nối ngầm trực tiếp trong phần mềm`;
  }

  const activeStage =
    step === 'logged_in'
      ? 3
      : ['otp', 'password', 'two_factor_method', 'challenge'].includes(step)
      ? 2
      : 1;

  if (dot1 && dot2 && dot3) {
    dot1.className = `inapp-step-pill ${activeStage === 1 ? 'active' : 'done'}`;
    dot2.className = `inapp-step-pill ${activeStage === 2 ? 'active' : activeStage > 2 ? 'done' : ''}`;
    dot3.className = `inapp-step-pill ${activeStage === 3 ? 'active done' : ''}`;
  }

  if (inAppLoginUiState.busy) {
    area.innerHTML = `
      <div class="inapp-loading-card">
        <div class="inapp-spinner"></div>
        <div class="inapp-loading-title">${escapeHtml(inAppLoginUiState.busyMessage)}</div>
        <div class="inapp-loading-sub">Vui lòng đợi giây lát...</div>
      </div>
    `;
    return;
  }

  const errorBanner = st.errorText
    ? `<div class="inapp-error-alert">⚠️ ${escapeHtml(st.errorText)}</div>`
    : '';

  if (step === 'logged_in') {
    const meta = getAccountDisplayLoginAndUsage(acc);
    area.innerHTML = `
      <div class="inapp-success-card">
        <div class="inapp-success-icon">✅</div>
        <div class="inapp-success-title">Đã Đăng Nhập: ${escapeHtml(meta.loginName)}</div>
        <div class="inapp-success-desc">Tài khoản đã lưu tự động — sẵn sàng tạo video ngầm.</div>

        <div class="acc-quota-dashboard" style="margin-top:10px;width:100%;text-align:left;">
          <div class="acc-quota-grid">
            <div class="acc-quota-stat stat-used">
              <span class="acc-quota-label">Token đã sử dụng</span>
              <strong class="acc-quota-value">${escapeHtml(meta.usedText)}</strong>
            </div>
            <div class="acc-quota-stat stat-remaining ${meta.hasUsage && meta.remPct <= 15 ? 'low-warn' : ''}">
              <span class="acc-quota-label">Token còn lại</span>
              <strong class="acc-quota-value">${escapeHtml(meta.remainingText)}</strong>
            </div>
          </div>
          ${
            meta.hasUsage
              ? `<div class="acc-quota-bar-track"><div class="acc-quota-bar-fill" style="width: ${meta.usedPct}%;"></div></div>`
              : ''
          }
        </div>

        <div class="inapp-btn-row" style="margin-top:12px;">
          <button type="button" class="btn-secondary" data-inapp-act="sync-token-now">↻ Cập nhật Token</button>
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="finish-close">Hoàn tất</button>
        </div>
      </div>
    `;
    return;
  }

  if (step === 'saved_account') {
    area.innerHTML = `
      <div class="inapp-form-card">
        <div class="inapp-form-heading">Phát hiện tài khoản có sẵn trên phiên này</div>
        <p class="inapp-form-desc">Bấm nút bên dưới để tiếp tục kết nối nhanh với tài khoản này:</p>
        ${errorBanner}
        <div class="inapp-btn-stack">
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="continue-saved">
            ⚡ ${escapeHtml(st.savedAccountLabel || 'Tiếp tục đăng nhập nhanh')}
          </button>
        </div>
      </div>
    `;
    return;
  }

  if (step === 'otp') {
    const idNote = inAppLoginUiState.draftIdentifier
      ? ` cho <strong>${escapeHtml(inAppLoginUiState.draftIdentifier)}</strong>`
      : '';
    area.innerHTML = `
      <div class="inapp-form-card">
        <div class="inapp-form-heading">📩 Nhập Mã Xác Thực Bảo Mật (OTP)</div>
        <p class="inapp-form-desc">
          Kiểm tra hộp thư Email / Tin nhắn${idNote} và nhập mã xác nhận (thường gồm 6 chữ số) từ Muse / Meta:
        </p>
        ${st.description ? `<div class="inapp-muse-hint">${escapeHtml(st.description)}</div>` : ''}
        ${errorBanner}
        <input
          type="text"
          id="inAppInputOtpCode"
          class="sidebar-input inapp-otp-input"
          inputmode="numeric"
          autocomplete="one-time-code"
          maxlength="12"
          placeholder="Nhập mã 6 số (VD: 482910)"
        />
        <div class="inapp-btn-row">
          <button type="button" class="btn-secondary" data-inapp-act="back-start">← Đổi Email khác</button>
          ${
            st.canResendCode
              ? `<button type="button" class="btn-secondary" data-inapp-act="resend-code">↻ Gửi lại mã</button>`
              : ''
          }
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="submit-otp">
            ✅ Xác Nhận &amp; Kết Nối
          </button>
        </div>
      </div>
    `;
    setTimeout(() => document.getElementById('inAppInputOtpCode')?.focus(), 50);
    return;
  }

  if (step === 'password') {
    const idLabel = inAppLoginUiState.draftIdentifier || '';
    area.innerHTML = `
      <div class="inapp-form-card">
        <div class="inapp-form-heading">🔑 Nhập Mật Khẩu Tài Khoản Muse.ai</div>
        ${
          idLabel
            ? `<p class="inapp-form-desc">Tài khoản: <strong>${escapeHtml(idLabel)}</strong></p>`
            : `<p class="inapp-form-desc">Nhập mật khẩu đăng nhập tài khoản Muse / Meta của bạn:</p>`
        }
        ${st.description ? `<div class="inapp-muse-hint">${escapeHtml(st.description)}</div>` : ''}
        ${errorBanner}
        <div class="inapp-pwd-wrap">
          <input
            type="${inAppLoginUiState.showPassword ? 'text' : 'password'}"
            id="inAppInputPassword"
            class="sidebar-input inapp-main-input"
            placeholder="Nhập mật khẩu của bạn..."
          />
          <button type="button" class="btn-mini inapp-pwd-toggle" data-inapp-act="toggle-pwd">
            ${inAppLoginUiState.showPassword ? '🙈 Ẩn' : '👁 Hiện'}
          </button>
        </div>
        <div class="inapp-btn-row">
          <button type="button" class="btn-secondary" data-inapp-act="back-start">← Đổi Email</button>
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="submit-password">
            🚀 Đăng Nhập Ngay
          </button>
        </div>
        ${
          st.canSwitchToOtp
            ? `
          <button type="button" class="inapp-link-btn" data-inapp-act="request-otp-instead">
            📩 Không nhớ mật khẩu? Bấm nhận mã OTP 6 số qua Email để đăng nhập
          </button>
        `
            : ''
        }
      </div>
    `;
    setTimeout(() => document.getElementById('inAppInputPassword')?.focus(), 50);
    return;
  }

  if (step === 'two_factor_method') {
    const methods = Array.isArray(st.twoFactorMethods) ? st.twoFactorMethods : [];
    const radiosHtml = methods
      .map(
        (m, idx) => `
        <label class="inapp-2fa-option">
          <input type="radio" name="inApp2faMethod" value="${escapeAttr(m.methodId)}" ${
          m.checked || idx === 0 ? 'checked' : ''
        } />
          <span>${escapeHtml(m.label)}</span>
        </label>
      `
      )
      .join('');
    area.innerHTML = `
      <div class="inapp-form-card">
        <div class="inapp-form-heading">🛡️ Chọn Phương Thức Xác Minh 2 Lớp</div>
        <p class="inapp-form-desc">${escapeHtml(
          st.description || 'Chọn nơi bạn muốn nhận mã bảo mật đăng nhập:'
        )}</p>
        ${errorBanner}
        <div class="inapp-2fa-list">${radiosHtml}</div>
        <div class="inapp-btn-row">
          <button type="button" class="btn-secondary" data-inapp-act="back-start">← Quay lại</button>
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="submit-2fa-method">
            Tiếp Tục Nhận Mã ➔
          </button>
        </div>
      </div>
    `;
    return;
  }

  if (step === 'challenge') {
    area.innerHTML = `
      <div class="inapp-form-card">
        <div class="inapp-form-heading">🔐 ${escapeHtml(st.heading || 'Kiểm tra xác thực tài khoản')}</div>
        <p class="inapp-form-desc">${escapeHtml(
          st.description || 'Vui lòng bấm tải lại Form bên dưới để tiếp tục đăng nhập trực tiếp.'
        )}</p>
        ${errorBanner}
        <div class="inapp-btn-row">
          <button type="button" class="btn-primary inapp-primary-cta" data-inapp-act="back-start">
            ↻ Thử lại ngay
          </button>
        </div>
      </div>
    `;
    return;
  }

  // Mặc định Bước 1: Nhập Email hoặc Số điện thoại (step === 'identifier' | 'loading')
  const prefill = inAppLoginUiState.draftIdentifier || st.currentIdentifier || acc?.accountInfo?.customLoginName || '';
  area.innerHTML = `
    <div class="inapp-form-card">
      <div class="inapp-form-heading">✉️ Nhập Email hoặc Số Điện Thoại</div>
      <p class="inapp-form-desc">
        Email hoặc Số điện thoại này sẽ tự động lưu làm tên tài khoản của dự án.
      </p>
      ${st.description ? `<div class="inapp-muse-hint">${escapeHtml(st.description)}</div>` : ''}
      ${errorBanner}
      <input
        type="text"
        id="inAppInputIdentifier"
        class="sidebar-input inapp-main-input"
        value="${escapeAttr(prefill)}"
        placeholder="Nhập Email hoặc Số điện thoại (VD: tenban@gmail.com)"
        autocomplete="username"
      />
      <div class="inapp-btn-row">
        <button type="button" class="btn-primary inapp-primary-cta" style="width:100%;" data-inapp-act="submit-identifier">
          Tiếp Tục Đăng Nhập ➔
        </button>
      </div>
    </div>
  `;
  setTimeout(() => document.getElementById('inAppInputIdentifier')?.focus(), 50);
}

async function saveAccountProjectName(accountId, rawNewName) {
  const cleanName = String(rawNewName || '').trim();
  const acc = state.accounts.find((a) => a.id === accountId);
  if (!cleanName) {
    renderAccountsModalList();
    return false;
  }
  if (acc && acc.name === cleanName) {
    return true;
  }
  const res = await apiFetch(`/api/accounts/${accountId}/name`, {
    method: 'PUT',
    body: JSON.stringify({ name: cleanName })
  });
  await loadAppState();
  showToast(res.message || `Đã đổi tên thành "${cleanName}"`, 'success');
  return true;
}

function renderAccountsModalList() {
  const container = document.getElementById('accountsModalList');
  if (!container) return;

  container.innerHTML = '';
  state.accounts.forEach((acc) => {
    const isCurrent = state.activeAccount && acc.id === state.activeAccount.id;
    const item = document.createElement('div');
    item.className = `account-list-item ${isCurrent ? 'active-acc' : ''}`;

    const meta = getAccountDisplayLoginAndUsage(acc);
    const statusDotClass = acc.loginVerified ? 'led-green' : 'led-red';
    const accountIdentityPill = acc.loginVerified
      ? `<span class="acc-login-pill is-logged" title="${escapeAttr(meta.loginName)}">${escapeHtml(meta.loginName)}</span>`
      : `<span class="acc-login-pill is-guest">Chưa đăng nhập</span>`;

    const proxyBadge = acc.proxyLabel
      ? `<span class="banner-badge badge-proxy">🌐 ${escapeHtml(acc.proxyLabel)}</span>`
      : '';

    const loginBtnHtml = !acc.loginVerified
      ? `<button class="btn-mini btn-inapp-login-acc" data-modal-action="inapp-login" data-id="${acc.id}">🔑 Đăng nhập</button>`
      : '';

    item.innerHTML = `
      <div class="acc-item-top">
        <div class="acc-item-head-left">
          <span class="status-led ${statusDotClass}"></span>
          <div class="acc-name-edit-wrap" title="Bấm vào để sửa tên dự án tùy ý (Enter hoặc bấm ra ngoài để lưu)">
            <input
              type="text"
              class="acc-name-inline-input"
              data-rename-acc-id="${acc.id}"
              data-orig-name="${escapeAttr(acc.name)}"
              value="${escapeAttr(acc.name)}"
              maxlength="80"
              spellcheck="false"
            />
            <span class="acc-name-edit-icon" data-focus-rename="${acc.id}">✎</span>
          </div>
          ${accountIdentityPill}
          ${proxyBadge}
        </div>
        <div class="acc-item-actions">
          <button class="btn-mini ${isCurrent ? 'btn-acc-selected' : ''}" data-modal-action="switch-acc" data-id="${acc.id}">
            ${isCurrent ? '✓ Đang dùng' : 'Chọn'}
          </button>
          ${loginBtnHtml}
          <button class="btn-mini btn-sync-token" data-modal-action="sync-quota" data-id="${acc.id}" title="Làm mới số dư Token">
            ↻ Token
          </button>
          <button class="btn-mini btn-danger-soft" data-modal-action="reset-acc" data-id="${acc.id}" data-name="${escapeAttr(acc.name)}" title="Xóa phiên đăng nhập">
            🗑 Xóa
          </button>
        </div>
      </div>

      <div class="acc-quota-dashboard">
        <div class="acc-quota-grid">
          <div class="acc-quota-stat stat-used">
            <span class="acc-quota-label">Token đã sử dụng</span>
            <strong class="acc-quota-value">${escapeHtml(meta.usedText)}</strong>
          </div>
          <div class="acc-quota-stat stat-remaining ${meta.hasUsage && meta.remPct <= 15 ? 'low-warn' : ''}">
            <span class="acc-quota-label">Token còn lại</span>
            <strong class="acc-quota-value">${escapeHtml(meta.remainingText)}</strong>
          </div>
        </div>
        ${
          meta.hasUsage
            ? `<div class="acc-quota-bar-track"><div class="acc-quota-bar-fill" style="width: ${meta.usedPct}%;"></div></div>`
            : ''
        }
      </div>

      <div class="acc-proxy-row">
        <input
          type="text"
          class="sidebar-input acc-proxy-input"
          data-proxy-for="${acc.id}"
          value="${escapeAttr(acc.proxy || '')}"
          placeholder="Proxy tùy chọn (ip:port hoặc ip:port:user:pass)"
        />
        <button type="button" class="btn-mini btn-save-proxy" data-modal-action="save-proxy" data-id="${acc.id}">
          Lưu Proxy
        </button>
      </div>
    `;
    container.appendChild(item);
  });
}

// ============================================================================
// CAPCUT STUDIO — CẮT & NỐI VIDEO
// ============================================================================

function formatTimeSec(sec) {
  const s = Math.max(0, Number(sec) || 0);
  const mins = Math.floor(s / 60);
  const rem = (s % 60).toFixed(1).padStart(4, '0');
  return `${String(mins).padStart(2, '0')}:${rem}`;
}

function probeBrowserVideoDuration(videoUrl) {
  return new Promise((resolve) => {
    const tempVid = document.createElement('video');
    tempVid.preload = 'metadata';
    const done = (dur) => {
      tempVid.removeAttribute('src');
      tempVid.load();
      resolve(dur && isFinite(dur) && dur > 0 ? Number(dur.toFixed(2)) : 10);
    };
    tempVid.onloadedmetadata = () => done(tempVid.duration);
    tempVid.onerror = () => done(10);
    setTimeout(() => done(10), 2500);
    tempVid.src = videoUrl;
  });
}

async function createClipFromRow(row) {
  const duration = await probeBrowserVideoDuration(row.videoUrl);
  return {
    id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    rowIndex: row.index,
    videoUrl: row.videoUrl,
    videoFilePath: row.videoFilePath,
    label: `Hàng #${String(row.index).padStart(2, '0')}`,
    prompt: row.prompt || '',
    sourceDuration: duration,
    startTime: 0,
    endTime: duration,
    speed: 1,
    muted: false
  };
}

function getActiveCapcutClip() {
  return capcutState.clips.find((c) => c.id === capcutState.activeClipId) || null;
}

async function openCapcutEditorModal({ initialRows = [], singleRowTarget = null } = {}) {
  if (!state.activeAccount) return;

  capcutState.playingAll = false;
  capcutState.singleRowTarget = singleRowTarget;
  document.getElementById('capcutExportResultBox')?.classList.add('hidden');

  const modal = document.getElementById('capcutEditorModal');
  modal.classList.remove('hidden');

  if (initialRows.length > 0) {
    capcutState.clips = [];
    for (const r of initialRows) {
      if (r && r.videoUrl) {
        const clip = await createClipFromRow(r);
        capcutState.clips.push(clip);
      }
    }
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
  } else if (capcutState.clips.length === 0) {
    const availableRows = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
    for (const r of availableRows) {
      const clip = await createClipFromRow(r);
      capcutState.clips.push(clip);
    }
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
  }

  renderCapcutAll();
  loadActiveClipIntoPlayer(false);
}

function renderCapcutAll() {
  renderCapcutSourceLibrary();
  renderCapcutTimelineTrack();
  renderCapcutInspector();
  renderCapcutFooterButtons();
}

function renderCapcutSourceLibrary() {
  const listEl = document.getElementById('capcutSourceRowsList');
  if (!listEl || !state.activeAccount) return;

  const rowsWithVideo = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
  listEl.innerHTML = '';

  if (rowsWithVideo.length === 0) {
    listEl.innerHTML = `<div class="empty-hint-box">Chưa có hàng nào có video.</div>`;
    return;
  }

  rowsWithVideo.forEach((row) => {
    const item = document.createElement('div');
    item.className = 'capcut-source-item';
    item.innerHTML = `
      <div class="source-item-info">
        <div class="source-item-title">Hàng #${String(row.index).padStart(2, '0')}</div>
        <div class="source-item-prompt">${escapeHtml(row.prompt || 'Không có prompt')}</div>
      </div>
      <button type="button" class="btn-mini-accent" data-add-row="${row.index}">+ Thêm</button>
    `;
    listEl.appendChild(item);
  });
}

function renderCapcutTimelineTrack() {
  const trackEl = document.getElementById('capcutTimelineTrack');
  const summaryEl = document.getElementById('capcutSummaryBadge');
  if (!trackEl) return;

  trackEl.innerHTML = '';

  let totalSec = 0;
  capcutState.clips.forEach((c) => {
    totalSec += Math.max(0.1, (c.endTime - c.startTime) / (c.speed || 1));
  });

  if (summaryEl) {
    summaryEl.textContent = `${capcutState.clips.length} đoạn • ${totalSec.toFixed(1)}s`;
  }

  if (capcutState.clips.length === 0) {
    trackEl.innerHTML = `<div class="empty-hint-box">Timeline trống — Bấm "+ Thêm" từ cột bên trái.</div>`;
    return;
  }

  capcutState.clips.forEach((clip, idx) => {
    const isActive = clip.id === capcutState.activeClipId;
    const card = document.createElement('div');
    card.className = `timeline-clip-card ${isActive ? 'active-clip' : ''}`;
    card.draggable = true;
    card.dataset.clipId = clip.id;

    const maxDur = clip.sourceDuration || 10;
    const leftPct = Math.max(0, Math.min(95, (clip.startTime / maxDur) * 100));
    const widthPct = Math.max(5, Math.min(100 - leftPct, ((clip.endTime - clip.startTime) / maxDur) * 100));
    const effectiveDur = ((clip.endTime - clip.startTime) / (clip.speed || 1)).toFixed(1);

    card.innerHTML = `
      <div class="clip-card-top">
        <span class="clip-order-badge">#${idx + 1}</span>
        <span class="clip-row-tag">${escapeHtml(clip.label)}</span>
        <button type="button" class="clip-remove-x" data-remove-clip="${clip.id}">×</button>
      </div>
      <div class="clip-visual-bar">
        <div class="clip-trim-fill" style="left:${leftPct}%;width:${widthPct}%;"></div>
      </div>
      <div class="clip-card-bottom">
        <span>${clip.startTime.toFixed(1)}s - ${clip.endTime.toFixed(1)}s</span>
        <span>${clip.muted ? '🔇' : '🔊'} ${effectiveDur}s</span>
      </div>
    `;

    card.addEventListener('dragstart', () => {
      capcutState.draggedClipId = clip.id;
    });
    card.addEventListener('dragover', (e) => e.preventDefault());
    card.addEventListener('drop', (e) => {
      e.preventDefault();
      const fromId = capcutState.draggedClipId;
      const toId = clip.id;
      if (!fromId || fromId === toId) return;
      const fromIdx = capcutState.clips.findIndex((c) => c.id === fromId);
      const toIdx = capcutState.clips.findIndex((c) => c.id === toId);
      if (fromIdx === -1 || toIdx === -1) return;
      const [moved] = capcutState.clips.splice(fromIdx, 1);
      capcutState.clips.splice(toIdx, 0, moved);
      renderCapcutTimelineTrack();
    });

    trackEl.appendChild(card);
  });
}

function renderCapcutInspector() {
  const clip = getActiveCapcutClip();
  const tagEl = document.getElementById('capcutSelectedClipTag');
  const durBadge = document.getElementById('capcutTrimDurationBadge');
  const inStart = document.getElementById('inputCapcutTrimStart');
  const inEnd = document.getElementById('inputCapcutTrimEnd');
  const slStart = document.getElementById('sliderCapcutTrimStart');
  const slEnd = document.getElementById('sliderCapcutTrimEnd');
  const selSpeed = document.getElementById('selectCapcutClipSpeed');
  const btnMute = document.getElementById('btnCapcutToggleMute');
  const emptyStage = document.getElementById('capcutEmptyStage');
  const overlay = document.getElementById('capcutActiveClipOverlay');

  if (!clip) {
    if (tagEl) tagEl.textContent = 'Chưa chọn';
    if (durBadge) durBadge.textContent = '0.0s';
    if (emptyStage) emptyStage.classList.remove('hidden');
    if (overlay) overlay.classList.add('hidden');
    return;
  }

  if (emptyStage) emptyStage.classList.add('hidden');
  const clipIdx = capcutState.clips.findIndex((c) => c.id === clip.id) + 1;
  if (tagEl) tagEl.textContent = `#${clipIdx} (${clip.label})`;
  if (overlay) {
    overlay.classList.remove('hidden');
    overlay.textContent = `#${clipIdx} • ${clip.label} (${clip.startTime.toFixed(1)}s - ${clip.endTime.toFixed(1)}s)`;
  }

  const maxDur = clip.sourceDuration || 10;
  const trimmedLen = Math.max(0.1, (clip.endTime - clip.startTime) / (clip.speed || 1));
  if (durBadge) {
    durBadge.textContent = `${trimmedLen.toFixed(1)}s / ${maxDur.toFixed(1)}s`;
  }

  if (inStart) {
    inStart.max = String(maxDur);
    inStart.value = clip.startTime.toFixed(1);
  }
  if (inEnd) {
    inEnd.max = String(maxDur);
    inEnd.value = clip.endTime.toFixed(1);
  }
  if (slStart) {
    slStart.max = String(maxDur);
    slStart.value = String(clip.startTime);
  }
  if (slEnd) {
    slEnd.max = String(maxDur);
    slEnd.value = String(clip.endTime);
  }
  if (selSpeed) selSpeed.value = String(clip.speed || 1);
  if (btnMute) btnMute.textContent = clip.muted ? '🔇 Đã tắt tiếng' : '🔊 Bật tiếng';
}

function renderCapcutFooterButtons() {
  const btnSaveSingle = document.getElementById('btnCapcutSaveToSingleRow');
  if (!btnSaveSingle) return;

  const uniqueRows = new Set(capcutState.clips.map((c) => c.rowIndex).filter(Boolean));
  const targetRow = capcutState.singleRowTarget || (uniqueRows.size === 1 ? [...uniqueRows][0] : null);

  if (targetRow && capcutState.clips.length > 0) {
    btnSaveSingle.classList.remove('hidden');
    btnSaveSingle.dataset.targetRow = String(targetRow);
    btnSaveSingle.textContent = `💾 Lưu vào Hàng #${String(targetRow).padStart(2, '0')}`;
  } else {
    btnSaveSingle.classList.add('hidden');
  }
}

function loadActiveClipIntoPlayer(autoPlay = false) {
  const player = document.getElementById('capcutPreviewPlayer');
  const slider = document.getElementById('capcutPlayheadSlider');
  const curLabel = document.getElementById('capcutCurrentTimeLabel');
  const endLabel = document.getElementById('capcutClipEndLabel');
  const clip = getActiveCapcutClip();
  if (!player) return;

  if (!clip) {
    player.pause();
    player.removeAttribute('src');
    return;
  }

  const maxDur = clip.sourceDuration || 10;
  if (slider) {
    slider.min = '0';
    slider.max = String(maxDur);
    slider.value = String(clip.startTime);
  }
  if (curLabel) curLabel.textContent = formatTimeSec(clip.startTime);
  if (endLabel) endLabel.textContent = formatTimeSec(clip.endTime);

  const sameSrc = player.getAttribute('data-loaded-url') === clip.videoUrl;
  player.muted = Boolean(clip.muted);
  player.playbackRate = Number(clip.speed) || 1;

  if (!sameSrc) {
    player.setAttribute('data-loaded-url', clip.videoUrl);
    player.src = clip.videoUrl;
    player.onloadedmetadata = () => {
      if (player.duration && isFinite(player.duration) && player.duration > 0) {
        clip.sourceDuration = Number(player.duration.toFixed(2));
        if (clip.endTime > clip.sourceDuration || clip.endTime <= 0) {
          clip.endTime = clip.sourceDuration;
        }
        renderCapcutInspector();
        renderCapcutTimelineTrack();
      }
      player.currentTime = clip.startTime;
      if (autoPlay) player.play().catch(() => {});
    };
  } else {
    player.currentTime = clip.startTime;
    if (autoPlay) player.play().catch(() => {});
  }
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(str) {
  return escapeHtml(str);
}

// ==================== DOM EVENT LISTENERS ====================
document.addEventListener('DOMContentLoaded', () => {
  const savedTheme = localStorage.getItem('muse_flow_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', savedTheme);
  const themeIcon = document.getElementById('themeIcon');
  if (themeIcon) themeIcon.textContent = savedTheme === 'light' ? '🌙' : '☀️';

  document.getElementById('btnToggleTheme')?.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('muse_flow_theme', next);
    if (themeIcon) themeIcon.textContent = next === 'light' ? '🌙' : '☀️';
  });

  document.getElementById('btnToggleSidebar')?.addEventListener('click', () => {
    document.getElementById('studioLayout')?.classList.toggle('sidebar-collapsed');
  });

  document.getElementById('statusFilterGroup')?.addEventListener('click', (e) => {
    const tab = e.target.closest('.filter-tab');
    if (!tab) return;
    state.statusFilter = tab.dataset.filter || 'all';
    document.querySelectorAll('#statusFilterGroup .filter-tab').forEach((t) => {
      t.classList.toggle('active', t === tab);
    });
    renderRowCountsAndFilterVisibility();
  });

  document.getElementById('chkSelectAllRows')?.addEventListener('change', (e) => {
    const rows = state.activeAccount?.rows || [];
    state.selectedRows.clear();
    if (e.target.checked) {
      rows.forEach((r) => {
        if (r.videoUrl) state.selectedRows.add(r.index);
      });
      if (state.selectedRows.size === 0) {
        rows.forEach((r) => state.selectedRows.add(r.index));
      }
    }
    renderFlowRows();
  });

  loadAppState();
  connectWebSocket();

  // ==================== HỆ THỐNG TỰ ĐỘNG KIỂM TRA & CẬP NHẬT OTA QUA GITHUB ====================
  let cachedUpdateInfo = null;
  let updateInstalling = false;

  // Thông báo chào mừng ngay sau khi tự động cập nhật thành công và tải lại trang
  try {
    const justUpdatedVer = sessionStorage.getItem('mfs_just_updated_to');
    if (justUpdatedVer) {
      sessionStorage.removeItem('mfs_just_updated_to');
      setTimeout(() => {
        showToast(`🎉 Đã tự động cập nhật thành công lên phiên bản v${justUpdatedVer}!`, 'success');
      }, 600);
    }
  } catch (_) {}

  function openUpdateModalWithInfo(info) {
    if (!info || !info.updateAvailable) return;
    cachedUpdateInfo = info;

    const topAlertBtn = document.getElementById('btnTopUpdateAlert');
    const topVerSpan = document.getElementById('topUpdateVerText');
    if (topVerSpan) topVerSpan.textContent = `v${info.latestVersion}`;
    topAlertBtn?.classList.remove('hidden');

    const titleEl = document.getElementById('updateModalTitle');
    const curEl = document.getElementById('updateCurrentVerLabel');
    const newEl = document.getElementById('updateLatestVerLabel');
    const logEl = document.getElementById('updateModalChangelog');
    const dismissBtn = document.getElementById('btnDismissUpdateModal');
    const closeXBtn = document.getElementById('btnCloseUpdateModalX');

    if (titleEl) titleEl.textContent = `🎉 ${info.title || `ĐÃ CÓ PHIÊN BẢN MỚI v${info.latestVersion}`}`;
    if (curEl) curEl.textContent = `v${info.currentVersion || state.version || '3.0'}`;
    if (newEl) newEl.textContent = `v${info.latestVersion}`;
    if (logEl) {
      const kb = info.patchSize ? ` (~${Math.max(1, Math.round(info.patchSize / 1024))} KB)` : '';
      logEl.textContent = `${info.changelog || '• Cập nhật tính năng & tối ưu độ ổn định.'}${kb ? `\n\n📦 Dung lượng gói nâng cấp nhẹ:${kb}` : ''}`;
    }

    if (info.mandatory) {
      dismissBtn?.classList.add('hidden');
      closeXBtn?.classList.add('hidden');
    } else {
      dismissBtn?.classList.remove('hidden');
      closeXBtn?.classList.remove('hidden');
    }

    document.getElementById('updateAvailableModal')?.classList.remove('hidden');
  }

  async function checkRemoteUpdate(manualClick = false) {
    try {
      const res = await fetch('/api/update/check', { cache: 'no-store' });
      const info = await res.json();
      if (info && info.updateAvailable) {
        openUpdateModalWithInfo(info);
        return;
      }
      if (manualClick) {
        if (!info.configured) {
          showToast(`Đang chạy phiên bản v${state.version || '2.9'} (Chưa gắn kho cập nhật GitHub).`, 'info');
        } else if (info.error) {
          showToast(`Không thể kiểm tra cập nhật: ${info.error}`, 'error');
        } else {
          showToast(`✅ Bạn đang sử dụng phiên bản mới nhất (v${info.currentVersion || state.version || '2.9'})!`, 'success');
        }
      }
    } catch (_) {
      if (manualClick) {
        showToast('Không thể kết nối máy chủ kiểm tra cập nhật lúc này.', 'error');
      }
    }
  }

  setTimeout(() => checkRemoteUpdate(false), 1800);
  setInterval(() => checkRemoteUpdate(false), 30 * 60 * 1000);

  document.getElementById('topVersionBadge')?.addEventListener('click', () => {
    checkRemoteUpdate(true);
  });

  document.getElementById('btnTopUpdateAlert')?.addEventListener('click', () => {
    if (cachedUpdateInfo && cachedUpdateInfo.updateAvailable) {
      openUpdateModalWithInfo(cachedUpdateInfo);
    } else {
      checkRemoteUpdate(true);
    }
  });

  document.getElementById('btnApplyUpdateNow')?.addEventListener('click', async () => {
    if (updateInstalling) return;
    updateInstalling = true;

    const btnApply = document.getElementById('btnApplyUpdateNow');
    const btnDismiss = document.getElementById('btnDismissUpdateModal');
    const btnCloseX = document.getElementById('btnCloseUpdateModalX');
    const progBox = document.getElementById('updateProgressBox');
    const progStatus = document.getElementById('updateProgressStatus');

    if (btnApply) btnApply.disabled = true;
    btnDismiss?.classList.add('hidden');
    btnCloseX?.classList.add('hidden');
    progBox?.classList.remove('hidden');
    if (progStatus) progStatus.textContent = 'Đang kết nối GitHub tải gói nâng cấp mới...';

    try {
      const res = await apiFetch('/api/update/apply', { method: 'POST' });
      if (res.alreadyLatest) {
        updateInstalling = false;
        if (btnApply) btnApply.disabled = false;
        progBox?.classList.add('hidden');
        document.getElementById('updateAvailableModal')?.classList.add('hidden');
        showToast(res.message || 'Bạn đang ở phiên bản mới nhất!', 'success');
        return;
      }

      const targetVer = res.newVersion || cachedUpdateInfo?.latestVersion || '';
      if (progStatus) {
        progStatus.textContent = `Đã cài xong v${targetVer}! Đang tự khởi động lại công cụ (vui lòng đợi 2–3 giây)...`;
      }

      // Chờ server mới khởi động xong trên cổng 3888 rồi tự làm mới trang mượt mà
      let attempts = 0;
      const pollRestart = setInterval(async () => {
        attempts++;
        try {
          const r = await fetch(`/api/state?t=${Date.now()}`, { cache: 'no-store' });
          if (r.ok) {
            const st = await r.json();
            if (st && st.ok && (!targetVer || st.version === targetVer || attempts >= 6)) {
              clearInterval(pollRestart);
              try {
                sessionStorage.setItem('mfs_just_updated_to', st.version || targetVer);
              } catch (_) {}
              window.location.reload();
            }
          }
        } catch (_) {
          // Server đang trong 0.5s khởi động lại, tiếp tục đợi
        }
        if (attempts > 35) {
          clearInterval(pollRestart);
          window.location.reload();
        }
      }, 600);
    } catch (err) {
      updateInstalling = false;
      if (btnApply) btnApply.disabled = false;
      if (!cachedUpdateInfo?.mandatory) {
        btnDismiss?.classList.remove('hidden');
        btnCloseX?.classList.remove('hidden');
      }
      progBox?.classList.add('hidden');
      showToast(`Lỗi cập nhật: ${err.message}`, 'error');
    }
  });

  // Nút ẩn dự phòng (giữ an toàn DOM)
  document.getElementById('btnConnectChrome')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    openInAppLoginModal(state.activeAccount.id);
  });

  // Sự kiện bên trong Modal Đăng Nhập Trực Tiếp (#inAppLoginModal)
  document.getElementById('inAppLoginDynamicArea')?.addEventListener('click', async (e) => {
    const actBtn = e.target.closest('button[data-inapp-act]');
    if (!actBtn) return;
    const act = actBtn.dataset.inappAct;

    if (act === 'submit-identifier') {
      const val = document.getElementById('inAppInputIdentifier')?.value.trim() || '';
      if (!val) {
        showToast('Vui lòng nhập Email hoặc Số điện thoại đăng nhập!', 'error');
        return;
      }
      inAppLoginUiState.draftIdentifier = val;
      await submitInAppLoginAction('submit_identifier', { identifier: val });
    } else if (act === 'submit-otp') {
      const code = document.getElementById('inAppInputOtpCode')?.value.trim() || '';
      if (!code) {
        showToast('Vui lòng nhập mã xác thực bảo mật!', 'error');
        return;
      }
      await submitInAppLoginAction('submit_otp', { code });
    } else if (act === 'submit-password') {
      const pwd = document.getElementById('inAppInputPassword')?.value || '';
      if (!pwd) {
        showToast('Vui lòng nhập mật khẩu!', 'error');
        return;
      }
      await submitInAppLoginAction('submit_password', { password: pwd });
    } else if (act === 'toggle-pwd') {
      const curVal = document.getElementById('inAppInputPassword')?.value || '';
      inAppLoginUiState.showPassword = !inAppLoginUiState.showPassword;
      renderInAppLoginModal();
      const newInp = document.getElementById('inAppInputPassword');
      if (newInp) {
        newInp.value = curVal;
        newInp.focus();
      }
    } else if (act === 'request-otp-instead') {
      await submitInAppLoginAction('request_otp_instead', {
        identifier: inAppLoginUiState.draftIdentifier
      });
    } else if (act === 'resend-code') {
      await submitInAppLoginAction('resend_code');
    } else if (act === 'submit-2fa-method') {
      const checked = document.querySelector('input[name="inApp2faMethod"]:checked');
      await submitInAppLoginAction('select_2fa_method', {
        methodId: checked ? checked.value : ''
      });
    } else if (act === 'continue-saved') {
      await submitInAppLoginAction('continue_saved_account');
    } else if (act === 'use-another') {
      await submitInAppLoginAction('use_another_account');
    } else if (act === 'back-start') {
      await submitInAppLoginAction('back_to_start');
    } else if (act === 'sync-token-now') {
      await syncAccountQuotaFromUi(inAppLoginUiState.accountId, actBtn);
      renderInAppLoginModal();
    } else if (act === 'finish-close') {
      closeInAppLoginModal();
    }
  });

  document.getElementById('inAppLoginDynamicArea')?.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'inAppInputIdentifier') {
      e.preventDefault();
      document.querySelector('button[data-inapp-act="submit-identifier"]')?.click();
    } else if (e.target.id === 'inAppInputOtpCode') {
      e.preventDefault();
      document.querySelector('button[data-inapp-act="submit-otp"]')?.click();
    } else if (e.target.id === 'inAppInputPassword') {
      e.preventDefault();
      document.querySelector('button[data-inapp-act="submit-password"]')?.click();
    }
  });

  // Làm mới dự án
  document.getElementById('btnResetProject').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const ok = window.confirm(`Làm mới dự án "${state.activeAccount.name}" (xóa trắng ảnh, prompt và video trên các hàng)?`);
    if (!ok) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/reset-project`, {
        method: 'POST'
      });
      state.activeAccount = res.account;
      state.selectedRows.clear();
      state.statusFilter = 'all';
      document.querySelectorAll('#statusFilterGroup .filter-tab').forEach((tab) => {
        tab.classList.toggle('active', tab.dataset.filter === 'all');
      });
      renderAll();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(`Lỗi làm mới: ${err.message}`, 'error');
    }
  });

  // Ẩn Chrome (nếu còn nút)
  document.getElementById('btnHideChromeWindow')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/hide-chrome`, {
        method: 'POST'
      });
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Mở thư mục xuất & Kho Video Output xem mượt tức thì
  let outputGalleryItems = [];
  let activeOutputRelPath = '';

  function renderOutputGalleryList() {
    const listEl = document.getElementById('outputGalleryList');
    const badgeEl = document.getElementById('outputGalleryCountBadge');
    if (!listEl) return;

    if (badgeEl) badgeEl.textContent = `${outputGalleryItems.length} video`;

    if (outputGalleryItems.length === 0) {
      listEl.innerHTML = `<div class="pane-sub-hint" style="padding:18px;text-align:center;">Chưa có video nào trong thư mục Output_Videos.</div>`;
      return;
    }

    listEl.innerHTML = outputGalleryItems
      .map((item) => {
        const mb = (Number(item.sizeBytes || 0) / (1024 * 1024)).toFixed(2);
        const dt = item.createdAt ? new Date(item.createdAt).toLocaleString('vi-VN') : '';
        const isActive = item.relativePath === activeOutputRelPath;
        const mergedTag = item.isMerged ? `<span class="badge-accent">Đã nối</span>` : '';
        return `
          <div class="output-video-card ${isActive ? 'active-output-item' : ''}" data-rel="${escapeHtml(item.relativePath)}">
            <div class="output-video-info">
              <div class="output-video-name" title="${escapeHtml(item.fileName)}">${escapeHtml(item.fileName)}</div>
              <div class="output-video-sub">
                <span>📁 ${escapeHtml(item.accountName || item.accountId)}</span>
                <span>• ${mb} MB</span>
                <span>• ${escapeHtml(dt)}</span>
                ${mergedTag}
              </div>
            </div>
            <div class="output-video-btns">
              <button type="button" class="btn-mini-accent" data-out-act="play" data-rel="${escapeHtml(item.relativePath)}">▶ Xem</button>
              <button type="button" class="btn-mini" data-out-act="locate" data-rel="${escapeHtml(item.relativePath)}" title="Hiện đúng file này trong Windows Explorer">📂</button>
              <a class="btn-mini" href="${escapeHtml(item.publicUrl)}" download="${escapeHtml(item.fileName)}" title="Tải về máy" onclick="event.stopPropagation()">⬇</a>
            </div>
          </div>
        `;
      })
      .join('');
  }

  function playOutputGalleryItem(relPath) {
    const item = outputGalleryItems.find((x) => x.relativePath === relPath);
    const player = document.getElementById('outputGalleryPlayer');
    const emptyEl = document.getElementById('outputGalleryEmpty');
    const metaEl = document.getElementById('outputGalleryActiveMeta');
    if (!player) return;

    if (!item) {
      activeOutputRelPath = '';
      player.pause();
      player.removeAttribute('src');
      player.classList.remove('has-src');
      emptyEl?.classList.remove('hidden');
      metaEl?.classList.add('hidden');
      renderOutputGalleryList();
      return;
    }

    activeOutputRelPath = item.relativePath;
    emptyEl?.classList.add('hidden');
    player.classList.add('has-src');
    player.src = `${item.publicUrl}?t=${Date.now()}`;
    player.play().catch(() => {});

    if (metaEl) {
      const mb = (Number(item.sizeBytes || 0) / (1024 * 1024)).toFixed(2);
      metaEl.textContent = `${item.fileName} (${mb} MB • ${item.accountName || item.accountId})`;
      metaEl.classList.remove('hidden');
    }
    renderOutputGalleryList();
  }

  async function refreshOutputGallery(autoPlayFirst = false) {
    const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
    const accQuery = scope === 'active' && state.activeAccount ? state.activeAccount.id : 'all';
    try {
      const res = await apiFetch(`/api/output-videos?accountId=${encodeURIComponent(accQuery)}`);
      outputGalleryItems = res.items || [];
      renderOutputGalleryList();
      if (autoPlayFirst && outputGalleryItems.length > 0) {
        playOutputGalleryItem(outputGalleryItems[0].relativePath);
      } else if (activeOutputRelPath && !outputGalleryItems.some((x) => x.relativePath === activeOutputRelPath)) {
        playOutputGalleryItem('');
      }
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  document.getElementById('btnOpenOutputGallery')?.addEventListener('click', async () => {
    document.getElementById('outputGalleryModal')?.classList.remove('hidden');
    await refreshOutputGallery(true);
  });

  document.getElementById('selectOutputGalleryScope')?.addEventListener('change', () => {
    refreshOutputGallery(true);
  });

  document.getElementById('btnRefreshOutputGallery')?.addEventListener('click', () => {
    refreshOutputGallery(false);
  });

  document.getElementById('btnOpenExplorerFromGallery')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const origText = btn ? btn.textContent : '';
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Đang mở thư mục...';
    }
    try {
      const selectedItem =
        activeOutputRelPath && outputGalleryItems.find((x) => x.relativePath === activeOutputRelPath);
      if (selectedItem) {
        await apiFetch('/api/open-output-file', {
          method: 'POST',
          body: JSON.stringify({ relativePath: selectedItem.relativePath })
        });
      } else {
        const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
        const accountId = scope === 'active' ? state.activeAccount?.id : undefined;
        await apiFetch('/api/open-output-folder', {
          method: 'POST',
          body: JSON.stringify({ accountId })
        });
      }
      showToast('📂 Đã mở thư mục chứa video trên máy tính!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = origText || '📂 Mở Thư Mục Trên Máy';
      }
    }
  });

  document.getElementById('btnRepairOutputVideos')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnRepairOutputVideos');
    if (btn) btn.disabled = true;
    showToast('Đang chuẩn hóa toàn bộ video MP4 sang chuẩn 44.1kHz Stereo mượt...', 'info');
    try {
      const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
      const accountId = scope === 'active' && state.activeAccount ? state.activeAccount.id : 'all';
      const res = await apiFetch('/api/output-videos/repair', {
        method: 'POST',
        body: JSON.stringify({ accountId, forceReencode: true })
      });
      outputGalleryItems = res.items || [];
      renderOutputGalleryList();
      if (activeOutputRelPath) playOutputGalleryItem(activeOutputRelPath);
      showToast(res.message || 'Đã chuẩn hóa xong toàn bộ video!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('outputGalleryList')?.addEventListener('click', async (e) => {
    const actBtn = e.target.closest('button[data-out-act]');
    if (actBtn) {
      e.stopPropagation();
      const rel = actBtn.dataset.rel;
      if (actBtn.dataset.outAct === 'play') {
        playOutputGalleryItem(rel);
      } else if (actBtn.dataset.outAct === 'locate') {
        actBtn.disabled = true;
        try {
          await apiFetch('/api/open-output-file', {
            method: 'POST',
            body: JSON.stringify({ relativePath: rel })
          });
          showToast('📂 Đã mở thư mục và tô sáng file video!', 'success');
        } catch (err) {
          showToast(err.message, 'error');
        } finally {
          actBtn.disabled = false;
        }
      }
      return;
    }
    const card = e.target.closest('.output-video-card');
    if (card && card.dataset.rel) {
      playOutputGalleryItem(card.dataset.rel);
    }
  });

  // Chuyển dự án & Sửa tên dự án ngay trên Topbar
  document.getElementById('accountSelect').addEventListener('change', async (e) => {
    const accountId = e.target.value;
    try {
      await apiFetch('/api/accounts/select', {
        method: 'POST',
        body: JSON.stringify({ accountId })
      });
      state.selectedRows.clear();
      capcutState.clips = [];
      await loadAppState();
      showToast(`Đã chuyển sang ${state.activeAccount?.name}`, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  const topRenameInput = document.getElementById('topInlineProjectNameInput');
  const topAccountSelect = document.getElementById('accountSelect');
  const btnRenameActiveProject = document.getElementById('btnRenameActiveProject');

  function openTopbarProjectRename() {
    if (!state.activeAccount || !topRenameInput || !topAccountSelect) return;
    topRenameInput.value = state.activeAccount.name || '';
    topRenameInput.dataset.origName = state.activeAccount.name || '';
    topRenameInput.dataset.cancelling = '';
    topAccountSelect.classList.add('hidden');
    topRenameInput.classList.remove('hidden');
    topRenameInput.focus();
    topRenameInput.select();
  }

  async function finishTopbarProjectRename(commitSave) {
    if (!topRenameInput || !topAccountSelect || topRenameInput.classList.contains('hidden')) return;
    if (topRenameInput.dataset.saving === '1') return;
    const newVal = topRenameInput.value.trim();
    const origVal = topRenameInput.dataset.origName || '';
    topRenameInput.classList.add('hidden');
    topAccountSelect.classList.remove('hidden');

    if (!commitSave || !state.activeAccount || !newVal || newVal === origVal) {
      return;
    }
    topRenameInput.dataset.saving = '1';
    try {
      await saveAccountProjectName(state.activeAccount.id, newVal);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      topRenameInput.dataset.saving = '';
    }
  }

  btnRenameActiveProject?.addEventListener('click', () => {
    if (topRenameInput && !topRenameInput.classList.contains('hidden')) {
      finishTopbarProjectRename(true);
    } else {
      openTopbarProjectRename();
    }
  });

  topRenameInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      finishTopbarProjectRename(true);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      topRenameInput.dataset.cancelling = '1';
      finishTopbarProjectRename(false);
    }
  });

  topRenameInput?.addEventListener('blur', () => {
    if (topRenameInput.dataset.cancelling === '1') {
      topRenameInput.dataset.cancelling = '';
      return;
    }
    finishTopbarProjectRename(true);
  });

  // Nút duy nhất Quản lý tài khoản & Token trên Topbar
  document.getElementById('btnOpenAccountModal')?.addEventListener('click', () => {
    renderAccountsModalList();
    document.getElementById('accountModal')?.classList.remove('hidden');
  });

  document.getElementById('topAccountQuotaClickArea')?.addEventListener('click', () => {
    renderAccountsModalList();
    document.getElementById('accountModal')?.classList.remove('hidden');
  });

  document.getElementById('btnSyncQuotaTop')?.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!state.activeAccount) return;
    await syncAccountQuotaFromUi(state.activeAccount.id, e.currentTarget);
  });

  document.getElementById('btnSyncAllAccountsQuota')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const targets = state.accounts.filter((a) => a.connected || a.loginVerified);
    if (targets.length === 0) {
      showToast('Chưa có tài khoản nào đăng nhập để cập nhật Token!', 'error');
      return;
    }
    btn.disabled = true;
    try {
      showToast(`🔄 Đang đồng bộ Token cho ${targets.length} tài khoản...`, 'info');
      let okCount = 0;
      for (const acc of targets) {
        try {
          await apiFetch(`/api/accounts/${acc.id}/sync-usage`, {
            method: 'POST',
            body: JSON.stringify({ forceConnect: true })
          });
          okCount++;
        } catch (_) {}
      }
      await loadAppState();
      showToast(`✅ Đã cập nhật số dư Token cho ${okCount}/${targets.length} tài khoản!`, 'success');
    } finally {
      btn.disabled = false;
    }
  });

  document.getElementById('btnCreateAndConnectAcc').addEventListener('click', async () => {
    const nameInput = document.getElementById('newAccName');
    const proxyInput = document.getElementById('newAccProxy');
    try {
      const res = await apiFetch('/api/accounts', {
        method: 'POST',
        body: JSON.stringify({
          name: nameInput.value.trim(),
          proxy: proxyInput ? proxyInput.value.trim() : '',
          autoLaunch: false
        })
      });
      nameInput.value = '';
      if (proxyInput) proxyInput.value = '';
      await loadAppState();
      showToast(`Đã tạo "${res.account.name}"! Nhập Email/OTP ngay trên bảng đăng nhập.`, 'success');
      openInAppLoginModal(res.account.id, { resetToStart: true });
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('accountsModalList').addEventListener('click', async (e) => {
    const editIcon = e.target.closest('[data-focus-rename]');
    if (editIcon) {
      const accId = editIcon.dataset.focusRename;
      const inp = document.querySelector(`input[data-rename-acc-id="${accId}"]`);
      if (inp) {
        inp.focus();
        inp.select();
      }
      return;
    }

    const btn = e.target.closest('button[data-modal-action]');
    if (!btn) return;
    const action = btn.dataset.modalAction;
    const id = btn.dataset.id;

    try {
      if (action === 'switch-acc') {
        await apiFetch('/api/accounts/select', {
          method: 'POST',
          body: JSON.stringify({ accountId: id })
        });
        await loadAppState();
        showToast('Đã chuyển dự án!', 'info');
      } else if (action === 'sync-quota') {
        await syncAccountQuotaFromUi(id, btn);
      } else if (action === 'inapp-login') {
        openInAppLoginModal(id);
      } else if (action === 'reset-acc') {
        await confirmAndResetAccount(id, btn.dataset.name || id);
      } else if (action === 'save-proxy') {
        const proxyInp = document.querySelector(`input[data-proxy-for="${id}"]`);
        const rawProxy = proxyInp ? proxyInp.value.trim() : '';
        btn.disabled = true;
        try {
          const res = await apiFetch(`/api/accounts/${id}/proxy`, {
            method: 'PUT',
            body: JSON.stringify({ proxy: rawProxy })
          });
          await loadAppState();
          showToast(res.message, 'success');
        } finally {
          btn.disabled = false;
        }
      }
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('accountsModalList').addEventListener('focusin', (e) => {
    const renameInp = e.target.closest('input[data-rename-acc-id]');
    if (renameInp) {
      renameInp.select();
    }
  });

  document.getElementById('accountsModalList').addEventListener('keydown', (e) => {
    const renameInp = e.target.closest('input[data-rename-acc-id]');
    if (renameInp) {
      if (e.key === 'Enter') {
        e.preventDefault();
        renameInp.blur();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        renameInp.dataset.cancelling = '1';
        renameInp.value = renameInp.dataset.origName || renameInp.value;
        renameInp.blur();
      }
      return;
    }

    if (e.key === 'Enter') {
      const proxyInp = e.target.closest('input[data-proxy-for]');
      if (proxyInp) {
        e.preventDefault();
        const id = proxyInp.dataset.proxyFor;
        document.querySelector(`button[data-modal-action="save-proxy"][data-id="${id}"]`)?.click();
      }
    }
  });

  document.getElementById('accountsModalList').addEventListener('focusout', async (e) => {
    const renameInp = e.target.closest('input[data-rename-acc-id]');
    if (!renameInp) return;
    if (renameInp.dataset.cancelling === '1') {
      renameInp.dataset.cancelling = '';
      return;
    }
    if (renameInp.dataset.saving === '1') return;

    const accId = renameInp.dataset.renameAccId;
    const origName = renameInp.dataset.origName || '';
    const nextName = renameInp.value.trim();

    if (!nextName) {
      renameInp.value = origName;
      return;
    }
    if (nextName === origName) return;

    renameInp.dataset.saving = '1';
    try {
      await saveAccountProjectName(accId, nextName);
    } catch (err) {
      renameInp.value = origName;
      showToast(err.message, 'error');
    } finally {
      renameInp.dataset.saving = '';
    }
  });

  // Cấu hình Sidebar
  document.getElementById('aspectRatioGroup').addEventListener('click', (e) => {
    const btn = e.target.closest('.ratio-btn');
    if (!btn) return;
    saveSidebarSettings({ aspectRatio: btn.dataset.ratio });
  });

  document.getElementById('durationGroup').addEventListener('click', async (e) => {
    const btn = e.target.closest('.pill-btn');
    if (!btn) return;
    const sec = parseDurationToSeconds(btn.dataset.duration);
    const selectDurUnit = document.getElementById('selectDurationUnit');
    const inputCustomDur = document.getElementById('inputCustomDuration');
    if (selectDurUnit && inputCustomDur) {
      if (sec >= 60 && sec % 60 === 0 && selectDurUnit.value === 'min') {
        inputCustomDur.value = sec / 60;
      } else {
        selectDurUnit.value = 'sec';
        inputCustomDur.value = sec;
      }
    }
    await saveSidebarSettings({ duration: `${sec}s` });
    if ((state.activeAccount?.rows || []).some((r) => (r.referenceImages || []).filter(Boolean).length >= 2)) {
      renderFlowRows();
    } else {
      refreshAllRowDialogueBadges();
    }
  });

  const applyCustomDurationFromInput = async () => {
    const inputEl = document.getElementById('inputCustomDuration');
    const unitEl = document.getElementById('selectDurationUnit');
    if (!inputEl) return;
    const maxSec = getMaxAllowedRowDurationSec();
    const rawNum = parseFloat(String(inputEl.value || '').replace(',', '.'));
    if (!Number.isFinite(rawNum) || rawNum <= 0) {
      showToast(
        isFilmmakingMode()
          ? 'Vui lòng nhập thời lượng phân cảnh hợp lệ (từ 5 giây)!'
          : 'Vui lòng nhập thời lượng hợp lệ (từ 5 giây đến tối đa 60 giây)!',
        'error'
      );
      return;
    }
    const unit = unitEl ? unitEl.value : 'sec';
    const rawSeconds = unit === 'min' ? rawNum * 60 : rawNum;
    const wasOverAffiliateCap = !isFilmmakingMode() && rawSeconds > 60;
    const clampedSec = Math.max(5, Math.min(maxSec, Math.round(rawSeconds)));
    inputEl.value = unit === 'min' ? Number((clampedSec / 60).toFixed(2)) : clampedSec;
    await saveSidebarSettings({ duration: `${clampedSec}s` });
    if ((state.activeAccount?.rows || []).some((r) => (r.referenceImages || []).filter(Boolean).length >= 2)) {
      renderFlowRows();
    } else {
      refreshAllRowDialogueBadges();
    }
    if (wasOverAffiliateCap) {
      showToast(
        '🛍️ Chế độ Affiliate giới hạn tối đa 60s (1 phút)! Để sản xuất video dài hơn, hãy chuyển sang "🎬 Chế Độ Làm Phim".',
        'info'
      );
    } else {
      showToast(`⏱ Đã đặt thời lượng: ${formatDurationBadgeSummary(clampedSec)}!`, 'success');
    }
  };

  document.getElementById('btnApplyCustomDuration')?.addEventListener('click', applyCustomDurationFromInput);
  document.getElementById('inputCustomDuration')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      applyCustomDurationFromInput();
    }
  });
  document.getElementById('selectDurationUnit')?.addEventListener('change', (e) => {
    const inputEl = document.getElementById('inputCustomDuration');
    if (!inputEl) return;
    const maxSec = getMaxAllowedRowDurationSec();
    const val = parseFloat(String(inputEl.value || '').replace(',', '.'));
    if (Number.isFinite(val) && val > 0) {
      if (e.target.value === 'min') {
        inputEl.value = Number((val / 60).toFixed(2));
      } else {
        inputEl.value = Math.max(5, Math.min(maxSec, Math.round(val * 60)));
      }
    }
    inputEl.focus();
  });

  document.getElementById('selectResolution').addEventListener('change', (e) => {
    saveSidebarSettings({ resolution: e.target.value });
  });

  document.getElementById('selectCameraMotion').addEventListener('change', (e) => {
    saveSidebarSettings({ cameraMotion: e.target.value });
  });

  document.getElementById('selectTransitionEffect')?.addEventListener('change', (e) => {
    saveSidebarSettings({ transitionEffect: e.target.value });
    showToast('Đã cập nhật hiệu ứng chuyển cảnh!', 'info');
  });

  document.getElementById('chkEnableDialogue')?.addEventListener('change', async (e) => {
    const enabled = Boolean(e.target.checked);
    await saveSidebarSettings({ enableDialogue: enabled });
    refreshAllRowDialogueBadges();
    showToast(enabled ? '🎙️ Đã bật lời thoại nhân vật!' : '🔇 Đã tắt lời thoại nhân vật!', 'info');
  });

  document.getElementById('selectVoicePreset')?.addEventListener('change', async (e) => {
    const presetVal = e.target.value || 'auto';
    const noteEl = document.getElementById('inputVoiceCustomNote');
    if (noteEl) {
      noteEl.placeholder =
        presetVal === 'custom'
          ? 'Nhập mô tả chất giọng riêng (VD: Nữ 25 tuổi giọng Hà Nội trầm ấm, nói chậm rãi...)'
          : 'Ghi chú giọng chung (VD: nói chậm rãi, truyền cảm, nhấn nhá tự nhiên...)';
      if (presetVal === 'custom') noteEl.focus();
    }
    await saveSidebarSettings({ voicePreset: presetVal });
    showToast('🎙️ Đã cập nhật giọng đọc chung cho tất cả các hàng!', 'success');
  });

  document.getElementById('inputVoiceCustomNote')?.addEventListener('input', (e) => {
    const val = e.target.value || '';
    if (voiceNoteSaveTimer) clearTimeout(voiceNoteSaveTimer);
    voiceNoteSaveTimer = setTimeout(() => {
      saveSidebarSettings({ voiceCustomNote: val });
    }, 400);
  });

  document.getElementById('inputVoiceCustomNote')?.addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (voiceNoteSaveTimer) clearTimeout(voiceNoteSaveTimer);
      await saveSidebarSettings({ voiceCustomNote: e.target.value || '' });
      showToast('🎙️ Đã lưu ghi chú chất giọng chung!', 'success');
    }
  });

  // Video mẫu tham chiếu (Chung ở Sidebar + 3 nút tích lọc)
  const globalSampleBox = document.getElementById('globalSampleVideoBox');
  if (globalSampleBox) {
    globalSampleBox.addEventListener('click', async (e) => {
      const target = e.target.closest('[data-sample-global]');
      if (!target) return;
      const act = target.dataset.sampleGlobal;
      if (act === 'pick') {
        openGlobalSampleVideoPicker();
      } else if (act === 'remove') {
        e.stopPropagation();
        await removeGlobalSampleVideo();
      } else if (act === 'preview') {
        e.stopPropagation();
        const globalVid = state.activeAccount?.settings?.sampleVideo;
        if (globalVid) {
          previewSampleVideoModal(globalVid, `🎬 VIDEO MẪU CHUNG — ${state.activeAccount?.name || ''}`);
        }
      }
    });

    globalSampleBox.addEventListener('dragover', (e) => {
      e.preventDefault();
      globalSampleBox.classList.add('drag-over');
    });
    globalSampleBox.addEventListener('dragleave', (e) => {
      if (!globalSampleBox.contains(e.relatedTarget)) {
        globalSampleBox.classList.remove('drag-over');
      }
    });
    globalSampleBox.addEventListener('drop', async (e) => {
      e.preventDefault();
      globalSampleBox.classList.remove('drag-over');
      const vidFiles = Array.from(e.dataTransfer?.files || []).filter((f) => isVideoFileObj(f));
      if (vidFiles.length > 0) {
        await uploadGlobalSampleVideo(vidFiles[0]);
      } else {
        showToast('Hãy kéo thả tệp Video (.mp4, .mov, .webm) vào ô Video mẫu chung!', 'error');
      }
    });
  }

  document.getElementById('chkSampleLearnMotion')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnMotion: e.target.checked });
    showToast(
      e.target.checked ? '✅ Đã bật Học cử chỉ & chuyển động từ Video mẫu' : 'Đã tắt Học cử chỉ & chuyển động',
      'info'
    );
  });

  document.getElementById('chkSampleLearnCamera')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnCamera: e.target.checked });
    showToast(
      e.target.checked ? '✅ Đã bật Học góc máy & Camera từ Video mẫu' : 'Đã tắt Học góc máy & Camera',
      'info'
    );
  });

  document.getElementById('chkSampleLearnScene')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnScene: e.target.checked });
    showToast(
      e.target.checked
        ? '✅ Đã bật Học bối cảnh & ánh sáng theo Video mẫu'
        : '🔒 Đã tắt Học bối cảnh — Sẽ giữ nguyên 100% nền gốc trong ảnh nhân vật!',
      'info'
    );
  });

  // Số luồng song song & Số hàng
  const applyConcurrencyValue = (rawVal) => {
    const threads = Math.max(1, Math.min(20, Number(rawVal) || 6));
    const inputConc = document.getElementById('inputConcurrency');
    if (inputConc) inputConc.value = threads;
    saveSidebarSettings({ concurrency: threads });
    showToast(`Đã đặt ${threads} luồng song song!`, 'success');
  };

  document.getElementById('btnApplyConcurrency').addEventListener('click', () => {
    applyConcurrencyValue(document.getElementById('inputConcurrency')?.value);
  });

  document.getElementById('inputConcurrency')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      applyConcurrencyValue(e.target.value);
    }
  });

  document.querySelectorAll('#concurrencyPresetGroup .preset-chip').forEach((chip) => {
    chip.addEventListener('click', () => applyConcurrencyValue(chip.dataset.threads));
  });

  document.getElementById('btnApplyRowCount').addEventListener('click', () => {
    const count = Number(document.getElementById('inputRowCount').value) || 10;
    saveSidebarSettings({ rowCount: count });
    showToast(`Đã đặt ${count} hàng!`, 'info');
  });

  document.querySelectorAll('#rowPresetGroup .preset-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const count = Number(chip.dataset.rows) || 10;
      document.getElementById('inputRowCount').value = count;
      saveSidebarSettings({ rowCount: count });
    });
  });

  // Thanh công cụ Action Ribbon
  document.getElementById('btnBulkUploadImages').addEventListener('click', () => openBulkImagePicker(1));
  document.getElementById('btnOpenBulkPromptModal').addEventListener('click', () => {
    document.getElementById('bulkPromptModal').classList.remove('hidden');
  });

  document.getElementById('btnOpenCapcutEditor').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const allRows = state.activeAccount.rows || [];
    const chosenIndices = [...state.selectedRows].sort((a, b) => a - b);
    const chosenRowsWithVideo = chosenIndices
      .map((idx) => allRows.find((r) => r.index === idx))
      .filter((r) => r && r.videoUrl);

    await openCapcutEditorModal({
      initialRows: chosenRowsWithVideo,
      singleRowTarget: chosenRowsWithVideo.length === 1 ? chosenRowsWithVideo[0].index : null
    });
  });

  document.getElementById('selectBulkImportMode')?.addEventListener('change', (e) => {
    const mode = e.target.value || 'prompt';
    const ta = document.getElementById('bulkPromptTextarea');
    const helpEl = document.getElementById('bulkModalHelpText');
    if (!ta || !helpEl) return;
    if (mode === 'dialogue') {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng Lời thoại. Với video dài ≥20s, đặt từng câu trong "..." trên cùng 1 dòng để tự gán riêng từng phần 10s!';
      ta.placeholder =
        'Hàng 1: "Xin chào mọi người, hôm nay mình giới thiệu mẫu đầm mới..." "Chất vải lụa mềm mát, lên dáng cực xinh!"\nHàng 2: "Các chị bấm ngay vào giỏ hàng góc trái màn hình nhé!"';
    } else if (mode === 'both') {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng theo cú pháp: Chuyển động || Lời thoại (ngăn cách bởi dấu ||).';
      ta.placeholder =
        'Nhân vật bước đi tự tin, mỉm cười trước ống kính || "Xin chào mọi người, cùng xem thiết kế mới nhất hôm nay nhé!" "Form dáng chuẩn từng đường kim mũi chỉ luôn ạ!"\nNhân vật xoay nhẹ khoe tà váy, ánh sáng studio || "Số lượng ưu đãi có hạn, đặt ngay hôm nay nhé!"';
    } else {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng Prompt chuyển động. Tự động thêm hàng mới nếu vượt quá số hàng hiện tại.';
      ta.placeholder =
        'Dòng 1: Nhân vật bước đi tự tin, góc máy lia chậm...\nDòng 2: Nhân vật mỉm cười nhẹ nhàng, ánh sáng điện ảnh...';
    }
  });

  document.getElementById('btnConfirmBulkPrompts').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const raw = document.getElementById('bulkPromptTextarea').value || '';
    const mode = document.getElementById('selectBulkImportMode')?.value || 'prompt';
    const lines = raw
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) {
      showToast('Hãy nhập ít nhất 1 dòng nội dung!', 'error');
      return;
    }

    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/bulk-prompts`, {
        method: 'POST',
        body: JSON.stringify({ prompts: lines, mode })
      });
      document.getElementById('bulkPromptModal').classList.add('hidden');
      await loadAppState();
      showToast(res.message || `Đã điền ${lines.length} dòng thành công!`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Cấu hình nâng cao
  document.getElementById('btnSaveSelectors').addEventListener('click', () => {
    saveSidebarSettings({
      targetUrl: document.getElementById('inputTargetUrl').value.trim() || 'https://muse.ai',
      customSelectors: {
        fileInput: document.getElementById('inputSelFile').value.trim(),
        promptInput: document.getElementById('inputSelPrompt').value.trim(),
        submitButton: document.getElementById('inputSelSubmit').value.trim()
      }
    });
    showToast('Đã lưu cấu hình!', 'success');
  });

  document.getElementById('btnInspectDom').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const modal = document.getElementById('domInspectorModal');
    const out = document.getElementById('domInspectorOutput');
    modal.classList.remove('hidden');
    out.textContent = 'Đang quét...';
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/inspect-dom`);
      out.textContent = JSON.stringify(res.report, null, 2);
    } catch (err) {
      out.textContent = `Lỗi: ${err.message}`;
    }
  });

  // Thao tác trên từng hàng
  document.getElementById('flowRowsContainer').addEventListener('click', async (e) => {
    const target = e.target.closest('[data-action]');
    if (!target || !state.activeAccount) return;

    const action = target.dataset.action;
    const rowIndex = Number(target.dataset.row);
    const slotIndex = Number(target.dataset.slot);

    if (action === 'pick-ref') {
      openFilePickerForSlot(rowIndex, slotIndex);
    } else if (action === 'replace-ref') {
      e.stopPropagation();
      openReplaceSingleSlotPicker(rowIndex, slotIndex);
    } else if (action === 'append-row-refs') {
      e.stopPropagation();
      openAppendRowImagesPicker(rowIndex);
    } else if (action === 'toggle-multi-ref-mode') {
      e.stopPropagation();
      const rowObj = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!rowObj) return;
      const curEffective = resolveClientRowMultiRefMode(rowObj);
      const nextMode = curEffective === 'multi_outfit' ? 'multi_angle' : 'multi_outfit';
      rowObj.multiRefMode = nextMode;
      updateSingleRowDom(rowObj);
      await saveRowFields(rowIndex, { multiRefMode: nextMode });
      showToast(
        nextMode === 'multi_angle'
          ? `📐 Hàng #${rowIndex}: Đã chuyển sang chế độ Đa góc nhìn (AI hiểu nhiều góc SP/Nhân vật, không biến hình)!`
          : `🪭 Hàng #${rowIndex}: Đã chuyển sang chế độ Biến hình thay nhiều bộ trang phục!`,
        'success'
      );
    } else if (action === 'apply-recommended-dur') {
      e.stopPropagation();
      const maxSec = getMaxAllowedRowDurationSec();
      const recSec = Math.max(10, Math.min(maxSec, Number(target.dataset.sec) || 30));
      await saveSidebarSettings({ duration: `${recSec}s` });
      renderFlowRows();
      showToast(`⚡ Đã đặt thời lượng ${recSec}s (${Math.ceil(recSec / 10)} phần) khớp số bộ đồ biến hình!`, 'success');
    } else if (action === 'open-film-cast-from-row') {
      e.stopPropagation();
      openFilmCharactersModal();
    } else if (action === 'toggle-row-cast-char') {
      e.stopPropagation();
      const charId = String(target.dataset.charId || '');
      const charTag = String(target.dataset.charTag || '');
      const rowObj = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!rowObj || !charId) return;

      if (e.shiftKey && charTag) {
        const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
        if (dlgEl) {
          const prefix = `[${charTag}]: `;
          const cur = dlgEl.value.trim();
          const nextDlg = cur ? `${cur}\n${prefix}` : prefix;
          dlgEl.value = nextDlg;
          rowObj.dialogue = nextDlg;
          refreshRowDialogueBadge(rowIndex, nextDlg);
          await saveRowFields(rowIndex, { dialogue: nextDlg });
          dlgEl.focus();
        }
      }

      const curIds = new Set(Array.isArray(rowObj.sceneCharacterIds) ? rowObj.sceneCharacterIds : []);
      if (curIds.has(charId) && !e.shiftKey) {
        curIds.delete(charId);
      } else {
        curIds.add(charId);
      }
      const nextList = Array.from(curIds);
      rowObj.sceneCharacterIds = nextList;
      updateSingleRowDom(rowObj);
      await saveRowFields(rowIndex, { sceneCharacterIds: nextList });
    } else if (action === 'auto-quote-dialogue') {
      e.stopPropagation();
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      if (!dlgEl) return;
      const durSec = parseDurationToSeconds(state.activeAccount.settings?.duration || '10s');
      const totalParts = durSec > 10 ? Math.ceil(durSec / 10) : 1;
      const formatted = formatDialogueIntoQuotedParts(dlgEl.value, totalParts);
      dlgEl.value = formatted;
      const rowObj = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (rowObj) rowObj.dialogue = formatted;
      refreshRowDialogueBadge(rowIndex, formatted);
      await saveRowFields(rowIndex, { dialogue: formatted });
      dlgEl.focus();
      const qCount = extractQuotedListClient(formatted).length;
      showToast(
        totalParts > 1
          ? `✂️ Đã tự chia thành ${qCount} câu "..." khớp các phân đoạn 10s của Hàng #${rowIndex}!`
          : `✂️ Đã chuẩn hóa câu thoại "..." cho Hàng #${rowIndex}!`,
        'success'
      );
    } else if (action === 'remove-ref') {
      e.stopPropagation();
      await removeReferenceImage(rowIndex, slotIndex);
    } else if (action === 'pick-row-sample') {
      e.stopPropagation();
      openRowSampleVideoPicker(rowIndex);
    } else if (action === 'remove-row-sample') {
      e.stopPropagation();
      await removeRowSampleVideo(rowIndex);
    } else if (action === 'preview-row-sample') {
      e.stopPropagation();
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (row && row.sampleVideo) {
        previewSampleVideoModal(
          row.sampleVideo,
          `🎬 VIDEO MẪU RIÊNG HÀNG #${String(rowIndex).padStart(2, '0')} — ${state.activeAccount.name}`
        );
      }
    } else if (action === 'run-row') {
      const promptEl = document.getElementById(`row-prompt-${rowIndex}`);
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      const patch = {};
      if (promptEl) patch.prompt = promptEl.value;
      if (dlgEl) patch.dialogue = dlgEl.value;
      if (Object.keys(patch).length > 0) await saveRowFields(rowIndex, patch);
      try {
        const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/run`, {
          method: 'POST'
        });
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    } else if (action === 'regen-row') {
      const promptEl = document.getElementById(`row-prompt-${rowIndex}`);
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      const patch = {};
      if (promptEl) patch.prompt = promptEl.value;
      if (dlgEl) patch.dialogue = dlgEl.value;
      if (Object.keys(patch).length > 0) await saveRowFields(rowIndex, patch);
      try {
        const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/regenerate`, {
          method: 'POST'
        });
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    } else if (action === 'edit-capcut-row') {
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!row || !row.videoUrl) return;
      await openCapcutEditorModal({ initialRows: [row], singleRowTarget: row.index });
    } else if (action === 'preview-video') {
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!row || !row.videoUrl) return;
      const modal = document.getElementById('videoPreviewModal');
      const player = document.getElementById('previewModalPlayer');
      const title = document.getElementById('previewModalTitle');
      const meta = document.getElementById('previewModalMeta');
      title.textContent = `🎬 HÀNG #${String(rowIndex).padStart(2, '0')} — ${state.activeAccount.name}`;
      player.src = row.videoUrl;
      const metaParts = [];
      if (row.prompt) metaParts.push(`🎬 Chuyển động: ${row.prompt}`);
      if (row.dialogue) metaParts.push(`🎙️ Lời thoại: ${row.dialogue}`);
      meta.textContent = metaParts.join('  •  ');
      modal.classList.remove('hidden');
    } else if (action === 'download-video') {
      const downloadUrl = `/api/download-video?accountId=${encodeURIComponent(state.activeAccount.id)}&rowIndex=${rowIndex}`;
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `MuseFlow_Row_${rowIndex}.mp4`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  });

  // Chạy tất cả / Dừng
  document.getElementById('btnRunAllBatch').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/batch/start`, {
        method: 'POST',
        body: JSON.stringify({ forceAll: false })
      });
      state.batchStats = res.stats;
      renderBatchMonitor();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnStopBatch').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      await apiFetch(`/api/accounts/${state.activeAccount.id}/batch/stop`, { method: 'POST' });
      showToast('Đã dừng chạy hàng loạt.', 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Bàn dựng CapCut Studio
  const capcutPlayer = document.getElementById('capcutPreviewPlayer');
  const playheadSlider = document.getElementById('capcutPlayheadSlider');

  document.getElementById('capcutSourceRowsList')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-add-row]');
    if (!btn || !state.activeAccount) return;
    const rowIdx = Number(btn.dataset.addRow);
    const row = state.activeAccount.rows.find((r) => r.index === rowIdx);
    if (!row || !row.videoUrl) return;

    const clip = await createClipFromRow(row);
    capcutState.clips.push(clip);
    capcutState.activeClipId = clip.id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutAddAllRows')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const rows = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
    if (rows.length === 0) {
      showToast('Chưa có hàng nào có video!', 'error');
      return;
    }
    for (const r of rows) {
      capcutState.clips.push(await createClipFromRow(r));
    }
    if (!capcutState.activeClipId && capcutState.clips[0]) {
      capcutState.activeClipId = capcutState.clips[0].id;
    }
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('capcutTimelineTrack')?.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('button[data-remove-clip]');
    if (removeBtn) {
      e.stopPropagation();
      const id = removeBtn.dataset.removeClip;
      capcutState.clips = capcutState.clips.filter((c) => c.id !== id);
      if (capcutState.activeClipId === id) {
        capcutState.activeClipId = capcutState.clips[0]?.id || null;
        loadActiveClipIntoPlayer(false);
      }
      renderCapcutAll();
      return;
    }

    const card = e.target.closest('.timeline-clip-card');
    if (card && card.dataset.clipId) {
      capcutState.playingAll = false;
      capcutState.activeClipId = card.dataset.clipId;
      renderCapcutAll();
      loadActiveClipIntoPlayer(false);
    }
  });

  document.getElementById('btnCapcutClearTimeline')?.addEventListener('click', () => {
    capcutState.clips = [];
    capcutState.activeClipId = null;
    capcutState.playingAll = false;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutPlayPause')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    capcutState.playingAll = false;
    if (capcutPlayer.paused) {
      if (capcutPlayer.currentTime < clip.startTime || capcutPlayer.currentTime >= clip.endTime - 0.05) {
        capcutPlayer.currentTime = clip.startTime;
      }
      capcutPlayer.play().catch(() => {});
    } else {
      capcutPlayer.pause();
    }
  });

  document.getElementById('btnCapcutPlayAll')?.addEventListener('click', () => {
    if (capcutState.clips.length === 0) return;
    capcutState.playingAll = true;
    capcutState.activeClipId = capcutState.clips[0].id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(true);
  });

  if (capcutPlayer) {
    capcutPlayer.addEventListener('play', () => {
      const btn = document.getElementById('btnCapcutPlayPause');
      if (btn) btn.textContent = '⏸ Tạm dừng';
    });
    capcutPlayer.addEventListener('pause', () => {
      const btn = document.getElementById('btnCapcutPlayPause');
      if (btn) btn.textContent = '▶ Phát đoạn';
    });
    capcutPlayer.addEventListener('timeupdate', () => {
      const clip = getActiveCapcutClip();
      if (!clip) return;
      const cur = capcutPlayer.currentTime;
      if (playheadSlider) playheadSlider.value = String(cur);
      const curLabel = document.getElementById('capcutCurrentTimeLabel');
      if (curLabel) curLabel.textContent = formatTimeSec(cur);

      if (cur >= clip.endTime - 0.03) {
        if (capcutState.playingAll) {
          const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
          if (idx !== -1 && idx + 1 < capcutState.clips.length) {
            capcutState.activeClipId = capcutState.clips[idx + 1].id;
            renderCapcutAll();
            loadActiveClipIntoPlayer(true);
            return;
          }
        }
        capcutState.playingAll = false;
        capcutPlayer.pause();
        capcutPlayer.currentTime = clip.endTime;
      }
    });
    capcutPlayer.addEventListener('ended', () => {
      const clip = getActiveCapcutClip();
      if (capcutState.playingAll && clip) {
        const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
        if (idx !== -1 && idx + 1 < capcutState.clips.length) {
          capcutState.activeClipId = capcutState.clips[idx + 1].id;
          renderCapcutAll();
          loadActiveClipIntoPlayer(true);
          return;
        }
      }
      capcutState.playingAll = false;
    });
  }

  playheadSlider?.addEventListener('input', (e) => {
    const val = Number(e.target.value) || 0;
    if (capcutPlayer) capcutPlayer.currentTime = val;
    const curLabel = document.getElementById('capcutCurrentTimeLabel');
    if (curLabel) curLabel.textContent = formatTimeSec(val);
  });

  document.getElementById('btnCapcutSetIn')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const t = Number(capcutPlayer.currentTime.toFixed(2));
    if (t >= clip.endTime - 0.2) {
      showToast('Điểm đầu phải nhỏ hơn điểm cuối ít nhất 0.2s!', 'error');
      return;
    }
    clip.startTime = Math.max(0, t);
    renderCapcutAll();
  });

  document.getElementById('btnCapcutSetOut')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const t = Number(capcutPlayer.currentTime.toFixed(2));
    if (t <= clip.startTime + 0.2) {
      showToast('Điểm cuối phải lớn hơn điểm đầu ít nhất 0.2s!', 'error');
      return;
    }
    clip.endTime = Math.min(clip.sourceDuration || 10, t);
    renderCapcutAll();
  });

  document.getElementById('btnCapcutSplitClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const splitPoint = Number(capcutPlayer.currentTime.toFixed(2));
    if (splitPoint <= clip.startTime + 0.25 || splitPoint >= clip.endTime - 0.25) {
      showToast('Di chuyển kim phát vào giữa đoạn để tách đôi!', 'error');
      return;
    }

    const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
    if (idx === -1) return;

    const secondHalf = {
      ...clip,
      id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      startTime: splitPoint,
      endTime: clip.endTime
    };
    clip.endTime = splitPoint;

    capcutState.clips.splice(idx + 1, 0, secondHalf);
    capcutState.activeClipId = secondHalf.id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
    showToast(`Đã tách đôi tại mốc ${splitPoint.toFixed(1)}s!`, 'success');
  });

  const syncClipTrimStart = (rawVal) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const v = Math.max(0, Math.min(clip.endTime - 0.2, Number(rawVal) || 0));
    clip.startTime = Number(v.toFixed(2));
    if (capcutPlayer) capcutPlayer.currentTime = clip.startTime;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  };

  const syncClipTrimEnd = (rawVal) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const maxDur = clip.sourceDuration || 10;
    const v = Math.min(maxDur, Math.max(clip.startTime + 0.2, Number(rawVal) || maxDur));
    clip.endTime = Number(v.toFixed(2));
    if (capcutPlayer) capcutPlayer.currentTime = clip.endTime;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  };

  document.getElementById('sliderCapcutTrimStart')?.addEventListener('input', (e) => syncClipTrimStart(e.target.value));
  document.getElementById('inputCapcutTrimStart')?.addEventListener('change', (e) => syncClipTrimStart(e.target.value));
  document.getElementById('sliderCapcutTrimEnd')?.addEventListener('input', (e) => syncClipTrimEnd(e.target.value));
  document.getElementById('inputCapcutTrimEnd')?.addEventListener('change', (e) => syncClipTrimEnd(e.target.value));

  document.getElementById('selectCapcutClipSpeed')?.addEventListener('change', (e) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.speed = Number(e.target.value) || 1;
    if (capcutPlayer) capcutPlayer.playbackRate = clip.speed;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  });

  document.getElementById('btnCapcutToggleMute')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.muted = !clip.muted;
    if (capcutPlayer) capcutPlayer.muted = clip.muted;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  });

  document.getElementById('btnCapcutMoveLeft')?.addEventListener('click', () => {
    const idx = capcutState.clips.findIndex((c) => c.id === capcutState.activeClipId);
    if (idx > 0) {
      const [item] = capcutState.clips.splice(idx, 1);
      capcutState.clips.splice(idx - 1, 0, item);
      renderCapcutAll();
    }
  });

  document.getElementById('btnCapcutMoveRight')?.addEventListener('click', () => {
    const idx = capcutState.clips.findIndex((c) => c.id === capcutState.activeClipId);
    if (idx !== -1 && idx < capcutState.clips.length - 1) {
      const [item] = capcutState.clips.splice(idx, 1);
      capcutState.clips.splice(idx + 1, 0, item);
      renderCapcutAll();
    }
  });

  document.getElementById('btnCapcutDuplicateClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
    const copy = { ...clip, id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}` };
    capcutState.clips.splice(idx + 1, 0, copy);
    capcutState.activeClipId = copy.id;
    renderCapcutAll();
  });

  document.getElementById('btnCapcutResetClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.startTime = 0;
    clip.endTime = clip.sourceDuration || 10;
    clip.speed = 1;
    clip.muted = false;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutDeleteClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    capcutState.clips = capcutState.clips.filter((c) => c.id !== clip.id);
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  async function executeCapcutRender(saveToRowIndex = null) {
    if (!state.activeAccount) return;
    if (capcutState.clips.length === 0) {
      showToast('Hãy thêm ít nhất 1 đoạn video vào Timeline!', 'error');
      return;
    }

    const btnExport = document.getElementById('btnCapcutRenderExport');
    const btnSaveRow = document.getElementById('btnCapcutSaveToSingleRow');
    const outputName = document.getElementById('inputCapcutOutputName')?.value || 'Video_Da_Noi';
    const aspectMode = document.getElementById('selectCapcutAspect')?.value || 'auto';

    if (btnExport) btnExport.disabled = true;
    if (btnSaveRow) btnSaveRow.disabled = true;

    try {
      showToast('Đang xuất video...', 'info');
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/video-editor/render`, {
        method: 'POST',
        body: JSON.stringify({
          clips: capcutState.clips,
          outputCustomName: outputName,
          aspectMode,
          transitionEffect: state.activeAccount?.settings?.transitionEffect || 'fade',
          saveToRowIndex
        })
      });

      capcutState.lastExportedResult = res.result;
      const resultBox = document.getElementById('capcutExportResultBox');
      const resultText = document.getElementById('capcutExportResultText');
      const downloadLink = document.getElementById('linkCapcutDownloadExported');

      if (resultBox && res.result) {
        resultBox.classList.remove('hidden');
        if (resultText) {
          resultText.textContent = `✓ Đã xuất: ${res.result.duration}s`;
        }
        if (downloadLink) {
          downloadLink.href = saveToRowIndex
            ? `/api/download-video?accountId=${encodeURIComponent(state.activeAccount.id)}&rowIndex=${saveToRowIndex}`
            : `/api/download-merged?accountId=${encodeURIComponent(state.activeAccount.id)}&fileName=${encodeURIComponent(
                res.result.fileName
              )}`;
          downloadLink.download = res.result.fileName;
        }
      }

      if (saveToRowIndex) await loadAppState();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(`Lỗi xuất video: ${err.message}`, 'error');
    } finally {
      if (btnExport) btnExport.disabled = false;
      if (btnSaveRow) btnSaveRow.disabled = false;
    }
  }

  document.getElementById('btnCapcutRenderExport')?.addEventListener('click', () => executeCapcutRender(null));
  document.getElementById('btnCapcutSaveToSingleRow')?.addEventListener('click', (e) => {
    const targetRow = Number(e.currentTarget.dataset.targetRow);
    if (targetRow) executeCapcutRender(targetRow);
  });

  document.getElementById('btnCapcutPreviewExported')?.addEventListener('click', () => {
    const r = capcutState.lastExportedResult;
    if (!r || !r.publicUrl) return;
    if (capcutPlayer) capcutPlayer.pause();
    const modal = document.getElementById('videoPreviewModal');
    const player = document.getElementById('previewModalPlayer');
    const title = document.getElementById('previewModalTitle');
    const meta = document.getElementById('previewModalMeta');
    title.textContent = `🎬 VIDEO ĐÃ XUẤT (${r.duration}s)`;
    player.src = `${r.publicUrl}?t=${Date.now()}`;
    meta.textContent = `${r.width}x${r.height} • ${r.clipCount} đoạn`;
    modal.classList.remove('hidden');
  });

  // ==================== HƯỚNG DẪN, SKILL AI & BẢN QUYỀN ====================
  document.getElementById('selectActiveSkill')?.addEventListener('change', async (e) => {
    const chosenId = e.target.value || '';
    await saveSidebarSettings({ activeSkillId: chosenId });
    if ((state.activeAccount?.rows || []).some((r) => (r.referenceImages || []).filter(Boolean).length >= 2)) {
      renderFlowRows();
    }
    const sk = (state.skills || []).find((s) => s.id === chosenId);
    if (sk) {
      showToast(`Đã bật "${sk.name}" cho ${state.activeAccount?.name || 'dự án này'}!`, 'success');
    } else {
      showToast('Đã tắt Skill AI cho dự án này.', 'info');
    }
  });

  document.getElementById('btnOpenSkillModal')?.addEventListener('click', () => {
    resetSkillEditorForm();
    renderSkillsModalList();
    document.getElementById('skillModal')?.classList.remove('hidden');
  });

  document.getElementById('btnClearSkillForm')?.addEventListener('click', () => {
    resetSkillEditorForm();
  });

  document.getElementById('btnTriggerImportSkillFile')?.addEventListener('click', () => {
    const fileInp = document.getElementById('inputSkillFiles');
    if (fileInp) {
      fileInp.value = '';
      fileInp.click();
    }
  });

  document.getElementById('inputSkillFiles')?.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const items = [];
      for (const f of files) {
        const content = await f.text();
        items.push({ fileName: f.name, content });
      }
      const res = await apiFetch('/api/skills/import', {
        method: 'POST',
        body: JSON.stringify({ items })
      });
      state.skills = res.skills || [];
      if (Array.isArray(res.imported) && res.imported.length > 0 && state.activeAccount) {
        await saveSidebarSettings({ activeSkillId: res.imported[0].id });
      }
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message || 'Đã nhập file Skill thành công!', 'success');
    } catch (err) {
      showToast(`Lỗi nhập file Skill: ${err.message}`, 'error');
    }
  });

  document.getElementById('btnRestoreDefaultSkills')?.addEventListener('click', async () => {
    try {
      const res = await apiFetch('/api/skills/restore-defaults', { method: 'POST' });
      state.skills = res.skills || [];
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnSaveAndApplySkill')?.addEventListener('click', async () => {
    const id = document.getElementById('editSkillId')?.value || '';
    const name = document.getElementById('inputSkillName')?.value || '';
    const summary = document.getElementById('inputSkillSummary')?.value || '';
    const instructions = document.getElementById('inputSkillInstructions')?.value || '';

    const btn = document.getElementById('btnSaveAndApplySkill');
    if (btn) btn.disabled = true;

    try {
      const res = await apiFetch('/api/skills', {
        method: 'POST',
        body: JSON.stringify({ id: id || undefined, name, summary, instructions })
      });
      state.skills = res.skills || [];
      if (res.skill && state.activeAccount) {
        await saveSidebarSettings({ activeSkillId: res.skill.id });
      }
      resetSkillEditorForm();
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message || 'Đã lưu và áp dụng Skill!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('skillsModalList')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-skill-action]');
    if (!btn) return;
    const action = btn.dataset.skillAction;
    const skillId = btn.dataset.id;
    const sk = (state.skills || []).find((s) => s.id === skillId);
    if (!sk) return;

    if (action === 'apply') {
      const curId = state.activeAccount?.settings?.activeSkillId || '';
      const nextId = curId === sk.id ? '' : sk.id;
      await saveSidebarSettings({ activeSkillId: nextId });
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(
        nextId ? `Đã áp dụng "${sk.name}" cho ${state.activeAccount?.name}!` : 'Đã bỏ chọn Skill cho dự án này.',
        'success'
      );
    } else if (action === 'edit') {
      document.getElementById('editSkillId').value = sk.id;
      document.getElementById('inputSkillName').value = sk.name || '';
      document.getElementById('inputSkillSummary').value = sk.summary || '';
      document.getElementById('inputSkillInstructions').value = sk.instructions || '';
      const headEl = document.getElementById('skillFormHeading');
      if (headEl) headEl.textContent = `Đang sửa: ${sk.name}`;
      document.getElementById('btnClearSkillForm')?.classList.remove('hidden');
      document.getElementById('inputSkillName')?.focus();
    } else if (action === 'export') {
      const mdContent = [
        '---',
        `name: "${String(sk.name || '').replace(/"/g, '\\"')}"`,
        `description: "${String(sk.summary || '').replace(/"/g, '\\"')}"`,
        '---',
        '',
        sk.instructions || ''
      ].join('\n');
      const blob = new Blob([mdContent], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safeSlug = String(sk.name || 'SKILL')
        .replace(/[^\p{L}\p{N}_-]+/gu, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 45);
      a.href = url;
      a.download = `SKILL_${safeSlug || 'MuseFlow'}.md`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast(`Đã xuất file SKILL_${safeSlug || 'MuseFlow'}.md!`, 'success');
    } else if (action === 'delete') {
      const ok = window.confirm(`Xóa "${sk.name}" khỏi thư viện Skill?`);
      if (!ok) return;
      try {
        const res = await apiFetch(`/api/skills/${encodeURIComponent(sk.id)}`, { method: 'DELETE' });
        state.skills = res.skills || [];
        if (res.activeAccount) state.activeAccount = res.activeAccount;
        renderSkillSelectorAndBadge();
        renderSkillsModalList();
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    }
  });

  document.getElementById('btnGeneratePromptsBySkill')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const activeSkillId = state.activeAccount.settings?.activeSkillId || '';
    if (!activeSkillId) {
      showToast('Hãy chọn 1 Skill AI ở ô bên trên trước khi bấm Viết Prompt Theo Skill!', 'error');
      document.getElementById('selectActiveSkill')?.focus();
      return;
    }

    const rows = state.activeAccount.rows || [];
    const emptyPromptWithImg = rows.filter((r) => {
      const hasImg = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => Boolean(img));
      return hasImg && (!r.prompt || !r.prompt.trim());
    });
    const anyRowWithImgOrPrompt = rows.filter((r) => {
      const hasImg = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => Boolean(img));
      return hasImg || Boolean(r.prompt && r.prompt.trim());
    });

    if (anyRowWithImgOrPrompt.length === 0) {
      showToast('Hãy thêm ảnh tham chiếu (hoặc gợi ý ngắn) vào các hàng trước!', 'error');
      return;
    }

    let overwriteExisting = false;
    if (emptyPromptWithImg.length === 0) {
      const confirmOverwrite = window.confirm(
        'Các hàng có ảnh đều đã có sẵn Prompt. Bạn có muốn AI viết lại Prompt mới theo Skill đè lên các hàng hiện tại không?'
      );
      if (!confirmOverwrite) return;
      overwriteExisting = true;
    }

    state.skillPromptRunning = true;
    renderSkillAutoPromptButtons({ completed: 0, total: overwriteExisting ? anyRowWithImgOrPrompt.length : emptyPromptWithImg.length });

    try {
      showToast('🧠 Đang gửi ảnh & Skill lên Muse.ai để tự động viết Prompt...', 'info');
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/skills/generate-prompts`, {
        method: 'POST',
        body: JSON.stringify({ skillId: activeSkillId, overwriteExisting })
      });
      if (res.account) {
        state.activeAccount = res.account;
        renderFlowRows();
      }
      showToast(res.message || 'Đã viết xong Prompt theo Skill!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      state.skillPromptRunning = false;
      renderSkillAutoPromptButtons();
    }
  });

  document.getElementById('btnStopSkillPrompts')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/skills/stop-prompts`, {
        method: 'POST'
      });
      showToast(res.message, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnOpenGuideModal')?.addEventListener('click', () => {
    document.getElementById('guideModal')?.classList.remove('hidden');
  });

  document.getElementById('btnOpenLicenseModal')?.addEventListener('click', () => {
    renderLicenseUI(true);
  });

  document.getElementById('pricingPlansGrid')?.addEventListener('click', (e) => {
    const card = e.target.closest('.pricing-card[data-plan]');
    if (!card) return;
    selectPricingPlan(card.dataset.plan);
  });

  document.getElementById('btnCheckPaymentNow')?.addEventListener('click', () => {
    pollPaymentOrderOnce(true);
  });

  document.getElementById('btnCopyHwid')?.addEventListener('click', async () => {
    const hwid = state.license?.hwid || document.getElementById('inputMachineHwid')?.value || '';
    if (!hwid) return;
    await navigator.clipboard.writeText(hwid).catch(() => {});
    showToast(`Đã copy Mã Máy: ${hwid}`, 'success');
  });

  document.getElementById('btnCopyAmount')?.addEventListener('click', async () => {
    const rawAmt = document.getElementById('payAmountText')?.dataset.rawAmount || '';
    if (!rawAmt) return;
    await navigator.clipboard.writeText(rawAmt).catch(() => {});
    showToast(`Đã copy số tiền: ${rawAmt}`, 'success');
  });

  document.querySelectorAll('[data-copy-target]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const targetEl = document.getElementById(btn.dataset.copyTarget);
      if (!targetEl) return;
      const val = targetEl.dataset.copyValue || targetEl.textContent.trim();
      await navigator.clipboard.writeText(val).catch(() => {});
      showToast(`Đã copy: ${val}`, 'success');
    });
  });

  document.getElementById('btnActivateLicense')?.addEventListener('click', async () => {
    const keyInput = document.getElementById('inputLicenseKey');
    const licenseKey = (keyInput?.value || '').trim();
    if (!licenseKey) {
      showToast('Vui lòng dán mã License Key vào ô!', 'error');
      return;
    }

    const btn = document.getElementById('btnActivateLicense');
    if (btn) btn.disabled = true;

    try {
      const res = await apiFetch('/api/license/activate', {
        method: 'POST',
        body: JSON.stringify({ licenseKey })
      });
      state.license = res.license;
      if (keyInput) keyInput.value = '';
      stopPaymentPolling();
      renderLicenseUI(false);
      startLicenseCountdownTimer();
      showToast(res.message || 'Kích hoạt thành công!', 'success');
      await loadAppState();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('btnDeactivateLicense')?.addEventListener('click', async () => {
    const ok = window.confirm('Gỡ mã Key hiện tại khỏi máy này?');
    if (!ok) return;
    try {
      const res = await apiFetch('/api/license/deactivate', { method: 'POST' });
      state.license = res.license;
      renderLicenseUI(true);
      startLicenseCountdownTimer();
      showToast(res.message, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // ==================== CHẾ ĐỘ LÀM PHIM & AFFILIATE (V3.9) ====================
  document.getElementById('studioModeSwitcher')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.mode-switch-btn[data-studio-mode]');
    if (!btn || !state.activeAccount) return;
    const nextMode = btn.dataset.studioMode === 'filmmaking' ? 'filmmaking' : 'affiliate';
    if ((state.activeAccount.settings?.studioMode || 'affiliate') === nextMode) return;

    const patch = { studioMode: nextMode };
    if (nextMode === 'affiliate') {
      const curSec = parseDurationToSeconds(state.activeAccount.settings?.duration || '10s');
      if (curSec > 60) {
        patch.duration = '60s';
      }
    } else if (nextMode === 'filmmaking') {
      if (!state.activeAccount.settings?.enableDialogue && state.activeAccount.settings?.filmConfig?.audioMode !== 'ambient_only') {
        patch.enableDialogue = true;
      }
    }

    await saveSidebarSettings(patch);
    renderSidebarSettings();
    renderFlowRows();
    showToast(
      nextMode === 'filmmaking'
        ? '🎬 Đã chuyển sang CHẾ ĐỘ LÀM PHIM (Hỗ trợ kịch bản dài, đa nhân vật & xuất phim hoàn chỉnh)!'
        : '🛍️ Đã chuyển sang Chế độ Affiliate TikTok & Shopee (Thời lượng video tối đa 60s)!',
      'success'
    );
  });

  document.getElementById('selectFilmGenre')?.addEventListener('change', async (e) => {
    const genreId = e.target.value || '3d_pixar';
    document.getElementById('filmCustomStyleWrap')?.classList.toggle('hidden', genreId !== 'custom_cinema');
    await saveFilmConfigPatch({ genreId });
    showToast('🎬 Đã khóa thể loại phim cho toàn bộ các phân cảnh!', 'info');
  });

  document.getElementById('inputFilmCustomStyle')?.addEventListener('input', (e) => {
    const val = e.target.value;
    if (filmCustomStyleSaveTimer) clearTimeout(filmCustomStyleSaveTimer);
    filmCustomStyleSaveTimer = setTimeout(() => {
      saveFilmConfigPatch({ customStylePrompt: val });
    }, 450);
  });

  document.getElementById('inputFilmWorldLock')?.addEventListener('input', (e) => {
    const val = e.target.value;
    if (filmWorldSaveTimer) clearTimeout(filmWorldSaveTimer);
    filmWorldSaveTimer = setTimeout(() => {
      saveFilmConfigPatch({ worldLock: val });
    }, 450);
  });

  document.getElementById('selectFilmAudioMode')?.addEventListener('change', async (e) => {
    const audioMode = e.target.value || 'mixed';
    document.getElementById('filmNarratorVoiceBox')?.classList.toggle(
      'hidden',
      audioMode === 'dialogue' || audioMode === 'ambient_only'
    );
    await saveFilmConfigPatch({ audioMode });
    if (audioMode === 'ambient_only') {
      await saveSidebarSettings({ enableDialogue: false });
    } else if (!state.activeAccount?.settings?.enableDialogue) {
      await saveSidebarSettings({ enableDialogue: true });
    }
    refreshAllRowDialogueBadges();
  });

  document.getElementById('selectFilmNarratorVoice')?.addEventListener('change', async (e) => {
    await saveFilmConfigPatch({ narratorVoicePreset: e.target.value || 'vi_storyteller_cinema' });
  });

  document.getElementById('inputFilmNarratorNote')?.addEventListener('input', (e) => {
    const val = e.target.value;
    if (filmNarratorNoteSaveTimer) clearTimeout(filmNarratorNoteSaveTimer);
    filmNarratorNoteSaveTimer = setTimeout(() => {
      saveFilmConfigPatch({ narratorVoiceNote: val });
    }, 450);
  });

  document.getElementById('selectFilmContinuityMode')?.addEventListener('change', async (e) => {
    const continuityMode = e.target.value === 'sequential_chain' ? 'sequential_chain' : 'parallel_fast';
    await saveFilmConfigPatch({ continuityMode });
    renderFlowRows();
    showToast(
      continuityMode === 'sequential_chain'
        ? '🔗 Đã bật nối tiếp khung hình cuối tuần tự giữa các cảnh!'
        : '⚡ Đã bật chạy đa luồng nhanh (khóa đồng bộ Hồ sơ Diễn viên & Bối cảnh)!',
      'info'
    );
  });

  document.getElementById('btnOpenFilmCharactersModal')?.addEventListener('click', openFilmCharactersModal);
  document.getElementById('btnSidebarOpenCharacters')?.addEventListener('click', openFilmCharactersModal);
  document.getElementById('btnOpenFilmStoryboardModal')?.addEventListener('click', openFilmStoryboardModal);
  document.getElementById('btnSidebarOpenStoryboard')?.addEventListener('click', openFilmStoryboardModal);
  document.getElementById('btnOpenFilmExportModal')?.addEventListener('click', openFilmExportModal);

  // Modal 12: Hồ sơ Diễn viên
  document.getElementById('inputFilmCharName')?.addEventListener('input', (e) => {
    const tagInp = document.getElementById('inputFilmCharTag');
    if (!tagInp || tagInp.dataset.manualEdited === '1') return;
    tagInp.value = buildClientCharacterTagSuggestion(e.target.value);
  });

  document.getElementById('inputFilmCharTag')?.addEventListener('input', (e) => {
    e.target.dataset.manualEdited = e.target.value.trim() ? '1' : '';
  });

  document.getElementById('btnCancelEditFilmChar')?.addEventListener('click', resetFilmCharacterForm);

  document.getElementById('btnSaveFilmCharacter')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const name = (document.getElementById('inputFilmCharName')?.value || '').trim();
    if (!name) {
      showToast('Vui lòng nhập Tên nhân vật!', 'error');
      document.getElementById('inputFilmCharName')?.focus();
      return;
    }
    const id = (document.getElementById('filmCharEditId')?.value || '').trim();
    const tag = (document.getElementById('inputFilmCharTag')?.value || '').trim() || buildClientCharacterTagSuggestion(name);
    const roleType = document.getElementById('selectFilmCharRole')?.value || 'character';
    const voicePreset = document.getElementById('selectFilmCharVoice')?.value || 'auto';
    const voiceCustomNote = (document.getElementById('inputFilmCharVoiceNote')?.value || '').trim();
    const appearanceDna = (document.getElementById('inputFilmCharDna')?.value || '').trim();

    const btn = document.getElementById('btnSaveFilmCharacter');
    if (btn) btn.disabled = true;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/film/characters`, {
        method: 'POST',
        body: JSON.stringify({
          id: id || undefined,
          name,
          tag,
          roleType,
          voicePreset,
          voiceCustomNote,
          appearanceDna
        })
      });
      if (res.account) {
        state.activeAccount = res.account;
      }
      resetFilmCharacterForm();
      renderFilmCharactersModalList();
      renderFlowRows();
      showToast(`🎭 Đã lưu nhân vật "${res.character?.name}" (${res.character?.tag})!`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('filmCharactersListContainer')?.addEventListener('click', async (e) => {
    const actEl = e.target.closest('[data-char-act]');
    if (!actEl || !state.activeAccount) return;
    const act = actEl.dataset.charAct;
    const charId = actEl.dataset.charId;
    const slot = Number(actEl.dataset.slot) || 0;

    if (act === 'del-img') {
      e.stopPropagation();
      await deleteFilmCharacterImageSlot(charId, slot);
      return;
    }
    if (act === 'pick-img') {
      openFilmCharSlotFilePicker(charId, slot);
      return;
    }
    if (act === 'edit') {
      const ch = (state.activeAccount.characters || []).find((c) => c.id === charId);
      if (!ch) return;
      document.getElementById('filmCharEditId').value = ch.id;
      document.getElementById('inputFilmCharName').value = ch.name || '';
      const tagInp = document.getElementById('inputFilmCharTag');
      if (tagInp) {
        tagInp.value = ch.tag || '';
        tagInp.dataset.manualEdited = '1';
      }
      document.getElementById('selectFilmCharRole').value = ch.roleType || 'character';
      document.getElementById('selectFilmCharVoice').value = ch.voicePreset || 'auto';
      document.getElementById('inputFilmCharVoiceNote').value = ch.voiceCustomNote || '';
      document.getElementById('inputFilmCharDna').value = ch.appearanceDna || '';
      const head = document.getElementById('filmCharFormHeading');
      if (head) head.textContent = `✎ Đang sửa: ${ch.name}`;
      document.getElementById('btnCancelEditFilmChar')?.classList.remove('hidden');
      document.getElementById('inputFilmCharName')?.focus();
      return;
    }
    if (act === 'delete') {
      const ch = (state.activeAccount.characters || []).find((c) => c.id === charId);
      if (!ch) return;
      if (!window.confirm(`Xóa nhân vật "${ch.name}" (${ch.tag}) khỏi đoàn phim?`)) return;
      try {
        const res = await apiFetch(
          `/api/accounts/${state.activeAccount.id}/film/characters/${encodeURIComponent(charId)}`,
          { method: 'DELETE' }
        );
        if (res.account) state.activeAccount = res.account;
        renderFilmCharactersModalList();
        renderFlowRows();
        showToast(`Đã xóa nhân vật "${ch.name}".`, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
      return;
    }
    if (act === 'ai-dna') {
      const origTxt = actEl.textContent;
      actEl.disabled = true;
      actEl.textContent = '⏳ AI đang đọc ảnh...';
      try {
        const res = await apiFetch(
          `/api/accounts/${state.activeAccount.id}/film/characters/${encodeURIComponent(charId)}/extract-dna`,
          { method: 'POST' }
        );
        if (res.account) state.activeAccount = res.account;
        renderFilmCharactersModalList();
        showToast('✨ AI đã trích xuất & khóa đặc điểm ngoại hình cho nhân vật!', 'success');
      } catch (err) {
        showToast(err.message, 'error');
      } finally {
        actEl.disabled = false;
        actEl.textContent = origTxt;
      }
    }
  });

  // Modal 13: Đạo diễn Kịch bản & Chia phân cảnh
  document.getElementById('sbSelectTargetDuration')?.addEventListener('change', (e) => {
    const customInp = document.getElementById('sbInputCustomMinutes');
    if (customInp) customInp.classList.toggle('hidden', e.target.value !== 'custom');
    updateStoryboardSceneEstimate();
  });
  document.getElementById('sbInputCustomMinutes')?.addEventListener('input', updateStoryboardSceneEstimate);
  document.getElementById('sbSelectSceneSec')?.addEventListener('change', updateStoryboardSceneEstimate);

  document.getElementById('btnRunLocalStoryboardSplit')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const storyText = (document.getElementById('sbTextareaStory')?.value || '').trim();
    if (!storyText) {
      showToast('Vui lòng dán kịch bản hoặc câu chuyện vào ô nội dung!', 'error');
      document.getElementById('sbTextareaStory')?.focus();
      return;
    }

    const btn = document.getElementById('btnRunLocalStoryboardSplit');
    if (btn) btn.disabled = true;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/film/storyboard/local-split`, {
        method: 'POST',
        body: JSON.stringify({
          storyText,
          genreId: document.getElementById('sbSelectGenre')?.value || '3d_pixar',
          worldLock: document.getElementById('sbInputWorldLock')?.value || '',
          audioMode: document.getElementById('sbSelectAudioMode')?.value || 'mixed',
          targetMovieSeconds: getStoryboardSelectedSeconds(),
          sceneDurationSeconds: Number(document.getElementById('sbSelectSceneSec')?.value) || 10,
          overwriteAll: true
        })
      });
      if (res.account) {
        state.activeAccount = res.account;
      }
      renderSidebarSettings();
      renderFlowRows();
      renderFilmCharactersModalList();
      document.getElementById('filmStoryboardModal')?.classList.add('hidden');
      showToast(res.message || `Đã tách thành ${res.sceneCount} phân cảnh phim!`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('btnRunAiStoryboardGenerate')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const storyText = (document.getElementById('sbTextareaStory')?.value || '').trim();
    if (!storyText) {
      showToast('Vui lòng nhập ý tưởng cốt truyện hoặc câu chuyện dài trước!', 'error');
      document.getElementById('sbTextareaStory')?.focus();
      return;
    }

    const btnAi = document.getElementById('btnRunAiStoryboardGenerate');
    const btnLocal = document.getElementById('btnRunLocalStoryboardSplit');
    const progBox = document.getElementById('sbProgressBox');
    const progTxt = document.getElementById('sbProgressText');

    if (btnAi) btnAi.disabled = true;
    if (btnLocal) btnLocal.disabled = true;
    progBox?.classList.remove('hidden');
    if (progTxt) progTxt.textContent = '🎬 AI Đạo diễn đang đọc cốt truyện, lập Hồ sơ Diễn viên & chia phân cảnh...';

    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/film/storyboard/ai-generate`, {
        method: 'POST',
        body: JSON.stringify({
          storyText,
          genreId: document.getElementById('sbSelectGenre')?.value || '3d_pixar',
          worldLock: document.getElementById('sbInputWorldLock')?.value || '',
          audioMode: document.getElementById('sbSelectAudioMode')?.value || 'mixed',
          targetMovieSeconds: getStoryboardSelectedSeconds(),
          sceneDurationSeconds: Number(document.getElementById('sbSelectSceneSec')?.value) || 10,
          overwriteAll: true
        })
      });
      if (res.account) {
        state.activeAccount = res.account;
      }
      renderSidebarSettings();
      renderFlowRows();
      renderFilmCharactersModalList();
      document.getElementById('filmStoryboardModal')?.classList.add('hidden');
      showToast(res.message || 'AI Đạo diễn đã lập xong toàn bộ phân cảnh!', 'success');
      if (res.addedCharacters > 0) {
        setTimeout(() => {
          showToast(
            `🎭 AI đã tự tạo ${res.addedCharacters} nhân vật mới! Bạn có thể bấm "Hồ Sơ Diễn Viên" để gắn ảnh mặt chuẩn cho từng vai.`,
            'info'
          );
        }, 900);
      }
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btnAi) btnAi.disabled = false;
      if (btnLocal) btnLocal.disabled = false;
      progBox?.classList.add('hidden');
    }
  });

  document.getElementById('btnStopStoryboardAi')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      await apiFetch(`/api/accounts/${state.activeAccount.id}/film/storyboard/stop`, { method: 'POST' });
      showToast('Đã gửi lệnh dừng chia phân cảnh.', 'info');
    } catch (_) {}
  });

  // Modal 14: Xuất Bộ Phim Hoàn Chỉnh (Full Movie Master)
  document.getElementById('rangeFilmExportBgmVol')?.addEventListener('input', (e) => {
    const pct = Number(e.target.value) || 16;
    const lbl = document.getElementById('filmExportBgmVolLabel');
    if (lbl) lbl.textContent = `${pct}% (${pct <= 22 ? 'Rõ lời thoại' : 'Nhạc nổi bật'})`;
  });

  document.getElementById('btnStartFilmMasterExport')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const btn = document.getElementById('btnStartFilmMasterExport');
    const progBox = document.getElementById('filmExportProgressBox');
    const resBox = document.getElementById('filmExportResultBox');

    const formData = new FormData();
    formData.append(
      'movieTitle',
      (document.getElementById('inputFilmExportTitle')?.value || 'Bo_Phim_Hoan_Chinh').trim()
    );
    formData.append('aspectMode', document.getElementById('selectFilmExportAspect')?.value || 'auto');
    formData.append('transitionEffect', document.getElementById('selectFilmExportTransition')?.value || 'fade');
    const volPct = Number(document.getElementById('rangeFilmExportBgmVol')?.value) || 16;
    formData.append('bgmVolume', String((volPct / 100).toFixed(2)));

    const bgmInput = document.getElementById('inputFilmExportBgmFile');
    if (bgmInput?.files?.[0]) {
      formData.append('bgm', bgmInput.files[0]);
    }

    if (btn) btn.disabled = true;
    progBox?.classList.remove('hidden');
    resBox?.classList.add('hidden');

    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/film/export-movie`, {
        method: 'POST',
        body: formData
      });
      if (res.result) {
        state.lastExportedMovie = res.result;
        const player = document.getElementById('filmExportPreviewVideo');
        if (player && res.result.publicUrl) {
          player.src = `${res.result.publicUrl}?t=${Date.now()}`;
        }
        const metaEl = document.getElementById('filmExportResultMeta');
        if (metaEl) {
          const mb = ((res.result.sizeBytes || 0) / (1024 * 1024)).toFixed(2);
          metaEl.textContent = `✅ ${res.result.fileName} • ${res.result.sceneCount} cảnh • ${res.result.duration}s • ${mb} MB`;
        }
        const dlBtn = document.getElementById('btnDownloadExportedMovie');
        if (dlBtn) {
          dlBtn.href = `/api/download-merged?accountId=${encodeURIComponent(
            state.activeAccount.id
          )}&fileName=${encodeURIComponent(res.result.fileName)}`;
        }
        resBox?.classList.remove('hidden');
      }
      showToast(res.message || '🎞️ Đã xuất bộ phim hoàn chỉnh thành công!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
      progBox?.classList.add('hidden');
    }
  });

  document.getElementById('btnOpenExportedMovieFolder')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      await apiFetch('/api/open-output-folder', {
        method: 'POST',
        body: JSON.stringify({ accountId: state.activeAccount.id })
      });
      showToast('📂 Đã mở thư mục chứa bộ phim vừa xuất!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Đóng Modal
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.close;
      if (id === 'licenseModal' && !state.license?.valid) {
        showToast('Vui lòng chọn gói hoặc nhập Key để tiếp tục sử dụng!', 'error');
        return;
      }
      if (id === 'updateAvailableModal' && (updateInstalling || cachedUpdateInfo?.mandatory)) {
        return;
      }
      const modal = document.getElementById(id);
      if (modal) modal.classList.add('hidden');
      if (id === 'licenseModal') stopPaymentPolling();
      if (id === 'videoPreviewModal') {
        document.getElementById('previewModalPlayer')?.pause();
      } else if (id === 'outputGalleryModal') {
        document.getElementById('outputGalleryPlayer')?.pause();
      } else if (id === 'filmExportModal') {
        document.getElementById('filmExportPreviewVideo')?.pause();
      } else if (id === 'capcutEditorModal') {
        if (capcutPlayer) capcutPlayer.pause();
        capcutState.playingAll = false;
      }
    });
  });

  document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        if (backdrop.id === 'licenseModal' && !state.license?.valid) return;
        if (backdrop.id === 'updateAvailableModal' && (updateInstalling || cachedUpdateInfo?.mandatory)) return;
        backdrop.classList.add('hidden');
        if (backdrop.id === 'licenseModal') stopPaymentPolling();
        if (backdrop.id === 'videoPreviewModal') {
          document.getElementById('previewModalPlayer')?.pause();
        } else if (backdrop.id === 'outputGalleryModal') {
          document.getElementById('outputGalleryPlayer')?.pause();
        } else if (backdrop.id === 'filmExportModal') {
          document.getElementById('filmExportPreviewVideo')?.pause();
        } else if (backdrop.id === 'capcutEditorModal') {
          if (capcutPlayer) capcutPlayer.pause();
          capcutState.playingAll = false;
        }
      }
    });
  });
});
