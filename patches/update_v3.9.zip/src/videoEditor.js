const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const TRANSITION_EFFECTS = [
  { id: 'fade', label: 'Mờ dần (Crossfade)' },
  { id: 'dissolve', label: 'Hòa tan (Dissolve)' },
  { id: 'hblur', label: 'Mờ chuyển động (Blur)' },
  { id: 'smoothleft', label: 'Lướt trái mượt' },
  { id: 'smoothright', label: 'Lướt phải mượt' },
  { id: 'zoomin', label: 'Phóng tâm (Zoom In)' },
  { id: 'circleopen', label: 'Mở vòng tròn' },
  { id: 'fadeblack', label: 'Chuyển tối điện ảnh' },
  { id: 'fadewhite', label: 'Chớp sáng (Flash)' },
  { id: 'wipeleft', label: 'Quét ngang' },
  { id: 'random', label: 'Ngẫu nhiên mượt' },
  { id: 'none', label: 'Không hiệu ứng' }
];

const RANDOM_POOL = ['fade', 'dissolve', 'hblur', 'smoothleft', 'smoothright', 'zoomin'];

function getFfmpegExecutable(appRootDir) {
  try {
    const staticPath = require('ffmpeg-static');
    if (staticPath && fs.existsSync(staticPath)) {
      return staticPath;
    }
  } catch (_) {}

  const candidates = [
    path.join(appRootDir, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe'),
    path.join(appRootDir, 'runtime', 'ffmpeg', 'ffmpeg.exe'),
    'ffmpeg'
  ];

  for (const c of candidates) {
    if (c === 'ffmpeg' || fs.existsSync(c)) {
      return c;
    }
  }
  return 'ffmpeg';
}

function runFfmpeg(ffmpegBin, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegBin, args, { windowsHide: true });
    let stderr = '';
    proc.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    proc.on('error', (err) => {
      reject(new Error(`Không thể khởi chạy FFmpeg (${err.message}).`));
    });
    proc.on('close', (code) => {
      if (code === 0) {
        resolve(stderr);
      } else {
        const tail = stderr.split(/\r?\n/).slice(-8).join(' | ');
        reject(new Error(`Lỗi xử lý FFmpeg (code ${code}): ${tail}`));
      }
    });
  });
}

function probeMediaFile(ffmpegBin, filePath) {
  return new Promise((resolve) => {
    const proc = spawn(ffmpegBin, ['-hide_banner', '-i', filePath], { windowsHide: true });
    let stderr = '';
    proc.stderr.on('data', (d) => {
      stderr += d.toString();
    });
    proc.on('error', () => {
      resolve({
        duration: 0,
        width: 720,
        height: 1280,
        hasAudio: false,
        audioSampleRate: 0,
        audioChannels: '',
        bitrateKbps: 0,
        majorBrand: ''
      });
    });
    proc.on('close', () => {
      let duration = 0;
      const durMatch = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/i);
      if (durMatch) {
        duration =
          Number(durMatch[1]) * 3600 +
          Number(durMatch[2]) * 60 +
          parseFloat(durMatch[3]);
      }

      let bitrateKbps = 0;
      const brMatch = stderr.match(/bitrate:\s*(\d+)\s*kb\/s/i);
      if (brMatch) {
        bitrateKbps = Number(brMatch[1]) || 0;
      }

      let majorBrand = '';
      const brandMatch = stderr.match(/major_brand\s*:\s*(\S+)/i);
      if (brandMatch) {
        majorBrand = String(brandMatch[1] || '').trim().toLowerCase();
      }

      let width = 720;
      let height = 1280;
      const resMatch = stderr.match(/Stream\s+#\d+:\d+.*Video:.*?\s(\d{2,5})x(\d{2,5})(?:[\s,]|$)/i);
      if (resMatch) {
        width = Number(resMatch[1]) || 720;
        height = Number(resMatch[2]) || 1280;
      }

      const audioLineMatch = stderr.match(/Stream\s+#\d+:\d+.*Audio:([^\r\n]+)/i);
      const hasAudio = Boolean(audioLineMatch);
      let audioSampleRate = 0;
      let audioChannels = '';
      if (audioLineMatch) {
        const audioLine = audioLineMatch[1];
        const srMatch = audioLine.match(/(\d{4,6})\s*Hz/i);
        if (srMatch) audioSampleRate = Number(srMatch[1]) || 0;
        if (/\bstereo\b|\b2\s*channels\b/i.test(audioLine)) {
          audioChannels = 'stereo';
        } else if (/\bmono\b|\b1\s*channels?\b/i.test(audioLine)) {
          audioChannels = 'mono';
        }
      }

      resolve({
        duration,
        width,
        height,
        hasAudio,
        audioSampleRate,
        audioChannels,
        bitrateKbps,
        majorBrand
      });
    });
  });
}

/**
 * Chuẩn hóa file MP4 đầu ra sang chuẩn quốc tế (mp42 + H.264 yuv420p + AAC 44100Hz Stereo + faststart)
 * giúp mở mượt tức thì trên mọi trình phát Windows (kể cả Windows Media Player 12 cũ & DXVA2), Zalo, CapCut, iPhone.
 */
async function ensureUniversalPlayableMp4(appRootDir, filePath, options = {}) {
  if (!filePath || !fs.existsSync(filePath)) return filePath;
  const origStat = fs.statSync(filePath);
  if (origStat.size < 10000) return filePath;

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, filePath);

  const isMod16 = info.width > 0 && info.height > 0 && info.width % 16 === 0 && info.height % 16 === 0;
  const isReasonableBitrate = !info.bitrateKbps || info.bitrateKbps <= 10500;
  const isStandardAudio = !info.hasAudio || (info.audioSampleRate === 44100 && info.audioChannels === 'stereo');
  const isMp42 = info.majorBrand === 'mp42';

  if (!options.forceReencode && isMp42 && isStandardAudio && isMod16 && isReasonableBitrate) {
    return filePath;
  }

  const tempOut = `${filePath}.norm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.mp4`;

  const runFullCleanEncode = async () => {
    const evenW = Math.max(16, Math.round((info.width || 720) / 16) * 16);
    const evenH = Math.max(16, Math.round((info.height || 1280) / 16) * 16);
    const vf = `scale=${evenW}:${evenH}:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,setsar=1,format=yuv420p`;

    if (info.hasAudio) {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-af', 'aresample=44100',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '16',
        '-profile:v', 'high',
        '-level', '4.1',
        '-colorspace', 'bt709',
        '-color_primaries', 'bt709',
        '-color_trc', 'bt709',
        '-maxrate', '12M',
        '-bufsize', '24M',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-ar', '44100',
        '-ac', '2',
        '-brand', 'mp42',
        '-movflags', '+faststart',
        tempOut
      ]);
    } else {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '16',
        '-profile:v', 'high',
        '-level', '4.1',
        '-colorspace', 'bt709',
        '-color_primaries', 'bt709',
        '-color_trc', 'bt709',
        '-maxrate', '12M',
        '-bufsize', '24M',
        '-brand', 'mp42',
        '-movflags', '+faststart',
        tempOut
      ]);
    }
  };

  try {
    if (!options.forceReencode && isMod16 && isReasonableBitrate) {
      try {
        if (info.hasAudio) {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-c:a', 'aac',
            '-b:a', '192k',
            '-ar', '44100',
            '-ac', '2',
            '-brand', 'mp42',
            '-movflags', '+faststart',
            tempOut
          ]);
        } else {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-brand', 'mp42',
            '-movflags', '+faststart',
            tempOut
          ]);
        }
      } catch (_) {
        await runFullCleanEncode();
      }
    } else {
      await runFullCleanEncode();
    }

    if (fs.existsSync(tempOut) && fs.statSync(tempOut).size > 10000) {
      fs.renameSync(tempOut, filePath);
    }
  } catch (_) {
    // Giữ nguyên file gốc nếu FFmpeg gặp sự cố ngoài ý muốn
  } finally {
    if (fs.existsSync(tempOut)) {
      try {
        fs.unlinkSync(tempOut);
      } catch (_) {}
    }
  }

  return filePath;
}

function resolveOutputUrlToDiskPath(appRootDir, rawUrl) {
  if (!rawUrl) return null;
  const rel = String(rawUrl).split('?')[0].replace(/^\/+/, '');
  if (!rel.startsWith('outputs/')) return null;
  const sub = rel.slice('outputs/'.length);
  const decodedSegs = sub
    .split('/')
    .filter(Boolean)
    .map((s) => {
      try {
        return decodeURIComponent(s);
      } catch (_) {
        return s;
      }
    });
  const decodedCandidate = path.join(appRootDir, 'Output_Videos', ...decodedSegs);
  if (fs.existsSync(decodedCandidate)) return decodedCandidate;

  const rawCandidate = path.join(appRootDir, 'Output_Videos', sub);
  if (fs.existsSync(rawCandidate)) return rawCandidate;
  return null;
}

function resolveClipFilePath(appRootDir, accountManager, accountId, clip) {
  const acc = accountManager.getAccount(accountId);
  if (clip.rowIndex && acc) {
    const row = acc.rows.find((r) => r.index === Number(clip.rowIndex));
    if (row && row.videoFilePath && fs.existsSync(row.videoFilePath)) {
      return row.videoFilePath;
    }
    if (row && row.videoUrl) {
      const resolvedRowUrl = resolveOutputUrlToDiskPath(appRootDir, row.videoUrl);
      if (resolvedRowUrl) return resolvedRowUrl;
    }
  }

  if (clip.videoFilePath && fs.existsSync(clip.videoFilePath)) {
    return clip.videoFilePath;
  }

  if (clip.videoUrl) {
    const resolvedClipUrl = resolveOutputUrlToDiskPath(appRootDir, clip.videoUrl);
    if (resolvedClipUrl) return resolvedClipUrl;
  }

  throw new Error(`Không tìm thấy file video gốc cho ${clip.label || `Hàng #${clip.rowIndex || '?'}`}.`);
}

/**
 * Ghép nhiều đoạn đã chuẩn hóa (cùng khung hình, 30fps, stereo 44.1kHz) kèm hiệu ứng chuyển cảnh mượt xfade + acrossfade.
 * Tự động chia lô tối đa 8 đoạn/lần khi nối video dài (2 phút, 5 phút, 10+ phút...) để không tràn RAM hay giới hạn dòng lệnh Windows.
 */
async function mergeNormalizedSegmentsWithTransition(
  ffmpegBin,
  normFiles,
  finalOutputPath,
  transitionEffect = 'fade',
  transitionSec = 0.5,
  effectSeedOffset = 0
) {
  if (normFiles.length === 1) {
    fs.copyFileSync(normFiles[0], finalOutputPath);
    return finalOutputPath;
  }

  const cleanEffect = String(transitionEffect || 'fade').trim().toLowerCase();
  if (!cleanEffect || cleanEffect === 'none') {
    throw new Error('SKIP_TRANSITION');
  }

  const MAX_XFADE_BATCH = 8;
  if (normFiles.length > MAX_XFADE_BATCH) {
    const chunkWorkDir = path.join(
      path.dirname(finalOutputPath),
      `_xfade_chunks_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    );
    fs.mkdirSync(chunkWorkDir, { recursive: true });
    try {
      const chunkOutputs = [];
      let cursor = 0;
      let chunkIdx = 0;
      while (cursor < normFiles.length) {
        const slice = normFiles.slice(cursor, cursor + MAX_XFADE_BATCH);
        if (slice.length === 1) {
          chunkOutputs.push(slice[0]);
        } else {
          const chunkOut = path.join(chunkWorkDir, `chunk_${chunkIdx}.mp4`);
          await mergeNormalizedSegmentsWithTransition(
            ffmpegBin,
            slice,
            chunkOut,
            cleanEffect,
            transitionSec,
            effectSeedOffset + cursor
          );
          chunkOutputs.push(chunkOut);
        }
        cursor += MAX_XFADE_BATCH;
        chunkIdx++;
      }
      return await mergeNormalizedSegmentsWithTransition(
        ffmpegBin,
        chunkOutputs,
        finalOutputPath,
        cleanEffect,
        transitionSec,
        effectSeedOffset + 100
      );
    } finally {
      try {
        fs.rmSync(chunkWorkDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }

  const durations = [];
  for (const nf of normFiles) {
    const info = await probeMediaFile(ffmpegBin, nf);
    durations.push(info.duration > 0.8 ? info.duration : 10);
  }

  const minClipDur = Math.min(...durations);
  const tDur = Math.max(0.12, Math.min(transitionSec, minClipDur * 0.28, 0.7));

  const inputArgs = [];
  const filterParts = [];

  for (let i = 0; i < normFiles.length; i++) {
    inputArgs.push('-i', normFiles[i]);
    filterParts.push(`[${i}:v]settb=AVTB,fps=30,format=yuv420p[v${i}]`);
    filterParts.push(`[${i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo[a${i}]`);
  }

  let cumDuration = durations[0];
  let prevV = 'v0';
  let prevA = 'a0';

  for (let i = 1; i < normFiles.length; i++) {
    const chosenEffect =
      cleanEffect === 'random'
        ? RANDOM_POOL[(effectSeedOffset + i - 1) % RANDOM_POOL.length]
        : RANDOM_POOL.includes(cleanEffect) ||
          ['circleopen', 'fadeblack', 'fadewhite', 'wipeleft'].includes(cleanEffect)
        ? cleanEffect
        : 'fade';

    const offset = Math.max(0.1, cumDuration - tDur);
    const nextV = `vx${i}`;
    const nextA = `ax${i}`;

    filterParts.push(
      `[${prevV}][v${i}]xfade=transition=${chosenEffect}:duration=${tDur.toFixed(3)}:offset=${offset.toFixed(3)}[${nextV}]`
    );
    filterParts.push(`[${prevA}][a${i}]acrossfade=d=${tDur.toFixed(3)}:c1=tri:c2=tri[${nextA}]`);

    cumDuration = offset + durations[i];
    prevV = nextV;
    prevA = nextA;
  }

  const filterComplex = filterParts.join(';');
  const scriptFile = path.join(
    path.dirname(finalOutputPath),
    `_fscript_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.txt`
  );
  fs.writeFileSync(scriptFile, filterComplex, 'utf8');

  try {
    await runFfmpeg(ffmpegBin, [
      '-y',
      ...inputArgs,
      '-filter_complex_script',
      scriptFile,
      '-map',
      `[${prevV}]`,
      '-map',
      `[${prevA}]`,
      '-map_metadata',
      '-1',
      '-c:v',
      'libx264',
      '-preset',
      'fast',
      '-crf',
      '16',
      '-profile:v',
      'high',
      '-level',
      '4.1',
      '-colorspace',
      'bt709',
      '-color_primaries',
      'bt709',
      '-color_trc',
      'bt709',
      '-maxrate',
      '12M',
      '-bufsize',
      '24M',
      '-c:a',
      'aac',
      '-b:a',
      '192k',
      '-ar',
      '44100',
      '-ac',
      '2',
      '-brand',
      'mp42',
      '-movflags',
      '+faststart',
      finalOutputPath
    ]);
  } finally {
    try {
      if (fs.existsSync(scriptFile)) fs.unlinkSync(scriptFile);
    } catch (_) {}
  }

  return finalOutputPath;
}

/**
 * Cắt, tách đoạn, chỉnh tốc độ và nối nhiều đoạn video (hỗ trợ hiệu ứng chuyển cảnh mượt)
 */
async function renderTimelineVideo({
  appRootDir,
  accountManager,
  accountId,
  clips,
  outputCustomName,
  aspectMode = 'auto',
  transitionEffect = null,
  saveToRowIndex = null
}) {
  if (!Array.isArray(clips) || clips.length === 0) {
    throw new Error('Danh sách đoạn video cần nối đang trống.');
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const acc = accountManager ? accountManager.getAccount(accountId) : null;

  const outAccountDir = accountManager
    ? accountManager.ensureAccountOutputDir(accountId, { create: true })
    : path.join(appRootDir, 'Output_Videos', accountId || 'default');
  const mergedDir = path.join(outAccountDir, 'Merged_CapCut');
  const tempDir = path.join(appRootDir, 'Project_Data', 'temp_editor', `job_${Date.now()}`);

  [outAccountDir, mergedDir, tempDir].forEach((d) => {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  });

  try {
    const resolvedClips = [];
    let totalEffectiveSec = 0;

    for (let i = 0; i < clips.length; i++) {
      const c = clips[i];
      const filePath = resolveClipFilePath(appRootDir, accountManager, accountId, c);
      const info = await probeMediaFile(ffmpegBin, filePath);

      const maxDur = info.duration > 0 ? info.duration : 7200;
      const startTime = Math.max(0, Number(c.startTime) || 0);
      const rawEnd = Number(c.endTime);
      const endTime = rawEnd && rawEnd > startTime ? Math.min(rawEnd, maxDur) : maxDur;
      const segDuration = Math.max(0.15, endTime - startTime);
      const speed = Math.max(0.5, Math.min(2.0, Number(c.speed) || 1));
      totalEffectiveSec += segDuration / speed;

      resolvedClips.push({
        index: i,
        filePath,
        info,
        startTime,
        endTime,
        segDuration,
        speed,
        muted: Boolean(c.muted),
        rowIndex: c.rowIndex
      });
    }

    let targetW = resolvedClips[0].info.width || 720;
    let targetH = resolvedClips[0].info.height || 1280;

    if (aspectMode === '9:16') {
      targetW = 720;
      targetH = 1280;
    } else if (aspectMode === '16:9') {
      targetW = 1280;
      targetH = 720;
    } else if (aspectMode === '1:1') {
      targetW = 1088;
      targetH = 1088;
    } else if (aspectMode === '21:9') {
      targetW = 1280;
      targetH = 544;
    }

    targetW = Math.max(16, Math.round(targetW / 16) * 16);
    targetH = Math.max(16, Math.round(targetH / 16) * 16);

    const segmentFiles = [];
    for (let i = 0; i < resolvedClips.length; i++) {
      const seg = resolvedClips[i];
      const segOutPath = path.join(tempDir, `seg_${String(i).padStart(3, '0')}.mp4`);

      const setPtsFilter = seg.speed !== 1 ? `setpts=${(1 / seg.speed).toFixed(4)}*PTS,` : '';
      const vFilter = `${setPtsFilter}scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

      const useOriginalAudio = seg.info.hasAudio && !seg.muted;
      const effectiveDuration = seg.segDuration / seg.speed;

      let args = [];
      if (useOriginalAudio) {
        const aFilter = seg.speed !== 1 ? `atempo=${seg.speed.toFixed(2)},aresample=44100` : 'aresample=44100';
        args = [
          '-y',
          '-ss', seg.startTime.toFixed(3),
          '-t', seg.segDuration.toFixed(3),
          '-i', seg.filePath,
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-af', aFilter,
          '-c:v', 'libx264',
          '-preset', 'fast',
          '-crf', '16',
          '-profile:v', 'high',
          '-level', '4.1',
          '-colorspace', 'bt709',
          '-color_primaries', 'bt709',
          '-color_trc', 'bt709',
          '-maxrate', '12M',
          '-bufsize', '24M',
          '-c:a', 'aac',
          '-b:a', '192k',
          '-ac', '2',
          '-ar', '44100',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          segOutPath
        ];
      } else {
        args = [
          '-y',
          '-ss', seg.startTime.toFixed(3),
          '-t', seg.segDuration.toFixed(3),
          '-i', seg.filePath,
          '-f', 'lavfi',
          '-t', effectiveDuration.toFixed(3),
          '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-map', '0:v:0',
          '-map', '1:a:0',
          '-c:v', 'libx264',
          '-preset', 'fast',
          '-crf', '16',
          '-profile:v', 'high',
          '-level', '4.1',
          '-colorspace', 'bt709',
          '-color_primaries', 'bt709',
          '-color_trc', 'bt709',
          '-maxrate', '12M',
          '-bufsize', '24M',
          '-c:a', 'aac',
          '-b:a', '192k',
          '-ac', '2',
          '-ar', '44100',
          '-shortest',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          segOutPath
        ];
      }

      await runFfmpeg(ffmpegBin, args);
      segmentFiles.push(segOutPath);
    }

    const safeCustom = String(outputCustomName || '')
      .trim()
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 50);

    const finalFileName = saveToRowIndex
      ? `Row_${String(saveToRowIndex).padStart(2, '0')}_Edited_${Date.now()}.mp4`
      : `${safeCustom || 'MuseFlow_Merged'}_${Date.now()}.mp4`;

    const finalOutputDir = saveToRowIndex ? outAccountDir : mergedDir;
    const finalOutputPath = path.join(finalOutputDir, finalFileName);

    const chosenTransition =
      transitionEffect ||
      (totalEffectiveSec >= 19.5 ? acc?.settings?.transitionEffect || 'fade' : 'none');

    if (segmentFiles.length === 1) {
      fs.copyFileSync(segmentFiles[0], finalOutputPath);
    } else {
      let mergedWithXfade = false;
      if (chosenTransition && chosenTransition !== 'none') {
        try {
          await mergeNormalizedSegmentsWithTransition(
            ffmpegBin,
            segmentFiles,
            finalOutputPath,
            chosenTransition,
            0.5
          );
          mergedWithXfade = fs.existsSync(finalOutputPath) && fs.statSync(finalOutputPath).size > 50000;
        } catch (_) {
          mergedWithXfade = false;
        }
      }

      if (!mergedWithXfade) {
        const concatListPath = path.join(tempDir, 'concat_list.txt');
        const listContent = segmentFiles
          .map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`)
          .join('\n');
        fs.writeFileSync(concatListPath, listContent, 'utf8');

        await runFfmpeg(ffmpegBin, [
          '-y',
          '-f', 'concat',
          '-safe', '0',
          '-i', concatListPath,
          '-map_metadata', '-1',
          '-c', 'copy',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          finalOutputPath
        ]);
      }
    }

    const finalProbe = await probeMediaFile(ffmpegBin, finalOutputPath);
    const stat = fs.statSync(finalOutputPath);

    const publicUrl = accountManager
      ? saveToRowIndex
        ? accountManager.buildAccountOutputPublicUrl(accountId, finalFileName)
        : accountManager.buildAccountOutputPublicUrl(accountId, 'Merged_CapCut', finalFileName)
      : saveToRowIndex
      ? `/outputs/${encodeURIComponent(accountId || 'default')}/${encodeURIComponent(finalFileName)}`
      : `/outputs/${encodeURIComponent(accountId || 'default')}/Merged_CapCut/${encodeURIComponent(finalFileName)}`;

    let updatedRow = null;
    if (saveToRowIndex && accountManager) {
      updatedRow = accountManager.updateRow(accountId, Number(saveToRowIndex), {
        status: 'completed',
        statusMessage: `Đã cắt nối (${finalProbe.duration.toFixed(1)}s)`,
        videoUrl: publicUrl,
        videoFilePath: finalOutputPath
      });
    }

    return {
      ok: true,
      fileName: finalFileName,
      filePath: finalOutputPath,
      publicUrl,
      duration: Number(finalProbe.duration.toFixed(2)),
      width: targetW,
      height: targetH,
      sizeBytes: stat.size,
      clipCount: resolvedClips.length,
      updatedRow
    };
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

/**
 * Trích xuất khung hình cuối cùng SẮC NÉT NHẤT (ít nhòe chuyển động / chớp mắt nhất)
 * trong khoảng ~0.42s cuối của đoạn video để nối tiếp Phần sau không bị trôi nét mặt!
 */
async function extractLastFrameFromVideo(appRootDir, videoFilePath, outputImagePath) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, videoFilePath);

  const outDir = path.dirname(outputImagePath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  // Quét tối đa 7 khung hình PNG không nén trong 0.38s cuối video với ma trận màu chuẩn HD BT.709 (chống lệch màu da sang BT.601!);
  // khung hình ít motion-blur nhất sẽ giữ nhiều chi tiết tần số cao nhất (dung lượng PNG lớn nhất).
  const bt709RgbFilter = 'scale=in_color_matrix=bt709:out_color_matrix=bt709:flags=lanczos,format=rgb24';
  if (info.duration > 0.6) {
    const candDir = path.join(outDir, `_sharp_cand_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
    fs.mkdirSync(candDir, { recursive: true });
    try {
      const startWindow = Math.max(0, info.duration - 0.38);
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-ss', startWindow.toFixed(3),
        '-i', videoFilePath,
        '-vf', `fps=18,${bt709RgbFilter}`,
        '-frames:v', '7',
        path.join(candDir, 'cand_%02d.png')
      ]);

      const cands = fs
        .readdirSync(candDir)
        .filter((f) => f.endsWith('.png'))
        .sort()
        .map((f) => {
          const full = path.join(candDir, f);
          const sz = fs.statSync(full).size;
          return { name: f, full, size: sz };
        })
        .filter((c) => c.size > 1000);

      if (cands.length > 0) {
        // Ưu tiên độ nét cao + ưu tiên nhẹ các frame gần sát cuối để chuyển động liền mạch 100%
        const maxSz = Math.max(...cands.map((c) => c.size));
        let best = cands[cands.length - 1];
        let bestScore = -1;
        cands.forEach((c, idx) => {
          const sharpnessRatio = maxSz > 0 ? c.size / maxSz : 1;
          const recencyBonus = (idx / Math.max(1, cands.length - 1)) * 0.035;
          const score = sharpnessRatio + recencyBonus;
          if (score > bestScore) {
            bestScore = score;
            best = c;
          }
        });

        if (outputImagePath.toLowerCase().endsWith('.png')) {
          fs.copyFileSync(best.full, outputImagePath);
        } else {
          await runFfmpeg(ffmpegBin, ['-y', '-i', best.full, '-q:v', '1', outputImagePath]);
        }
      }
    } catch (_) {
    } finally {
      try {
        fs.rmSync(candDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }

  if (!fs.existsSync(outputImagePath) || fs.statSync(outputImagePath).size < 500) {
    const seekSec = info.duration > 0.25 ? Math.max(0, info.duration - 0.12) : 0;
    try {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-ss', seekSec.toFixed(3),
        '-i', videoFilePath,
        '-vf', bt709RgbFilter,
        '-frames:v', '1',
        ...(outputImagePath.toLowerCase().endsWith('.png') ? [] : ['-q:v', '1']),
        outputImagePath
      ]);
    } catch (_) {}
  }

  if (!fs.existsSync(outputImagePath) || fs.statSync(outputImagePath).size < 500) {
    await runFfmpeg(ffmpegBin, [
      '-y',
      '-sseof', '-0.25',
      '-i', videoFilePath,
      '-vf', bt709RgbFilter,
      '-frames:v', '1',
      ...(outputImagePath.toLowerCase().endsWith('.png') ? [] : ['-q:v', '1']),
      outputImagePath
    ]);
  }

  return outputImagePath;
}

/**
 * Ghép nối các phần video mở rộng (từ 15s, 30s, 60s đến video dài 2 phút, 5 phút, 10+ phút...)
 * bảo toàn 100% dải màu chuẩn HD BT.709 (không lệch màu da / ánh sáng so với Đoạn 1) và độ sắc nét cao (CRF 15-16 High Profile).
 */
async function concatExtendedPartFiles(
  appRootDir,
  partFilePaths,
  finalOutputPath,
  transitionEffect = 'fade',
  options = {}
) {
  if (!Array.isArray(partFilePaths) || partFilePaths.length === 0) {
    throw new Error('Không có file thành phần để nối.');
  }
  if (partFilePaths.length === 1) {
    fs.copyFileSync(partFilePaths[0], finalOutputPath);
    await ensureUniversalPlayableMp4(appRootDir, finalOutputPath);
    return finalOutputPath;
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const persistentCacheDir = options && options.cacheDir ? path.join(options.cacheDir, '_norm_cache') : null;
  const tempDir =
    persistentCacheDir ||
    path.join(
      appRootDir,
      'Project_Data',
      'temp_editor',
      `extend_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    );
  fs.mkdirSync(tempDir, { recursive: true });

  const cleanEffect = String(transitionEffect || 'fade').trim().toLowerCase();
  const fastPreviewOnly = Boolean(options && options.fastPreviewOnly);

  try {
    let targetW = 720;
    let targetH = 1280;
    const dimsMetaPath = path.join(tempDir, '_target_dims.json');
    if (persistentCacheDir && fs.existsSync(dimsMetaPath)) {
      try {
        const savedDims = JSON.parse(fs.readFileSync(dimsMetaPath, 'utf8'));
        if (savedDims.targetW && savedDims.targetH) {
          targetW = savedDims.targetW;
          targetH = savedDims.targetH;
        }
      } catch (_) {}
    } else {
      const firstInfo = await probeMediaFile(ffmpegBin, partFilePaths[0]);
      targetW = Math.max(16, Math.round((firstInfo.width || 720) / 16) * 16);
      targetH = Math.max(16, Math.round((firstInfo.height || 1280) / 16) * 16);
      if (persistentCacheDir) {
        try {
          fs.writeFileSync(dimsMetaPath, JSON.stringify({ targetW, targetH }), 'utf8');
        } catch (_) {}
      }
    }

    const normFiles = [];
    for (let i = 0; i < partFilePaths.length; i++) {
      const p = partFilePaths[i];
      const safeTag = path.basename(p).replace(/[^a-zA-Z0-9._-]/g, '_');
      const normOut = path.join(tempDir, persistentCacheDir ? `norm_${i}_${safeTag}` : `norm_${i}.mp4`);

      // Tái sử dụng ngay file chuẩn hóa đã lưu bộ nhớ đệm (giúp video dài 10-30 phần không phải mã hóa lại từ đầu!)
      if (persistentCacheDir && fs.existsSync(normOut) && fs.statSync(normOut).size > 5000) {
        normFiles.push(normOut);
        continue;
      }

      const info = await probeMediaFile(ffmpegBin, p);
      const vFilter = `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

      if (info.hasAudio) {
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p,
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-af', 'aresample=44100',
          '-c:v', 'libx264', '-preset', 'fast', '-crf', '15',
          '-profile:v', 'high', '-level', '4.1',
          '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
          '-maxrate', '12M', '-bufsize', '24M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100',
          '-brand', 'mp42',
          normOut
        ]);
      } else {
        const dur = Math.max(1, info.duration || 10);
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p,
          '-f', 'lavfi', '-t', dur.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-map', '0:v:0', '-map', '1:a:0',
          '-c:v', 'libx264', '-preset', 'fast', '-crf', '15',
          '-profile:v', 'high', '-level', '4.1',
          '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
          '-maxrate', '12M', '-bufsize', '24M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100',
          '-shortest',
          '-brand', 'mp42',
          normOut
        ]);
      }
      normFiles.push(normOut);
    }

    // Áp dụng hiệu ứng chuyển cảnh xfade + acrossfade mượt mà cho bản xuất hoàn chỉnh
    // Với video có lời thoại nối nhiều phần 10s, dùng crossfade siêu ngắn 0.18s để không đè âm tiết giữa 2 câu thoại!
    if (!fastPreviewOnly && cleanEffect && cleanEffect !== 'none') {
      const transitionSec = options && options.hasSpokenDialogue ? 0.18 : 0.5;
      try {
        await mergeNormalizedSegmentsWithTransition(ffmpegBin, normFiles, finalOutputPath, cleanEffect, transitionSec);
        if (fs.existsSync(finalOutputPath) && fs.statSync(finalOutputPath).size > 10000) {
          return finalOutputPath;
        }
      } catch (_) {}
    }

    // Nối siêu tốc 0.2s từ các mảnh đã chuẩn hóa đồng nhất 100% (dùng cho bản xem trước trung gian hoặc khi tắt chuyển cảnh)
    const normListPath = path.join(tempDir, `norm_list_${Date.now()}.txt`);
    fs.writeFileSync(
      normListPath,
      normFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'),
      'utf8'
    );

    try {
      await runFfmpeg(ffmpegBin, [
        '-y', '-f', 'concat', '-safe', '0', '-i', normListPath,
        '-map_metadata', '-1',
        '-c', 'copy',
        '-brand', 'mp42',
        '-movflags', '+faststart',
        finalOutputPath
      ]);
    } finally {
      try {
        if (fs.existsSync(normListPath)) fs.unlinkSync(normListPath);
      } catch (_) {}
    }

    return finalOutputPath;
  } finally {
    if (!persistentCacheDir) {
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }
}

/**
 * Trích xuất Bảng phân cảnh chuyển động (Motion Storyboard Filmstrip Grid 4x2 hoặc 4x3) từ Video mẫu tham chiếu.
 * Giúp Muse.ai đọc chính xác nhịp cử chỉ, góc máy & bối cảnh từ đầu đến cuối video mà KHÔNG làm nhiễu khuôn mặt/quần áo sang bước tạo video!
 */
async function extractSampleVideoMotionGrid(appRootDir, videoFilePath, outputGridPath) {
  if (!videoFilePath || !fs.existsSync(videoFilePath)) {
    throw new Error('Không tìm thấy tệp Video mẫu tham chiếu trên ổ cứng.');
  }
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, videoFilePath);
  const dur = Math.max(0.8, Number(info.duration) || 8);
  const cols = 4;
  const rows = dur >= 16 ? 3 : 2;
  const totalFrames = cols * rows;
  const fpsVal = Math.max(0.05, totalFrames / Math.max(0.6, dur * 0.96)).toFixed(4);

  const outDir = path.dirname(outputGridPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  try {
    await runFfmpeg(ffmpegBin, [
      '-y',
      '-i',
      videoFilePath,
      '-vf',
      `fps=${fpsVal},scale=384:-2,tile=${cols}x${rows}:padding=6:margin=6:color=0x0f172a`,
      '-frames:v',
      '1',
      '-q:v',
      '3',
      outputGridPath
    ]);
  } catch (_) {
    await extractLastFrameFromVideo(appRootDir, videoFilePath, outputGridPath);
  }

  if (!fs.existsSync(outputGridPath) || fs.statSync(outputGridPath).size < 1000) {
    await extractLastFrameFromVideo(appRootDir, videoFilePath, outputGridPath);
  }

  return {
    outputGridPath,
    durationSec: Number(dur.toFixed(1)),
    frameCount: totalFrames,
    cols,
    rows
  };
}

/**
 * Hòa trộn nhạc nền (BGM .mp3 / .wav / .m4a) lặp tự động + nhỏ dần cuối phim (fade-out) bên dưới lời thoại gốc,
 * giữ nguyên 100% luồng hình ảnh (-c:v copy) cực nhanh không giảm chất lượng video!
 */
async function mixBackgroundMusicIntoVideo(appRootDir, videoFilePath, bgmFilePath, bgmVolume = 0.16) {
  if (!videoFilePath || !fs.existsSync(videoFilePath)) {
    throw new Error('Không tìm thấy file phim cần lồng nhạc nền.');
  }
  if (!bgmFilePath || !fs.existsSync(bgmFilePath)) {
    return videoFilePath;
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const vidInfo = await probeMediaFile(ffmpegBin, videoFilePath);
  const dur = Math.max(1, Number(vidInfo.duration) || 10);
  const vol = Math.max(0.02, Math.min(0.85, Number(bgmVolume) || 0.16));
  const fadeOutDur = Math.min(2.2, Math.max(0.5, dur * 0.12));
  const fadeOutStart = Math.max(0, dur - fadeOutDur);

  const tmpOut = `${videoFilePath}.bgm_mix_${Date.now()}.mp4`;
  try {
    const filterComplex = vidInfo.hasAudio
      ? `[0:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=1.0[va];` +
        `[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=${vol.toFixed(
          3
        )},afade=t=in:st=0:d=0.6,afade=t=out:st=${fadeOutStart.toFixed(2)}:d=${fadeOutDur.toFixed(2)}[bgm];` +
        `[va][bgm]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]`
      : `[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=${vol.toFixed(
          3
        )},afade=t=in:st=0:d=0.6,afade=t=out:st=${fadeOutStart.toFixed(2)}:d=${fadeOutDur.toFixed(
          2
        )},atrim=0:${dur.toFixed(3)}[aout]`;

    await runFfmpeg(ffmpegBin, [
      '-y',
      '-i',
      videoFilePath,
      '-stream_loop',
      '-1',
      '-i',
      bgmFilePath,
      '-filter_complex',
      filterComplex,
      '-map',
      '0:v:0',
      '-map',
      '[aout]',
      '-c:v',
      'copy',
      '-c:a',
      'aac',
      '-b:a',
      '192k',
      '-ac',
      '2',
      '-ar',
      '44100',
      '-shortest',
      '-brand',
      'mp42',
      '-movflags',
      '+faststart',
      tmpOut
    ]);

    if (fs.existsSync(tmpOut) && fs.statSync(tmpOut).size > 10000) {
      fs.renameSync(tmpOut, videoFilePath);
    }
  } finally {
    try {
      if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
    } catch (_) {}
  }

  return videoFilePath;
}

/**
 * Xuất Trọn Bộ Phim Dài (Full Movie Master MP4) từ danh sách các Phân cảnh đã hoàn tất theo đúng thứ tự kịch bản
 */
async function renderFullMovieMaster({
  appRootDir,
  accountManager,
  accountId,
  rowIndices = null,
  movieTitle = 'Bo_Phim_Hoan_Chinh',
  aspectMode = 'auto',
  transitionEffect = 'fade',
  bgmFilePath = null,
  bgmVolume = 0.16
}) {
  const acc = accountManager.getAccount(accountId);
  if (!acc) throw new Error('Không tìm thấy dự án phim.');

  const allCompletedRows = (acc.rows || [])
    .filter((r) => r && r.videoFilePath && fs.existsSync(r.videoFilePath))
    .sort((a, b) => a.index - b.index);

  let targetRows = allCompletedRows;
  if (Array.isArray(rowIndices) && rowIndices.length > 0) {
    const setIdx = new Set(rowIndices.map((n) => Number(n)));
    targetRows = allCompletedRows.filter((r) => setIdx.has(r.index));
  }

  if (targetRows.length === 0) {
    throw new Error('Chưa có phân cảnh nào hoàn tất video để xuất bộ phim! Hãy bấm Chạy tạo các phân cảnh trước.');
  }

  const clips = targetRows.map((r) => ({
    rowIndex: r.index,
    filePath: r.videoFilePath,
    startTime: 0,
    endTime: 0,
    speed: 1,
    muted: false
  }));

  const mergedRes = await renderTimelineVideo({
    appRootDir,
    accountManager,
    accountId,
    clips,
    outputCustomName: movieTitle || 'Phim_Full_Master',
    aspectMode: aspectMode || 'auto',
    transitionEffect: transitionEffect || 'fade',
    saveToRowIndex: null
  });

  if (bgmFilePath && fs.existsSync(bgmFilePath)) {
    await mixBackgroundMusicIntoVideo(appRootDir, mergedRes.filePath, bgmFilePath, bgmVolume);
    const statAfter = fs.statSync(mergedRes.filePath);
    mergedRes.sizeBytes = statAfter.size;
    mergedRes.hasBgm = true;
  }

  return {
    ...mergedRes,
    sceneCount: targetRows.length,
    sceneIndices: targetRows.map((r) => r.index)
  };
}

module.exports = {
  TRANSITION_EFFECTS,
  getFfmpegExecutable,
  runFfmpeg,
  probeMediaFile,
  ensureUniversalPlayableMp4,
  renderTimelineVideo,
  mixBackgroundMusicIntoVideo,
  renderFullMovieMaster,
  extractLastFrameFromVideo,
  concatExtendedPartFiles,
  extractSampleVideoMotionGrid
};
