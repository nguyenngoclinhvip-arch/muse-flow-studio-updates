const fs = require('fs');
const path = require('path');

const AFFILIATE_MAX_DURATION_SEC = 60;
const FILMMAKING_MAX_DURATION_SEC = 3600;
const MAX_FILM_CHARACTERS = 40;
const MAX_CHAR_REF_IMAGES = 2;

const FILM_GENRES = [
  {
    id: '3d_pixar',
    label: '🧸 Hoạt Hình 3D (Pixar / Disney Style)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'High-end 3D CGI feature animation in Pixar / Walt Disney Animation Studios style: appealing stylized 3D character sculpts with consistent proportions, expressive eyes and subtle facial micro-expressions, rich subsurface skin scattering, tactile fabric/hair grooming, warm cinematic key-and-rim lighting, and cohesive feature-film color grading.'
  },
  {
    id: '2d_anime',
    label: '🌸 Hoạt Hình 2D / Anime (Ghibli / Shinkai)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Theatrical 2D Japanese anime feature film aesthetic inspired by Studio Ghibli and Makoto Shinkai: crisp hand-drawn character linework, consistent cel-shaded facial geometry and outfits, painterly atmospheric backgrounds, luminous volumetric sky and sunlight, and fluid 2D character animation.'
  },
  {
    id: 'historical_epic',
    label: '⚔️ Phim Lịch Sử / Cổ Trang Hào Hùng',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Grand historical period epic cinema: authentic period-accurate traditional garments, armor, textiles, hairstyles, props, and ancient architecture; natural sunlight, firelight/torchlight, atmospheric battle/palace mist, anamorphic 35mm theatrical color grading. STRICT HISTORICAL PURITY: ZERO modern buildings, ZERO electricity/wires/streetlights, ZERO cars/plastics/watches/glasses/modern text signage.'
  },
  {
    id: 'cinema_35mm',
    label: '🎥 Phim Điện Ảnh Đời Thực (35mm Realism)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Photorealistic live-action theatrical cinema shot on ARRI Alexa Mini LF with 35mm anamorphic prime lenses: authentic human skin texture, natural film grain, shallow cinematic depth of field, motivated three-point dramatic lighting, and cohesive Hollywood color grading.'
  },
  {
    id: 'xianxia_fantasy',
    label: '🐉 Tiên Hiệp / Huyền Huyễn Kỳ Ảo',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'High-budget Eastern Xianxia / mythical fantasy cinema: flowing layered silk ancient robes, intricate hairpins/crowns, ethereal spiritual aura and elemental energy particles, mist-shrouded celestial peaks and ancient pavilions, dramatic mystical lighting. STRICT ANCIENT FANTASY PURITY: ZERO modern objects or contemporary clothing.'
  },
  {
    id: 'scifi_cyberpunk',
    label: '🚀 Khoa Học Viễn Tưởng (Sci-Fi / Cyberpunk)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'AAA theatrical science-fiction cinema: detailed futuristic architecture, spacecraft/cybernetic props, volumetric neon and holographic illumination, sleek atmospheric fog, anamorphic lens flares, and crisp futuristic costume design.'
  },
  {
    id: 'horror_thriller',
    label: '🕵️ Kinh Dị / Trinh Thám Bí Ẩn',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Suspenseful psychological thriller & mystery horror cinema: moody low-key chiaroscuro lighting, deep shadows, desaturated cold teal-and-amber palette, subtle volumetric mist, and tense controlled camera movement.'
  },
  {
    id: 'fairy_tale_kids',
    label: '🧚 Cổ Tích / Truyện Kể Thiếu Nhi',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Enchanting storybook fairy-tale feature film: vibrant warm magical color palette, wholesome expressive characters, charming cottage/forest/kingdom environments, soft golden-hour glow, and clear family-friendly visual storytelling with zero modern clutter.'
  },
  {
    id: 'buddhist_spiritual',
    label: '🪷 Phật Giáo / Tâm Linh Nhân Quả',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Reverent Eastern spiritual & karmic parable cinema: serene ancient temple, lotus pond, and traditional Asian village settings, warm golden incense and morning sunbeams, peaceful compassionate character expressions, dignified traditional attire, zero modern distractions.'
  },
  {
    id: 'survival_prehistoric',
    label: '🦖 Sinh Tồn / Tiền Sử Hoang Dã',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Epic wilderness survival & prehistoric cinema: untouched primeval jungle, caves, rivers, and rugged natural terrain, tactile earth/rain/fire textures, dramatic natural daylight and campfire lighting, zero modern man-made structures.'
  },
  {
    id: 'family_drama',
    label: '💼 Tâm Lý Xã Hội / Drama Gia Đình & Tổng Tài',
    defaultAspect: '9:16',
    eraGuard: false,
    styleDirective:
      'Polished contemporary Asian drama & emotional cinema: crisp expressive close-ups and two-shots, refined modern interiors/wardrobe, flattering cinematic lighting, and authentic emotional acting.'
  },
  {
    id: 'documentary_story',
    label: '📜 Phim Tài Liệu / Kể Chuyện Đời Sống',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Poetic cinematic documentary realism: authentic real-world environments, natural golden-hour and window lighting, grounded human expressions, observational handheld/gimbal camera intimacy, and rich documentary color tone.'
  },
  {
    id: 'custom',
    label: '✍️ Thể loại & Phong cách tự định nghĩa...',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Cohesive theatrical filmmaking aesthetic with 100% consistent visual art direction, lighting, color palette, and character design across every scene.'
  }
];

const VALID_FILM_GENRE_IDS = new Set(FILM_GENRES.map((g) => g.id));
const VALID_STUDIO_MODES = new Set(['affiliate', 'filmmaking']);
const VALID_FILM_AUDIO_MODES = new Set(['mixed', 'narrator', 'dialogue', 'ambient_only']);
const VALID_FILM_CONTINUITY_MODES = new Set(['parallel_fast', 'sequential_chain']);

function stripVietnameseAccents(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

function sanitizeCharacterTag(rawTagOrName, fallbackIndex = 1) {
  const raw = String(rawTagOrName || '').trim().replace(/^@+/, '');
  const ascii = stripVietnameseAccents(raw)
    .replace(/[^a-zA-Z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 28);
  return `@${ascii || `NhanVat${fallbackIndex}`}`;
}

function createDefaultFilmConfig() {
  return {
    genreId: '3d_pixar',
    customStylePrompt: '',
    worldLock: '',
    audioMode: 'mixed', // mixed | narrator | dialogue | ambient_only
    narratorVoicePreset: 'vi_storyteller_cinema',
    narratorVoiceNote: '',
    continuityMode: 'parallel_fast', // parallel_fast | sequential_chain
    storyDraft: '',
    targetMovieSeconds: 180,
    sceneDurationSeconds: 10
  };
}

function normalizeFilmConfig(rawCfg = {}) {
  const base = { ...createDefaultFilmConfig(), ...(rawCfg || {}) };
  if (!VALID_FILM_GENRE_IDS.has(base.genreId)) {
    base.genreId = '3d_pixar';
  }
  base.customStylePrompt = String(base.customStylePrompt || '').trim().slice(0, 600);
  base.worldLock = String(base.worldLock || '').trim().slice(0, 800);
  if (!VALID_FILM_AUDIO_MODES.has(base.audioMode)) {
    base.audioMode = 'mixed';
  }
  base.narratorVoicePreset = String(base.narratorVoicePreset || 'vi_storyteller_cinema').trim();
  base.narratorVoiceNote = String(base.narratorVoiceNote || '').trim().slice(0, 300);
  if (!VALID_FILM_CONTINUITY_MODES.has(base.continuityMode)) {
    base.continuityMode = 'parallel_fast';
  }
  base.storyDraft = typeof base.storyDraft === 'string' ? base.storyDraft.slice(0, 60000) : '';
  base.targetMovieSeconds = Math.max(20, Math.min(7200, Math.round(Number(base.targetMovieSeconds) || 180)));
  base.sceneDurationSeconds = Math.max(5, Math.min(60, Math.round(Number(base.sceneDurationSeconds) || 10)));
  return base;
}

function normalizeCharacterReferenceImages(rawList) {
  if (!Array.isArray(rawList)) return [];
  const valid = [];
  for (const item of rawList) {
    if (item && item.filePath && fs.existsSync(item.filePath)) {
      valid.push({
        ...item,
        slot: valid.length
      });
      if (valid.length >= MAX_CHAR_REF_IMAGES) break;
    }
  }
  return valid;
}

function normalizeFilmCharacters(rawChars = []) {
  if (!Array.isArray(rawChars)) return [];
  const usedTagsLower = new Set();
  const list = [];

  for (let i = 0; i < rawChars.length && list.length < MAX_FILM_CHARACTERS; i++) {
    const c = rawChars[i];
    if (!c || typeof c !== 'object') continue;
    const cleanName = String(c.name || '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 60);
    if (!cleanName) continue;

    let candidateTag = sanitizeCharacterTag(c.tag || cleanName, list.length + 1);
    let suffix = 2;
    while (usedTagsLower.has(candidateTag.toLowerCase())) {
      candidateTag = `${sanitizeCharacterTag(c.tag || cleanName, list.length + 1)}${suffix}`;
      suffix++;
    }
    usedTagsLower.add(candidateTag.toLowerCase());

    const id =
      typeof c.id === 'string' && c.id.trim()
        ? c.id.trim()
        : `char_${Date.now().toString(36)}_${i + 1}`;
    const roleType = c.roleType === 'narrator' ? 'narrator' : 'character';

    list.push({
      id,
      name: cleanName,
      tag: candidateTag,
      roleType,
      appearanceDna: String(c.appearanceDna || '').trim().slice(0, 600),
      voicePreset: String(c.voicePreset || (roleType === 'narrator' ? 'vi_storyteller_cinema' : 'auto')).trim(),
      voiceCustomNote: String(c.voiceCustomNote || '').trim().slice(0, 260),
      referenceImages: normalizeCharacterReferenceImages(c.referenceImages)
    });
  }

  return list;
}

function getFilmGenreInfo(genreId = '3d_pixar', customStylePrompt = '') {
  const found = FILM_GENRES.find((g) => g.id === genreId) || FILM_GENRES[0];
  const customNote = String(customStylePrompt || '').trim();
  const fullStyleDirective =
    found.id === 'custom' && customNote
      ? `Custom Film Visual Style: ${customNote}. Maintain 100% consistent art style, color grading, lighting, and lens language across every shot of the film.`
      : customNote
      ? `${found.styleDirective} Additional Director Visual Style Note: ${customNote}.`
      : found.styleDirective;

  return {
    ...found,
    fullStyleDirective
  };
}

/**
 * Tự động phát hiện các nhân vật (từ danh sách Hồ sơ Diễn viên) xuất hiện trong văn bản cảnh (Prompt / Thoại / Tiêu đề cảnh)
 */
function detectCharactersInSceneText(rawText, characters = []) {
  if (!rawText || !Array.isArray(characters) || characters.length === 0) return [];
  const textLower = String(rawText).toLowerCase();
  const textAscii = stripVietnameseAccents(textLower);
  const matched = [];

  for (const ch of characters) {
    if (!ch || !ch.id) continue;
    const tagLower = String(ch.tag || '').toLowerCase();
    const tagBareLower = tagLower.replace(/^@+/, '');
    const nameLower = String(ch.name || '').trim().toLowerCase();
    const nameAscii = stripVietnameseAccents(nameLower);

    let pos = -1;
    if (tagLower && textLower.includes(tagLower)) {
      pos = textLower.indexOf(tagLower);
    } else if (tagBareLower.length >= 3) {
      const tagRegex = new RegExp(`(^|[^a-z0-9_])@?${tagBareLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?=$|[^a-z0-9_])`, 'i');
      const m = tagRegex.exec(textAscii);
      if (m) pos = m.index;
    }

    if (pos === -1 && nameLower.length >= 2) {
      const idxDirect = textLower.indexOf(nameLower);
      if (idxDirect !== -1) {
        pos = idxDirect;
      } else if (nameAscii.length >= 3) {
        const escapedName = nameAscii.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const nameRegex = new RegExp(`(^|[^a-z0-9])${escapedName}(?=$|[^a-z0-9])`, 'i');
        const m2 = nameRegex.exec(textAscii);
        if (m2) pos = m2.index;
      }
    }

    if (pos !== -1) {
      matched.push({ char: ch, pos });
    }
  }

  matched.sort((a, b) => a.pos - b.pos);
  return matched.map((m) => m.char);
}

/**
 * Xác định danh sách nhân vật xuất hiện trong một Hàng (Phân cảnh):
 * Kết hợp cả nhân vật do người dùng gắn thẻ thủ công (`row.sceneCharacterIds`) + nhân vật tự nhận diện trong Prompt/Thoại.
 */
function resolveSceneCharacters(row, characters = []) {
  if (!Array.isArray(characters) || characters.length === 0) return [];
  const byId = new Map(characters.map((c) => [c.id, c]));
  const result = [];
  const seen = new Set();

  if (Array.isArray(row?.sceneCharacterIds)) {
    for (const cid of row.sceneCharacterIds) {
      const c = byId.get(cid);
      if (c && !seen.has(c.id)) {
        seen.add(c.id);
        result.push(c);
      }
    }
  }

  const combinedText = [row?.sceneTitle || '', row?.prompt || '', row?.dialogue || ''].join('\n');
  const autoDetected = detectCharactersInSceneText(combinedText, characters);
  for (const c of autoDetected) {
    if (c && !seen.has(c.id)) {
      seen.add(c.id);
      result.push(c);
    }
  }

  return result;
}

/**
 * Phân tích cú pháp lời thoại đa nhân vật & người dẫn chuyện trong 1 phân cảnh:
 * Hỗ trợ:
 * - `[Dẫn chuyện]: Năm 1288...` / `Thuyết minh: ...` / `@Narrator: ...`
 * - `[@TranHungDao]: Hôm nay ta quyết chiến!` / `Trần Hưng Đạo: "Hôm nay..."`
 */
function parseSceneMultiSpeakerLines(rawDialogueText, characters = [], defaultAudioMode = 'mixed') {
  const text = String(rawDialogueText || '').trim();
  if (!text) return [];

  const rawLines = text
    .split(/\r?\n|\s*\|\|\s*/)
    .map((l) => l.trim())
    .filter(Boolean);

  const parsedEntries = [];

  for (const line of rawLines) {
    const cleanLine = line.replace(/^(?:phần|part|đoạn|nhịp|cảnh|scene)\s*\d+\s*[:.-]\s*/i, '').trim();
    if (!cleanLine) continue;

    // Kiểm tra cú pháp [Người nói]: Nội dung hoặc @Tag: Nội dung hoặc Tên: Nội dung
    const prefixMatch = cleanLine.match(/^(?:\[([^\]]+)\]|(@[a-zA-Z0-9_]+)|([^:"“”]{1,35}))\s*:\s*(.+)$/);
    if (prefixMatch) {
      const rawSpeaker = (prefixMatch[1] || prefixMatch[2] || prefixMatch[3] || '').trim();
      const spokenBody = String(prefixMatch[4] || '')
        .replace(/^[“"«]+|[”"»]+$/g, '')
        .trim();

      if (spokenBody) {
        const speakerAscii = stripVietnameseAccents(rawSpeaker).toLowerCase();
        const isNarratorKeyword =
          /^(dan\s*chuyen|nguoi\s*dan\s*chuyen|thuyet\s*minh|narrator|voice\s*over|vo|ke\s*chuyen)$/i.test(
            speakerAscii.replace(/^@+/, '')
          );

        if (isNarratorKeyword) {
          parsedEntries.push({
            type: 'narrator',
            speakerLabel: 'Người dẫn chuyện (Off-screen Narrator)',
            character: null,
            text: spokenBody
          });
          continue;
        }

        // Tìm trong danh sách nhân vật
        const matchedChars = detectCharactersInSceneText(rawSpeaker, characters);
        if (matchedChars.length > 0) {
          const ch = matchedChars[0];
          parsedEntries.push({
            type: ch.roleType === 'narrator' ? 'narrator' : 'character',
            speakerLabel: `${ch.name} (${ch.tag})`,
            character: ch,
            text: spokenBody
          });
          continue;
        }

        // Nếu người dùng viết tên nhân vật chưa khai báo trong Cast Vault (VD: "Lính gác: Báo cáo!")
        if (rawSpeaker.length <= 28 && !/\b(http|https|mp4)\b/i.test(rawSpeaker)) {
          parsedEntries.push({
            type: 'ad_hoc_character',
            speakerLabel: rawSpeaker,
            character: null,
            text: spokenBody
          });
          continue;
        }
      }
    }

    const strippedQuotes = cleanLine.replace(/^[“"«]+|[”"»]+$/g, '').trim();
    if (!strippedQuotes) continue;

    parsedEntries.push({
      type: defaultAudioMode === 'narrator' ? 'narrator' : 'default',
      speakerLabel: defaultAudioMode === 'narrator' ? 'Người dẫn chuyện (Off-screen Narrator)' : '',
      character: null,
      text: strippedQuotes
    });
  }

  return parsedEntries;
}

/**
 * Chuẩn bị danh sách ảnh tham chiếu tối ưu (tối đa 5 ảnh theo giới hạn Muse.ai) cho một Phân cảnh phim:
 * - Nếu hàng có gắn ảnh riêng (`rowValidImages`), ưu tiên giữ ảnh của hàng trước.
 * - Tự động lấy ảnh chuẩn từ Hồ sơ Diễn viên (`character.referenceImages`) của ĐÚNG các nhân vật xuất hiện trên màn hình trong cảnh này!
 * - Dành sẵn 1 slot nếu cần đính kèm ảnh nối tiếp khung hình cuối từ cảnh trước (`prevSceneLastFramePath`).
 */
function buildSceneCastReferenceImages({
  rowValidImages = [],
  sceneCharacters = [],
  prevSceneLastFramePath = null,
  tempDir = null,
  rowIndex = 1
}) {
  const maxSlots = 5;
  const needPrevSceneSlot = Boolean(prevSceneLastFramePath && fs.existsSync(prevSceneLastFramePath));
  const maxCastAndRowSlots = needPrevSceneSlot ? maxSlots - 1 : maxSlots;

  const selected = [];
  const usedFilePaths = new Set();

  // 1. Giữ ảnh tham chiếu riêng đã tải trực tiếp trên hàng (ví dụ: ảnh bối cảnh/đạo cụ riêng của cảnh đó)
  for (const rImg of rowValidImages) {
    if (!rImg || !rImg.filePath || !fs.existsSync(rImg.filePath)) continue;
    if (selected.length >= maxCastAndRowSlots) break;
    usedFilePaths.add(path.resolve(rImg.filePath).toLowerCase());
    selected.push({
      ...rImg,
      role: 'scene_custom_ref',
      sceneRefNumber: selected.length + 1
    });
  }

  // 2. Lấy ảnh tạo hình chuẩn của các nhân vật xuất hiện trên hình (roleType !== 'narrator')
  const onScreenChars = (sceneCharacters || []).filter((c) => c && c.roleType !== 'narrator');
  for (const ch of onScreenChars) {
    if (selected.length >= maxCastAndRowSlots) break;
    const charImgs = Array.isArray(ch.referenceImages)
      ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
      : [];
    if (charImgs.length === 0) continue;

    const primaryImg = charImgs[0];
    const resolvedPrimary = path.resolve(primaryImg.filePath).toLowerCase();
    if (!usedFilePaths.has(resolvedPrimary)) {
      let targetPath = primaryImg.filePath;
      let targetName = primaryImg.savedName || primaryImg.fileName || `${ch.tag.replace('@', '')}.png`;
      if (tempDir && fs.existsSync(tempDir)) {
        const ext = path.extname(primaryImg.filePath) || '.png';
        const cleanTag = ch.tag.replace(/[^a-zA-Z0-9_]/g, '');
        targetName = `Cast_${selected.length + 1}_${cleanTag}_Scene${String(rowIndex).padStart(2, '0')}${ext}`;
        const copyDest = path.join(tempDir, targetName);
        try {
          fs.copyFileSync(primaryImg.filePath, copyDest);
          targetPath = copyDest;
        } catch (_) {}
      }
      usedFilePaths.add(resolvedPrimary);
      selected.push({
        filePath: targetPath,
        savedName: targetName,
        fileName: targetName,
        publicUrl: primaryImg.publicUrl,
        role: 'film_cast_character',
        characterId: ch.id,
        characterName: ch.name,
        characterTag: ch.tag,
        characterDna: ch.appearanceDna || ''
      });
    }
  }

  // Nếu chỉ có 1–2 nhân vật trong cảnh và còn dư slot ảnh, có thể nạp thêm ảnh góc thứ 2 của nhân vật chính để AI hiểu 3D tốt hơn
  if (onScreenChars.length <= 2 && selected.length < maxCastAndRowSlots) {
    for (const ch of onScreenChars) {
      if (selected.length >= maxCastAndRowSlots) break;
      const charImgs = Array.isArray(ch.referenceImages)
        ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
        : [];
      if (charImgs.length >= 2) {
        const secondImg = charImgs[1];
        const resolvedSec = path.resolve(secondImg.filePath).toLowerCase();
        if (!usedFilePaths.has(resolvedSec)) {
          usedFilePaths.add(resolvedSec);
          selected.push({
            filePath: secondImg.filePath,
            savedName: secondImg.savedName || secondImg.fileName,
            fileName: secondImg.fileName || secondImg.savedName,
            publicUrl: secondImg.publicUrl,
            role: 'film_cast_character_extra_angle',
            characterId: ch.id,
            characterName: ch.name,
            characterTag: ch.tag,
            characterDna: ch.appearanceDna || ''
          });
        }
      }
    }
  }

  // 3. Nếu có khung hình cuối nối tiếp từ cảnh liền trước, gắn vào vị trí cuối cùng kèm chỉ thị rõ ràng
  if (needPrevSceneSlot) {
    selected.push({
      filePath: prevSceneLastFramePath,
      savedName: path.basename(prevSceneLastFramePath),
      fileName: path.basename(prevSceneLastFramePath),
      role: 'prev_scene_last_frame'
    });
  }

  return selected;
}

/**
 * Xây dựng khối chỉ thị Đạo diễn Điện ảnh + Đa Nhân Vật + Phân vai Thoại/Thuyết minh cho 1 phần/cảnh
 */
function buildFilmmakingPromptBlocks({
  filmConfig = {},
  sceneCharacters = [],
  attachedImages = [],
  rawPartDialogue = '',
  rowSceneTitle = '',
  rowIndex = 1,
  partIdx = 1,
  totalParts = 1,
  partDurSec = 10,
  getVoicePresetDirectiveFn
}) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const getVoiceFn =
    typeof getVoicePresetDirectiveFn === 'function'
      ? getVoicePresetDirectiveFn
      : () => 'Natural studio-clear expressive Vietnamese voice.';

  // 1. Khối Thể loại phim & Khóa Bối cảnh / Thời đại (World Bible)
  const bibleLines = [
    `[CINEMATIC FILM PRODUCTION MODE — SCENE #${String(rowIndex).padStart(2, '0')}${
      rowSceneTitle ? ` ("${rowSceneTitle}")` : ''
    }${totalParts > 1 ? ` • PART ${partIdx}/${totalParts}` : ''}]`,
    `• FILM GENRE & VISUAL ART DIRECTION: ${genre.fullStyleDirective}`
  ];

  if (cfg.worldLock) {
    bibleLines.push(
      `• MANDATORY WORLD, ERA & ENVIRONMENT BIBLE (LOCKED ACROSS ALL SCENES): ${cfg.worldLock}`
    );
  }
  if (genre.eraGuard) {
    bibleLines.push(
      `• STRICT PERIOD / FANTASY AUTHENTICITY GUARD: Zero modern anachronisms — never show modern buildings, cars, paved asphalt roads, power lines, smartphones, wristwatches, eyeglasses, plastic items, or modern text.`
    );
  }

  // 2. Khối Định danh Đa Nhân Vật & Ánh xạ từng Ảnh đính kèm
  const castLines = [];
  const onScreenChars = (sceneCharacters || []).filter((c) => c && c.roleType !== 'narrator');
  const castImgMap = new Map();
  attachedImages.forEach((im, idx) => {
    if (im && im.role === 'film_cast_character' && im.characterId) {
      castImgMap.set(im.characterId, idx + 1);
    }
  });

  if (onScreenChars.length > 0 || attachedImages.length > 0) {
    castLines.push(`[MULTI-CHARACTER CAST & STRICT VISUAL IDENTITY MAPPING — ZERO IDENTITY SWAP]`);
    if (onScreenChars.length >= 2) {
      castLines.push(
        `• CRITICAL ENSEMBLE SCENE RULE (${onScreenChars.length} DISTINCT CHARACTERS IN THIS SCENE): Keep each character 100% distinct in face, age, hair, height, and costume! NEVER blend two characters together, NEVER swap outfits between characters, and NEVER duplicate the same face onto two different characters!`
      );
    }

    onScreenChars.forEach((ch, cIdx) => {
      const imgNum = castImgMap.get(ch.id);
      const extraAngleIndices = [];
      attachedImages.forEach((im, idx) => {
        if (im && im.role === 'film_cast_character_extra_angle' && im.characterId === ch.id) {
          extraAngleIndices.push(`#${idx + 1}`);
        }
      });

      const imgAnchorText = imgNum
        ? `LOCKED TO ATTACHED IMAGE #${imgNum}${
            extraAngleIndices.length > 0 ? ` (plus supplementary angle ${extraAngleIndices.join(', ')})` : ''
          } — preserve 100% identical facial structure, hairstyle, and signature outfit from Image #${imgNum}`
        : `Consistent recurring character (no portrait attached — strictly construct from Visual DNA below)`;
      const dnaText = ch.appearanceDna ? ` | Visual DNA: ${ch.appearanceDna}` : '';
      castLines.push(
        `• CHARACTER ${cIdx + 1}: "${ch.name}" (Tag: ${ch.tag}) -> ${imgAnchorText}${dnaText}.`
      );
    });

    attachedImages.forEach((im, idx) => {
      const slotNum = idx + 1;
      if (im.role === 'scene_custom_ref') {
        castLines.push(
          `• ATTACHED IMAGE #${slotNum} (${im.savedName || im.fileName}): Scene-specific environment / prop / composition reference for Scene #${rowIndex}.`
        );
      } else if (im.role === 'prev_scene_last_frame') {
        castLines.push(
          `• ATTACHED IMAGE #${slotNum} (${im.savedName || im.fileName}): FINAL FRAME OF PREVIOUS SCENE (#${
            rowIndex - 1
          }) — use strictly to maintain spatial environment, lighting, and seamless shot continuity into Scene #${rowIndex} without overriding character portraits!`
        );
      }
    });
  }

  // 3. Khối Thoại Đa Nhân Vật & Giọng Người Dẫn Chuyện (Narrator vs Lip-Sync Dialogue)
  let filmDialogueBlock = '';
  const safeEndSec = Math.max(3.6, partDurSec - 0.6).toFixed(1);

  if (cfg.audioMode === 'ambient_only') {
    filmDialogueBlock = [
      `[FILM AUDIO & DIALOGUE: CINEMATIC SCORE & AMBIENT SOUND ONLY]`,
      `• Spoken Dialogue: DISABLED. Deliver rich cinematic film score and realistic environmental sound effects matching ${genre.label}. Characters act expressively without talking.`
    ].join('\n');
  } else {
    const entries = parseSceneMultiSpeakerLines(rawPartDialogue, sceneCharacters, cfg.audioMode);
    if (entries.length === 0) {
      filmDialogueBlock =
        `[FILM AUDIO & DIALOGUE: PURE CINEMATIC ACTION BEAT — NO DIALOGUE IN THIS SEGMENT]\n` +
        `• No spoken lines in this ${partDurSec}s beat. Render rich cinematic environmental audio and emotional film score; characters express emotion naturally without random lip flapping.`;
    } else {
      const dlgLines = [
        `[FILM MULTI-SPEAKER DIALOGUE & NARRATOR DIRECTION — ${partDurSec}s SEGMENT]`
      ];
      const narratorVoiceDesc = getVoiceFn(cfg.narratorVoicePreset || 'vi_storyteller_cinema', cfg.narratorVoiceNote || '');

      entries.forEach((entry, idx) => {
        if (entry.type === 'narrator') {
          const customNarrVoice = entry.character
            ? getVoiceFn(entry.character.voicePreset || 'vi_storyteller_cinema', entry.character.voiceCustomNote || '')
            : narratorVoiceDesc;
          dlgLines.push(
            `• LINE #${idx + 1} [OFF-SCREEN NARRATOR VOICEOVER — DO NOT MOVE ON-SCREEN CHARACTER LIPS]:`,
            `  - Narrator Voice Profile: ${customNarrVoice}`,
            `  - Exact Verbatim Narration: "${entry.text}"`,
            `  - Visual Rule: On-screen characters perform the scene's physical actions and facial emotions silently while this narration plays cleanly over the soundtrack!`
          );
        } else {
          const speakerChar =
            entry.character ||
            (onScreenChars.length === 1 ? onScreenChars[0] : null);
          const speakerName = speakerChar
            ? `"${speakerChar.name}" (${speakerChar.tag}${
                castImgMap.has(speakerChar.id) ? `, Attached Image #${castImgMap.get(speakerChar.id)}` : ''
              })`
            : entry.speakerLabel
            ? `"${entry.speakerLabel}"`
            : onScreenChars.length > 0
            ? `"${onScreenChars[0].name}" (${onScreenChars[0].tag})`
            : 'The speaking character on screen';
          const charVoiceDesc = speakerChar
            ? getVoiceFn(speakerChar.voicePreset || 'auto', speakerChar.voiceCustomNote || '')
            : getVoiceFn('auto', '');
          const otherSilentNote =
            onScreenChars.length >= 2
              ? ` All other characters in the frame listen/react naturally and MUST KEEP THEIR MOUTHS CLOSED while ${speakerName} speaks!`
              : '';
          dlgLines.push(
            `• LINE #${idx + 1} [ON-SCREEN LIP-SYNCED CHARACTER SPEECH -> SPEAKER: ${speakerName}]:`,
            `  - Locked Speaker Voice Profile: ${charVoiceDesc}`,
            `  - Exact Verbatim Spoken Line: "${entry.text}"`,
            `  - Lip-Sync Attribution Rule: ONLY ${speakerName} visibly opens their mouth and speaks these exact words with 100% synchronized lip movements.${otherSilentNote}`
          );
        }
      });

      dlgLines.push(
        `• TIMING & PACING GUARD: Deliver all lines above word-for-word with crisp pronunciation between 0.2s and ~${safeEndSec}s so no syllable is cut off at the ${partDurSec}.0s end boundary.`
      );
      filmDialogueBlock = dlgLines.join('\n');
    }
  }

  return {
    genre,
    bibleBlock: bibleLines.join('\n'),
    castBlock: castLines.join('\n'),
    filmDialogueBlock,
    hasActiveSpeech:
      cfg.audioMode !== 'ambient_only' && Boolean(String(rawPartDialogue || '').trim())
  };
}

/**
 * Tách kịch bản / câu chuyện dài thành danh sách Phân cảnh ngay lập tức trên máy cục bộ (0.05s, không cần chờ AI)
 * Dành cho trường hợp người dùng đã có kịch bản chia đoạn hoặc muốn tách nhanh tức thì.
 */
function splitScriptIntoScenesLocally({
  storyText = '',
  existingCharacters = [],
  targetMovieSeconds = 120,
  sceneDurationSeconds = 10,
  audioMode = 'mixed'
}) {
  const cleanStory = String(storyText || '').replace(/\r\n/g, '\n').trim();
  if (!cleanStory) {
    throw new Error('Vui lòng nhập cốt truyện hoặc kịch bản phim trước khi chia phân cảnh!');
  }

  const sceneDur = Math.max(5, Math.min(60, Math.round(Number(sceneDurationSeconds) || 10)));
  const maxWordsPerScene = Math.max(14, Math.round(sceneDur * 2.2));

  // Kiểm tra xem người dùng có viết sẵn dạng "Cảnh 1:", "Scene 1:", "Phân cảnh 1:" hay không
  const explicitSceneRegex = /(?:^|\n)\s*(?:cảnh|phân\s*cảnh|scene|shot|đoạn)\s*(\d+)\s*[:.\-–—]\s*/gi;
  const explicitMatches = Array.from(cleanStory.matchAll(explicitSceneRegex));

  let rawBlocks = [];
  if (explicitMatches.length >= 2) {
    for (let i = 0; i < explicitMatches.length; i++) {
      const start = explicitMatches[i].index + explicitMatches[i][0].length;
      const end = i + 1 < explicitMatches.length ? explicitMatches[i + 1].index : cleanStory.length;
      const chunk = cleanStory.slice(start, end).trim();
      if (chunk) rawBlocks.push(chunk);
    }
  } else {
    const paragraphs = cleanStory
      .split(/\n\s*\n+/)
      .map((p) => p.trim())
      .filter(Boolean);

    if (paragraphs.length >= 2) {
      for (const para of paragraphs) {
        const words = para.split(/\s+/).filter(Boolean);
        if (words.length <= maxWordsPerScene * 1.45) {
          rawBlocks.push(para);
        } else {
          // Tách thêm theo câu nếu đoạn văn quá dài
          const sentences = para
            .split(/(?<=[.!?…])\s+/)
            .map((s) => s.trim())
            .filter(Boolean);
          let buf = [];
          let wCount = 0;
          for (const sent of sentences) {
            const sw = sent.split(/\s+/).filter(Boolean).length;
            if (buf.length > 0 && wCount + sw > maxWordsPerScene * 1.25) {
              rawBlocks.push(buf.join(' '));
              buf = [sent];
              wCount = sw;
            } else {
              buf.push(sent);
              wCount += sw;
            }
          }
          if (buf.length > 0) rawBlocks.push(buf.join(' '));
        }
      }
    } else {
      const sentences = cleanStory
        .split(/(?<=[.!?…\n])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);
      let buf = [];
      let wCount = 0;
      for (const sent of sentences) {
        const sw = sent.split(/\s+/).filter(Boolean).length;
        if (buf.length > 0 && wCount + sw > maxWordsPerScene) {
          rawBlocks.push(buf.join(' '));
          buf = [sent];
          wCount = sw;
        } else {
          buf.push(sent);
          wCount += sw;
        }
      }
      if (buf.length > 0) rawBlocks.push(buf.join(' '));
    }
  }

  rawBlocks = rawBlocks.slice(0, 200);

  const cameraCycle = [
    'Wide cinematic establishing shot, slow smooth camera push-in',
    'Medium cinematic shot at eye-level, gentle gimbal tracking',
    'Expressive medium close-up shot, shallow depth of field',
    'Dynamic two-shot / over-the-shoulder cinematic framing, subtle camera pan'
  ];

  // Tự động phát hiện nhân vật mới từ nhãn thoại [Tên]: hoặc @Tag trong kịch bản có sẵn
  const autoDiscoveredMap = new Map();
  const speakerScanRe = /(?:^\s*|\n\s*)(?:\[([^\]]{1,40})\]|(@[a-zA-Z0-9_]{2,32}))\s*:/g;
  let spMatch;
  while ((spMatch = speakerScanRe.exec(cleanStory)) !== null) {
    const rawSpeaker = String(spMatch[1] || spMatch[2] || '').trim();
    if (!rawSpeaker) continue;
    if (/^(?:dẫn\s*chuyện|người\s*dẫn|thuyết\s*minh|narrator|voiceover|vo|cảnh\s*\d+|scene\s*\d+|tập\s*\d+|phần\s*\d+|hình\s*ảnh|visual|prompt)$/i.test(rawSpeaker)) {
      continue;
    }
    const cleanName = rawSpeaker.replace(/^@+/, '').trim();
    if (!cleanName) continue;
    const normTag = sanitizeCharacterTag(rawSpeaker, existingCharacters.length + autoDiscoveredMap.size + 1);
    const alreadyExists = (existingCharacters || []).some(
      (c) =>
        c.tag.toLowerCase() === normTag.toLowerCase() ||
        c.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (!alreadyExists && !autoDiscoveredMap.has(normTag.toLowerCase())) {
      autoDiscoveredMap.set(normTag.toLowerCase(), {
        name: cleanName,
        tag: normTag,
        roleType: 'character',
        appearanceDna: '',
        voicePreset: 'auto'
      });
    }
  }
  const extractedCharacters = Array.from(autoDiscoveredMap.values());
  const combinedCharacters = [
    ...(Array.isArray(existingCharacters) ? existingCharacters : []),
    ...extractedCharacters.map((ec, i) => ({ id: `__ext_${i}`, ...ec }))
  ];

  const scenes = rawBlocks.map((block, idx) => {
    let visualPart = '';
    let dialoguePart = '';

    // Nếu người dùng dùng dấu || để ngăn cách Hình ảnh || Lời thoại
    if (block.includes('||')) {
      const sp = block.split('||');
      visualPart = sp[0].trim();
      dialoguePart = sp.slice(1).join(' ').trim();
    } else {
      const lines = block
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      const actionLines = [];
      const speechLines = [];

      for (const ln of lines) {
        if (/^(?:\[[^\]]+\]|@[a-zA-Z0-9_]+|(?:dẫn\s*chuyện|thuyết\s*minh|thoại|narrator))\s*:/i.test(ln)) {
          speechLines.push(ln);
        } else if (/^(?:hình\s*ảnh|bối\s*cảnh|hành\s*động|visual|prompt|camera)\s*:/i.test(ln)) {
          actionLines.push(ln.replace(/^[^:]+:\s*/, '').trim());
        } else {
          actionLines.push(ln);
        }
      }

      if (speechLines.length > 0 && actionLines.length > 0) {
        visualPart = actionLines.join(' ');
        dialoguePart = speechLines.join('\n');
      } else if (speechLines.length > 0 && actionLines.length === 0) {
        const camHint = cameraCycle[idx % cameraCycle.length];
        visualPart = `${camHint}. Nhân vật biểu cảm tự nhiên, khẩu hình khớp lời thoại trong bối cảnh phim.`;
        dialoguePart = speechLines.join('\n');
      } else if (audioMode === 'ambient_only') {
        visualPart = block.replace(/\s+/g, ' ').trim();
        dialoguePart = '';
      } else {
        // Đoạn truyện kể thông thường -> Biến thành cả mô tả cảnh quay + lời dẫn/thoại tương ứng
        const cleanNarrative = block.replace(/\s+/g, ' ').trim();
        const camHint = cameraCycle[idx % cameraCycle.length];
        visualPart = `${camHint}. Diễn tả sống động phân cảnh: ${cleanNarrative}`;
        if (audioMode === 'narrator' || audioMode === 'mixed') {
          const quotes = [];
          const qRe = /[“"«]([^”"»]+)[”"»]/g;
          let m;
          while ((m = qRe.exec(cleanNarrative)) !== null) {
            if (m[1].trim()) quotes.push(m[1].trim());
          }
          if (audioMode === 'mixed' && quotes.length > 0 && cleanNarrative.length - quotes.join(' ').length < 60) {
            dialoguePart = quotes.map((q) => `"${q}"`).join('\n');
          } else {
            dialoguePart = `[Dẫn chuyện]: ${cleanNarrative}`;
          }
        } else if (audioMode === 'dialogue') {
          dialoguePart = cleanNarrative;
        }
      }
    }

    const matchedChars = detectCharactersInSceneText(`${visualPart}\n${dialoguePart}`, combinedCharacters);

    return {
      sceneNumber: idx + 1,
      sceneTitle: `Cảnh ${idx + 1}`,
      characterIds: matchedChars.filter((c) => !String(c.id).startsWith('__ext_')).map((c) => c.id),
      characterTags: matchedChars.map((c) => c.tag),
      prompt: visualPart,
      dialogue: dialoguePart
    };
  });

  return {
    extractedCharacters,
    scenes
  };
}

/**
 * Tạo Prompt yêu cầu Muse.ai đóng vai Đạo diễn & Biên kịch Điện ảnh để bóc tách cốt truyện dài
 * thành Hồ sơ Diễn viên + Danh sách Phân cảnh chuẩn chỉnh (chỉ trả về Text có cấu trúc, KHÔNG render video ở bước này).
 */
function buildAiStoryboardBreakdownPrompt({
  storyText = '',
  genreId = '3d_pixar',
  customStylePrompt = '',
  worldLock = '',
  audioMode = 'mixed',
  existingCharacters = [],
  batchStartScene = 1,
  batchEndScene = 12,
  totalTargetScenes = 12,
  sceneDurationSeconds = 10,
  uniqueTag = 'mfs_sb_01',
  doneMarker = 'MFS_SB_DONE_01'
}) {
  const genre = getFilmGenreInfo(genreId, customStylePrompt);
  const maxWordsPerScene = Math.max(15, Math.round(sceneDurationSeconds * 2.1));

  const existingCastLines =
    Array.isArray(existingCharacters) && existingCharacters.length > 0
      ? [
          `EXISTING LOCKED CHARACTER CAST (YOU MUST REUSE THESE EXACT @TAGS WHEN THEY APPEAR):`,
          ...existingCharacters.map(
            (c) =>
              `- ${c.tag} | Name: "${c.name}" | Role: ${c.roleType} | DNA: ${
                c.appearanceDna || 'keep consistent appearance'
              }`
          )
        ].join('\n')
      : `No pre-defined character cast yet — identify all recurring characters in the story and output CHAR| lines for them first.`;

  const audioRule =
    audioMode === 'narrator'
      ? `AUDIO MODE = NARRATOR STORYTELLING: Every scene's SPEECH field MUST start with "[Dẫn chuyện]: " followed by expressive Vietnamese narration (~${maxWordsPerScene} Vietnamese words per ${sceneDurationSeconds}s scene).`
      : audioMode === 'dialogue'
      ? `AUDIO MODE = DIRECT CHARACTER DIALOGUE: Use "[@CharTag]: <câu thoại tiếng Việt tự nhiên>" so characters speak directly to each other (~${maxWordsPerScene} Vietnamese words max per ${sceneDurationSeconds}s scene).`
      : audioMode === 'ambient_only'
      ? `AUDIO MODE = SILENT / CINEMATIC SCORE ONLY: Leave SPEECH empty ("NONE") for every scene.`
      : `AUDIO MODE = CINEMATIC MIXED (NARRATOR + CHARACTER DIALOGUE): Combine "[Dẫn chuyện]: ..." for story transitions and "[@CharTag]: ..." for key emotional character lines (total <= ${maxWordsPerScene} Vietnamese words per ${sceneDurationSeconds}s scene). Separate multiple lines in the same scene with " / ".`;

  return [
    `[TEXT-ONLY AI FILM DIRECTOR & STORYBOARD BREAKDOWN — ID: ${uniqueTag}]`,
    `[CRITICAL MANDATE: DO NOT GENERATE ANY VIDEO OR IMAGE IN THIS STEP! REPLY WITH PLAIN STRUCTURED TEXT ONLY!]`,
    ``,
    `You are a Master Film Director breaking down a story into a cohesive multi-scene movie.`,
    `• FILM GENRE: ${genre.label} (${genre.fullStyleDirective})`,
    worldLock ? `• WORLD & ERA BIBLE: ${worldLock}` : '',
    `• TOTAL PLANNED SCENES FOR ENTIRE MOVIE: ${totalTargetScenes} scenes (${sceneDurationSeconds}s each).`,
    `• YOUR CURRENT OUTPUT RANGE: Generate Scenes #${batchStartScene} through #${batchEndScene} chronologically covering the corresponding portion of the story.`,
    `• ${audioRule}`,
    ``,
    existingCastLines,
    ``,
    `=== SOURCE STORY / SCREENPLAY ===`,
    String(storyText || '').trim().slice(0, 22000),
    `=== END OF STORY ===`,
    ``,
    `STRICT OUTPUT FORMAT (NO MARKDOWN TABLES, NO EXTRA CHATTER):`,
    batchStartScene === 1
      ? `1. First, output one line per main/recurring character in the story (up to 10 characters) using EXACTLY 6 pipe-separated fields:\nCHAR|<@AsciiTag>|<Vietnamese Character Name>|<character_or_narrator>|<SuggestedVoiceId: vi_male_north_warm / vi_female_north_warm / vi_female_south_sweet / vi_male_south_friendly / vi_storyteller_cinema>|<Detailed locked visual appearance DNA in Vietnamese/English: age, face, hairstyle, signature outfit/armor so every scene stays 100% consistent>`
      : `1. Reuse the exact @Tags from earlier scenes (only output a new CHAR| line if a brand-new character debuts in Scenes #${batchStartScene}-${batchEndScene}).`,
    `2. Next, output EVERY scene from Scene #${batchStartScene} to Scene #${batchEndScene} (one single line per scene, NO line breaks inside a SCENE line) using EXACTLY 6 pipe-separated fields:`,
    `SCENE|<SceneNumber>|<Short Vietnamese Scene Title>|<Comma-separated @Tags of on-screen characters in this shot, or NONE>|<Detailed cinematic visual & action prompt in Vietnamese + English camera framing (Wide/Medium/Close-up/Tracking), specific environment, lighting, character actions & emotions — NEVER vague>|<Vietnamese Dialogue / Narration matching Audio Mode above, or NONE>`,
    `3. End your response with the exact marker on its own final line:`,
    doneMarker
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * Giải mã kết quả phân cảnh trả về từ Muse.ai (CHAR|... và SCENE|...)
 */
function parseAiStoryboardBreakdownReply(rawReplyText = '') {
  const lines = String(rawReplyText || '')
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.replace(/^[-*•\s`]+/, '').replace(/[`]+$/, '').trim())
    .filter(Boolean);

  const extractedCharacters = [];
  const scenes = [];

  for (const line of lines) {
    if (/^CHAR\s*\|/i.test(line)) {
      const parts = line.split('|').map((p) => p.trim());
      if (parts.length >= 6) {
        const rawTag = parts[1];
        const name = parts[2];
        const roleRaw = (parts[3] || '').toLowerCase();
        const voiceRaw = parts[4] || 'auto';
        const dna = parts.slice(5).join(' | ').trim();
        if (name) {
          extractedCharacters.push({
            tag: sanitizeCharacterTag(rawTag || name, extractedCharacters.length + 1),
            name,
            roleType: roleRaw.includes('narrator') || roleRaw.includes('dan_chuyen') ? 'narrator' : 'character',
            voicePreset: voiceRaw,
            appearanceDna: dna
          });
        }
      }
      continue;
    }

    if (/^SCENE\s*\|/i.test(line)) {
      const parts = line.split('|').map((p) => p.trim());
      if (parts.length >= 5) {
        const sceneNum = parseInt(parts[1].replace(/\D+/g, ''), 10) || scenes.length + 1;
        const sceneTitle = parts[2] || `Cảnh ${sceneNum}`;
        const rawTags = parts[3] || '';
        const visualPrompt = parts[4] || '';
        const rawSpeech = parts.length >= 6 ? parts.slice(5).join(' | ').trim() : '';

        const tags =
          !rawTags || /^none$/i.test(rawTags)
            ? []
            : rawTags
                .split(/[,;]+/)
                .map((t) => t.trim())
                .filter((t) => t && !/^none$/i.test(t))
                .map((t) => sanitizeCharacterTag(t));

        const cleanSpeech =
          !rawSpeech || /^none$/i.test(rawSpeech)
            ? ''
            : rawSpeech
                .split(/\s+\/\s+/)
                .map((s) => s.trim())
                .filter(Boolean)
                .join('\n');

        if (visualPrompt) {
          scenes.push({
            sceneNumber: sceneNum,
            sceneTitle,
            characterTags: tags,
            prompt: visualPrompt,
            dialogue: cleanSpeech
          });
        }
      }
    }
  }

  return {
    extractedCharacters,
    scenes
  };
}

module.exports = {
  AFFILIATE_MAX_DURATION_SEC,
  FILMMAKING_MAX_DURATION_SEC,
  MAX_FILM_CHARACTERS,
  MAX_CHAR_REF_IMAGES,
  FILM_GENRES,
  VALID_FILM_GENRE_IDS,
  VALID_STUDIO_MODES,
  VALID_FILM_AUDIO_MODES,
  VALID_FILM_CONTINUITY_MODES,
  sanitizeCharacterTag,
  createDefaultFilmConfig,
  normalizeFilmConfig,
  normalizeFilmCharacters,
  getFilmGenreInfo,
  detectCharactersInSceneText,
  resolveSceneCharacters,
  parseSceneMultiSpeakerLines,
  buildSceneCastReferenceImages,
  buildFilmmakingPromptBlocks,
  splitScriptIntoScenesLocally,
  buildAiStoryboardBreakdownPrompt,
  parseAiStoryboardBreakdownReply
};
