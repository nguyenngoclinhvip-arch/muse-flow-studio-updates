const state = {
  license: null,
  skills: [],
  skillPromptRunning: false,
  accounts: [],
  activeAccountId: null,
  activeAccount: null,
  batchStats: null,
  chromePath: null,
  statusFilter: 'all',
  selectedRows: new Set()
};

const capcutState = {
  clips: [],
  activeClipId: null,
  playingAll: false,
  singleRowTarget: null,
  lastExportedResult: null,
  draggedClipId: null
};

const paymentState = {
  selectedPlanId: null,
  currentOrder: null,
  pollTimer: null,
  checking: false
};

let countdownIntervalId = null;
const promptSaveTimers = new Map();
const dialogueSaveTimers = new Map();
let voiceNoteSaveTimer = null;

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.3s ease';
    setTimeout(() => el.remove(), 300);
  }, 3800);
}

async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json().catch(() => ({ ok: false, error: 'Phản hồi không hợp lệ từ Server' }));
  if (data && data.licenseRequired && data.license) {
    state.license = data.license;
    renderLicenseUI(true);
  }
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

function formatCountdownShort(ms) {
  const safeMs = Math.max(0, Number(ms) || 0);
  const totalSec = Math.floor(safeMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const hh = String(hours).padStart(2, '0');
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return days > 0 ? `${days}n ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
}

function formatCountdownLong(ms) {
  const safeMs = Math.max(0, Number(ms) || 0);
  const totalSec = Math.floor(safeMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const hh = String(hours).padStart(2, '0');
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return days > 0 ? `${days} ngày ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
}

function startLicenseCountdownTimer() {
  if (countdownIntervalId) clearInterval(countdownIntervalId);
  countdownIntervalId = setInterval(async () => {
    const lic = state.license;
    if (!lic) return;

    const topText = document.getElementById('topLicenseBadgeText');
    const remEl = document.getElementById('licDaysRemaining');

    if (!lic.valid) {
      if (topText) topText.textContent = 'Hết hạn • Kích hoạt';
      if (remEl) remEl.textContent = 'Đã hết hạn';
      return;
    }

    if (!lic.expiresAtMs || lic.expiresAtMs === 0) {
      if (topText) topText.textContent = 'Vĩnh viễn';
      if (remEl) remEl.textContent = 'Vĩnh viễn';
      return;
    }

    const remMs = lic.expiresAtMs - Date.now();
    if (remMs <= 0) {
      try {
        const res = await apiFetch('/api/license/status');
        state.license = res.license;
        renderLicenseUI(!state.license?.valid);
      } catch (_) {}
      return;
    }

    const shortTxt = formatCountdownShort(remMs);
    if (topText) {
      topText.textContent = lic.isTrial ? `Dùng thử: ${shortTxt}` : `Còn ${shortTxt}`;
    }
    if (remEl) {
      remEl.textContent = formatCountdownLong(remMs);
    }
  }, 1000);
}

async function loadAppState() {
  try {
    const data = await apiFetch('/api/state');
    state.version = data.version || '2.8';
    const verBadge = document.getElementById('topVersionBadge');
    if (verBadge && data.version) {
      verBadge.textContent = `v${data.version}`;
    }
    state.license = data.license || null;
    state.skills = data.skills || [];
    state.accounts = data.accounts || [];
    state.activeAccountId = data.activeAccountId;
    state.activeAccount = data.activeAccount;
    state.batchStats = data.batchStats;
    state.chromePath = data.chromePath;
    renderAll();
    renderLicenseUI(!state.license?.valid);
    startLicenseCountdownTimer();
  } catch (err) {
    showToast(`Lỗi tải trạng thái: ${err.message}`, 'error');
  }
}

function stopPaymentPolling() {
  if (paymentState.pollTimer) {
    clearInterval(paymentState.pollTimer);
    paymentState.pollTimer = null;
  }
}

async function pollPaymentOrderOnce(manualClick = false) {
  if (!paymentState.currentOrder || paymentState.checking) return;
  paymentState.checking = true;
  const statusEl = document.getElementById('paymentWatchStatusText');
  if (manualClick && statusEl) {
    statusEl.textContent = 'Đang đối soát giao dịch chuyển khoản...';
  }

  try {
    const res = await apiFetch('/api/license/payment/check', {
      method: 'POST',
      body: JSON.stringify({
        planId: paymentState.currentOrder.plan.id,
        orderCode: paymentState.currentOrder.orderCode
      })
    });

    if (res.paid && res.license) {
      stopPaymentPolling();
      state.license = res.license;
      document.getElementById('paymentQrPanel')?.classList.add('hidden');
      renderLicenseUI(false);
      startLicenseCountdownTimer();
      showToast(res.message || '🎉 Chuyển khoản thành công! Đã tự động kích hoạt bản quyền.', 'success');
      await loadAppState();
      return;
    }

    if (statusEl) {
      statusEl.textContent = res.message || 'Đang chờ nhận chuyển khoản để tự động kích hoạt...';
    }
    if (manualClick) {
      showToast('Hệ thống chưa ghi nhận giao dịch mới, vui lòng đợi vài giây sau khi chuyển khoản!', 'info');
    }
  } catch (err) {
    if (manualClick) {
      showToast(err.message, 'error');
    }
  } finally {
    paymentState.checking = false;
  }
}

async function selectPricingPlan(planId) {
  paymentState.selectedPlanId = planId;
  document.querySelectorAll('#pricingPlansGrid .pricing-card').forEach((card) => {
    card.classList.toggle('active', card.dataset.plan === planId);
  });

  try {
    const res = await apiFetch('/api/license/payment/create-order', {
      method: 'POST',
      body: JSON.stringify({ planId })
    });
    const order = res.order;
    paymentState.currentOrder = order;

    const qrPanel = document.getElementById('paymentQrPanel');
    const qrImg = document.getElementById('paymentQrImg');
    const accNumEl = document.getElementById('payAccNum');
    const holderEl = document.getElementById('payAccHolder');
    const amountEl = document.getElementById('payAmountText');
    const contentEl = document.getElementById('payTransferContent');
    const watchEl = document.getElementById('paymentWatchStatusText');

    if (qrImg) qrImg.src = order.qrUrl;
    if (accNumEl) accNumEl.textContent = order.accountNumber;
    if (holderEl) holderEl.textContent = order.accountHolder;
    if (amountEl) {
      amountEl.textContent = order.amountFormatted;
      amountEl.dataset.rawAmount = String(order.amount);
    }
    if (contentEl) {
      contentEl.textContent = order.transferDisplay;
      contentEl.dataset.copyValue = order.transferContent;
    }
    if (watchEl) {
      watchEl.textContent = `Quét mã QR chuyển ${order.amountFormatted} — Tự động kích hoạt ngay khi thành công`;
    }
    if (qrPanel) {
      qrPanel.classList.remove('hidden');
    }

    stopPaymentPolling();
    paymentState.pollTimer = setInterval(() => {
      const modal = document.getElementById('licenseModal');
      if (!modal || modal.classList.contains('hidden')) {
        stopPaymentPolling();
        return;
      }
      pollPaymentOrderOnce(false);
    }, 5000);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function renderLicenseUI(forceOpenModal = false) {
  const lic = state.license;
  if (!lic) return;

  const topPill = document.getElementById('btnOpenLicenseModal');
  const topText = document.getElementById('topLicenseBadgeText');
  const modal = document.getElementById('licenseModal');
  const closeBtn = document.getElementById('btnCloseLicenseModal');
  const banner = document.getElementById('licenseStatusBanner');
  const titleEl = document.getElementById('licenseStatusTitle');
  const reasonEl = document.getElementById('licenseStatusReason');
  const hwidInput = document.getElementById('inputMachineHwid');
  const inlineHwid = document.getElementById('licInlineHwid');
  const deactivateBtn = document.getElementById('btnDeactivateLicense');
  const planEl = document.getElementById('licPlanName');
  const remEl = document.getElementById('licDaysRemaining');
  const expEl = document.getElementById('licExpiresAt');

  if (hwidInput) hwidInput.value = lic.hwid || '';
  if (inlineHwid) inlineHwid.textContent = lic.hwid || '';

  if (lic.valid) {
    if (topPill) {
      topPill.classList.remove('unlicensed');
      topPill.classList.toggle('trial-pill', Boolean(lic.isTrial));
    }

    const remMs = lic.expiresAtMs > 0 ? Math.max(0, lic.expiresAtMs - Date.now()) : 0;
    if (topText) {
      topText.textContent =
        lic.expiresAtMs === 0
          ? 'Vĩnh viễn'
          : lic.isTrial
          ? `Dùng thử: ${formatCountdownShort(remMs)}`
          : `Còn ${formatCountdownShort(remMs)}`;
    }

    if (closeBtn) closeBtn.classList.remove('hidden');
    if (deactivateBtn) {
      deactivateBtn.classList.toggle('hidden', Boolean(lic.isTrial));
    }

    if (banner) {
      banner.classList.remove('status-locked');
      banner.classList.add('status-unlocked');
    }
    if (titleEl) {
      titleEl.textContent = lic.isTrial
        ? '🎁 ĐANG DÙNG THỬ MIỄN PHÍ 2 NGÀY'
        : '✅ BẢN QUYỀN CHÍNH HÃNG ĐANG HOẠT ĐỘNG';
    }
    if (reasonEl) {
      reasonEl.textContent = lic.isTrial
        ? 'Bạn có thể chọn gói bên dưới để nâng cấp tự động qua QR hoặc nhập Key bất cứ lúc nào.'
        : `Máy [${lic.hwid}] đã kích hoạt bản quyền chính hãng.`;
    }

    if (planEl) planEl.textContent = lic.planName || 'Chính hãng';
    if (remEl) {
      remEl.className = 'text-emerald';
      remEl.textContent = lic.expiresAtMs === 0 ? 'Vĩnh viễn' : formatCountdownLong(remMs);
    }
    if (expEl) expEl.textContent = lic.expiresAtFormatted || 'Vĩnh viễn';

    if (modal) {
      if (forceOpenModal) {
        modal.classList.remove('hidden');
      } else {
        modal.classList.add('hidden');
        stopPaymentPolling();
      }
    }
  } else {
    if (topPill) {
      topPill.classList.add('unlicensed');
      topPill.classList.remove('trial-pill');
    }
    if (topText) topText.textContent = 'Hết hạn • Kích hoạt';
    if (closeBtn) closeBtn.classList.add('hidden');
    if (deactivateBtn) deactivateBtn.classList.toggle('hidden', Boolean(lic.isTrial));

    if (banner) {
      banner.classList.add('status-locked');
      banner.classList.remove('status-unlocked');
    }
    if (titleEl) {
      titleEl.textContent = lic.tampered
        ? '🚨 CẢNH BÁO BẢN QUYỀN THƯƠNG HIỆU'
        : lic.isTrial
        ? '⏰ ĐÃ HẾT 2 NGÀY DÙNG THỬ MIỄN PHÍ'
        : '🔒 BẢN QUYỀN ĐÃ HẾT HẠN';
    }
    if (reasonEl) {
      reasonEl.textContent =
        lic.reason || 'Chọn gói bản quyền bên dưới để chuyển khoản kích hoạt tự động hoặc nhập mã Key.';
    }

    if (planEl) planEl.textContent = lic.planName || 'Chưa kích hoạt';
    if (remEl) {
      remEl.className = 'text-rose';
      remEl.textContent = 'Đã hết hạn';
    }
    if (expEl) expEl.textContent = lic.expiresAtFormatted || '--';

    if (modal) {
      modal.classList.remove('hidden');
    }
  }
}

function connectWebSocket() {
  const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const ws = new WebSocket(`${proto}//${window.location.host}`);

  ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      handleRealtimeEvent(msg.event, msg.payload);
    } catch (_) {}
  };

  ws.onclose = () => {
    setTimeout(connectWebSocket, 2500);
  };
}

function handleRealtimeEvent(event, payload) {
  if (!payload) return;

  if (event === 'update_progress') {
    const statusEl = document.getElementById('updateProgressStatus');
    if (statusEl && payload.message) {
      statusEl.textContent = payload.message;
    }
    return;
  }

  if (event === 'license_updated') {
    state.license = payload.license;
    if (state.license?.valid) stopPaymentPolling();
    renderLicenseUI(!state.license?.valid);
    startLicenseCountdownTimer();
    return;
  }

  if (event === 'account_connected' || event === 'account_status_changed') {
    const updatedAcc = payload.account;
    if (updatedAcc) {
      const idx = state.accounts.findIndex((a) => a.id === updatedAcc.id);
      if (idx !== -1) {
        state.accounts[idx] = {
          ...state.accounts[idx],
          connected: updatedAcc.connected,
          loginVerified: updatedAcc.loginVerified,
          savedAccount: updatedAcc.savedAccount,
          proxy: updatedAcc.proxy || '',
          proxyLabel: updatedAcc.proxyLabel || '',
          accountInfo: updatedAcc.accountInfo
        };
      }
      if (state.activeAccount && state.activeAccount.id === updatedAcc.id) {
        state.activeAccount.connected = updatedAcc.connected;
        state.activeAccount.loginVerified = updatedAcc.loginVerified;
        state.activeAccount.savedAccount = updatedAcc.savedAccount;
        state.activeAccount.proxy = updatedAcc.proxy || '';
        state.activeAccount.proxyLabel = updatedAcc.proxyLabel || '';
        state.activeAccount.accountInfo = updatedAcc.accountInfo;
        renderTopbarAndAccountStatus();
      }
      if (payload.justLoggedIn) {
        showToast('Đã lưu tài khoản! Chrome sẽ tự ẩn chạy ngầm.', 'success');
      }
    }
    renderAccountSelect();
    renderAccountsModalList();
  } else if (event === 'row_updated') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id && payload.row) {
      const rIdx = state.activeAccount.rows.findIndex((r) => r.index === payload.row.index);
      if (rIdx !== -1) {
        state.activeAccount.rows[rIdx] = payload.row;
        updateSingleRowDom(payload.row);
        renderRowCountsAndFilterVisibility();
        updateSampleVideoStatusBadgeOnly();
      }
    }
  } else if (event === 'row_error_skipped') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      showToast(`Hàng #${payload.rowIndex} lỗi, đã tự động bỏ qua!`, 'error');
    }
  } else if (event === 'batch_progress') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.batchStats = payload.stats;
      renderBatchMonitor();
    }
  } else if (event === 'settings_updated') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.activeAccount.settings = payload.settings;
      if (Array.isArray(payload.rows)) {
        state.activeAccount.rows = payload.rows;
      }
      renderSidebarSettings();
      renderBatchMonitor();
      renderFlowRows();
    }
  } else if (event === 'accounts_updated') {
    loadAppState();
  } else if (event === 'skills_updated') {
    state.skills = payload.skills || [];
    renderSkillSelectorAndBadge();
    renderSkillsModalList();
  } else if (event === 'skill_prompt_progress') {
    if (state.activeAccount && payload.accountId === state.activeAccount.id) {
      state.skillPromptRunning = Boolean(payload.running);
      renderSkillAutoPromptButtons(payload);
    }
  }
}

function renderAll() {
  renderAccountSelect();
  renderTopbarAndAccountStatus();
  renderSidebarSettings();
  renderSkillSelectorAndBadge();
  renderBatchMonitor();
  renderFlowRows();
  renderAccountsModalList();
  renderSkillsModalList();
  updateCapcutRibbonButtonLabel();
}

function renderAccountSelect() {
  const sel = document.getElementById('accountSelect');
  if (!sel || !state.activeAccount) return;

  sel.innerHTML = '';
  state.accounts.forEach((acc) => {
    const opt = document.createElement('option');
    opt.value = acc.id;
    const statusDot = acc.loginVerified ? '🟢' : acc.connected ? '🟡' : '🔴';
    const proxySuffix = acc.proxy ? ' • Proxy' : '';
    opt.textContent = `${statusDot} ${acc.name}${proxySuffix}`;
    if (acc.id === state.activeAccount.id) {
      opt.selected = true;
    }
    sel.appendChild(opt);
  });
}

function renderTopbarAndAccountStatus() {
  const acc = state.activeAccount;
  if (!acc) return;

  const btnConnect = document.getElementById('btnConnectChrome');
  const cdpLed = document.getElementById('cdpLed');
  const btnTitle = document.getElementById('btnConnectTitle');
  const btnSub = document.getElementById('btnConnectSub');

  if (!btnConnect || !cdpLed || !btnTitle || !btnSub) return;

  const proxyTag = acc.proxy ? ' • Proxy' : '';

  if (acc.connected && acc.loginVerified) {
    btnConnect.classList.add('connected');
    cdpLed.className = 'status-led led-green';
    btnTitle.textContent = 'Đã kết nối';
    btnSub.textContent = acc.proxy ? 'Proxy' : '';
  } else if (acc.connected) {
    btnConnect.classList.add('connected');
    cdpLed.className = 'status-led led-green';
    btnTitle.textContent = 'Đang mở Chrome';
    btnSub.textContent = 'Chờ đăng nhập';
  } else if (acc.savedAccount || acc.loginVerified) {
    btnConnect.classList.add('connected');
    cdpLed.className = 'status-led led-green';
    btnTitle.textContent = 'Kết nối lại';
    btnSub.textContent = `Đã lưu phiên${proxyTag}`;
  } else {
    btnConnect.classList.remove('connected');
    cdpLed.className = 'status-led led-red';
    btnTitle.textContent = 'Kết nối tài khoản';
    btnSub.textContent = `Bấm để đăng nhập${proxyTag}`;
  }
}

function parseDurationToSeconds(rawVal) {
  if (rawVal === null || rawVal === undefined) return 10;
  const str = String(rawVal).trim().toLowerCase();
  if (!str) return 10;
  const colon = str.match(/^(\d+)\s*:\s*(\d{1,2})$/);
  if (colon) {
    const t = (Number(colon[1]) || 0) * 60 + (Number(colon[2]) || 0);
    return Math.max(5, Math.min(3600, Math.round(t || 10)));
  }
  const minMatch = str.match(/^(\d+(?:[.,]\d+)?)\s*(?:m|min|p|phut|phút)\s*(\d+)?/i);
  if (minMatch) {
    const m = parseFloat(minMatch[1].replace(',', '.')) || 0;
    const extraS = minMatch[2] ? Number(minMatch[2]) || 0 : 0;
    return Math.max(5, Math.min(3600, Math.round(m * 60 + extraS)));
  }
  const num = parseFloat(str.replace(',', '.'));
  if (!Number.isFinite(num) || num <= 0) return 10;
  return Math.max(5, Math.min(3600, Math.round(num)));
}

function formatDurationBadgeSummary(sec) {
  const n = Math.max(5, Math.min(3600, Math.round(Number(sec) || 10)));
  const parts = n > 10 ? Math.ceil(n / 10) : 1;
  if (n < 60) {
    return `${n}s • ${parts} phần`;
  }
  const mins = Math.floor(n / 60);
  const rem = n % 60;
  const timeText = rem === 0 ? `${mins} phút (${n}s)` : `${mins}p${String(rem).padStart(2, '0')}s (${n}s)`;
  return `${timeText} • ${parts} phần`;
}

function renderSidebarSettings() {
  const acc = state.activeAccount;
  if (!acc || !acc.settings) return;
  const s = acc.settings;

  document.querySelectorAll('#aspectRatioGroup .ratio-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.ratio === s.aspectRatio);
  });

  const curDurSec = parseDurationToSeconds(s.duration || '10s');
  const normDurStr = `${curDurSec}s`;
  let matchedDurationPreset = false;
  document.querySelectorAll('#durationGroup .pill-btn').forEach((btn) => {
    const isMatch = btn.dataset.duration === normDurStr;
    if (isMatch) matchedDurationPreset = true;
    btn.classList.toggle('active', isMatch);
  });

  const durBadge = document.getElementById('durationSummaryBadge');
  if (durBadge) {
    durBadge.textContent = formatDurationBadgeSummary(curDurSec);
  }
  const customDurBox = document.getElementById('customDurationBox');
  if (customDurBox) {
    customDurBox.classList.toggle('custom-active', !matchedDurationPreset);
  }
  const inputCustomDur = document.getElementById('inputCustomDuration');
  const selectDurUnit = document.getElementById('selectDurationUnit');
  if (inputCustomDur && selectDurUnit && document.activeElement !== inputCustomDur) {
    if (selectDurUnit.value === 'min') {
      inputCustomDur.value = Number((curDurSec / 60).toFixed(2));
    } else {
      inputCustomDur.value = curDurSec;
    }
  }

  document.getElementById('selectResolution').value = s.resolution || '720p';
  document.getElementById('selectCameraMotion').value = s.cameraMotion || 'Auto';

  const transSelect = document.getElementById('selectTransitionEffect');
  if (transSelect) {
    transSelect.value = s.transitionEffect || 'fade';
  }

  document.getElementById('chkBackgroundMode').checked = s.backgroundMode !== false;
  document.getElementById('chkNativeAudio').checked = Boolean(s.nativeAudio);
  if (document.getElementById('chkEnableDialogue')) {
    document.getElementById('chkEnableDialogue').checked = Boolean(s.enableDialogue);
  }
  const voiceSel = document.getElementById('selectVoicePreset');
  if (voiceSel) {
    voiceSel.value = s.voicePreset || 'auto';
  }
  const voiceNoteInp = document.getElementById('inputVoiceCustomNote');
  if (voiceNoteInp) {
    if (document.activeElement !== voiceNoteInp) {
      voiceNoteInp.value = s.voiceCustomNote || '';
    }
    voiceNoteInp.placeholder =
      s.voicePreset === 'custom'
        ? 'Mô tả chất giọng riêng (VD: Giọng nữ Hà Nội 24 tuổi trong trẻo, nói ấm áp...)'
        : 'Ghi chú giọng chung (VD: nói chậm rãi, giọng cô giáo 25 tuổi...)';
  }
  document.getElementById('chkInjectParams').checked = s.injectParamsIntoPrompt !== false;

  const concurrency = Math.max(1, Math.min(20, Number(s.concurrency) || 6));
  const inputConc = document.getElementById('inputConcurrency');
  if (inputConc) inputConc.value = concurrency;
  const badgeConc = document.getElementById('concurrencyBadgeLabel');
  if (badgeConc) badgeConc.textContent = `${concurrency} luồng`;
  document.querySelectorAll('#concurrencyPresetGroup .preset-chip').forEach((chip) => {
    btnToggleActive(chip, Number(chip.dataset.threads) === Number(concurrency));
  });

  const runAllTitle = document.getElementById('runAllBtnTitle');
  if (runAllTitle) {
    runAllTitle.textContent = `CHẠY TẤT CẢ (${concurrency} LUỒNG)`;
  }

  const rowCount = acc.rows?.length || s.rowCount || 10;
  document.getElementById('inputRowCount').value = rowCount;
  document.querySelectorAll('#rowPresetGroup .preset-chip').forEach((chip) => {
    btnToggleActive(chip, Number(chip.dataset.rows) === Number(rowCount));
  });

  document.getElementById('inputTargetUrl').value = s.targetUrl || 'https://muse.ai';
  document.getElementById('inputSelFile').value = s.customSelectors?.fileInput || '';
  document.getElementById('inputSelPrompt').value = s.customSelectors?.promptInput || '';
  document.getElementById('inputSelSubmit').value = s.customSelectors?.submitButton || '';
  renderSkillSelectorAndBadge();
  renderSampleVideoSidebar();
}

function updateSampleVideoStatusBadgeOnly() {
  const badgeEl = document.getElementById('sampleVideoStatusBadge');
  if (!badgeEl || !state.activeAccount) return;

  const s = state.activeAccount.settings || {};
  const hasAnyLearnChecked =
    s.sampleLearnMotion !== false || s.sampleLearnCamera !== false || s.sampleLearnScene !== false;
  const globalSample = s.sampleVideo && s.sampleVideo.publicUrl ? s.sampleVideo : null;
  const rowSampleCount = (state.activeAccount.rows || []).filter(
    (r) => r.sampleVideo && r.sampleVideo.publicUrl
  ).length;

  if (!hasAnyLearnChecked && (globalSample || rowSampleCount > 0)) {
    badgeEl.textContent = 'Tạm tắt lọc';
    badgeEl.classList.remove('sample-active-badge');
  } else if (globalSample && rowSampleCount > 0) {
    badgeEl.textContent = `Chung + ${rowSampleCount} hàng`;
    badgeEl.classList.add('sample-active-badge');
  } else if (globalSample) {
    badgeEl.textContent = 'Đang bật (Chung)';
    badgeEl.classList.add('sample-active-badge');
  } else if (rowSampleCount > 0) {
    badgeEl.textContent = `Đang bật (${rowSampleCount} hàng)`;
    badgeEl.classList.add('sample-active-badge');
  } else {
    badgeEl.textContent = 'Tắt';
    badgeEl.classList.remove('sample-active-badge');
  }
}

function renderSampleVideoSidebar() {
  const acc = state.activeAccount;
  if (!acc || !acc.settings) return;
  const s = acc.settings;

  const chkMotion = document.getElementById('chkSampleLearnMotion');
  const chkCamera = document.getElementById('chkSampleLearnCamera');
  const chkScene = document.getElementById('chkSampleLearnScene');
  const hintEl = document.getElementById('sampleSceneModeHint');

  const learnMotion = s.sampleLearnMotion !== false;
  const learnCamera = s.sampleLearnCamera !== false;
  const learnScene = s.sampleLearnScene !== false;

  if (chkMotion) chkMotion.checked = learnMotion;
  if (chkCamera) chkCamera.checked = learnCamera;
  if (chkScene) chkScene.checked = learnScene;

  if (hintEl) {
    if (!learnMotion && !learnCamera && !learnScene) {
      hintEl.textContent = '⚠️ Bạn đã bỏ tích cả 3 ô — Video mẫu sẽ tạm không áp dụng';
    } else if (learnScene) {
      hintEl.textContent = 'Giữ 100% mặt & trang phục ảnh gốc • Đổi bối cảnh theo video mẫu';
    } else {
      hintEl.textContent = 'Giữ 100% mặt, trang phục & NỀN GỐC của ảnh (chỉ học cử chỉ/camera)';
    }
  }

  updateSampleVideoStatusBadgeOnly();

  const boxEl = document.getElementById('globalSampleVideoBox');
  if (!boxEl) return;

  const globalSample = s.sampleVideo && s.sampleVideo.publicUrl ? s.sampleVideo : null;
  const nextUrlKey = globalSample ? `${globalSample.publicUrl}|${globalSample.fileName || ''}` : '__EMPTY__';
  if (boxEl.dataset.loadedSampleKey === nextUrlKey) {
    return;
  }
  boxEl.dataset.loadedSampleKey = nextUrlKey;

  if (globalSample) {
    const durTag =
      globalSample.durationSec && Number(globalSample.durationSec) > 0
        ? `<span class="sample-video-dur-tag">${Number(globalSample.durationSec).toFixed(1)}s</span>`
        : '';
    boxEl.innerHTML = `
      <div class="sample-video-preview-card">
        <div class="sample-video-stage" data-sample-global="preview" title="Rê chuột xem thử • Click để phóng to Video mẫu chung">
          <video class="sample-video-thumb" src="${escapeAttr(globalSample.publicUrl)}" muted loop playsinline preload="metadata"></video>
          ${durTag}
        </div>
        <div class="sample-video-meta-bar">
          <span class="sample-video-fname" title="${escapeAttr(globalSample.fileName || 'Video mẫu chung')}">🎬 ${escapeHtml(globalSample.fileName || 'Video mẫu chung')}</span>
          <div class="sample-video-actions">
            <button type="button" class="btn-sample-act" data-sample-global="preview" title="Phóng to xem video mẫu">👁</button>
            <button type="button" class="btn-sample-act" data-sample-global="pick" title="Đổi sang video mẫu chung khác">Đổi</button>
            <button type="button" class="btn-sample-act btn-sample-del" data-sample-global="remove" title="Gỡ video mẫu chung">×</button>
          </div>
        </div>
      </div>
    `;
    const stageEl = boxEl.querySelector('.sample-video-stage');
    const vidEl = boxEl.querySelector('video.sample-video-thumb');
    if (stageEl && vidEl) {
      stageEl.addEventListener('mouseenter', () => {
        vidEl.play().catch(() => {});
      });
      stageEl.addEventListener('mouseleave', () => {
        vidEl.pause();
      });
    }
  } else {
    boxEl.innerHTML = `
      <div class="sample-video-dropzone" data-sample-global="pick">
        <span class="sample-drop-icon">🎬</span>
        <span class="sample-drop-title">+ Tải Video Mẫu Chung</span>
        <span class="sample-drop-sub">Click hoặc kéo thả video mẫu (.mp4, .mov, .webm)</span>
      </div>
    `;
  }
}

function renderSkillSelectorAndBadge() {
  const selectEl = document.getElementById('selectActiveSkill');
  const badgeEl = document.getElementById('skillStatusBadge');
  const summaryEl = document.getElementById('activeSkillSummaryText');
  if (!selectEl) return;

  const activeSkillId = state.activeAccount?.settings?.activeSkillId || '';
  selectEl.innerHTML = `<option value="">— Không dùng Skill —</option>`;

  (state.skills || []).forEach((sk) => {
    const opt = document.createElement('option');
    opt.value = sk.id;
    opt.textContent = sk.name;
    if (sk.id === activeSkillId) {
      opt.selected = true;
    }
    selectEl.appendChild(opt);
  });

  const currentSkill = (state.skills || []).find((sk) => sk.id === activeSkillId) || null;
  if (badgeEl) {
    if (currentSkill) {
      badgeEl.textContent = 'Đang bật';
      badgeEl.classList.add('skill-active-badge');
    } else {
      badgeEl.textContent = 'Tắt';
      badgeEl.classList.remove('skill-active-badge');
    }
  }

  if (summaryEl) {
    if (currentSkill && currentSkill.summary) {
      summaryEl.textContent = currentSkill.summary;
      summaryEl.classList.remove('hidden');
    } else {
      summaryEl.textContent = '';
      summaryEl.classList.add('hidden');
    }
  }
}

function renderSkillAutoPromptButtons(progress = null) {
  const btnGen = document.getElementById('btnGeneratePromptsBySkill');
  const btnStop = document.getElementById('btnStopSkillPrompts');
  if (!btnGen || !btnStop) return;

  if (state.skillPromptRunning) {
    btnGen.disabled = true;
    const comp = progress?.completed ?? 0;
    const tot = progress?.total ?? 0;
    btnGen.textContent = tot > 0 ? `⏳ Đang viết Prompt (${comp}/${tot})...` : '⏳ AI đang viết Prompt...';
    btnStop.classList.remove('hidden');
  } else {
    btnGen.disabled = false;
    btnGen.textContent = '✨ Viết Prompt Theo Skill';
    btnStop.classList.add('hidden');
  }
}

function resetSkillEditorForm() {
  const idEl = document.getElementById('editSkillId');
  const nameEl = document.getElementById('inputSkillName');
  const sumEl = document.getElementById('inputSkillSummary');
  const instEl = document.getElementById('inputSkillInstructions');
  const headEl = document.getElementById('skillFormHeading');
  const clearBtn = document.getElementById('btnClearSkillForm');

  if (idEl) idEl.value = '';
  if (nameEl) nameEl.value = '';
  if (sumEl) sumEl.value = '';
  if (instEl) instEl.value = '';
  if (headEl) headEl.textContent = 'Tạo / Dán Nội Dung Skill Mới';
  if (clearBtn) clearBtn.classList.add('hidden');
}

function renderSkillsModalList() {
  const container = document.getElementById('skillsModalList');
  const countLabel = document.getElementById('skillTotalCountLabel');
  if (!container) return;

  const skills = state.skills || [];
  if (countLabel) countLabel.textContent = String(skills.length);

  const activeSkillId = state.activeAccount?.settings?.activeSkillId || '';
  container.innerHTML = '';

  if (skills.length === 0) {
    container.innerHTML = `<div class="acc-sub-note">Thư viện đang trống. Hãy nhập file SKILL.md hoặc bấm khôi phục Skill mẫu.</div>`;
    return;
  }

  skills.forEach((sk) => {
    const isApplied = sk.id === activeSkillId;
    const item = document.createElement('div');
    item.className = `account-list-item ${isApplied ? 'active-acc' : ''}`;

    const typeBadge = sk.isBuiltIn
      ? `<span class="banner-badge badge-proxy">Mẫu cài sẵn</span>`
      : `<span class="banner-badge badge-amber">Tự nhập</span>`;

    const activeBadge = isApplied
      ? `<span class="banner-badge badge-green">✓ Đang áp dụng</span>`
      : '';

    item.innerHTML = `
      <div class="acc-item-top">
        <div class="acc-item-head-left">
          <span class="acc-item-name">${escapeHtml(sk.name)}</span>
          ${typeBadge}
          ${activeBadge}
        </div>
        <div class="acc-item-actions">
          <button type="button" class="btn-mini" data-skill-action="apply" data-id="${escapeAttr(sk.id)}">
            ${isApplied ? 'Bỏ chọn' : 'Áp dụng'}
          </button>
          <button type="button" class="btn-mini" data-skill-action="edit" data-id="${escapeAttr(sk.id)}">
            ✎ Sửa / Xem
          </button>
          <button type="button" class="btn-mini" data-skill-action="export" data-id="${escapeAttr(sk.id)}">
            ⬇ Xuất .md
          </button>
          <button type="button" class="btn-mini btn-danger-soft" data-skill-action="delete" data-id="${escapeAttr(sk.id)}" data-name="${escapeAttr(sk.name)}">
            🗑 Xóa
          </button>
        </div>
      </div>
      <div class="skill-item-summary">${escapeHtml(sk.summary || '')}</div>
    `;
    container.appendChild(item);
  });
}

function btnToggleActive(el, active) {
  if (el) el.classList.toggle('active', Boolean(active));
}

function renderBatchMonitor() {
  const stats = state.batchStats;
  const pill = document.getElementById('batchMonitorBar');
  const pillText = document.getElementById('batchMonitorText');
  const btnStop = document.getElementById('btnStopBatch');
  const subLabel = document.getElementById('batchStatusSub');
  const concurrency = Math.max(1, Math.min(20, Number(state.activeAccount?.settings?.concurrency) || 6));

  if (stats && stats.running) {
    pill.classList.remove('hidden');
    btnStop.classList.remove('hidden');
    const errText = stats.totalFailed > 0 ? ` • Lỗi: ${stats.totalFailed}` : '';
    pillText.textContent = `${stats.activeThreads}/${stats.batchSize || concurrency} luồng • Xong ${stats.totalCompleted}/${stats.totalTargetRows}${errText}`;
    subLabel.textContent = `Xong ${stats.totalCompleted}/${stats.totalTargetRows}${errText}`;
  } else {
    pill.classList.add('hidden');
    btnStop.classList.add('hidden');
    subLabel.textContent = `Tự bỏ qua nếu lỗi`;
  }
}

function getRowFilterCategory(status) {
  if (status === 'completed') return 'completed';
  if (status === 'error') return 'error';
  if (['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(status)) {
    return 'running';
  }
  return 'ready';
}

function renderRowCountsAndFilterVisibility() {
  const rows = state.activeAccount?.rows || [];
  let ready = 0;
  let running = 0;
  let completed = 0;
  let error = 0;

  rows.forEach((r) => {
    const cat = getRowFilterCategory(r.status);
    if (cat === 'completed') completed++;
    else if (cat === 'error') error++;
    else if (cat === 'running') running++;
    else ready++;

    const el = document.getElementById(`flow-row-${r.index}`);
    if (el) {
      const shouldShow = state.statusFilter === 'all' || state.statusFilter === cat;
      el.classList.toggle('hidden', !shouldShow);
    }
  });

  const setTxt = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = String(val);
  };
  setTxt('countAll', rows.length);
  setTxt('countReady', ready);
  setTxt('countRunning', running);
  setTxt('countCompleted', completed);
  setTxt('countError', error);
}

function updateCapcutRibbonButtonLabel() {
  const sub = document.getElementById('capcutBtnSub');
  const title = document.getElementById('capcutBtnTitle');
  if (!sub || !title) return;
  const count = state.selectedRows.size;
  if (count > 0) {
    title.textContent = `Cắt & Nối (${count})`;
    sub.textContent = `Nối ${count} hàng đã chọn`;
  } else {
    title.textContent = 'Cắt & Nối';
    sub.textContent = 'Bàn dựng video';
  }
}

function renderFlowRows() {
  const container = document.getElementById('flowRowsContainer');
  if (!container || !state.activeAccount) return;

  const rows = state.activeAccount.rows || [];
  container.innerHTML = '';

  rows.forEach((row) => {
    const rowEl = createRowElement(row);
    container.appendChild(rowEl);
  });

  renderRowCountsAndFilterVisibility();
  updateCapcutRibbonButtonLabel();
}

function getRowStateBadgeInfo(status) {
  switch (status) {
    case 'queued':
      return { cls: 'state-queued', label: 'Đang chờ', rowCls: '' };
    case 'connecting':
    case 'uploading':
    case 'submitting':
    case 'rendering':
    case 'downloading':
      return { cls: 'state-running', label: 'Đang tạo', rowCls: 'row-running' };
    case 'completed':
      return { cls: 'state-completed', label: 'Hoàn tất', rowCls: 'row-completed' };
    case 'error':
      return { cls: 'state-error', label: 'Lỗi', rowCls: 'row-error' };
    default:
      return { cls: 'state-idle', label: 'Sẵn sàng', rowCls: '' };
  }
}

function extractQuotedListClient(rawText) {
  if (!rawText) return [];
  const norm = String(rawText)
    .replace(/[“”«»„‟]/g, '"')
    .trim();
  if (!norm) return [];
  const list = [];
  const re = /"([^"]+)"/g;
  let m;
  while ((m = re.exec(norm)) !== null) {
    const clean = m[1].replace(/\s+/g, ' ').trim();
    if (clean) list.push(clean);
  }
  return list;
}

function countSpeechWordsClient(text) {
  const s = String(text || '').trim();
  if (!s) return 0;
  return s.split(/\s+/).filter(Boolean).length;
}

function splitLongSpeechChunksClient(rawText, maxChunks = 1, targetWords = 22) {
  const clean = String(rawText || '')
    .replace(/[“”«»„‟"]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) return [];
  if (maxChunks <= 1) return [clean];

  const atomic = clean
    .split(/(?<=[.!?;|])\s+/)
    .map((u) => u.replace(/^[|]+|[|]+$/g, '').trim())
    .filter(Boolean);

  const refined = [];
  for (const unit of atomic) {
    if (countSpeechWordsClient(unit) > Math.round(targetWords * 1.35) && unit.includes(',')) {
      refined.push(
        ...unit
          .split(/(?<=,)\s+/)
          .map((sp) => sp.trim())
          .filter(Boolean)
      );
    } else {
      refined.push(unit);
    }
  }

  if (refined.length === 1 && countSpeechWordsClient(refined[0]) > Math.round(targetWords * 1.3)) {
    const words = refined[0].split(/\s+/).filter(Boolean);
    const needed = Math.min(maxChunks, Math.max(2, Math.ceil(words.length / targetWords)));
    const per = Math.ceil(words.length / needed);
    const out = [];
    for (let i = 0; i < words.length; i += per) {
      out.push(words.slice(i, i + per).join(' '));
    }
    return out;
  }

  const totalWords = countSpeechWordsClient(clean);
  const desired = Math.min(maxChunks, Math.max(1, Math.min(refined.length, Math.ceil(totalWords / targetWords))));
  if (desired <= 1) return [clean];

  const ideal = totalWords / desired;
  const result = [];
  let buf = [];
  let curW = 0;

  for (let i = 0; i < refined.length; i++) {
    const u = refined[i];
    const w = countSpeechWordsClient(u);
    const remUnits = refined.length - i;
    const remSlots = desired - result.length;
    if (buf.length > 0 && remSlots > 1 && (curW + w > ideal * 1.28 || remUnits < remSlots)) {
      result.push(buf.join(' ').trim());
      buf = [u];
      curW = w;
    } else {
      buf.push(u);
      curW += w;
    }
  }
  if (buf.length > 0) result.push(buf.join(' ').trim());
  return result;
}

function formatDialogueIntoQuotedParts(rawText, totalParts = 1) {
  const parts = Math.max(1, Number(totalParts) || 1);
  const trimmed = String(rawText || '').trim();
  if (!trimmed) {
    if (parts <= 1) {
      return '"Nhập câu thoại (~20 chữ) tại đây..."';
    }
    const tpl = [];
    for (let i = 1; i <= parts; i++) {
      const sSec = (i - 1) * 10;
      const eSec = i * 10;
      tpl.push(`"Lời thoại phần ${i} (${sSec}s-${eSec}s)..."`);
    }
    return tpl.join('\n');
  }

  const existingQuotes = extractQuotedListClient(trimmed);
  let chunks = [];
  if (existingQuotes.length >= 2) {
    if (existingQuotes.length <= parts) {
      chunks = existingQuotes;
    } else {
      for (let p = 0; p < parts; p++) {
        const s = Math.floor((p * existingQuotes.length) / parts);
        const e = Math.floor(((p + 1) * existingQuotes.length) / parts);
        chunks.push(existingQuotes.slice(s, e).join(' '));
      }
    }
  } else {
    const plainSource = existingQuotes.length === 1 ? existingQuotes[0] : trimmed;
    const lines = plainSource
      .split(/\r?\n|\s*\|\|\s*|\s+\|\s+/)
      .map((l) => l.replace(/^(?:phần|part|đoạn|nhịp|p)\s*\d+\s*[:.-]\s*/i, '').trim())
      .filter(Boolean);
    if (lines.length >= 2 && lines.length <= parts) {
      chunks = lines;
    } else {
      chunks = splitLongSpeechChunksClient(plainSource, parts, 22);
    }
  }

  return chunks.map((c) => `"${c.replace(/"/g, '').trim()}"`).join('\n');
}

function getDialogueLiveBadgeMeta(rawDialogue, durationSec = 10, enableDialogue = false) {
  const clean = String(rawDialogue || '').trim();
  const dur = Math.max(5, Number(durationSec) || 10);
  const totalParts = dur > 10 ? Math.ceil(dur / 10) : 1;

  if (!clean) {
    return {
      cls: '',
      text: totalParts > 1 ? `Trống • Hỗ trợ ${totalParts} câu "..."` : 'Trống (Không thoại)',
      mutedWarn: false
    };
  }

  if (!enableDialogue) {
    return {
      cls: 'pill-warn',
      text: '🔇 Đang tắt công tắc Lời thoại ở Sidebar',
      mutedWarn: true
    };
  }

  const qList = extractQuotedListClient(clean);
  if (totalParts <= 1) {
    const spoken = qList.length > 0 ? qList.join(' ') : clean;
    const wCount = countSpeechWordsClient(spoken);
    const maxRec = Math.max(10, Math.round(dur * 2.5));
    if (wCount <= maxRec) {
      return { cls: 'pill-ok', text: `✓ ${wCount} chữ • Khớp ${dur}s`, mutedWarn: false };
    }
    return {
      cls: 'pill-warn',
      text: `⚠️ ${wCount} chữ (Nên ≤${maxRec} chữ/${dur}s)`,
      mutedWarn: false
    };
  }

  if (qList.length === totalParts) {
    return {
      cls: 'pill-ok',
      text: `✓ Đã cắt ${qList.length}/${totalParts} câu "..." (10s/phần)`,
      mutedWarn: false
    };
  }
  if (qList.length === 1 && countSpeechWordsClient(qList[0]) > 28) {
    const autoCount = splitLongSpeechChunksClient(qList[0], totalParts, 22).length;
    return {
      cls: 'pill-info',
      text: `⚡ Tự chia ${autoCount}/${totalParts} nhịp 10s`,
      mutedWarn: false
    };
  }
  if (qList.length > 0 && qList.length < totalParts) {
    return {
      cls: 'pill-info',
      text: `🎙️ ${qList.length}/${totalParts} câu "..." (${totalParts - qList.length} phần cuối im lặng)`,
      mutedWarn: false
    };
  }
  if (qList.length > totalParts) {
    return {
      cls: 'pill-info',
      text: `🎙️ ${qList.length} câu "..." ➔ Gộp vào ${totalParts} phần 10s`,
      mutedWarn: false
    };
  }

  const autoSegs = splitLongSpeechChunksClient(clean, totalParts, 22);
  return {
    cls: 'pill-info',
    text: `⚡ Tự chia ${autoSegs.length}/${totalParts} nhịp 10s`,
    mutedWarn: false
  };
}

function refreshRowDialogueBadge(rowIndex, rawDialogueVal) {
  const pillEl = document.getElementById(`row-dialogue-pill-${rowIndex}`);
  const wrapEl = document.getElementById(`row-dialogue-wrap-${rowIndex}`);
  const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
  if (!pillEl || !state.activeAccount) return;
  const durSec = parseDurationToSeconds(state.activeAccount.settings?.duration || '10s');
  const totalParts = durSec > 10 ? Math.ceil(durSec / 10) : 1;
  const enableDlg = Boolean(state.activeAccount.settings?.enableDialogue);
  const meta = getDialogueLiveBadgeMeta(rawDialogueVal, durSec, enableDlg);
  pillEl.className = `dialogue-live-pill ${meta.cls}`.trim();
  pillEl.textContent = meta.text;
  pillEl.title = meta.text;
  if (wrapEl) {
    wrapEl.classList.toggle('dialogue-muted-warning', Boolean(meta.mutedWarn));
  }
  if (dlgEl) {
    dlgEl.placeholder =
      totalParts > 1
        ? `Nhập lời thoại cho Hàng #${rowIndex} (${totalParts} phần x 10s): đặt mỗi câu trong "..." để tự gán riêng từng nhịp 10s. VD: "Câu phần 1..." "Câu phần 2..."`
        : `Nhập lời thoại nhân vật nói cho Hàng #${rowIndex} (để trống nếu không nói)...`;
  }
}

function refreshAllRowDialogueBadges() {
  const rows = state.activeAccount?.rows || [];
  rows.forEach((r) => {
    const el = document.getElementById(`row-dialogue-${r.index}`);
    const val = el ? el.value : r.dialogue || '';
    refreshRowDialogueBadge(r.index, val);
  });
}

function createRowElement(row) {
  const badgeInfo = getRowStateBadgeInfo(row.status);
  const isBusy = ['connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(row.status);
  const isSelected = state.selectedRows.has(row.index);

  const cat = getRowFilterCategory(row.status);
  const hiddenCls = state.statusFilter !== 'all' && state.statusFilter !== cat ? 'hidden' : '';
  const selectedCls = isSelected ? 'row-selected-merge' : '';

  const rowEl = document.createElement('div');
  rowEl.className = `flow-row ${badgeInfo.rowCls} ${selectedCls} ${hiddenCls}`.trim();
  rowEl.id = `flow-row-${row.index}`;
  rowEl.dataset.index = row.index;

  const curDurSecForRow = parseDurationToSeconds(state.activeAccount?.settings?.duration || '10s');
  const totalPartsForRow = curDurSecForRow > 10 ? Math.ceil(curDurSecForRow / 10) : 1;
  const dlgMeta = getDialogueLiveBadgeMeta(
    row.dialogue || '',
    curDurSecForRow,
    Boolean(state.activeAccount?.settings?.enableDialogue)
  );
  const dialoguePlaceholder =
    totalPartsForRow > 1
      ? `Nhập lời thoại cho Hàng #${row.index} (${totalPartsForRow} phần x 10s): đặt mỗi câu trong "..." để tự gán riêng từng nhịp 10s. VD: "Câu phần 1..." "Câu phần 2..."`
      : `Nhập lời thoại nhân vật nói cho Hàng #${row.index} (để trống nếu không nói)...`;

  const validImgs = Array.isArray(row.referenceImages)
    ? row.referenceImages.filter((im) => im && im.publicUrl)
    : [];
  let refsHtml = '';

  if (validImgs.length === 0) {
    refsHtml = `
      <div class="ref-slot" data-action="pick-ref" data-row="${row.index}" data-slot="0" title="Click hoặc kéo thả 1–5 ảnh tham chiếu / bộ trang phục vào Hàng #${row.index}">
        <div class="ref-slot-empty">
          <span class="ref-slot-plus">+</span>
          <span>Thêm 1–5 ảnh</span>
        </div>
      </div>
    `;
  } else if (validImgs.length === 1) {
    const img = validImgs[0];
    refsHtml = `
      <div class="ref-single-split">
        <div class="ref-slot has-image" data-action="replace-ref" data-row="${row.index}" data-slot="0" title="Bộ #1 (${escapeAttr(img.fileName || '')}) • Click để đổi ảnh này">
          <img src="${escapeAttr(img.publicUrl)}" class="ref-thumb" alt="Hàng #${row.index}" />
          <span class="ref-filename-tag">${escapeHtml(img.fileName || `Ảnh #${row.index}`)}</span>
          <button type="button" class="ref-remove-btn" data-action="remove-ref" data-row="${row.index}" data-slot="0" title="Xóa ảnh">×</button>
        </div>
        <button type="button" class="ref-add-more-tile" data-action="append-row-refs" data-row="${row.index}" title="Thêm ảnh bộ đồ thứ 2..5 vào Hàng #${row.index} để làm video biến hình thay nhiều bộ đồ (tối đa 5 ảnh/hàng)">
          <span class="ref-add-more-plus">+</span>
          <span class="ref-add-more-txt">Thêm<br/>bộ 2..5</span>
        </button>
      </div>
    `;
  } else {
    const curDurSec = curDurSecForRow;
    const recSec = validImgs.length * 10;
    const cardsHtml = validImgs
      .map(
        (im, sIdx) => `
          <div class="ref-mini-card" data-action="replace-ref" data-row="${row.index}" data-slot="${sIdx}" title="Bộ #${sIdx + 1}: ${escapeAttr(im.fileName || '')} • Click để đổi ảnh này">
            <img src="${escapeAttr(im.publicUrl)}" alt="Bộ ${sIdx + 1}" />
            <span class="ref-slot-num-badge">Bộ ${sIdx + 1}</span>
            <button type="button" class="ref-mini-remove-btn" data-action="remove-ref" data-row="${row.index}" data-slot="${sIdx}" title="Xóa Bộ #${sIdx + 1}">×</button>
          </div>
        `
      )
      .join('');
    const addTileHtml =
      validImgs.length < 5
        ? `
          <button type="button" class="ref-mini-add-btn" data-action="append-row-refs" data-row="${row.index}" title="Thêm ảnh Bộ #${validImgs.length + 1} (tối đa 5 ảnh/hàng)">
            <span style="font-size:14px;line-height:1;">+</span>
            <span>Bộ ${validImgs.length + 1}</span>
          </button>
        `
        : '';
    const durSuggestHtml =
      curDurSec < validImgs.length * 8
        ? `<button type="button" class="ref-dur-suggest-btn" data-action="apply-recommended-dur" data-sec="${recSec}" title="Gợi ý đặt ${recSec}s (${validImgs.length} phần x 10s) để mỗi bộ trang phục có trọn ~10s biến hình mượt nhất!">⚡ Đặt ${recSec}s</button>`
        : `<span>✓ ${curDurSec}s</span>`;

    refsHtml = `
      <div class="ref-multi-wrap">
        <div class="ref-multi-grid">
          ${cardsHtml}
          ${addTileHtml}
        </div>
        <div class="ref-multi-hint-bar">
          <span>🪭 ${validImgs.length} ảnh biến hình</span>
          ${durSuggestHtml}
        </div>
      </div>
    `;
  }

  const rowSample = row.sampleVideo && row.sampleVideo.publicUrl ? row.sampleVideo : null;
  const globalSample =
    state.activeAccount?.settings?.sampleVideo?.publicUrl ? state.activeAccount.settings.sampleVideo : null;

  let rowSampleHtml = '';
  if (rowSample) {
    const durSuffix =
      rowSample.durationSec && Number(rowSample.durationSec) > 0
        ? ` (${Number(rowSample.durationSec).toFixed(1)}s)`
        : '';
    rowSampleHtml = `
      <div class="row-sample-bar has-row-sample">
        <button type="button" class="row-sample-main-btn" data-action="preview-row-sample" data-row="${row.index}" title="Xem Video mẫu riêng của Hàng #${row.index}: ${escapeAttr(rowSample.fileName || '')}">
          <span>🎬 ${escapeHtml(rowSample.fileName || 'Mẫu riêng')}${durSuffix}</span>
        </button>
        <button type="button" class="row-sample-mini-btn" data-action="pick-row-sample" data-row="${row.index}" title="Đổi Video mẫu riêng cho Hàng #${row.index}">🔄</button>
        <button type="button" class="row-sample-mini-btn sample-mini-del" data-action="remove-row-sample" data-row="${row.index}" title="Gỡ Video mẫu riêng của Hàng #${row.index}">×</button>
      </div>
    `;
  } else if (globalSample) {
    rowSampleHtml = `
      <div class="row-sample-bar using-global-sample">
        <button type="button" class="row-sample-main-btn" data-action="pick-row-sample" data-row="${row.index}" title="Đang dùng Video mẫu chung (${escapeAttr(globalSample.fileName || '')}) • Bấm để gắn Video mẫu riêng cho Hàng #${row.index}">
          <span>🎞 Theo mẫu chung • Đổi riêng</span>
        </button>
      </div>
    `;
  } else {
    rowSampleHtml = `
      <div class="row-sample-bar empty-sample">
        <button type="button" class="row-sample-main-btn" data-action="pick-row-sample" data-row="${row.index}" title="Chọn hoặc kéo thả Video mẫu riêng cho Hàng #${row.index}">
          <span>🎞 + Video mẫu riêng</span>
        </button>
      </div>
    `;
  }

  let videoBoxHtml = '';
  if (row.videoUrl) {
    videoBoxHtml = `<video class="row-video-player" src="${escapeAttr(row.videoUrl)}" controls preload="metadata"></video>`;
  } else if (isBusy) {
    videoBoxHtml = `
      <div class="video-placeholder">
        <div class="cdp-spinner"></div>
        <span class="placeholder-active">Đang tạo video...</span>
      </div>
    `;
  } else if (row.status === 'error') {
    videoBoxHtml = `
      <div class="video-placeholder">
        <span class="placeholder-err-title">⚠️ Đã bỏ qua</span>
        <span class="placeholder-err-desc">${escapeHtml(row.error || row.statusMessage || 'Lỗi tạo video')}</span>
      </div>
    `;
  } else {
    videoBoxHtml = `
      <div class="video-placeholder">
        <span>Chưa có video</span>
      </div>
    `;
  }

  rowEl.innerHTML = `
    <div class="row-col-index">
      <label class="row-idx-top" title="Chọn Hàng #${row.index} để nối video">
        <input type="checkbox" class="row-select-chk" data-row="${row.index}" ${isSelected ? 'checked' : ''} />
        <span class="row-num">#${String(row.index).padStart(2, '0')}</span>
      </label>
      <span class="row-state-badge ${badgeInfo.cls}" id="row-badge-${row.index}">${badgeInfo.label}</span>
    </div>

    <div class="row-col-refs" id="row-refs-${row.index}">
      ${refsHtml}
      ${rowSampleHtml}
    </div>

    <div class="row-col-prompt">
      <div class="prompt-dialogue-split">
        <div class="motion-box-wrap">
          <div class="subbox-mini-header">
            <span class="subbox-mini-title">🎬 Chuyển động &amp; Bối cảnh</span>
          </div>
          <textarea
            class="prompt-textarea"
            id="row-prompt-${row.index}"
            data-row="${row.index}"
            placeholder="Nhập mô tả cử chỉ, hành động, góc máy cho Hàng #${row.index}..."
          >${escapeHtml(row.prompt || '')}</textarea>
        </div>

        <div class="dialogue-box-wrap ${dlgMeta.mutedWarn ? 'dialogue-muted-warning' : ''}" id="row-dialogue-wrap-${row.index}">
          <div class="subbox-mini-header">
            <span class="subbox-mini-title">🎙️ Lời thoại nhân vật</span>
            <div class="dialogue-header-right">
              <span class="dialogue-live-pill ${dlgMeta.cls}" id="row-dialogue-pill-${row.index}" title="${escapeAttr(dlgMeta.text)}">${escapeHtml(dlgMeta.text)}</span>
              <button
                type="button"
                class="btn-dialogue-split-helper"
                data-action="auto-quote-dialogue"
                data-row="${row.index}"
                title="Tự động chia đoạn văn bản dài thành từng câu trong ngoặc kép &quot;...&quot; (~20-22 chữ/câu) khớp với từng phân đoạn 10s"
              >✂️ Tự chia &quot;...&quot;</button>
            </div>
          </div>
          <textarea
            class="dialogue-textarea"
            id="row-dialogue-${row.index}"
            data-row="${row.index}"
            placeholder="${escapeAttr(dialoguePlaceholder)}"
          >${escapeHtml(row.dialogue || '')}</textarea>
        </div>
      </div>

      <div class="prompt-footer-bar">
        <span class="prompt-live-status" id="row-status-msg-${row.index}" title="${escapeAttr(row.statusMessage || '')}">
          ${escapeHtml(row.statusMessage || 'Sẵn sàng')}
        </span>
      </div>
    </div>

    <div class="row-col-video" id="row-video-box-${row.index}">
      ${videoBoxHtml}
    </div>

    <div class="row-col-actions">
      <button type="button" class="row-btn btn-run-single" data-action="run-row" data-row="${row.index}" ${isBusy ? 'disabled' : ''}>
        ▶ Chạy
      </button>
      <button type="button" class="row-btn btn-edit-capcut" data-action="edit-capcut-row" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        ✂️ Sửa
      </button>
      <button type="button" class="row-btn btn-download" data-action="download-video" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        ⬇ Tải
      </button>
      <button type="button" class="row-btn btn-preview" data-action="preview-video" data-row="${row.index}" ${row.videoUrl ? '' : 'disabled'}>
        👁 Xem
      </button>
      <button type="button" class="row-btn btn-regen" data-action="regen-row" data-row="${row.index}" ${isBusy ? 'disabled' : ''}>
        ↻ Lại
      </button>
    </div>
  `;

  const chk = rowEl.querySelector('.row-select-chk');
  if (chk) {
    chk.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.selectedRows.add(row.index);
        rowEl.classList.add('row-selected-merge');
      } else {
        state.selectedRows.delete(row.index);
        rowEl.classList.remove('row-selected-merge');
      }
      updateCapcutRibbonButtonLabel();
    });
  }

  const textarea = rowEl.querySelector(`#row-prompt-${row.index}`);
  textarea.addEventListener('input', (e) => {
    const val = e.target.value;
    row.prompt = val;
    if (promptSaveTimers.has(row.index)) {
      clearTimeout(promptSaveTimers.get(row.index));
    }
    promptSaveTimers.set(
      row.index,
      setTimeout(() => {
        saveRowFields(row.index, { prompt: val });
      }, 350)
    );
  });

  const dialogueTextarea = rowEl.querySelector(`#row-dialogue-${row.index}`);
  if (dialogueTextarea) {
    dialogueTextarea.addEventListener('input', (e) => {
      const val = e.target.value;
      row.dialogue = val;
      refreshRowDialogueBadge(row.index, val);
      if (dialogueSaveTimers.has(row.index)) {
        clearTimeout(dialogueSaveTimers.get(row.index));
      }
      dialogueSaveTimers.set(
        row.index,
        setTimeout(() => {
          saveRowFields(row.index, { dialogue: val });
        }, 350)
      );
    });
  }

  const refsColEl = rowEl.querySelector(`#row-refs-${row.index}`);
  const slotEl = rowEl.querySelector('.ref-slot');
  if (refsColEl) {
    refsColEl.addEventListener('dragover', (e) => {
      e.preventDefault();
      slotEl?.classList.add('drag-over');
      refsColEl.classList.add('drag-over-video');
    });
    refsColEl.addEventListener('dragleave', (e) => {
      if (!refsColEl.contains(e.relatedTarget)) {
        slotEl?.classList.remove('drag-over');
        refsColEl.classList.remove('drag-over-video');
      }
    });
    refsColEl.addEventListener('drop', async (e) => {
      e.preventDefault();
      slotEl?.classList.remove('drag-over');
      refsColEl.classList.remove('drag-over-video');
      const allDropped = Array.from(e.dataTransfer?.files || []);
      const imgFiles = allDropped.filter((f) => isImageFileObj(f));
      const vidFiles = allDropped.filter((f) => isVideoFileObj(f));
      if (imgFiles.length > 0) {
        await uploadFilesToRowSlots(row.index, 0, imgFiles);
      }
      if (vidFiles.length > 0) {
        await uploadRowSampleVideo(row.index, vidFiles[0]);
      }
    });
  }

  return rowEl;
}

function updateSingleRowDom(row) {
  const existingEl = document.getElementById(`flow-row-${row.index}`);
  if (!existingEl) return;

  const activeId = document.activeElement?.id;
  const isFocusedEditor =
    activeId === `row-prompt-${row.index}` || activeId === `row-dialogue-${row.index}`;

  if (isFocusedEditor) {
    const badgeInfo = getRowStateBadgeInfo(row.status);
    const cat = getRowFilterCategory(row.status);
    const hiddenCls = state.statusFilter !== 'all' && state.statusFilter !== cat ? 'hidden' : '';
    const selectedCls = state.selectedRows.has(row.index) ? 'row-selected-merge' : '';
    existingEl.className = `flow-row ${badgeInfo.rowCls} ${selectedCls} ${hiddenCls}`.trim();
    const badgeEl = document.getElementById(`row-badge-${row.index}`);
    if (badgeEl) {
      badgeEl.className = `row-state-badge ${badgeInfo.cls}`;
      badgeEl.textContent = badgeInfo.label;
    }
    const msgEl = document.getElementById(`row-status-msg-${row.index}`);
    if (msgEl) {
      msgEl.textContent = row.statusMessage || '';
    }
    return;
  }

  const newEl = createRowElement(row);
  existingEl.replaceWith(newEl);
}

async function saveRowFields(rowIndex, patch) {
  if (!state.activeAccount || !patch) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}`, {
      method: 'PUT',
      body: JSON.stringify(patch)
    });
    if (res && res.autoEnabledDialogue && res.settings) {
      state.activeAccount.settings = res.settings;
      const chkDlg = document.getElementById('chkEnableDialogue');
      if (chkDlg) chkDlg.checked = Boolean(res.settings.enableDialogue);
      refreshAllRowDialogueBadges();
      showToast('🎙️ Đã tự động bật Lời thoại nhân vật!', 'info');
    }
  } catch (_) {}
}

async function saveRowPrompt(rowIndex, promptText) {
  await saveRowFields(rowIndex, { prompt: promptText });
}

async function uploadBulkImagesOnePerRow(files, startRowIndex = 1) {
  if (!state.activeAccount || !files || files.length === 0) return;

  const sortedFiles = Array.from(files).sort((a, b) =>
    (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' })
  );

  const formData = new FormData();
  formData.append('startRowIndex', String(startRowIndex));
  sortedFiles.forEach((f) => {
    formData.append('images', f);
  });

  try {
    showToast(`Đang tải ${sortedFiles.length} ảnh...`, 'info');
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/bulk-images`, {
      method: 'POST',
      body: formData
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || `Đã chia ${sortedFiles.length} ảnh vào các hàng!`, 'success');
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

function openBulkImagePicker(startRowIndex = 1) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await uploadBulkImagesOnePerRow(files, startRowIndex);
    }
  };
  input.click();
}

async function appendImagesToSingleRow(rowIndex, files, { replaceAll = false } = {}) {
  if (!state.activeAccount || !files || files.length === 0) return;

  const sortedFiles = Array.from(files)
    .slice(0, 5)
    .sort((a, b) => (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' }));

  const formData = new FormData();
  if (replaceAll) {
    formData.append('replaceAll', 'true');
  }
  sortedFiles.forEach((f) => {
    formData.append('images', f);
  });

  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/images`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
    if (res.totalOnRow >= 2) {
      const curDurSec = parseDurationToSeconds(state.activeAccount?.settings?.duration || '10s');
      const recSec = res.totalOnRow * 10;
      const durTip = curDurSec < res.totalOnRow * 8 ? ` • Gợi ý bấm "⚡ Đặt ${recSec}s" để chia đều ${res.totalOnRow} bộ!` : '';
      showToast(`🪭 Hàng #${rowIndex}: Đã gắn ${res.totalOnRow} ảnh biến hình${durTip}`, 'success');
    } else if (res.message) {
      showToast(res.message, 'success');
    }
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

async function uploadFilesToRowSlots(rowIndex, startSlot, files) {
  if (!state.activeAccount || !files || files.length === 0) return;

  // Nếu kéo thả > 5 ảnh cùng lúc ➔ Tự động chia 1 ảnh / 1 hàng như Thêm Ảnh Hàng Loạt
  if (files.length > 5) {
    await uploadBulkImagesOnePerRow(files, Number(rowIndex));
    return;
  }

  // Nếu chọn/kéo thả 2–5 ảnh vào 1 hàng ➔ Gắn thành chuỗi bộ đồ biến hình trên chính hàng đó!
  if (files.length >= 2) {
    await appendImagesToSingleRow(rowIndex, files, { replaceAll: false });
    return;
  }

  const targetSlot = Math.max(0, Math.min(4, Number(startSlot) || 0));
  const formData = new FormData();
  formData.append('image', files[0]);
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/image/${targetSlot}`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
  } catch (err) {
    showToast(`Lỗi tải ảnh: ${err.message}`, 'error');
  }
}

function openFilePickerForSlot(rowIndex, slotIndex = 0) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await uploadFilesToRowSlots(rowIndex, Number(slotIndex), files);
    }
  };
  input.click();
}

function openReplaceSingleSlotPicker(rowIndex, slotIndex = 0) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = false;
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadFilesToRowSlots(rowIndex, Number(slotIndex), [file]);
    }
  };
  input.click();
}

function openAppendRowImagesPicker(rowIndex) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.multiple = true;
  input.onchange = async () => {
    const files = Array.from(input.files || []);
    if (files.length > 0) {
      await appendImagesToSingleRow(rowIndex, files, { replaceAll: false });
    }
  };
  input.click();
}

async function removeReferenceImage(rowIndex, slotIndex = 0) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/image/${slotIndex}`,
      { method: 'DELETE' }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
    }
  } catch (err) {
    showToast(`Lỗi xóa ảnh: ${err.message}`, 'error');
  }
}

function isImageFileObj(file) {
  if (!file) return false;
  if (file.type && file.type.startsWith('image/')) return true;
  return /\.(png|jpe?g|webp|gif|bmp)$/i.test(file.name || '');
}

function isVideoFileObj(file) {
  if (!file) return false;
  if (file.type && file.type.startsWith('video/')) return true;
  return /\.(mp4|mov|webm|mkv|avi|m4v)$/i.test(file.name || '');
}

function previewSampleVideoModal(videoMeta, titleLabel = '🎬 VIDEO MẪU THAM CHIẾU') {
  if (!videoMeta || !videoMeta.publicUrl) return;
  const modal = document.getElementById('videoPreviewModal');
  const player = document.getElementById('previewModalPlayer');
  const title = document.getElementById('previewModalTitle');
  const meta = document.getElementById('previewModalMeta');
  if (!modal || !player) return;

  if (title) title.textContent = titleLabel;
  player.src = `${videoMeta.publicUrl}?t=${Date.now()}`;
  if (meta) {
    const durTxt =
      videoMeta.durationSec && Number(videoMeta.durationSec) > 0
        ? ` • Thời lượng gốc: ${Number(videoMeta.durationSec).toFixed(1)}s`
        : '';
    const sizeMb =
      videoMeta.size && Number(videoMeta.size) > 0
        ? ` • ${(Number(videoMeta.size) / (1024 * 1024)).toFixed(2)} MB`
        : '';
    meta.textContent = `${videoMeta.fileName || 'Video mẫu'}${durTxt}${sizeMb}`;
  }
  modal.classList.remove('hidden');
}

async function uploadGlobalSampleVideo(file) {
  if (!state.activeAccount || !file) return;
  if (!isVideoFileObj(file)) {
    showToast('Vui lòng chọn tệp video hợp lệ (.mp4, .mov, .webm, .mkv, .avi, .m4v)!', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('video', file);
  try {
    showToast(`Đang tải Video mẫu chung "${file.name}"...`, 'info');
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/sample-video`, {
      method: 'POST',
      body: formData
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || 'Đã gắn Video mẫu chung thành công!', 'success');
  } catch (err) {
    showToast(`Lỗi tải Video mẫu chung: ${err.message}`, 'error');
  }
}

async function removeGlobalSampleVideo() {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/sample-video`, {
      method: 'DELETE'
    });
    if (res.account) {
      state.activeAccount = res.account;
      renderSidebarSettings();
      renderFlowRows();
    }
    showToast(res.message || 'Đã gỡ Video mẫu chung.', 'info');
  } catch (err) {
    showToast(`Lỗi gỡ Video mẫu chung: ${err.message}`, 'error');
  }
}

function openGlobalSampleVideoPicker() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'video/mp4,video/quicktime,video/webm,video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v';
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadGlobalSampleVideo(file);
    }
  };
  input.click();
}

async function uploadRowSampleVideo(rowIndex, file) {
  if (!state.activeAccount || !file) return;
  if (!isVideoFileObj(file)) {
    showToast('Vui lòng chọn tệp video hợp lệ (.mp4, .mov, .webm, .mkv, .avi, .m4v)!', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('video', file);
  try {
    showToast(`Đang tải Video mẫu riêng cho Hàng #${rowIndex}...`, 'info');
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/sample-video`,
      {
        method: 'POST',
        body: formData
      }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
      updateSampleVideoStatusBadgeOnly();
    }
    showToast(res.message || `Đã gắn Video mẫu riêng cho Hàng #${rowIndex}!`, 'success');
  } catch (err) {
    showToast(`Lỗi tải Video mẫu Hàng #${rowIndex}: ${err.message}`, 'error');
  }
}

async function removeRowSampleVideo(rowIndex) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(
      `/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/sample-video`,
      { method: 'DELETE' }
    );
    if (res.row) {
      const idx = state.activeAccount.rows.findIndex((r) => r.index === Number(rowIndex));
      if (idx !== -1) state.activeAccount.rows[idx] = res.row;
      updateSingleRowDom(res.row);
      updateSampleVideoStatusBadgeOnly();
    }
    showToast(res.message || `Đã gỡ Video mẫu riêng của Hàng #${rowIndex}.`, 'info');
  } catch (err) {
    showToast(`Lỗi gỡ Video mẫu Hàng #${rowIndex}: ${err.message}`, 'error');
  }
}

function openRowSampleVideoPicker(rowIndex) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'video/mp4,video/quicktime,video/webm,video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v';
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (file) {
      await uploadRowSampleVideo(rowIndex, file);
    }
  };
  input.click();
}

async function saveSidebarSettings(partial) {
  if (!state.activeAccount) return;
  try {
    const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/settings`, {
      method: 'PUT',
      body: JSON.stringify(partial)
    });
    state.activeAccount = res.account;
    renderSidebarSettings();
    renderFlowRows();
  } catch (err) {
    showToast(`Lỗi lưu cấu hình: ${err.message}`, 'error');
  }
}

async function confirmAndResetAccount(accountId, accountName) {
  const ok = window.confirm(`Xóa phiên đăng nhập cũ của "${accountName}" để đăng nhập tài khoản mới?`);
  if (!ok) return;

  try {
    showToast('Đang xóa phiên cũ...', 'info');
    const res = await apiFetch(`/api/accounts/${accountId}/reset-account`, {
      method: 'POST',
      body: JSON.stringify({ openLoginNow: true })
    });
    await loadAppState();
    showToast(res.message, 'success');
  } catch (err) {
    showToast(`Lỗi xóa tài khoản: ${err.message}`, 'error');
  }
}

function renderAccountsModalList() {
  const container = document.getElementById('accountsModalList');
  if (!container) return;

  container.innerHTML = '';
  state.accounts.forEach((acc) => {
    const isCurrent = state.activeAccount && acc.id === state.activeAccount.id;
    const item = document.createElement('div');
    item.className = `account-list-item ${isCurrent ? 'active-acc' : ''}`;

    const connBadge = acc.loginVerified
      ? `<span class="banner-badge badge-green">Đã lưu</span>`
      : acc.connected
      ? `<span class="banner-badge badge-amber">Chờ đăng nhập</span>`
      : `<span class="banner-badge badge-red">Chưa kết nối</span>`;

    const proxyBadge = acc.proxyLabel
      ? `<span class="banner-badge badge-proxy">🌐 ${escapeHtml(acc.proxyLabel)}</span>`
      : `<span class="acc-sub-note">IP Trực tiếp</span>`;

    item.innerHTML = `
      <div class="acc-item-top">
        <div class="acc-item-head-left">
          <span class="acc-item-name">${escapeHtml(acc.name)}</span>
          ${connBadge}
          ${proxyBadge}
        </div>
        <div class="acc-item-actions">
          <button class="btn-mini" data-modal-action="switch-acc" data-id="${acc.id}">
            ${isCurrent ? '✓ Đang chọn' : 'Chọn'}
          </button>
          <button class="btn-mini" data-modal-action="connect-visible" data-id="${acc.id}">
            👁 Mở Chrome
          </button>
          <button class="btn-mini btn-danger-soft" data-modal-action="reset-acc" data-id="${acc.id}" data-name="${escapeAttr(acc.name)}">
            🗑 Xóa phiên
          </button>
        </div>
      </div>
      <div class="acc-proxy-row">
        <input
          type="text"
          class="sidebar-input acc-proxy-input"
          data-proxy-for="${acc.id}"
          value="${escapeAttr(acc.proxy || '')}"
          placeholder="Nhập Proxy cho tài khoản này (ip:port hoặc ip:port:user:pass — để trống nếu dùng mạng gốc)"
        />
        <button type="button" class="btn-mini btn-save-proxy" data-modal-action="save-proxy" data-id="${acc.id}">
          Lưu Proxy
        </button>
      </div>
    `;
    container.appendChild(item);
  });
}

// ============================================================================
// CAPCUT STUDIO — CẮT & NỐI VIDEO
// ============================================================================

function formatTimeSec(sec) {
  const s = Math.max(0, Number(sec) || 0);
  const mins = Math.floor(s / 60);
  const rem = (s % 60).toFixed(1).padStart(4, '0');
  return `${String(mins).padStart(2, '0')}:${rem}`;
}

function probeBrowserVideoDuration(videoUrl) {
  return new Promise((resolve) => {
    const tempVid = document.createElement('video');
    tempVid.preload = 'metadata';
    const done = (dur) => {
      tempVid.removeAttribute('src');
      tempVid.load();
      resolve(dur && isFinite(dur) && dur > 0 ? Number(dur.toFixed(2)) : 10);
    };
    tempVid.onloadedmetadata = () => done(tempVid.duration);
    tempVid.onerror = () => done(10);
    setTimeout(() => done(10), 2500);
    tempVid.src = videoUrl;
  });
}

async function createClipFromRow(row) {
  const duration = await probeBrowserVideoDuration(row.videoUrl);
  return {
    id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    rowIndex: row.index,
    videoUrl: row.videoUrl,
    videoFilePath: row.videoFilePath,
    label: `Hàng #${String(row.index).padStart(2, '0')}`,
    prompt: row.prompt || '',
    sourceDuration: duration,
    startTime: 0,
    endTime: duration,
    speed: 1,
    muted: false
  };
}

function getActiveCapcutClip() {
  return capcutState.clips.find((c) => c.id === capcutState.activeClipId) || null;
}

async function openCapcutEditorModal({ initialRows = [], singleRowTarget = null } = {}) {
  if (!state.activeAccount) return;

  capcutState.playingAll = false;
  capcutState.singleRowTarget = singleRowTarget;
  document.getElementById('capcutExportResultBox')?.classList.add('hidden');

  const modal = document.getElementById('capcutEditorModal');
  modal.classList.remove('hidden');

  if (initialRows.length > 0) {
    capcutState.clips = [];
    for (const r of initialRows) {
      if (r && r.videoUrl) {
        const clip = await createClipFromRow(r);
        capcutState.clips.push(clip);
      }
    }
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
  } else if (capcutState.clips.length === 0) {
    const availableRows = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
    for (const r of availableRows) {
      const clip = await createClipFromRow(r);
      capcutState.clips.push(clip);
    }
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
  }

  renderCapcutAll();
  loadActiveClipIntoPlayer(false);
}

function renderCapcutAll() {
  renderCapcutSourceLibrary();
  renderCapcutTimelineTrack();
  renderCapcutInspector();
  renderCapcutFooterButtons();
}

function renderCapcutSourceLibrary() {
  const listEl = document.getElementById('capcutSourceRowsList');
  if (!listEl || !state.activeAccount) return;

  const rowsWithVideo = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
  listEl.innerHTML = '';

  if (rowsWithVideo.length === 0) {
    listEl.innerHTML = `<div class="empty-hint-box">Chưa có hàng nào có video.</div>`;
    return;
  }

  rowsWithVideo.forEach((row) => {
    const item = document.createElement('div');
    item.className = 'capcut-source-item';
    item.innerHTML = `
      <div class="source-item-info">
        <div class="source-item-title">Hàng #${String(row.index).padStart(2, '0')}</div>
        <div class="source-item-prompt">${escapeHtml(row.prompt || 'Không có prompt')}</div>
      </div>
      <button type="button" class="btn-mini-accent" data-add-row="${row.index}">+ Thêm</button>
    `;
    listEl.appendChild(item);
  });
}

function renderCapcutTimelineTrack() {
  const trackEl = document.getElementById('capcutTimelineTrack');
  const summaryEl = document.getElementById('capcutSummaryBadge');
  if (!trackEl) return;

  trackEl.innerHTML = '';

  let totalSec = 0;
  capcutState.clips.forEach((c) => {
    totalSec += Math.max(0.1, (c.endTime - c.startTime) / (c.speed || 1));
  });

  if (summaryEl) {
    summaryEl.textContent = `${capcutState.clips.length} đoạn • ${totalSec.toFixed(1)}s`;
  }

  if (capcutState.clips.length === 0) {
    trackEl.innerHTML = `<div class="empty-hint-box">Timeline trống — Bấm "+ Thêm" từ cột bên trái.</div>`;
    return;
  }

  capcutState.clips.forEach((clip, idx) => {
    const isActive = clip.id === capcutState.activeClipId;
    const card = document.createElement('div');
    card.className = `timeline-clip-card ${isActive ? 'active-clip' : ''}`;
    card.draggable = true;
    card.dataset.clipId = clip.id;

    const maxDur = clip.sourceDuration || 10;
    const leftPct = Math.max(0, Math.min(95, (clip.startTime / maxDur) * 100));
    const widthPct = Math.max(5, Math.min(100 - leftPct, ((clip.endTime - clip.startTime) / maxDur) * 100));
    const effectiveDur = ((clip.endTime - clip.startTime) / (clip.speed || 1)).toFixed(1);

    card.innerHTML = `
      <div class="clip-card-top">
        <span class="clip-order-badge">#${idx + 1}</span>
        <span class="clip-row-tag">${escapeHtml(clip.label)}</span>
        <button type="button" class="clip-remove-x" data-remove-clip="${clip.id}">×</button>
      </div>
      <div class="clip-visual-bar">
        <div class="clip-trim-fill" style="left:${leftPct}%;width:${widthPct}%;"></div>
      </div>
      <div class="clip-card-bottom">
        <span>${clip.startTime.toFixed(1)}s - ${clip.endTime.toFixed(1)}s</span>
        <span>${clip.muted ? '🔇' : '🔊'} ${effectiveDur}s</span>
      </div>
    `;

    card.addEventListener('dragstart', () => {
      capcutState.draggedClipId = clip.id;
    });
    card.addEventListener('dragover', (e) => e.preventDefault());
    card.addEventListener('drop', (e) => {
      e.preventDefault();
      const fromId = capcutState.draggedClipId;
      const toId = clip.id;
      if (!fromId || fromId === toId) return;
      const fromIdx = capcutState.clips.findIndex((c) => c.id === fromId);
      const toIdx = capcutState.clips.findIndex((c) => c.id === toId);
      if (fromIdx === -1 || toIdx === -1) return;
      const [moved] = capcutState.clips.splice(fromIdx, 1);
      capcutState.clips.splice(toIdx, 0, moved);
      renderCapcutTimelineTrack();
    });

    trackEl.appendChild(card);
  });
}

function renderCapcutInspector() {
  const clip = getActiveCapcutClip();
  const tagEl = document.getElementById('capcutSelectedClipTag');
  const durBadge = document.getElementById('capcutTrimDurationBadge');
  const inStart = document.getElementById('inputCapcutTrimStart');
  const inEnd = document.getElementById('inputCapcutTrimEnd');
  const slStart = document.getElementById('sliderCapcutTrimStart');
  const slEnd = document.getElementById('sliderCapcutTrimEnd');
  const selSpeed = document.getElementById('selectCapcutClipSpeed');
  const btnMute = document.getElementById('btnCapcutToggleMute');
  const emptyStage = document.getElementById('capcutEmptyStage');
  const overlay = document.getElementById('capcutActiveClipOverlay');

  if (!clip) {
    if (tagEl) tagEl.textContent = 'Chưa chọn';
    if (durBadge) durBadge.textContent = '0.0s';
    if (emptyStage) emptyStage.classList.remove('hidden');
    if (overlay) overlay.classList.add('hidden');
    return;
  }

  if (emptyStage) emptyStage.classList.add('hidden');
  const clipIdx = capcutState.clips.findIndex((c) => c.id === clip.id) + 1;
  if (tagEl) tagEl.textContent = `#${clipIdx} (${clip.label})`;
  if (overlay) {
    overlay.classList.remove('hidden');
    overlay.textContent = `#${clipIdx} • ${clip.label} (${clip.startTime.toFixed(1)}s - ${clip.endTime.toFixed(1)}s)`;
  }

  const maxDur = clip.sourceDuration || 10;
  const trimmedLen = Math.max(0.1, (clip.endTime - clip.startTime) / (clip.speed || 1));
  if (durBadge) {
    durBadge.textContent = `${trimmedLen.toFixed(1)}s / ${maxDur.toFixed(1)}s`;
  }

  if (inStart) {
    inStart.max = String(maxDur);
    inStart.value = clip.startTime.toFixed(1);
  }
  if (inEnd) {
    inEnd.max = String(maxDur);
    inEnd.value = clip.endTime.toFixed(1);
  }
  if (slStart) {
    slStart.max = String(maxDur);
    slStart.value = String(clip.startTime);
  }
  if (slEnd) {
    slEnd.max = String(maxDur);
    slEnd.value = String(clip.endTime);
  }
  if (selSpeed) selSpeed.value = String(clip.speed || 1);
  if (btnMute) btnMute.textContent = clip.muted ? '🔇 Đã tắt tiếng' : '🔊 Bật tiếng';
}

function renderCapcutFooterButtons() {
  const btnSaveSingle = document.getElementById('btnCapcutSaveToSingleRow');
  if (!btnSaveSingle) return;

  const uniqueRows = new Set(capcutState.clips.map((c) => c.rowIndex).filter(Boolean));
  const targetRow = capcutState.singleRowTarget || (uniqueRows.size === 1 ? [...uniqueRows][0] : null);

  if (targetRow && capcutState.clips.length > 0) {
    btnSaveSingle.classList.remove('hidden');
    btnSaveSingle.dataset.targetRow = String(targetRow);
    btnSaveSingle.textContent = `💾 Lưu vào Hàng #${String(targetRow).padStart(2, '0')}`;
  } else {
    btnSaveSingle.classList.add('hidden');
  }
}

function loadActiveClipIntoPlayer(autoPlay = false) {
  const player = document.getElementById('capcutPreviewPlayer');
  const slider = document.getElementById('capcutPlayheadSlider');
  const curLabel = document.getElementById('capcutCurrentTimeLabel');
  const endLabel = document.getElementById('capcutClipEndLabel');
  const clip = getActiveCapcutClip();
  if (!player) return;

  if (!clip) {
    player.pause();
    player.removeAttribute('src');
    return;
  }

  const maxDur = clip.sourceDuration || 10;
  if (slider) {
    slider.min = '0';
    slider.max = String(maxDur);
    slider.value = String(clip.startTime);
  }
  if (curLabel) curLabel.textContent = formatTimeSec(clip.startTime);
  if (endLabel) endLabel.textContent = formatTimeSec(clip.endTime);

  const sameSrc = player.getAttribute('data-loaded-url') === clip.videoUrl;
  player.muted = Boolean(clip.muted);
  player.playbackRate = Number(clip.speed) || 1;

  if (!sameSrc) {
    player.setAttribute('data-loaded-url', clip.videoUrl);
    player.src = clip.videoUrl;
    player.onloadedmetadata = () => {
      if (player.duration && isFinite(player.duration) && player.duration > 0) {
        clip.sourceDuration = Number(player.duration.toFixed(2));
        if (clip.endTime > clip.sourceDuration || clip.endTime <= 0) {
          clip.endTime = clip.sourceDuration;
        }
        renderCapcutInspector();
        renderCapcutTimelineTrack();
      }
      player.currentTime = clip.startTime;
      if (autoPlay) player.play().catch(() => {});
    };
  } else {
    player.currentTime = clip.startTime;
    if (autoPlay) player.play().catch(() => {});
  }
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(str) {
  return escapeHtml(str);
}

// ==================== DOM EVENT LISTENERS ====================
document.addEventListener('DOMContentLoaded', () => {
  const savedTheme = localStorage.getItem('muse_flow_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', savedTheme);
  const themeIcon = document.getElementById('themeIcon');
  if (themeIcon) themeIcon.textContent = savedTheme === 'light' ? '🌙' : '☀️';

  document.getElementById('btnToggleTheme')?.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('muse_flow_theme', next);
    if (themeIcon) themeIcon.textContent = next === 'light' ? '🌙' : '☀️';
  });

  document.getElementById('btnToggleSidebar')?.addEventListener('click', () => {
    document.getElementById('studioLayout')?.classList.toggle('sidebar-collapsed');
  });

  document.getElementById('statusFilterGroup')?.addEventListener('click', (e) => {
    const tab = e.target.closest('.filter-tab');
    if (!tab) return;
    state.statusFilter = tab.dataset.filter || 'all';
    document.querySelectorAll('#statusFilterGroup .filter-tab').forEach((t) => {
      t.classList.toggle('active', t === tab);
    });
    renderRowCountsAndFilterVisibility();
  });

  document.getElementById('chkSelectAllRows')?.addEventListener('change', (e) => {
    const rows = state.activeAccount?.rows || [];
    state.selectedRows.clear();
    if (e.target.checked) {
      rows.forEach((r) => {
        if (r.videoUrl) state.selectedRows.add(r.index);
      });
      if (state.selectedRows.size === 0) {
        rows.forEach((r) => state.selectedRows.add(r.index));
      }
    }
    renderFlowRows();
  });

  loadAppState();
  connectWebSocket();

  // ==================== HỆ THỐNG TỰ ĐỘNG KIỂM TRA & CẬP NHẬT OTA QUA GITHUB ====================
  let cachedUpdateInfo = null;
  let updateInstalling = false;

  // Thông báo chào mừng ngay sau khi tự động cập nhật thành công và tải lại trang
  try {
    const justUpdatedVer = sessionStorage.getItem('mfs_just_updated_to');
    if (justUpdatedVer) {
      sessionStorage.removeItem('mfs_just_updated_to');
      setTimeout(() => {
        showToast(`🎉 Đã tự động cập nhật thành công lên phiên bản v${justUpdatedVer}!`, 'success');
      }, 600);
    }
  } catch (_) {}

  function openUpdateModalWithInfo(info) {
    if (!info || !info.updateAvailable) return;
    cachedUpdateInfo = info;

    const topAlertBtn = document.getElementById('btnTopUpdateAlert');
    const topVerSpan = document.getElementById('topUpdateVerText');
    if (topVerSpan) topVerSpan.textContent = `v${info.latestVersion}`;
    topAlertBtn?.classList.remove('hidden');

    const titleEl = document.getElementById('updateModalTitle');
    const curEl = document.getElementById('updateCurrentVerLabel');
    const newEl = document.getElementById('updateLatestVerLabel');
    const logEl = document.getElementById('updateModalChangelog');
    const dismissBtn = document.getElementById('btnDismissUpdateModal');
    const closeXBtn = document.getElementById('btnCloseUpdateModalX');

    if (titleEl) titleEl.textContent = `🎉 ${info.title || `ĐÃ CÓ PHIÊN BẢN MỚI v${info.latestVersion}`}`;
    if (curEl) curEl.textContent = `v${info.currentVersion || state.version || '2.8'}`;
    if (newEl) newEl.textContent = `v${info.latestVersion}`;
    if (logEl) {
      const kb = info.patchSize ? ` (~${Math.max(1, Math.round(info.patchSize / 1024))} KB)` : '';
      logEl.textContent = `${info.changelog || '• Cập nhật tính năng & tối ưu độ ổn định.'}${kb ? `\n\n📦 Dung lượng gói nâng cấp nhẹ:${kb}` : ''}`;
    }

    if (info.mandatory) {
      dismissBtn?.classList.add('hidden');
      closeXBtn?.classList.add('hidden');
    } else {
      dismissBtn?.classList.remove('hidden');
      closeXBtn?.classList.remove('hidden');
    }

    document.getElementById('updateAvailableModal')?.classList.remove('hidden');
  }

  async function checkRemoteUpdate(manualClick = false) {
    try {
      const res = await fetch('/api/update/check', { cache: 'no-store' });
      const info = await res.json();
      if (info && info.updateAvailable) {
        openUpdateModalWithInfo(info);
        return;
      }
      if (manualClick) {
        if (!info.configured) {
          showToast(`Đang chạy phiên bản v${state.version || '2.8'} (Chưa gắn kho cập nhật GitHub).`, 'info');
        } else if (info.error) {
          showToast(`Không thể kiểm tra cập nhật: ${info.error}`, 'error');
        } else {
          showToast(`✅ Bạn đang sử dụng phiên bản mới nhất (v${info.currentVersion || state.version || '2.8'})!`, 'success');
        }
      }
    } catch (_) {
      if (manualClick) {
        showToast('Không thể kết nối máy chủ kiểm tra cập nhật lúc này.', 'error');
      }
    }
  }

  setTimeout(() => checkRemoteUpdate(false), 1800);
  setInterval(() => checkRemoteUpdate(false), 30 * 60 * 1000);

  document.getElementById('topVersionBadge')?.addEventListener('click', () => {
    checkRemoteUpdate(true);
  });

  document.getElementById('btnTopUpdateAlert')?.addEventListener('click', () => {
    if (cachedUpdateInfo && cachedUpdateInfo.updateAvailable) {
      openUpdateModalWithInfo(cachedUpdateInfo);
    } else {
      checkRemoteUpdate(true);
    }
  });

  document.getElementById('btnApplyUpdateNow')?.addEventListener('click', async () => {
    if (updateInstalling) return;
    updateInstalling = true;

    const btnApply = document.getElementById('btnApplyUpdateNow');
    const btnDismiss = document.getElementById('btnDismissUpdateModal');
    const btnCloseX = document.getElementById('btnCloseUpdateModalX');
    const progBox = document.getElementById('updateProgressBox');
    const progStatus = document.getElementById('updateProgressStatus');

    if (btnApply) btnApply.disabled = true;
    btnDismiss?.classList.add('hidden');
    btnCloseX?.classList.add('hidden');
    progBox?.classList.remove('hidden');
    if (progStatus) progStatus.textContent = 'Đang kết nối GitHub tải gói nâng cấp mới...';

    try {
      const res = await apiFetch('/api/update/apply', { method: 'POST' });
      if (res.alreadyLatest) {
        updateInstalling = false;
        if (btnApply) btnApply.disabled = false;
        progBox?.classList.add('hidden');
        document.getElementById('updateAvailableModal')?.classList.add('hidden');
        showToast(res.message || 'Bạn đang ở phiên bản mới nhất!', 'success');
        return;
      }

      const targetVer = res.newVersion || cachedUpdateInfo?.latestVersion || '';
      if (progStatus) {
        progStatus.textContent = `Đã cài xong v${targetVer}! Đang tự khởi động lại công cụ (vui lòng đợi 2–3 giây)...`;
      }

      // Chờ server mới khởi động xong trên cổng 3888 rồi tự làm mới trang mượt mà
      let attempts = 0;
      const pollRestart = setInterval(async () => {
        attempts++;
        try {
          const r = await fetch(`/api/state?t=${Date.now()}`, { cache: 'no-store' });
          if (r.ok) {
            const st = await r.json();
            if (st && st.ok && (!targetVer || st.version === targetVer || attempts >= 6)) {
              clearInterval(pollRestart);
              try {
                sessionStorage.setItem('mfs_just_updated_to', st.version || targetVer);
              } catch (_) {}
              window.location.reload();
            }
          }
        } catch (_) {
          // Server đang trong 0.5s khởi động lại, tiếp tục đợi
        }
        if (attempts > 35) {
          clearInterval(pollRestart);
          window.location.reload();
        }
      }, 600);
    } catch (err) {
      updateInstalling = false;
      if (btnApply) btnApply.disabled = false;
      if (!cachedUpdateInfo?.mandatory) {
        btnDismiss?.classList.remove('hidden');
        btnCloseX?.classList.remove('hidden');
      }
      progBox?.classList.add('hidden');
      showToast(`Lỗi cập nhật: ${err.message}`, 'error');
    }
  });

  // Kết nối tài khoản Chrome
  document.getElementById('btnConnectChrome').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const btn = document.getElementById('btnConnectChrome');
    const sub = document.getElementById('btnConnectSub');
    btn.disabled = true;

    const needLoginWindow = !state.activeAccount.loginVerified;
    sub.textContent = needLoginWindow ? 'Đang mở Chrome...' : 'Đang kết nối...';

    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/connect`, {
        method: 'POST',
        body: JSON.stringify({ forceVisibleWindow: needLoginWindow })
      });
      state.activeAccount = res.account;
      await loadAppState();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
      renderTopbarAndAccountStatus();
    } finally {
      btn.disabled = false;
    }
  });

  // Làm mới dự án
  document.getElementById('btnResetProject').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const ok = window.confirm(`Làm mới dự án "${state.activeAccount.name}" (xóa trắng ảnh, prompt và video trên các hàng)?`);
    if (!ok) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/reset-project`, {
        method: 'POST'
      });
      state.activeAccount = res.account;
      state.selectedRows.clear();
      renderAll();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(`Lỗi làm mới: ${err.message}`, 'error');
    }
  });

  // Ẩn Chrome (nếu còn nút)
  document.getElementById('btnHideChromeWindow')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/hide-chrome`, {
        method: 'POST'
      });
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Mở thư mục xuất & Kho Video Output xem mượt tức thì
  let outputGalleryItems = [];
  let activeOutputRelPath = '';

  function renderOutputGalleryList() {
    const listEl = document.getElementById('outputGalleryList');
    const badgeEl = document.getElementById('outputGalleryCountBadge');
    if (!listEl) return;

    if (badgeEl) badgeEl.textContent = `${outputGalleryItems.length} video`;

    if (outputGalleryItems.length === 0) {
      listEl.innerHTML = `<div class="pane-sub-hint" style="padding:18px;text-align:center;">Chưa có video nào trong thư mục Output_Videos.</div>`;
      return;
    }

    listEl.innerHTML = outputGalleryItems
      .map((item) => {
        const mb = (Number(item.sizeBytes || 0) / (1024 * 1024)).toFixed(2);
        const dt = item.createdAt ? new Date(item.createdAt).toLocaleString('vi-VN') : '';
        const isActive = item.relativePath === activeOutputRelPath;
        const mergedTag = item.isMerged ? `<span class="badge-accent">Đã nối</span>` : '';
        return `
          <div class="output-video-card ${isActive ? 'active-output-item' : ''}" data-rel="${escapeHtml(item.relativePath)}">
            <div class="output-video-info">
              <div class="output-video-name" title="${escapeHtml(item.fileName)}">${escapeHtml(item.fileName)}</div>
              <div class="output-video-sub">
                <span>📁 ${escapeHtml(item.accountName || item.accountId)}</span>
                <span>• ${mb} MB</span>
                <span>• ${escapeHtml(dt)}</span>
                ${mergedTag}
              </div>
            </div>
            <div class="output-video-btns">
              <button type="button" class="btn-mini-accent" data-out-act="play" data-rel="${escapeHtml(item.relativePath)}">▶ Xem</button>
              <button type="button" class="btn-mini" data-out-act="locate" data-rel="${escapeHtml(item.relativePath)}" title="Hiện đúng file này trong Windows Explorer">📂</button>
              <a class="btn-mini" href="${escapeHtml(item.publicUrl)}" download="${escapeHtml(item.fileName)}" title="Tải về máy" onclick="event.stopPropagation()">⬇</a>
            </div>
          </div>
        `;
      })
      .join('');
  }

  function playOutputGalleryItem(relPath) {
    const item = outputGalleryItems.find((x) => x.relativePath === relPath);
    const player = document.getElementById('outputGalleryPlayer');
    const emptyEl = document.getElementById('outputGalleryEmpty');
    const metaEl = document.getElementById('outputGalleryActiveMeta');
    if (!player) return;

    if (!item) {
      activeOutputRelPath = '';
      player.pause();
      player.removeAttribute('src');
      player.classList.remove('has-src');
      emptyEl?.classList.remove('hidden');
      metaEl?.classList.add('hidden');
      renderOutputGalleryList();
      return;
    }

    activeOutputRelPath = item.relativePath;
    emptyEl?.classList.add('hidden');
    player.classList.add('has-src');
    player.src = `${item.publicUrl}?t=${Date.now()}`;
    player.play().catch(() => {});

    if (metaEl) {
      const mb = (Number(item.sizeBytes || 0) / (1024 * 1024)).toFixed(2);
      metaEl.textContent = `${item.fileName} (${mb} MB • ${item.accountName || item.accountId})`;
      metaEl.classList.remove('hidden');
    }
    renderOutputGalleryList();
  }

  async function refreshOutputGallery(autoPlayFirst = false) {
    const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
    const accQuery = scope === 'active' && state.activeAccount ? state.activeAccount.id : 'all';
    try {
      const res = await apiFetch(`/api/output-videos?accountId=${encodeURIComponent(accQuery)}`);
      outputGalleryItems = res.items || [];
      renderOutputGalleryList();
      if (autoPlayFirst && outputGalleryItems.length > 0) {
        playOutputGalleryItem(outputGalleryItems[0].relativePath);
      } else if (activeOutputRelPath && !outputGalleryItems.some((x) => x.relativePath === activeOutputRelPath)) {
        playOutputGalleryItem('');
      }
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  document.getElementById('btnOpenOutputGallery')?.addEventListener('click', async () => {
    document.getElementById('outputGalleryModal')?.classList.remove('hidden');
    await refreshOutputGallery(true);
  });

  document.getElementById('selectOutputGalleryScope')?.addEventListener('change', () => {
    refreshOutputGallery(true);
  });

  document.getElementById('btnRefreshOutputGallery')?.addEventListener('click', () => {
    refreshOutputGallery(false);
  });

  document.getElementById('btnOpenExplorerFromGallery')?.addEventListener('click', async () => {
    try {
      const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
      const accountId = scope === 'active' ? state.activeAccount?.id : undefined;
      await apiFetch('/api/open-output-folder', {
        method: 'POST',
        body: JSON.stringify({ accountId })
      });
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnRepairOutputVideos')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnRepairOutputVideos');
    if (btn) btn.disabled = true;
    showToast('Đang chuẩn hóa toàn bộ video MP4 sang chuẩn 44.1kHz Stereo mượt...', 'info');
    try {
      const scope = document.getElementById('selectOutputGalleryScope')?.value || 'all';
      const accountId = scope === 'active' && state.activeAccount ? state.activeAccount.id : 'all';
      const res = await apiFetch('/api/output-videos/repair', {
        method: 'POST',
        body: JSON.stringify({ accountId, forceReencode: true })
      });
      outputGalleryItems = res.items || [];
      renderOutputGalleryList();
      if (activeOutputRelPath) playOutputGalleryItem(activeOutputRelPath);
      showToast(res.message || 'Đã chuẩn hóa xong toàn bộ video!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('outputGalleryList')?.addEventListener('click', async (e) => {
    const actBtn = e.target.closest('button[data-out-act]');
    if (actBtn) {
      e.stopPropagation();
      const rel = actBtn.dataset.rel;
      if (actBtn.dataset.outAct === 'play') {
        playOutputGalleryItem(rel);
      } else if (actBtn.dataset.outAct === 'locate') {
        try {
          await apiFetch('/api/open-output-file', {
            method: 'POST',
            body: JSON.stringify({ relativePath: rel })
          });
        } catch (err) {
          showToast(err.message, 'error');
        }
      }
      return;
    }
    const card = e.target.closest('.output-video-card');
    if (card && card.dataset.rel) {
      playOutputGalleryItem(card.dataset.rel);
    }
  });

  document.getElementById('btnOpenOutputFolder').addEventListener('click', async () => {
    try {
      await apiFetch('/api/open-output-folder', {
        method: 'POST',
        body: JSON.stringify({ accountId: state.activeAccount?.id })
      });
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Chuyển dự án trên Topbar
  document.getElementById('accountSelect').addEventListener('change', async (e) => {
    const accountId = e.target.value;
    try {
      await apiFetch('/api/accounts/select', {
        method: 'POST',
        body: JSON.stringify({ accountId })
      });
      state.selectedRows.clear();
      capcutState.clips = [];
      await loadAppState();
      showToast(`Đã chuyển sang ${state.activeAccount?.name}`, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Quản lý tài khoản & Proxy
  document.getElementById('btnOpenAccountModal').addEventListener('click', () => {
    renderAccountsModalList();
    document.getElementById('accountModal').classList.remove('hidden');
  });

  document.getElementById('btnCreateAndConnectAcc').addEventListener('click', async () => {
    const nameInput = document.getElementById('newAccName');
    const proxyInput = document.getElementById('newAccProxy');
    try {
      const res = await apiFetch('/api/accounts', {
        method: 'POST',
        body: JSON.stringify({
          name: nameInput.value.trim(),
          proxy: proxyInput ? proxyInput.value.trim() : '',
          autoLaunch: true
        })
      });
      nameInput.value = '';
      if (proxyInput) proxyInput.value = '';
      await loadAppState();
      showToast(`Đã tạo "${res.account.name}"! Hãy đăng nhập 1 lần trên Chrome vừa mở.`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('accountsModalList').addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-modal-action]');
    if (!btn) return;
    const action = btn.dataset.modalAction;
    const id = btn.dataset.id;

    try {
      if (action === 'switch-acc') {
        await apiFetch('/api/accounts/select', {
          method: 'POST',
          body: JSON.stringify({ accountId: id })
        });
        await loadAppState();
        showToast('Đã chuyển dự án!', 'info');
      } else if (action === 'connect-visible') {
        const res = await apiFetch(`/api/accounts/${id}/connect`, {
          method: 'POST',
          body: JSON.stringify({ forceVisibleWindow: true })
        });
        await loadAppState();
        showToast(res.message, 'success');
      } else if (action === 'reset-acc') {
        await confirmAndResetAccount(id, btn.dataset.name || id);
      } else if (action === 'save-proxy') {
        const proxyInp = document.querySelector(`input[data-proxy-for="${id}"]`);
        const rawProxy = proxyInp ? proxyInp.value.trim() : '';
        btn.disabled = true;
        try {
          const res = await apiFetch(`/api/accounts/${id}/proxy`, {
            method: 'PUT',
            body: JSON.stringify({ proxy: rawProxy })
          });
          await loadAppState();
          showToast(res.message, 'success');
        } finally {
          btn.disabled = false;
        }
      }
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Cấu hình Sidebar
  document.getElementById('aspectRatioGroup').addEventListener('click', (e) => {
    const btn = e.target.closest('.ratio-btn');
    if (!btn) return;
    saveSidebarSettings({ aspectRatio: btn.dataset.ratio });
  });

  document.getElementById('durationGroup').addEventListener('click', async (e) => {
    const btn = e.target.closest('.pill-btn');
    if (!btn) return;
    const sec = parseDurationToSeconds(btn.dataset.duration);
    const selectDurUnit = document.getElementById('selectDurationUnit');
    const inputCustomDur = document.getElementById('inputCustomDuration');
    if (selectDurUnit && inputCustomDur) {
      if (sec >= 60 && sec % 60 === 0 && selectDurUnit.value === 'min') {
        inputCustomDur.value = sec / 60;
      } else {
        selectDurUnit.value = 'sec';
        inputCustomDur.value = sec;
      }
    }
    await saveSidebarSettings({ duration: `${sec}s` });
    if ((state.activeAccount?.rows || []).some((r) => (r.referenceImages || []).filter(Boolean).length >= 2)) {
      renderFlowRows();
    } else {
      refreshAllRowDialogueBadges();
    }
  });

  const applyCustomDurationFromInput = async () => {
    const inputEl = document.getElementById('inputCustomDuration');
    const unitEl = document.getElementById('selectDurationUnit');
    if (!inputEl) return;
    const rawNum = parseFloat(String(inputEl.value || '').replace(',', '.'));
    if (!Number.isFinite(rawNum) || rawNum <= 0) {
      showToast('Vui lòng nhập số thời lượng hợp lệ (từ 5 giây đến 60 phút)!', 'error');
      return;
    }
    const unit = unitEl ? unitEl.value : 'sec';
    const rawSeconds = unit === 'min' ? rawNum * 60 : rawNum;
    const clampedSec = Math.max(5, Math.min(3600, Math.round(rawSeconds)));
    inputEl.value = unit === 'min' ? Number((clampedSec / 60).toFixed(2)) : clampedSec;
    await saveSidebarSettings({ duration: `${clampedSec}s` });
    if ((state.activeAccount?.rows || []).some((r) => (r.referenceImages || []).filter(Boolean).length >= 2)) {
      renderFlowRows();
    } else {
      refreshAllRowDialogueBadges();
    }
    showToast(`⏱ Đã đặt thời lượng video: ${formatDurationBadgeSummary(clampedSec)}!`, 'success');
  };

  document.getElementById('btnApplyCustomDuration')?.addEventListener('click', applyCustomDurationFromInput);
  document.getElementById('inputCustomDuration')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      applyCustomDurationFromInput();
    }
  });
  document.getElementById('selectDurationUnit')?.addEventListener('change', (e) => {
    const inputEl = document.getElementById('inputCustomDuration');
    if (!inputEl) return;
    const val = parseFloat(String(inputEl.value || '').replace(',', '.'));
    if (Number.isFinite(val) && val > 0) {
      if (e.target.value === 'min') {
        inputEl.value = Number((val / 60).toFixed(2));
      } else {
        inputEl.value = Math.max(5, Math.min(3600, Math.round(val * 60)));
      }
    }
    inputEl.focus();
  });

  document.getElementById('selectResolution').addEventListener('change', (e) => {
    saveSidebarSettings({ resolution: e.target.value });
  });

  document.getElementById('selectCameraMotion').addEventListener('change', (e) => {
    saveSidebarSettings({ cameraMotion: e.target.value });
  });

  document.getElementById('selectTransitionEffect')?.addEventListener('change', (e) => {
    saveSidebarSettings({ transitionEffect: e.target.value });
    showToast('Đã cập nhật hiệu ứng chuyển cảnh!', 'info');
  });

  document.getElementById('chkEnableDialogue')?.addEventListener('change', async (e) => {
    const enabled = Boolean(e.target.checked);
    await saveSidebarSettings({ enableDialogue: enabled });
    refreshAllRowDialogueBadges();
    showToast(enabled ? '🎙️ Đã bật lời thoại nhân vật!' : '🔇 Đã tắt lời thoại nhân vật!', 'info');
  });

  document.getElementById('selectVoicePreset')?.addEventListener('change', async (e) => {
    const presetVal = e.target.value || 'auto';
    const noteEl = document.getElementById('inputVoiceCustomNote');
    if (noteEl) {
      noteEl.placeholder =
        presetVal === 'custom'
          ? 'Nhập mô tả chất giọng riêng (VD: Nữ 25 tuổi giọng Hà Nội trầm ấm, nói chậm rãi...)'
          : 'Ghi chú giọng chung (VD: nói chậm rãi, truyền cảm, nhấn nhá tự nhiên...)';
      if (presetVal === 'custom') noteEl.focus();
    }
    await saveSidebarSettings({ voicePreset: presetVal });
    showToast('🎙️ Đã cập nhật giọng đọc chung cho tất cả các hàng!', 'success');
  });

  document.getElementById('inputVoiceCustomNote')?.addEventListener('input', (e) => {
    const val = e.target.value || '';
    if (voiceNoteSaveTimer) clearTimeout(voiceNoteSaveTimer);
    voiceNoteSaveTimer = setTimeout(() => {
      saveSidebarSettings({ voiceCustomNote: val });
    }, 400);
  });

  document.getElementById('inputVoiceCustomNote')?.addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (voiceNoteSaveTimer) clearTimeout(voiceNoteSaveTimer);
      await saveSidebarSettings({ voiceCustomNote: e.target.value || '' });
      showToast('🎙️ Đã lưu ghi chú chất giọng chung!', 'success');
    }
  });

  // Video mẫu tham chiếu (Chung ở Sidebar + 3 nút tích lọc)
  const globalSampleBox = document.getElementById('globalSampleVideoBox');
  if (globalSampleBox) {
    globalSampleBox.addEventListener('click', async (e) => {
      const target = e.target.closest('[data-sample-global]');
      if (!target) return;
      const act = target.dataset.sampleGlobal;
      if (act === 'pick') {
        openGlobalSampleVideoPicker();
      } else if (act === 'remove') {
        e.stopPropagation();
        await removeGlobalSampleVideo();
      } else if (act === 'preview') {
        e.stopPropagation();
        const globalVid = state.activeAccount?.settings?.sampleVideo;
        if (globalVid) {
          previewSampleVideoModal(globalVid, `🎬 VIDEO MẪU CHUNG — ${state.activeAccount?.name || ''}`);
        }
      }
    });

    globalSampleBox.addEventListener('dragover', (e) => {
      e.preventDefault();
      globalSampleBox.classList.add('drag-over');
    });
    globalSampleBox.addEventListener('dragleave', (e) => {
      if (!globalSampleBox.contains(e.relatedTarget)) {
        globalSampleBox.classList.remove('drag-over');
      }
    });
    globalSampleBox.addEventListener('drop', async (e) => {
      e.preventDefault();
      globalSampleBox.classList.remove('drag-over');
      const vidFiles = Array.from(e.dataTransfer?.files || []).filter((f) => isVideoFileObj(f));
      if (vidFiles.length > 0) {
        await uploadGlobalSampleVideo(vidFiles[0]);
      } else {
        showToast('Hãy kéo thả tệp Video (.mp4, .mov, .webm) vào ô Video mẫu chung!', 'error');
      }
    });
  }

  document.getElementById('chkSampleLearnMotion')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnMotion: e.target.checked });
    showToast(
      e.target.checked ? '✅ Đã bật Học cử chỉ & chuyển động từ Video mẫu' : 'Đã tắt Học cử chỉ & chuyển động',
      'info'
    );
  });

  document.getElementById('chkSampleLearnCamera')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnCamera: e.target.checked });
    showToast(
      e.target.checked ? '✅ Đã bật Học góc máy & Camera từ Video mẫu' : 'Đã tắt Học góc máy & Camera',
      'info'
    );
  });

  document.getElementById('chkSampleLearnScene')?.addEventListener('change', (e) => {
    saveSidebarSettings({ sampleLearnScene: e.target.checked });
    showToast(
      e.target.checked
        ? '✅ Đã bật Học bối cảnh & ánh sáng theo Video mẫu'
        : '🔒 Đã tắt Học bối cảnh — Sẽ giữ nguyên 100% nền gốc trong ảnh nhân vật!',
      'info'
    );
  });

  // Số luồng song song & Số hàng
  const applyConcurrencyValue = (rawVal) => {
    const threads = Math.max(1, Math.min(20, Number(rawVal) || 6));
    const inputConc = document.getElementById('inputConcurrency');
    if (inputConc) inputConc.value = threads;
    saveSidebarSettings({ concurrency: threads });
    showToast(`Đã đặt ${threads} luồng song song!`, 'success');
  };

  document.getElementById('btnApplyConcurrency').addEventListener('click', () => {
    applyConcurrencyValue(document.getElementById('inputConcurrency')?.value);
  });

  document.getElementById('inputConcurrency')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      applyConcurrencyValue(e.target.value);
    }
  });

  document.querySelectorAll('#concurrencyPresetGroup .preset-chip').forEach((chip) => {
    chip.addEventListener('click', () => applyConcurrencyValue(chip.dataset.threads));
  });

  document.getElementById('btnApplyRowCount').addEventListener('click', () => {
    const count = Number(document.getElementById('inputRowCount').value) || 10;
    saveSidebarSettings({ rowCount: count });
    showToast(`Đã đặt ${count} hàng!`, 'info');
  });

  document.querySelectorAll('#rowPresetGroup .preset-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const count = Number(chip.dataset.rows) || 10;
      document.getElementById('inputRowCount').value = count;
      saveSidebarSettings({ rowCount: count });
    });
  });

  // Thanh công cụ Action Ribbon
  document.getElementById('btnBulkUploadImages').addEventListener('click', () => openBulkImagePicker(1));
  document.getElementById('btnOpenBulkPromptModal').addEventListener('click', () => {
    document.getElementById('bulkPromptModal').classList.remove('hidden');
  });

  document.getElementById('btnOpenCapcutEditor').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const allRows = state.activeAccount.rows || [];
    const chosenIndices = [...state.selectedRows].sort((a, b) => a - b);
    const chosenRowsWithVideo = chosenIndices
      .map((idx) => allRows.find((r) => r.index === idx))
      .filter((r) => r && r.videoUrl);

    await openCapcutEditorModal({
      initialRows: chosenRowsWithVideo,
      singleRowTarget: chosenRowsWithVideo.length === 1 ? chosenRowsWithVideo[0].index : null
    });
  });

  document.getElementById('selectBulkImportMode')?.addEventListener('change', (e) => {
    const mode = e.target.value || 'prompt';
    const ta = document.getElementById('bulkPromptTextarea');
    const helpEl = document.getElementById('bulkModalHelpText');
    if (!ta || !helpEl) return;
    if (mode === 'dialogue') {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng Lời thoại. Với video dài ≥20s, đặt từng câu trong "..." trên cùng 1 dòng để tự gán riêng từng phần 10s!';
      ta.placeholder =
        'Hàng 1: "Xin chào mọi người, hôm nay mình giới thiệu mẫu đầm mới..." "Chất vải lụa mềm mát, lên dáng cực xinh!"\nHàng 2: "Các chị bấm ngay vào giỏ hàng góc trái màn hình nhé!"';
    } else if (mode === 'both') {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng theo cú pháp: Chuyển động || Lời thoại (ngăn cách bởi dấu ||).';
      ta.placeholder =
        'Nhân vật bước đi tự tin, mỉm cười trước ống kính || "Xin chào mọi người, cùng xem thiết kế mới nhất hôm nay nhé!" "Form dáng chuẩn từng đường kim mũi chỉ luôn ạ!"\nNhân vật xoay nhẹ khoe tà váy, ánh sáng studio || "Số lượng ưu đãi có hạn, đặt ngay hôm nay nhé!"';
    } else {
      helpEl.textContent =
        'Mỗi dòng tương ứng 1 hàng Prompt chuyển động. Tự động thêm hàng mới nếu vượt quá số hàng hiện tại.';
      ta.placeholder =
        'Dòng 1: Nhân vật bước đi tự tin, góc máy lia chậm...\nDòng 2: Nhân vật mỉm cười nhẹ nhàng, ánh sáng điện ảnh...';
    }
  });

  document.getElementById('btnConfirmBulkPrompts').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const raw = document.getElementById('bulkPromptTextarea').value || '';
    const mode = document.getElementById('selectBulkImportMode')?.value || 'prompt';
    const lines = raw
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) {
      showToast('Hãy nhập ít nhất 1 dòng nội dung!', 'error');
      return;
    }

    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/bulk-prompts`, {
        method: 'POST',
        body: JSON.stringify({ prompts: lines, mode })
      });
      document.getElementById('bulkPromptModal').classList.add('hidden');
      await loadAppState();
      showToast(res.message || `Đã điền ${lines.length} dòng thành công!`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Cấu hình nâng cao
  document.getElementById('btnSaveSelectors').addEventListener('click', () => {
    saveSidebarSettings({
      targetUrl: document.getElementById('inputTargetUrl').value.trim() || 'https://muse.ai',
      customSelectors: {
        fileInput: document.getElementById('inputSelFile').value.trim(),
        promptInput: document.getElementById('inputSelPrompt').value.trim(),
        submitButton: document.getElementById('inputSelSubmit').value.trim()
      }
    });
    showToast('Đã lưu cấu hình!', 'success');
  });

  document.getElementById('btnInspectDom').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const modal = document.getElementById('domInspectorModal');
    const out = document.getElementById('domInspectorOutput');
    modal.classList.remove('hidden');
    out.textContent = 'Đang quét...';
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/inspect-dom`);
      out.textContent = JSON.stringify(res.report, null, 2);
    } catch (err) {
      out.textContent = `Lỗi: ${err.message}`;
    }
  });

  // Thao tác trên từng hàng
  document.getElementById('flowRowsContainer').addEventListener('click', async (e) => {
    const target = e.target.closest('[data-action]');
    if (!target || !state.activeAccount) return;

    const action = target.dataset.action;
    const rowIndex = Number(target.dataset.row);
    const slotIndex = Number(target.dataset.slot);

    if (action === 'pick-ref') {
      openFilePickerForSlot(rowIndex, slotIndex);
    } else if (action === 'replace-ref') {
      e.stopPropagation();
      openReplaceSingleSlotPicker(rowIndex, slotIndex);
    } else if (action === 'append-row-refs') {
      e.stopPropagation();
      openAppendRowImagesPicker(rowIndex);
    } else if (action === 'apply-recommended-dur') {
      e.stopPropagation();
      const recSec = Math.max(10, Math.min(3600, Number(target.dataset.sec) || 30));
      await saveSidebarSettings({ duration: `${recSec}s` });
      renderFlowRows();
      showToast(`⚡ Đã đặt thời lượng ${recSec}s (${Math.ceil(recSec / 10)} phần) khớp số bộ đồ biến hình!`, 'success');
    } else if (action === 'auto-quote-dialogue') {
      e.stopPropagation();
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      if (!dlgEl) return;
      const durSec = parseDurationToSeconds(state.activeAccount.settings?.duration || '10s');
      const totalParts = durSec > 10 ? Math.ceil(durSec / 10) : 1;
      const formatted = formatDialogueIntoQuotedParts(dlgEl.value, totalParts);
      dlgEl.value = formatted;
      const rowObj = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (rowObj) rowObj.dialogue = formatted;
      refreshRowDialogueBadge(rowIndex, formatted);
      await saveRowFields(rowIndex, { dialogue: formatted });
      dlgEl.focus();
      const qCount = extractQuotedListClient(formatted).length;
      showToast(
        totalParts > 1
          ? `✂️ Đã tự chia thành ${qCount} câu "..." khớp các phân đoạn 10s của Hàng #${rowIndex}!`
          : `✂️ Đã chuẩn hóa câu thoại "..." cho Hàng #${rowIndex}!`,
        'success'
      );
    } else if (action === 'remove-ref') {
      e.stopPropagation();
      await removeReferenceImage(rowIndex, slotIndex);
    } else if (action === 'pick-row-sample') {
      e.stopPropagation();
      openRowSampleVideoPicker(rowIndex);
    } else if (action === 'remove-row-sample') {
      e.stopPropagation();
      await removeRowSampleVideo(rowIndex);
    } else if (action === 'preview-row-sample') {
      e.stopPropagation();
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (row && row.sampleVideo) {
        previewSampleVideoModal(
          row.sampleVideo,
          `🎬 VIDEO MẪU RIÊNG HÀNG #${String(rowIndex).padStart(2, '0')} — ${state.activeAccount.name}`
        );
      }
    } else if (action === 'run-row') {
      const promptEl = document.getElementById(`row-prompt-${rowIndex}`);
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      const patch = {};
      if (promptEl) patch.prompt = promptEl.value;
      if (dlgEl) patch.dialogue = dlgEl.value;
      if (Object.keys(patch).length > 0) await saveRowFields(rowIndex, patch);
      try {
        const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/run`, {
          method: 'POST'
        });
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    } else if (action === 'regen-row') {
      const promptEl = document.getElementById(`row-prompt-${rowIndex}`);
      const dlgEl = document.getElementById(`row-dialogue-${rowIndex}`);
      const patch = {};
      if (promptEl) patch.prompt = promptEl.value;
      if (dlgEl) patch.dialogue = dlgEl.value;
      if (Object.keys(patch).length > 0) await saveRowFields(rowIndex, patch);
      try {
        const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/rows/${rowIndex}/regenerate`, {
          method: 'POST'
        });
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    } else if (action === 'edit-capcut-row') {
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!row || !row.videoUrl) return;
      await openCapcutEditorModal({ initialRows: [row], singleRowTarget: row.index });
    } else if (action === 'preview-video') {
      const row = state.activeAccount.rows.find((r) => r.index === rowIndex);
      if (!row || !row.videoUrl) return;
      const modal = document.getElementById('videoPreviewModal');
      const player = document.getElementById('previewModalPlayer');
      const title = document.getElementById('previewModalTitle');
      const meta = document.getElementById('previewModalMeta');
      title.textContent = `🎬 HÀNG #${String(rowIndex).padStart(2, '0')} — ${state.activeAccount.name}`;
      player.src = row.videoUrl;
      const metaParts = [];
      if (row.prompt) metaParts.push(`🎬 Chuyển động: ${row.prompt}`);
      if (row.dialogue) metaParts.push(`🎙️ Lời thoại: ${row.dialogue}`);
      meta.textContent = metaParts.join('  •  ');
      modal.classList.remove('hidden');
    } else if (action === 'download-video') {
      const downloadUrl = `/api/download-video?accountId=${encodeURIComponent(state.activeAccount.id)}&rowIndex=${rowIndex}`;
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `MuseFlow_Row_${rowIndex}.mp4`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  });

  // Chạy tất cả / Dừng
  document.getElementById('btnRunAllBatch').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/batch/start`, {
        method: 'POST',
        body: JSON.stringify({ forceAll: false })
      });
      state.batchStats = res.stats;
      renderBatchMonitor();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnStopBatch').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      await apiFetch(`/api/accounts/${state.activeAccount.id}/batch/stop`, { method: 'POST' });
      showToast('Đã dừng chạy hàng loạt.', 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Bàn dựng CapCut Studio
  const capcutPlayer = document.getElementById('capcutPreviewPlayer');
  const playheadSlider = document.getElementById('capcutPlayheadSlider');

  document.getElementById('capcutSourceRowsList')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-add-row]');
    if (!btn || !state.activeAccount) return;
    const rowIdx = Number(btn.dataset.addRow);
    const row = state.activeAccount.rows.find((r) => r.index === rowIdx);
    if (!row || !row.videoUrl) return;

    const clip = await createClipFromRow(row);
    capcutState.clips.push(clip);
    capcutState.activeClipId = clip.id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutAddAllRows')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const rows = (state.activeAccount.rows || []).filter((r) => Boolean(r.videoUrl));
    if (rows.length === 0) {
      showToast('Chưa có hàng nào có video!', 'error');
      return;
    }
    for (const r of rows) {
      capcutState.clips.push(await createClipFromRow(r));
    }
    if (!capcutState.activeClipId && capcutState.clips[0]) {
      capcutState.activeClipId = capcutState.clips[0].id;
    }
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('capcutTimelineTrack')?.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('button[data-remove-clip]');
    if (removeBtn) {
      e.stopPropagation();
      const id = removeBtn.dataset.removeClip;
      capcutState.clips = capcutState.clips.filter((c) => c.id !== id);
      if (capcutState.activeClipId === id) {
        capcutState.activeClipId = capcutState.clips[0]?.id || null;
        loadActiveClipIntoPlayer(false);
      }
      renderCapcutAll();
      return;
    }

    const card = e.target.closest('.timeline-clip-card');
    if (card && card.dataset.clipId) {
      capcutState.playingAll = false;
      capcutState.activeClipId = card.dataset.clipId;
      renderCapcutAll();
      loadActiveClipIntoPlayer(false);
    }
  });

  document.getElementById('btnCapcutClearTimeline')?.addEventListener('click', () => {
    capcutState.clips = [];
    capcutState.activeClipId = null;
    capcutState.playingAll = false;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutPlayPause')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    capcutState.playingAll = false;
    if (capcutPlayer.paused) {
      if (capcutPlayer.currentTime < clip.startTime || capcutPlayer.currentTime >= clip.endTime - 0.05) {
        capcutPlayer.currentTime = clip.startTime;
      }
      capcutPlayer.play().catch(() => {});
    } else {
      capcutPlayer.pause();
    }
  });

  document.getElementById('btnCapcutPlayAll')?.addEventListener('click', () => {
    if (capcutState.clips.length === 0) return;
    capcutState.playingAll = true;
    capcutState.activeClipId = capcutState.clips[0].id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(true);
  });

  if (capcutPlayer) {
    capcutPlayer.addEventListener('play', () => {
      const btn = document.getElementById('btnCapcutPlayPause');
      if (btn) btn.textContent = '⏸ Tạm dừng';
    });
    capcutPlayer.addEventListener('pause', () => {
      const btn = document.getElementById('btnCapcutPlayPause');
      if (btn) btn.textContent = '▶ Phát đoạn';
    });
    capcutPlayer.addEventListener('timeupdate', () => {
      const clip = getActiveCapcutClip();
      if (!clip) return;
      const cur = capcutPlayer.currentTime;
      if (playheadSlider) playheadSlider.value = String(cur);
      const curLabel = document.getElementById('capcutCurrentTimeLabel');
      if (curLabel) curLabel.textContent = formatTimeSec(cur);

      if (cur >= clip.endTime - 0.03) {
        if (capcutState.playingAll) {
          const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
          if (idx !== -1 && idx + 1 < capcutState.clips.length) {
            capcutState.activeClipId = capcutState.clips[idx + 1].id;
            renderCapcutAll();
            loadActiveClipIntoPlayer(true);
            return;
          }
        }
        capcutState.playingAll = false;
        capcutPlayer.pause();
        capcutPlayer.currentTime = clip.endTime;
      }
    });
    capcutPlayer.addEventListener('ended', () => {
      const clip = getActiveCapcutClip();
      if (capcutState.playingAll && clip) {
        const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
        if (idx !== -1 && idx + 1 < capcutState.clips.length) {
          capcutState.activeClipId = capcutState.clips[idx + 1].id;
          renderCapcutAll();
          loadActiveClipIntoPlayer(true);
          return;
        }
      }
      capcutState.playingAll = false;
    });
  }

  playheadSlider?.addEventListener('input', (e) => {
    const val = Number(e.target.value) || 0;
    if (capcutPlayer) capcutPlayer.currentTime = val;
    const curLabel = document.getElementById('capcutCurrentTimeLabel');
    if (curLabel) curLabel.textContent = formatTimeSec(val);
  });

  document.getElementById('btnCapcutSetIn')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const t = Number(capcutPlayer.currentTime.toFixed(2));
    if (t >= clip.endTime - 0.2) {
      showToast('Điểm đầu phải nhỏ hơn điểm cuối ít nhất 0.2s!', 'error');
      return;
    }
    clip.startTime = Math.max(0, t);
    renderCapcutAll();
  });

  document.getElementById('btnCapcutSetOut')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const t = Number(capcutPlayer.currentTime.toFixed(2));
    if (t <= clip.startTime + 0.2) {
      showToast('Điểm cuối phải lớn hơn điểm đầu ít nhất 0.2s!', 'error');
      return;
    }
    clip.endTime = Math.min(clip.sourceDuration || 10, t);
    renderCapcutAll();
  });

  document.getElementById('btnCapcutSplitClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip || !capcutPlayer) return;
    const splitPoint = Number(capcutPlayer.currentTime.toFixed(2));
    if (splitPoint <= clip.startTime + 0.25 || splitPoint >= clip.endTime - 0.25) {
      showToast('Di chuyển kim phát vào giữa đoạn để tách đôi!', 'error');
      return;
    }

    const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
    if (idx === -1) return;

    const secondHalf = {
      ...clip,
      id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      startTime: splitPoint,
      endTime: clip.endTime
    };
    clip.endTime = splitPoint;

    capcutState.clips.splice(idx + 1, 0, secondHalf);
    capcutState.activeClipId = secondHalf.id;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
    showToast(`Đã tách đôi tại mốc ${splitPoint.toFixed(1)}s!`, 'success');
  });

  const syncClipTrimStart = (rawVal) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const v = Math.max(0, Math.min(clip.endTime - 0.2, Number(rawVal) || 0));
    clip.startTime = Number(v.toFixed(2));
    if (capcutPlayer) capcutPlayer.currentTime = clip.startTime;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  };

  const syncClipTrimEnd = (rawVal) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const maxDur = clip.sourceDuration || 10;
    const v = Math.min(maxDur, Math.max(clip.startTime + 0.2, Number(rawVal) || maxDur));
    clip.endTime = Number(v.toFixed(2));
    if (capcutPlayer) capcutPlayer.currentTime = clip.endTime;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  };

  document.getElementById('sliderCapcutTrimStart')?.addEventListener('input', (e) => syncClipTrimStart(e.target.value));
  document.getElementById('inputCapcutTrimStart')?.addEventListener('change', (e) => syncClipTrimStart(e.target.value));
  document.getElementById('sliderCapcutTrimEnd')?.addEventListener('input', (e) => syncClipTrimEnd(e.target.value));
  document.getElementById('inputCapcutTrimEnd')?.addEventListener('change', (e) => syncClipTrimEnd(e.target.value));

  document.getElementById('selectCapcutClipSpeed')?.addEventListener('change', (e) => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.speed = Number(e.target.value) || 1;
    if (capcutPlayer) capcutPlayer.playbackRate = clip.speed;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  });

  document.getElementById('btnCapcutToggleMute')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.muted = !clip.muted;
    if (capcutPlayer) capcutPlayer.muted = clip.muted;
    renderCapcutInspector();
    renderCapcutTimelineTrack();
  });

  document.getElementById('btnCapcutMoveLeft')?.addEventListener('click', () => {
    const idx = capcutState.clips.findIndex((c) => c.id === capcutState.activeClipId);
    if (idx > 0) {
      const [item] = capcutState.clips.splice(idx, 1);
      capcutState.clips.splice(idx - 1, 0, item);
      renderCapcutAll();
    }
  });

  document.getElementById('btnCapcutMoveRight')?.addEventListener('click', () => {
    const idx = capcutState.clips.findIndex((c) => c.id === capcutState.activeClipId);
    if (idx !== -1 && idx < capcutState.clips.length - 1) {
      const [item] = capcutState.clips.splice(idx, 1);
      capcutState.clips.splice(idx + 1, 0, item);
      renderCapcutAll();
    }
  });

  document.getElementById('btnCapcutDuplicateClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    const idx = capcutState.clips.findIndex((c) => c.id === clip.id);
    const copy = { ...clip, id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}` };
    capcutState.clips.splice(idx + 1, 0, copy);
    capcutState.activeClipId = copy.id;
    renderCapcutAll();
  });

  document.getElementById('btnCapcutResetClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    clip.startTime = 0;
    clip.endTime = clip.sourceDuration || 10;
    clip.speed = 1;
    clip.muted = false;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  document.getElementById('btnCapcutDeleteClip')?.addEventListener('click', () => {
    const clip = getActiveCapcutClip();
    if (!clip) return;
    capcutState.clips = capcutState.clips.filter((c) => c.id !== clip.id);
    capcutState.activeClipId = capcutState.clips[0]?.id || null;
    renderCapcutAll();
    loadActiveClipIntoPlayer(false);
  });

  async function executeCapcutRender(saveToRowIndex = null) {
    if (!state.activeAccount) return;
    if (capcutState.clips.length === 0) {
      showToast('Hãy thêm ít nhất 1 đoạn video vào Timeline!', 'error');
      return;
    }

    const btnExport = document.getElementById('btnCapcutRenderExport');
    const btnSaveRow = document.getElementById('btnCapcutSaveToSingleRow');
    const outputName = document.getElementById('inputCapcutOutputName')?.value || 'Video_Da_Noi';
    const aspectMode = document.getElementById('selectCapcutAspect')?.value || 'auto';

    if (btnExport) btnExport.disabled = true;
    if (btnSaveRow) btnSaveRow.disabled = true;

    try {
      showToast('Đang xuất video...', 'info');
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/video-editor/render`, {
        method: 'POST',
        body: JSON.stringify({
          clips: capcutState.clips,
          outputCustomName: outputName,
          aspectMode,
          transitionEffect: state.activeAccount?.settings?.transitionEffect || 'fade',
          saveToRowIndex
        })
      });

      capcutState.lastExportedResult = res.result;
      const resultBox = document.getElementById('capcutExportResultBox');
      const resultText = document.getElementById('capcutExportResultText');
      const downloadLink = document.getElementById('linkCapcutDownloadExported');

      if (resultBox && res.result) {
        resultBox.classList.remove('hidden');
        if (resultText) {
          resultText.textContent = `✓ Đã xuất: ${res.result.duration}s`;
        }
        if (downloadLink) {
          downloadLink.href = saveToRowIndex
            ? `/api/download-video?accountId=${encodeURIComponent(state.activeAccount.id)}&rowIndex=${saveToRowIndex}`
            : `/api/download-merged?accountId=${encodeURIComponent(state.activeAccount.id)}&fileName=${encodeURIComponent(
                res.result.fileName
              )}`;
          downloadLink.download = res.result.fileName;
        }
      }

      if (saveToRowIndex) await loadAppState();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(`Lỗi xuất video: ${err.message}`, 'error');
    } finally {
      if (btnExport) btnExport.disabled = false;
      if (btnSaveRow) btnSaveRow.disabled = false;
    }
  }

  document.getElementById('btnCapcutRenderExport')?.addEventListener('click', () => executeCapcutRender(null));
  document.getElementById('btnCapcutSaveToSingleRow')?.addEventListener('click', (e) => {
    const targetRow = Number(e.currentTarget.dataset.targetRow);
    if (targetRow) executeCapcutRender(targetRow);
  });

  document.getElementById('btnCapcutPreviewExported')?.addEventListener('click', () => {
    const r = capcutState.lastExportedResult;
    if (!r || !r.publicUrl) return;
    if (capcutPlayer) capcutPlayer.pause();
    const modal = document.getElementById('videoPreviewModal');
    const player = document.getElementById('previewModalPlayer');
    const title = document.getElementById('previewModalTitle');
    const meta = document.getElementById('previewModalMeta');
    title.textContent = `🎬 VIDEO ĐÃ XUẤT (${r.duration}s)`;
    player.src = `${r.publicUrl}?t=${Date.now()}`;
    meta.textContent = `${r.width}x${r.height} • ${r.clipCount} đoạn`;
    modal.classList.remove('hidden');
  });

  // ==================== HƯỚNG DẪN, SKILL AI & BẢN QUYỀN ====================
  document.getElementById('selectActiveSkill')?.addEventListener('change', async (e) => {
    const chosenId = e.target.value || '';
    await saveSidebarSettings({ activeSkillId: chosenId });
    const sk = (state.skills || []).find((s) => s.id === chosenId);
    if (sk) {
      showToast(`Đã bật "${sk.name}" cho ${state.activeAccount?.name || 'dự án này'}!`, 'success');
    } else {
      showToast('Đã tắt Skill AI cho dự án này.', 'info');
    }
  });

  document.getElementById('btnOpenSkillModal')?.addEventListener('click', () => {
    resetSkillEditorForm();
    renderSkillsModalList();
    document.getElementById('skillModal')?.classList.remove('hidden');
  });

  document.getElementById('btnClearSkillForm')?.addEventListener('click', () => {
    resetSkillEditorForm();
  });

  document.getElementById('btnTriggerImportSkillFile')?.addEventListener('click', () => {
    const fileInp = document.getElementById('inputSkillFiles');
    if (fileInp) {
      fileInp.value = '';
      fileInp.click();
    }
  });

  document.getElementById('inputSkillFiles')?.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const items = [];
      for (const f of files) {
        const content = await f.text();
        items.push({ fileName: f.name, content });
      }
      const res = await apiFetch('/api/skills/import', {
        method: 'POST',
        body: JSON.stringify({ items })
      });
      state.skills = res.skills || [];
      if (Array.isArray(res.imported) && res.imported.length > 0 && state.activeAccount) {
        await saveSidebarSettings({ activeSkillId: res.imported[0].id });
      }
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message || 'Đã nhập file Skill thành công!', 'success');
    } catch (err) {
      showToast(`Lỗi nhập file Skill: ${err.message}`, 'error');
    }
  });

  document.getElementById('btnRestoreDefaultSkills')?.addEventListener('click', async () => {
    try {
      const res = await apiFetch('/api/skills/restore-defaults', { method: 'POST' });
      state.skills = res.skills || [];
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnSaveAndApplySkill')?.addEventListener('click', async () => {
    const id = document.getElementById('editSkillId')?.value || '';
    const name = document.getElementById('inputSkillName')?.value || '';
    const summary = document.getElementById('inputSkillSummary')?.value || '';
    const instructions = document.getElementById('inputSkillInstructions')?.value || '';

    const btn = document.getElementById('btnSaveAndApplySkill');
    if (btn) btn.disabled = true;

    try {
      const res = await apiFetch('/api/skills', {
        method: 'POST',
        body: JSON.stringify({ id: id || undefined, name, summary, instructions })
      });
      state.skills = res.skills || [];
      if (res.skill && state.activeAccount) {
        await saveSidebarSettings({ activeSkillId: res.skill.id });
      }
      resetSkillEditorForm();
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(res.message || 'Đã lưu và áp dụng Skill!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('skillsModalList')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-skill-action]');
    if (!btn) return;
    const action = btn.dataset.skillAction;
    const skillId = btn.dataset.id;
    const sk = (state.skills || []).find((s) => s.id === skillId);
    if (!sk) return;

    if (action === 'apply') {
      const curId = state.activeAccount?.settings?.activeSkillId || '';
      const nextId = curId === sk.id ? '' : sk.id;
      await saveSidebarSettings({ activeSkillId: nextId });
      renderSkillSelectorAndBadge();
      renderSkillsModalList();
      showToast(
        nextId ? `Đã áp dụng "${sk.name}" cho ${state.activeAccount?.name}!` : 'Đã bỏ chọn Skill cho dự án này.',
        'success'
      );
    } else if (action === 'edit') {
      document.getElementById('editSkillId').value = sk.id;
      document.getElementById('inputSkillName').value = sk.name || '';
      document.getElementById('inputSkillSummary').value = sk.summary || '';
      document.getElementById('inputSkillInstructions').value = sk.instructions || '';
      const headEl = document.getElementById('skillFormHeading');
      if (headEl) headEl.textContent = `Đang sửa: ${sk.name}`;
      document.getElementById('btnClearSkillForm')?.classList.remove('hidden');
      document.getElementById('inputSkillName')?.focus();
    } else if (action === 'export') {
      const mdContent = [
        '---',
        `name: "${String(sk.name || '').replace(/"/g, '\\"')}"`,
        `description: "${String(sk.summary || '').replace(/"/g, '\\"')}"`,
        '---',
        '',
        sk.instructions || ''
      ].join('\n');
      const blob = new Blob([mdContent], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safeSlug = String(sk.name || 'SKILL')
        .replace(/[^\p{L}\p{N}_-]+/gu, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 45);
      a.href = url;
      a.download = `SKILL_${safeSlug || 'MuseFlow'}.md`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast(`Đã xuất file SKILL_${safeSlug || 'MuseFlow'}.md!`, 'success');
    } else if (action === 'delete') {
      const ok = window.confirm(`Xóa "${sk.name}" khỏi thư viện Skill?`);
      if (!ok) return;
      try {
        const res = await apiFetch(`/api/skills/${encodeURIComponent(sk.id)}`, { method: 'DELETE' });
        state.skills = res.skills || [];
        if (res.activeAccount) state.activeAccount = res.activeAccount;
        renderSkillSelectorAndBadge();
        renderSkillsModalList();
        showToast(res.message, 'info');
      } catch (err) {
        showToast(err.message, 'error');
      }
    }
  });

  document.getElementById('btnGeneratePromptsBySkill')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    const activeSkillId = state.activeAccount.settings?.activeSkillId || '';
    if (!activeSkillId) {
      showToast('Hãy chọn 1 Skill AI ở ô bên trên trước khi bấm Viết Prompt Theo Skill!', 'error');
      document.getElementById('selectActiveSkill')?.focus();
      return;
    }

    const rows = state.activeAccount.rows || [];
    const emptyPromptWithImg = rows.filter((r) => {
      const hasImg = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => Boolean(img));
      return hasImg && (!r.prompt || !r.prompt.trim());
    });
    const anyRowWithImgOrPrompt = rows.filter((r) => {
      const hasImg = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => Boolean(img));
      return hasImg || Boolean(r.prompt && r.prompt.trim());
    });

    if (anyRowWithImgOrPrompt.length === 0) {
      showToast('Hãy thêm ảnh tham chiếu (hoặc gợi ý ngắn) vào các hàng trước!', 'error');
      return;
    }

    let overwriteExisting = false;
    if (emptyPromptWithImg.length === 0) {
      const confirmOverwrite = window.confirm(
        'Các hàng có ảnh đều đã có sẵn Prompt. Bạn có muốn AI viết lại Prompt mới theo Skill đè lên các hàng hiện tại không?'
      );
      if (!confirmOverwrite) return;
      overwriteExisting = true;
    }

    state.skillPromptRunning = true;
    renderSkillAutoPromptButtons({ completed: 0, total: overwriteExisting ? anyRowWithImgOrPrompt.length : emptyPromptWithImg.length });

    try {
      showToast('🧠 Đang gửi ảnh & Skill lên Muse.ai để tự động viết Prompt...', 'info');
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/skills/generate-prompts`, {
        method: 'POST',
        body: JSON.stringify({ skillId: activeSkillId, overwriteExisting })
      });
      if (res.account) {
        state.activeAccount = res.account;
        renderFlowRows();
      }
      showToast(res.message || 'Đã viết xong Prompt theo Skill!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      state.skillPromptRunning = false;
      renderSkillAutoPromptButtons();
    }
  });

  document.getElementById('btnStopSkillPrompts')?.addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const res = await apiFetch(`/api/accounts/${state.activeAccount.id}/skills/stop-prompts`, {
        method: 'POST'
      });
      showToast(res.message, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('btnOpenGuideModal')?.addEventListener('click', () => {
    document.getElementById('guideModal')?.classList.remove('hidden');
  });

  document.getElementById('btnOpenLicenseModal')?.addEventListener('click', () => {
    renderLicenseUI(true);
  });

  document.getElementById('pricingPlansGrid')?.addEventListener('click', (e) => {
    const card = e.target.closest('.pricing-card[data-plan]');
    if (!card) return;
    selectPricingPlan(card.dataset.plan);
  });

  document.getElementById('btnCheckPaymentNow')?.addEventListener('click', () => {
    pollPaymentOrderOnce(true);
  });

  document.getElementById('btnCopyHwid')?.addEventListener('click', async () => {
    const hwid = state.license?.hwid || document.getElementById('inputMachineHwid')?.value || '';
    if (!hwid) return;
    await navigator.clipboard.writeText(hwid).catch(() => {});
    showToast(`Đã copy Mã Máy: ${hwid}`, 'success');
  });

  document.getElementById('btnCopyAmount')?.addEventListener('click', async () => {
    const rawAmt = document.getElementById('payAmountText')?.dataset.rawAmount || '';
    if (!rawAmt) return;
    await navigator.clipboard.writeText(rawAmt).catch(() => {});
    showToast(`Đã copy số tiền: ${rawAmt}`, 'success');
  });

  document.querySelectorAll('[data-copy-target]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const targetEl = document.getElementById(btn.dataset.copyTarget);
      if (!targetEl) return;
      const val = targetEl.dataset.copyValue || targetEl.textContent.trim();
      await navigator.clipboard.writeText(val).catch(() => {});
      showToast(`Đã copy: ${val}`, 'success');
    });
  });

  document.getElementById('btnActivateLicense')?.addEventListener('click', async () => {
    const keyInput = document.getElementById('inputLicenseKey');
    const licenseKey = (keyInput?.value || '').trim();
    if (!licenseKey) {
      showToast('Vui lòng dán mã License Key vào ô!', 'error');
      return;
    }

    const btn = document.getElementById('btnActivateLicense');
    if (btn) btn.disabled = true;

    try {
      const res = await apiFetch('/api/license/activate', {
        method: 'POST',
        body: JSON.stringify({ licenseKey })
      });
      state.license = res.license;
      if (keyInput) keyInput.value = '';
      stopPaymentPolling();
      renderLicenseUI(false);
      startLicenseCountdownTimer();
      showToast(res.message || 'Kích hoạt thành công!', 'success');
      await loadAppState();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  document.getElementById('btnDeactivateLicense')?.addEventListener('click', async () => {
    const ok = window.confirm('Gỡ mã Key hiện tại khỏi máy này?');
    if (!ok) return;
    try {
      const res = await apiFetch('/api/license/deactivate', { method: 'POST' });
      state.license = res.license;
      renderLicenseUI(true);
      startLicenseCountdownTimer();
      showToast(res.message, 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Đóng Modal
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.close;
      if (id === 'licenseModal' && !state.license?.valid) {
        showToast('Vui lòng chọn gói hoặc nhập Key để tiếp tục sử dụng!', 'error');
        return;
      }
      if (id === 'updateAvailableModal' && (updateInstalling || cachedUpdateInfo?.mandatory)) {
        return;
      }
      const modal = document.getElementById(id);
      if (modal) modal.classList.add('hidden');
      if (id === 'licenseModal') stopPaymentPolling();
      if (id === 'videoPreviewModal') {
        document.getElementById('previewModalPlayer')?.pause();
      } else if (id === 'outputGalleryModal') {
        document.getElementById('outputGalleryPlayer')?.pause();
      } else if (id === 'capcutEditorModal') {
        if (capcutPlayer) capcutPlayer.pause();
        capcutState.playingAll = false;
      }
    });
  });

  document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        if (backdrop.id === 'licenseModal' && !state.license?.valid) return;
        if (backdrop.id === 'updateAvailableModal' && (updateInstalling || cachedUpdateInfo?.mandatory)) return;
        backdrop.classList.add('hidden');
        if (backdrop.id === 'licenseModal') stopPaymentPolling();
        if (backdrop.id === 'videoPreviewModal') {
          document.getElementById('previewModalPlayer')?.pause();
        } else if (backdrop.id === 'outputGalleryModal') {
          document.getElementById('outputGalleryPlayer')?.pause();
        } else if (backdrop.id === 'capcutEditorModal') {
          if (capcutPlayer) capcutPlayer.pause();
          capcutState.playingAll = false;
        }
      }
    });
  });
});
