@echo off
chcp 65001 >nul
title MUSE FLOW STUDIO 2.3 - NGUYEN LINH AI (0967981918)
cd /d "%~dp0"

echo ====================================================================
echo   DANG KHOI DONG MUSE FLOW STUDIO 2.3 - NGUYEN LINH AI (0967981918)
echo ====================================================================

if not exist "ChromeProfile_Data" mkdir "ChromeProfile_Data"
if not exist "Output_Videos" mkdir "Output_Videos"
if not exist "Project_Data" mkdir "Project_Data"

set "NODE_EXE=runtime\node\node.exe"
if not exist "%NODE_EXE%" (
  set "NODE_EXE=node"
)

start "" /b "%NODE_EXE%" "server.js"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:3888"
