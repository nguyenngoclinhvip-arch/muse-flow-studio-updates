class BatchScheduler {
  constructor({ accountManager, cdpEngine, onEvent }) {
    this.accountManager = accountManager;
    this.cdpEngine = cdpEngine;
    this.onEvent = typeof onEvent === 'function' ? onEvent : () => {};
    this.jobs = new Map();
  }

  emit(event, payload) {
    try {
      this.onEvent(event, payload);
    } catch (_) {}
  }

  getJobState(accountId) {
    const job = this.jobs.get(accountId);
    const acc = this.accountManager.getAccount(accountId);
    const defaultConcurrency = Math.max(1, Math.min(20, Number(acc?.settings?.concurrency) || 6));
    if (!job) {
      return {
        running: false,
        batchSize: defaultConcurrency,
        currentBatchIndex: 0,
        totalBatches: 0,
        activeThreads: 0,
        completedInCurrentBatch: 0,
        currentBatchTargetCount: 0,
        totalCompleted: 0,
        totalFailed: 0,
        totalTargetRows: 0,
        currentBatchRows: []
      };
    }
    return job.stats;
  }

  async runSingleRow(accountId, rowIndex, isRegenerate = false) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy tài khoản.');

    if (isRegenerate) {
      this.accountManager.updateRow(accountId, rowIndex, {
        status: 'queued',
        statusMessage: 'Đang chuẩn bị tạo lại...',
        videoUrl: null,
        videoFilePath: null,
        remoteVideoUrl: null,
        error: null
      });
    }

    return await this.cdpEngine.executeRow({
      accountId,
      rowIndex: Number(rowIndex)
    });
  }

  async runAllInBatchesOfSix(accountId, { forceAll = false } = {}) {
    const existingJob = this.jobs.get(accountId);
    if (existingJob && existingJob.running) {
      throw new Error('Dự án đang chạy hàng loạt. Vui lòng đợi hoặc bấm Dừng!');
    }

    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy dự án.');
    }

    const batchSize = Math.max(1, Math.min(20, Number(account.settings?.concurrency) || 6));

    const globalHasSampleVideo = Boolean(
      account.settings?.sampleVideo && account.settings.sampleVideo.filePath
    );

    const allHasData = account.rows.filter((r) => {
      const hasPrompt = Boolean(r.prompt && r.prompt.trim().length > 0);
      const hasDialogue = Boolean(r.dialogue && r.dialogue.trim().length > 0);
      const hasImages = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => img && img.filePath);
      const hasRowSampleVideo = Boolean(r.sampleVideo && r.sampleVideo.filePath);
      return hasPrompt || hasDialogue || hasImages || hasRowSampleVideo || globalHasSampleVideo;
    });

    let eligibleRows;
    if (forceAll) {
      eligibleRows = allHasData;
    } else {
      const nonErrorPending = allHasData.filter((r) => r.status !== 'completed' && r.status !== 'error');
      if (nonErrorPending.length > 0) {
        eligibleRows = nonErrorPending;
      } else {
        eligibleRows = allHasData.filter((r) => r.status !== 'completed');
      }
    }

    if (eligibleRows.length === 0) {
      throw new Error('Chưa có hàng nào có ảnh, Prompt chuyển động hoặc Lời thoại để chạy.');
    }

    const batches = [];
    for (let i = 0; i < eligibleRows.length; i += batchSize) {
      batches.push(eligibleRows.slice(i, i + batchSize));
    }

    batches.forEach((batchRows, bIdx) => {
      batchRows.forEach((r) => {
        this.accountManager.updateRow(accountId, r.index, {
          status: 'queued',
          statusMessage: `Chờ lượt ${bIdx + 1}/${batches.length}...`,
          error: null
        });
      });
    });

    const abortController = new AbortController();
    const stats = {
      running: true,
      batchSize,
      currentBatchIndex: 0,
      totalBatches: batches.length,
      activeThreads: 0,
      completedInCurrentBatch: 0,
      currentBatchTargetCount: 0,
      totalCompleted: 0,
      totalFailed: 0,
      totalTargetRows: eligibleRows.length,
      currentBatchRows: []
    };

    this.jobs.set(accountId, {
      running: true,
      abortController,
      stats
    });

    this.emit('batch_progress', { accountId, stats });

    (async () => {
      try {
        for (let bIndex = 0; bIndex < batches.length; bIndex++) {
          if (abortController.signal.aborted) break;

          const currentBatch = batches[bIndex];
          stats.currentBatchIndex = bIndex + 1;
          stats.completedInCurrentBatch = 0;
          stats.currentBatchTargetCount = currentBatch.length;
          stats.activeThreads = currentBatch.length;
          stats.currentBatchRows = currentBatch.map((r) => r.index);

          this.emit('batch_progress', { accountId, stats });

          const workerPromises = currentBatch.map(async (rowItem) => {
            try {
              await this.cdpEngine.executeRow({
                accountId,
                rowIndex: rowItem.index,
                abortSignal: abortController.signal
              });
              stats.totalCompleted += 1;
            } catch (err) {
              stats.totalFailed += 1;
              const errMsg = err?.message || 'Không tạo được video';
              const updatedRow = this.accountManager.updateRow(accountId, rowItem.index, {
                status: 'error',
                statusMessage: `Lỗi (Đã bỏ qua): ${errMsg}`,
                error: errMsg
              });
              this.emit('row_updated', {
                accountId,
                rowIndex: rowItem.index,
                row: updatedRow
              });
              this.emit('row_error_skipped', {
                accountId,
                rowIndex: rowItem.index,
                error: errMsg
              });
            } finally {
              stats.completedInCurrentBatch += 1;
              stats.activeThreads = Math.max(0, stats.activeThreads - 1);
              this.emit('batch_progress', { accountId, stats });
            }
          });

          await Promise.allSettled(workerPromises);
        }
      } finally {
        stats.running = false;
        stats.activeThreads = 0;
        this.jobs.set(accountId, {
          running: false,
          abortController: null,
          stats
        });
        this.emit('batch_progress', { accountId, stats });
      }
    })();

    return stats;
  }

  stopBatch(accountId) {
    const job = this.jobs.get(accountId);
    if (job && job.running && job.abortController) {
      job.abortController.abort();
      job.running = false;
      job.stats.running = false;
      this.emit('batch_progress', { accountId, stats: job.stats });
      return true;
    }
    return false;
  }
}

module.exports = {
  BatchScheduler
};
