const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execFileSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..');

function normalizeDir(p) {
  try {
    return path.resolve(p).replace(/[\\/]+$/, '').toLowerCase();
  } catch (_) {
    return String(p || '').replace(/[\\/]+$/, '').toLowerCase();
  }
}

function isRunningInsideTemp(dir) {
  const lower = String(dir || '').toLowerCase().replace(/\//g, '\\');
  if (
    lower.includes('\\temp\\rar$') ||
    lower.includes('\\temp\\7z') ||
    lower.includes('\\temp\\wz') ||
    lower.includes('\\temp\\bnz') ||
    lower.includes('.zip\\') ||
    lower.includes('.rar\\')
  ) {
    return true;
  }
  const sysTemp = String(os.tmpdir() || '').toLowerCase().replace(/\//g, '\\');
  return Boolean(sysTemp && lower.startsWith(sysTemp));
}

function httpGetText(url, timeoutMs = 1500) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout: timeoutMs }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        resolve({
          status: res.statusCode || 0,
          body: Buffer.concat(chunks).toString('utf8')
        });
      });
    });
    req.on('timeout', () => {
      req.destroy();
      resolve({ status: 0, body: '' });
    });
    req.on('error', () => resolve({ status: 0, body: '' }));
  });
}

function isTcpPortBusy(port) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let settled = false;
    const done = (busy) => {
      if (settled) return;
      settled = true;
      try {
        sock.destroy();
      } catch (_) {}
      resolve(busy);
    };
    sock.setTimeout(300);
    sock.once('connect', () => done(true));
    sock.once('timeout', () => done(false));
    sock.once('error', () => done(false));
    sock.connect(port, '127.0.0.1');
  });
}

function readExpectedVersion() {
  try {
    const srv = fs.readFileSync(path.join(APP_ROOT, 'server.js'), 'utf8');
    const m = srv.match(/const\s+APP_VERSION\s*=\s*['"]([^'"]+)['"]/);
    return m ? m[1].trim() : '';
  } catch (_) {
    return '';
  }
}

async function isHealthyCurrentStudio(port) {
  const rootRes = await httpGetText(`http://127.0.0.1:${port}/`, 1500);
  if (rootRes.status !== 200 || !rootRes.body.includes('MUSE FLOW') || rootRes.body.includes('Cannot GET')) {
    return false;
  }
  const stateRes = await httpGetText(`http://127.0.0.1:${port}/api/state`, 1500);
  if (stateRes.status !== 200) return false;
  try {
    const parsed = JSON.parse(stateRes.body);
    if (normalizeDir(parsed.appRootDir) !== normalizeDir(APP_ROOT)) return false;
    if (parsed.isInteractiveDesktop === false) return false;
    const expectedVer = readExpectedVersion();
    if (expectedVer && String(parsed.version || '') !== expectedVer) return false;
    return true;
  } catch (_) {
    return false;
  }
}

function killStaleNodeOnPort(port) {
  try {
    const out = execFileSync('netstat.exe', ['-ano', '-p', 'tcp'], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 3000
    });
    const suffix = `:${port}`;
    for (const rawLine of out.split(/\r?\n/)) {
      if (!/LISTENING/i.test(rawLine)) continue;
      const parts = rawLine.trim().split(/\s+/);
      if (parts.length < 5) continue;
      if (!parts[1].endsWith(suffix)) continue;
      const pid = Number(parts[parts.length - 1]);
      if (!pid || pid === process.pid) continue;
      try {
        const taskOut = execFileSync('tasklist.exe', ['/FI', `PID eq ${pid}`, '/NH'], {
          encoding: 'utf8',
          windowsHide: true,
          timeout: 2000
        });
        if (/node\.exe/i.test(taskOut)) {
          execFileSync('taskkill.exe', ['/F', '/PID', String(pid)], {
            windowsHide: true,
            timeout: 3000
          });
        }
      } catch (_) {}
    }
  } catch (_) {}
}

function openStudioDesktopBrowser(studioUrl) {
  const uiProfileDir = path.join(APP_ROOT, 'Project_Data', 'Studio_UI_Host');
  fs.mkdirSync(uiProfileDir, { recursive: true });

  const localAppData = process.env.LOCALAPPDATA || '';
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    localAppData ? path.join(localAppData, 'Google\\Chrome\\Application\\chrome.exe') : ''
  ].filter(Boolean);

  for (const exe of candidates) {
    if (fs.existsSync(exe)) {
      const child = spawn(
        exe,
        [
          `--app=${studioUrl}`,
          '--window-size=1560,920',
          `--user-data-dir=${uiProfileDir}`,
          '--no-first-run',
          '--no-default-browser-check'
        ],
        {
          cwd: APP_ROOT,
          detached: true,
          stdio: 'ignore',
          windowsHide: false
        }
      );
      child.unref();
      return;
    }
  }

  spawn('cmd.exe', ['/c', 'start', '', studioUrl], {
    cwd: APP_ROOT,
    detached: true,
    stdio: 'ignore',
    windowsHide: true
  }).unref();
}

async function main() {
  if (isRunningInsideTemp(APP_ROOT) || !fs.existsSync(path.join(APP_ROOT, 'public', 'index.html'))) {
    console.error('====================================================================');
    console.error('  [CANH BAO] BAN CHUA GIAI NEN DAY DU FILE CONG CU (.RAR / .ZIP)!');
    console.error('  Vui long bam Chuot phai vao file nen -> Chon "Extract to..."');
    console.error('  (Giai nen ra thu muc rieng) va doi 100% roi moi mo phan mem!');
    console.error('====================================================================');
    process.exit(2);
  }

  for (const sub of ['ChromeProfile_Data', 'Output_Videos', 'Project_Data']) {
    fs.mkdirSync(path.join(APP_ROOT, sub), { recursive: true });
  }

  let port = 3888;
  if (!(await isHealthyCurrentStudio(port))) {
    if (await isTcpPortBusy(port)) {
      killStaleNodeOnPort(port);
      await new Promise((r) => setTimeout(r, 500));
    }
    if (await isTcpPortBusy(port)) {
      for (let p = 3889; p <= 3896; p++) {
        if (!(await isTcpPortBusy(p))) {
          port = p;
          break;
        }
      }
    }

    const child = spawn(process.execPath, [path.join(APP_ROOT, 'server.js')], {
      cwd: APP_ROOT,
      env: { ...process.env, PORT: String(port) },
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    });
    child.unref();

    let ready = false;
    for (let i = 0; i < 60; i++) {
      const rootRes = await httpGetText(`http://127.0.0.1:${port}/`, 1200);
      if (rootRes.status === 200 && rootRes.body.includes('MUSE FLOW') && !rootRes.body.includes('Cannot GET')) {
        ready = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 250));
    }

    if (!ready) {
      console.error(`[LOI] Khong the khoi dong may chu tren cong ${port}. Vui long kiem tra thu muc giai nen!`);
      process.exit(1);
    }
  }

  openStudioDesktopBrowser(`http://127.0.0.1:${port}`);
}

main().catch((err) => {
  console.error('[LOI KHOI DONG]:', err.message);
  process.exit(1);
});
