# -*- coding: utf-8 -*-
"""
MUSE FLOW STUDIO 2.9 — On-Device Biometric Face-Lock & Smart Close-Up Cropper (Pure ONNX)
Zero C++ build dependencies: requires only numpy, opencv-python-headless, onnx, onnxruntime(-directml).
"""

import argparse
import json
import os
import shutil
import sys
import tempfile
import time
import cv2
import numpy as np
import onnx
from onnx import numpy_helper
import onnxruntime as ort

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

ARCFACE_DST_112 = np.array(
    [
        [38.2946, 51.6963],
        [73.5318, 51.5014],
        [56.0252, 71.7366],
        [41.5493, 92.3655],
        [70.7299, 92.2041],
    ],
    dtype=np.float32,
)

INSWAPPER_DST_128 = ARCFACE_DST_112.copy()
INSWAPPER_DST_128[:, 0] += 8.0

FFHQ_DST_512 = np.array(
    [
        [192.98138, 239.94708],
        [318.90277, 240.19360],
        [256.63416, 314.01935],
        [201.26117, 371.41043],
        [313.08905, 371.15118],
    ],
    dtype=np.float32,
)


def emit_json(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def imread_unicode(file_path):
    data = np.fromfile(file_path, dtype=np.uint8)
    if data.size == 0:
        return None
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def imwrite_unicode(file_path, img):
    ext = os.path.splitext(file_path)[1] or ".png"
    ok, buf = cv2.imencode(ext, img)
    if not ok:
        return False
    buf.tofile(file_path)
    return True


def umeyama_2d(src, dst, estimate_scale=True):
    """Exact 2D Umeyama similarity transform (identical to skimage.transform.SimilarityTransform)."""
    num = src.shape[0]
    dim = src.shape[1]
    src_mean = src.mean(axis=0)
    dst_mean = dst.mean(axis=0)
    src_demean = src - src_mean
    dst_demean = dst - dst_mean

    A = dst_demean.T @ src_demean / num
    d = np.ones((dim,), dtype=np.float64)
    if np.linalg.det(A) < 0:
        d[dim - 1] = -1

    T = np.eye(dim + 1, dtype=np.float64)
    U, S, Vt = np.linalg.svd(A)
    rank = np.linalg.matrix_rank(A)
    if rank == 0:
        return np.eye(2, 3, dtype=np.float32)
    elif rank == dim - 1:
        if np.linalg.det(U) * np.linalg.det(Vt) > 0:
            T[:dim, :dim] = U @ Vt
        else:
            s = d[dim - 1]
            d[dim - 1] = -1
            T[:dim, :dim] = U @ np.diag(d) @ Vt
            d[dim - 1] = s
    else:
        T[:dim, :dim] = U @ np.diag(d) @ Vt

    if estimate_scale:
        scale = 1.0 / src_demean.var(axis=0).sum() * (S @ d)
    else:
        scale = 1.0

    T[:dim, dim] = dst_mean - scale * (T[:dim, :dim] @ src_mean.T)
    T[:dim, :dim] *= scale
    return T[:2, :].astype(np.float32)


def nms_boxes(dets, iou_thresh=0.4):
    if len(dets) == 0:
        return []
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]
    areas = (x2 - x1 + 1.0) * (y2 - y1 + 1.0)
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        w = np.maximum(0.0, xx2 - xx1 + 1.0)
        h = np.maximum(0.0, yy2 - yy1 + 1.0)
        inter = w * h
        ovr = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
        inds = np.where(ovr <= iou_thresh)[0]
        order = order[inds + 1]
    return keep


def _build_raw_ort_session(model_path, providers):
    so = ort.SessionOptions()
    so.log_severity_level = 3
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.intra_op_num_threads = max(2, min(12, os.cpu_count() or 4))
    if "DmlExecutionProvider" in providers:
        so.enable_mem_pattern = False
        so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    try:
        return ort.InferenceSession(model_path, sess_options=so, providers=providers)
    except Exception:
        with open(model_path, "rb") as f:
            raw_bytes = f.read()
        return ort.InferenceSession(raw_bytes, sess_options=so, providers=providers)


class SafeOrtSession:
    """Crash-proof ONNX Runtime wrapper: if DirectML/CUDA fails during session.run(), seamlessly falls back to CPU."""

    def __init__(self, model_path, sess_options=None, providers=None):
        self.model_path = model_path
        self.providers = list(providers or ["CPUExecutionProvider"])
        self._on_cpu = self.providers == ["CPUExecutionProvider"]
        try:
            self._sess = _build_raw_ort_session(model_path, self.providers)
        except Exception:
            self.providers = ["CPUExecutionProvider"]
            self._on_cpu = True
            self._sess = _build_raw_ort_session(model_path, ["CPUExecutionProvider"])

    def get_inputs(self):
        return self._sess.get_inputs()

    def get_outputs(self):
        return self._sess.get_outputs()

    def run(self, output_names, input_feed):
        try:
            return self._sess.run(output_names, input_feed)
        except Exception:
            if self._on_cpu:
                raise
            self.providers = ["CPUExecutionProvider"]
            self._on_cpu = True
            self._sess = _build_raw_ort_session(self.model_path, ["CPUExecutionProvider"])
            fixed_feed = {}
            in_types = {inp.name: inp.type for inp in self._sess.get_inputs()}
            for k, val in input_feed.items():
                expected = in_types.get(k, "")
                if "float16" in expected and val.dtype != np.float16:
                    fixed_feed[k] = val.astype(np.float16)
                elif "float" in expected and "float16" not in expected and val.dtype != np.float32:
                    fixed_feed[k] = val.astype(np.float32)
                else:
                    fixed_feed[k] = val
            return self._sess.run(output_names, fixed_feed)


def create_ort_session(model_path, sess_options, providers):
    return SafeOrtSession(model_path, sess_options=sess_options, providers=providers)


class ScrfdDetector:
    def __init__(self, model_path, providers, input_size=(640, 640)):
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.intra_op_num_threads = max(2, min(8, os.cpu_count() or 4))
        self.session = create_ort_session(model_path, so, providers)
        self.input_name = self.session.get_inputs()[0].name
        self.output_names = [o.name for o in self.session.get_outputs()]
        self.input_size = input_size
        self._anchor_cache = {}

    def _get_anchors(self, feat_h, feat_w, stride):
        key = (feat_h, feat_w, stride)
        if key in self._anchor_cache:
            return self._anchor_cache[key]
        ac = np.stack(np.mgrid[:feat_h, :feat_w][::-1], axis=-1).astype(np.float32)
        ac = (ac * stride).reshape((-1, 2))
        ac = np.stack([ac, ac], axis=1).reshape((-1, 2))
        self._anchor_cache[key] = ac
        return ac

    def detect(self, bgr_img, score_thresh=0.45, input_size=None):
        in_w, in_h = input_size or self.input_size
        h, w = bgr_img.shape[:2]
        im_ratio = float(h) / float(w)
        model_ratio = float(in_h) / float(in_w)
        if im_ratio > model_ratio:
            new_h = in_h
            new_w = max(16, int(new_h / im_ratio))
        else:
            new_w = in_w
            new_h = max(16, int(new_w * im_ratio))

        det_scale = float(new_h) / float(h)
        resized = cv2.resize(bgr_img, (new_w, new_h))
        det_canvas = np.zeros((in_h, in_w, 3), dtype=np.uint8)
        det_canvas[:new_h, :new_w, :] = resized

        blob = cv2.dnn.blobFromImage(
            det_canvas, 1.0 / 128.0, (in_w, in_h), (127.5, 127.5, 127.5), swapRB=True
        )
        net_outs = self.session.run(self.output_names, {self.input_name: blob})

        fmc = 3
        strides = [8, 16, 32]
        scores_list, bboxes_list, kpss_list = [], [], []

        for idx, stride in enumerate(strides):
            scores = net_outs[idx].reshape(-1)
            bbox_preds = net_outs[idx + fmc].reshape(-1, 4) * stride
            kps_preds = net_outs[idx + fmc * 2].reshape(-1, 10) * stride

            feat_h = in_h // stride
            feat_w = in_w // stride
            anchors = self._get_anchors(feat_h, feat_w, stride)

            pos_inds = np.where(scores >= score_thresh)[0]
            if pos_inds.size == 0:
                continue

            pos_scores = scores[pos_inds]
            pos_bbox_preds = bbox_preds[pos_inds]
            pos_anchors = anchors[pos_inds]

            x1 = pos_anchors[:, 0] - pos_bbox_preds[:, 0]
            y1 = pos_anchors[:, 1] - pos_bbox_preds[:, 1]
            x2 = pos_anchors[:, 0] + pos_bbox_preds[:, 2]
            y2 = pos_anchors[:, 1] + pos_bbox_preds[:, 3]
            bboxes = np.stack([x1, y1, x2, y2], axis=-1)

            pos_kps_preds = kps_preds[pos_inds]
            kpss = np.zeros((pos_inds.size, 5, 2), dtype=np.float32)
            for k in range(5):
                kpss[:, k, 0] = pos_anchors[:, 0] + pos_kps_preds[:, k * 2]
                kpss[:, k, 1] = pos_anchors[:, 1] + pos_kps_preds[:, k * 2 + 1]

            scores_list.append(pos_scores)
            bboxes_list.append(bboxes)
            kpss_list.append(kpss)

        if not scores_list:
            return []

        scores_all = np.concatenate(scores_list, axis=0)
        bboxes_all = np.concatenate(bboxes_list, axis=0) / det_scale
        kpss_all = np.concatenate(kpss_list, axis=0) / det_scale

        pre_det = np.hstack((bboxes_all, scores_all[:, None])).astype(np.float32)
        keep = nms_boxes(pre_det, 0.4)
        faces = []
        for idx in keep:
            box = pre_det[idx, :4]
            score = float(pre_det[idx, 4])
            kps = kpss_all[idx]
            area = max(1.0, float((box[2] - box[0]) * (box[3] - box[1])))
            faces.append({"bbox": box, "score": score, "kps": kps, "area": area})
        return faces


def select_primary_face(faces, img_w, img_h, prev_center=None):
    if not faces:
        return None
    cx_img, cy_img = img_w * 0.5, img_h * 0.42
    best_face = None
    best_score = -1e18
    for f in faces:
        b = f["bbox"]
        fcx = 0.5 * (b[0] + b[2])
        fcy = 0.5 * (b[1] + b[3])
        if prev_center is not None:
            dist = np.hypot(fcx - prev_center[0], fcy - prev_center[1])
            diag = np.hypot(img_w, img_h)
            track_bonus = max(0.2, 1.0 - (dist / max(1.0, diag * 0.35)))
            score = f["area"] * track_bonus * (0.7 + 0.3 * f["score"])
        else:
            dist_center = np.hypot(fcx - cx_img, fcy - cy_img) / max(1.0, np.hypot(img_w, img_h))
            center_weight = max(0.55, 1.0 - 0.45 * dist_center)
            score = f["area"] * center_weight * f["score"]
        if score > best_score:
            best_score = score
            best_face = f
    return best_face


def load_emap_matrix(inswapper_path, cache_npy_path):
    if os.path.exists(cache_npy_path) and os.path.getsize(cache_npy_path) > 1024:
        try:
            mat = np.load(cache_npy_path)
            if mat.shape == (512, 512):
                return mat.astype(np.float32)
        except Exception:
            pass

    model = onnx.load(inswapper_path)
    emap = None
    for init in reversed(model.graph.initializer):
        arr = numpy_helper.to_array(init)
        if arr.shape == (512, 512):
            emap = arr.astype(np.float32)
            break
    if emap is None:
        emap = numpy_helper.to_array(model.graph.initializer[-1]).astype(np.float32)
    del model
    try:
        np.save(cache_npy_path, emap)
    except Exception:
        pass
    return emap


def extract_arcface_latent(arcface_sess, bgr_img, kps, emap):
    M = umeyama_2d(kps, ARCFACE_DST_112, True)
    aligned_112 = cv2.warpAffine(bgr_img, M, (112, 112), borderValue=0.0)
    blob = cv2.dnn.blobFromImage(
        aligned_112, 1.0 / 127.5, (112, 112), (127.5, 127.5, 127.5), swapRB=True
    )
    in_Info = arcface_sess.get_inputs()[0]
    if "float16" in in_Info.type:
        blob = blob.astype(np.float16)
    emb = arcface_sess.run(None, {in_Info.name: blob})[0].astype(np.float32).reshape(1, -1)
    normed = emb / (np.linalg.norm(emb) + 1e-8)
    latent = normed @ emap
    latent = latent / (np.linalg.norm(latent) + 1e-8)
    return latent.astype(np.float32)


def build_soft_face_mask_128():
    """Creates a smooth elliptical inner-face mask on 128x128 that preserves hairlines, ears & collars."""
    mask = np.zeros((128, 128), dtype=np.float32)
    # Center slightly below eyes/nose bridge, covering eyebrows, eyes, nose, cheeks, lips & chin cleanly
    cv2.ellipse(mask, (64, 69), (45, 52), 0, 0, 360, 1.0, -1)
    mask = cv2.GaussianBlur(mask, (23, 23), 8.0)
    return np.clip(mask, 0.0, 1.0)[:, :, None]


def build_soft_face_mask_512():
    mask = np.zeros((512, 512), dtype=np.float32)
    cv2.ellipse(mask, (256, 276), (178, 206), 0, 0, 360, 1.0, -1)
    mask = cv2.GaussianBlur(mask, (65, 65), 22.0)
    return np.clip(mask, 0.0, 1.0)[:, :, None]


def match_lab_lighting(swapped_bgr, target_bgr, mask_2d, strength=0.42):
    """Subtly matches scene illumination & color cast from target frame onto swapped face without losing source skin tone."""
    sw_lab = cv2.cvtColor(swapped_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    tg_lab = cv2.cvtColor(target_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)

    valid = mask_2d[:, :, 0] > 0.35
    if np.count_nonzero(valid) < 64:
        return swapped_bgr

    out_lab = sw_lab.copy()
    for ch in range(3):
        s_vals = sw_lab[:, :, ch][valid]
        t_vals = tg_lab[:, :, ch][valid]
        s_mean, s_std = float(s_vals.mean()), float(s_vals.std()) + 1e-5
        t_mean, t_std = float(t_vals.mean()), float(t_vals.std()) + 1e-5
        # Luminance (ch 0) adapts slightly more to studio/outdoor shadows than chrominance (ch 1,2)
        ch_strength = strength if ch == 0 else strength * 0.55
        adjusted = (sw_lab[:, :, ch] - s_mean) * (t_std / s_std) + t_mean
        out_lab[:, :, ch] = (1.0 - ch_strength) * sw_lab[:, :, ch] + ch_strength * adjusted

    out_lab = np.clip(out_lab, 0, 255).astype(np.uint8)
    return cv2.cvtColor(out_lab, cv2.COLOR_LAB2BGR)


def run_gfpgan_512(gfp_sess, bgr_512):
    rgb = cv2.cvtColor(bgr_512, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    norm = (rgb - 0.5) / 0.5
    tensor = np.transpose(norm, (2, 0, 1))[None, :, :, :].astype(np.float32)
    in_info = gfp_sess.get_inputs()[0]
    if "float16" in in_info.type:
        tensor = tensor.astype(np.float16)
    out = gfp_sess.run(None, {in_info.name: tensor})[0][0].astype(np.float32)
    out = np.clip((np.transpose(out, (1, 2, 0)) + 1.0) * 0.5, 0.0, 1.0) * 255.0
    return cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_RGB2BGR)


def _has_discrete_gpu_windows():
    if os.name != "nt":
        return False
    try:
        import winreg
        cls_key = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, cls_key) as root:
            idx = 0
            while True:
                try:
                    sub_name = winreg.EnumKey(root, idx)
                    idx += 1
                    if not sub_name.isdigit():
                        continue
                    with winreg.OpenKey(root, sub_name) as sub:
                        desc, _ = winreg.QueryValueEx(sub, "DriverDesc")
                        d = str(desc or "").lower()
                        if any(
                            kw in d
                            for kw in (
                                "nvidia",
                                "geforce",
                                "rtx",
                                "gtx",
                                "quadro",
                                "radeon rx",
                                "radeon pro",
                                "intel(r) arc",
                            )
                        ):
                            return True
                except OSError:
                    break
    except Exception:
        pass
    return False


def pick_best_providers():
    avail = ort.get_available_providers()
    if "CUDAExecutionProvider" in avail:
        return ["CUDAExecutionProvider", "CPUExecutionProvider"]
    if "DmlExecutionProvider" in avail and _has_discrete_gpu_windows():
        return ["DmlExecutionProvider", "CPUExecutionProvider"]
    return ["CPUExecutionProvider"]


def mode_crop_face(args):
    providers = ["CPUExecutionProvider"]
    det = ScrfdDetector(args.det_model, providers, input_size=(640, 640))
    img = imread_unicode(args.source)
    if img is None:
        raise RuntimeError(f"Cannot read source image: {args.source}")
    h, w = img.shape[:2]
    faces = det.detect(img, score_thresh=0.35, input_size=(640, 640))
    primary = select_primary_face(faces, w, h)
    if primary is None:
        emit_json({"ok": False, "reason": "no_face_detected"})
        return

    b = primary["bbox"]
    fw = max(16.0, float(b[2] - b[0]))
    fh = max(16.0, float(b[3] - b[1]))
    cx = 0.5 * float(b[0] + b[2])
    cy = float(b[1]) + fh * 0.46
    side = int(round(max(fw, fh) * 2.25))
    side = max(128, min(min(w, h), side))
    x1 = int(round(max(0, min(w - side, cx - side * 0.5))))
    y1 = int(round(max(0, min(h - side, cy - side * 0.5))))

    crop = img[y1 : y1 + side, x1 : x1 + side]
    upscaled = cv2.resize(crop, (768, 768), interpolation=cv2.INTER_LANCZOS4)
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    imwrite_unicode(args.output, upscaled)
    emit_json(
        {
            "ok": True,
            "output": args.output,
            "faceRatioH": round(fh / float(h), 4),
            "bbox": [round(float(v), 1) for v in b],
        }
    )


def mode_lock_video(args):
    providers = pick_best_providers()
    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.intra_op_num_threads = max(2, min(8, os.cpu_count() or 4))

    emit_json({"stage": "loading_models", "providers": providers, "progress": 2})

    det = ScrfdDetector(args.det_model, providers, input_size=(640, 640))
    arc_sess = create_ort_session(args.arc_model, so, providers)
    swap_sess = create_ort_session(args.swap_model, so, providers)

    gfp_sess = None
    if args.enhance and args.gfp_model and os.path.exists(args.gfp_model):
        try:
            gfp_sess = create_ort_session(args.gfp_model, so, providers)
        except Exception:
            gfp_sess = None

    emap_cache = os.path.join(os.path.dirname(args.swap_model), "inswapper_emap.npy")
    emap = load_emap_matrix(args.swap_model, emap_cache)

    src_img = imread_unicode(args.source)
    if src_img is None:
        raise RuntimeError("Không thể đọc Ảnh Khuôn Mặt Gốc (Source Face).")

    sh, sw = src_img.shape[:2]
    src_faces = det.detect(src_img, score_thresh=0.32, input_size=(640, 640))
    src_primary = select_primary_face(src_faces, sw, sh)
    if src_primary is None:
        raise RuntimeError("Không tìm thấy khuôn mặt rõ ràng trong Ảnh Tham Chiếu Gốc.")

    source_latent = extract_arcface_latent(arc_sess, src_img, src_primary["kps"], emap)

    swap_inputs = swap_sess.get_inputs()
    target_in_name = swap_inputs[0].name
    source_in_name = swap_inputs[1].name
    swap_fp16 = "float16" in swap_inputs[0].type
    source_feed = source_latent.astype(np.float16) if "float16" in swap_inputs[1].type else source_latent

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    has_non_ascii_in = any(ord(ch) > 127 for ch in os.path.abspath(args.target))
    has_non_ascii_out = any(ord(ch) > 127 for ch in os.path.abspath(args.output))

    ascii_tmp_dir = None
    safe_target_video = args.target
    safe_output_video = args.output
    if has_non_ascii_in or has_non_ascii_out:
        ascii_tmp_dir = tempfile.mkdtemp(prefix="mfs_fl_")
        if has_non_ascii_in:
            safe_target_video = os.path.join(ascii_tmp_dir, "in_vid.mp4")
            shutil.copy2(args.target, safe_target_video)
        if has_non_ascii_out:
            safe_output_video = os.path.join(ascii_tmp_dir, "out_vid.mp4")

    cap = cv2.VideoCapture(safe_target_video)
    if not cap.isOpened():
        if ascii_tmp_dir:
            shutil.rmtree(ascii_tmp_dir, ignore_errors=True)
        raise RuntimeError(f"Không thể mở video đầu vào: {args.target}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 1.0 or fps > 120.0:
        fps = 30.0
    vid_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 720
    vid_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 1280
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(safe_output_video, fourcc, fps, (vid_w, vid_h))
    if not writer.isOpened():
        cap.release()
        if ascii_tmp_dir:
            shutil.rmtree(ascii_tmp_dir, ignore_errors=True)
        raise RuntimeError("Không thể khởi tạo file ghi video tạm thời.")

    mask_128 = build_soft_face_mask_128()
    M_128_to_512 = umeyama_2d(INSWAPPER_DST_128, FFHQ_DST_512, True)
    mask_128_on_512 = cv2.warpAffine(
        mask_128[:, :, 0],
        M_128_to_512,
        (512, 512),
        flags=cv2.INTER_LINEAR,
        borderValue=0.0,
    )[:, :, None]

    using_gpu = providers[0] != "CPUExecutionProvider"
    gfp_stride = 1 if using_gpu else 4
    cached_gfp_delta = None
    cached_key_comp = None
    last_gfp_frame = -999

    # Use 384x384 fast SCRFD detection on video frames (nearly 3x faster, still ultra-accurate)
    det_vid_size = (384, 384)
    prev_kps = None
    prev_center = None
    frame_idx = 0
    swapped_count = 0
    last_report_ts = 0.0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame_idx += 1

            faces = det.detect(frame, score_thresh=0.40, input_size=det_vid_size)
            target_face = select_primary_face(faces, vid_w, vid_h, prev_center=prev_center)

            if target_face is not None:
                raw_kps = target_face["kps"]
                b = target_face["bbox"]
                cur_center = (0.5 * float(b[0] + b[2]), 0.5 * float(b[1] + b[3]))
                face_size_px = max(float(b[2] - b[0]), float(b[3] - b[1]))
                mean_shift = 0.0

                # Temporal EMA anti-jitter smoothing when motion between adjacent frames is subtle
                if prev_kps is not None:
                    mean_shift = float(np.linalg.norm(raw_kps - prev_kps, axis=1).mean())
                    if mean_shift < face_size_px * 0.06:
                        smooth_kps = 0.68 * raw_kps + 0.32 * prev_kps
                    elif mean_shift < face_size_px * 0.14:
                        smooth_kps = 0.85 * raw_kps + 0.15 * prev_kps
                    else:
                        smooth_kps = raw_kps
                else:
                    smooth_kps = raw_kps

                prev_kps = smooth_kps
                prev_center = cur_center

                M_128 = umeyama_2d(smooth_kps, INSWAPPER_DST_128, True)
                crop_128 = cv2.warpAffine(
                    frame, M_128, (128, 128), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE
                )

                target_blob = cv2.dnn.blobFromImage(
                    crop_128, 1.0 / 255.0, (128, 128), (0.0, 0.0, 0.0), swapRB=True
                )
                if swap_fp16:
                    target_blob = target_blob.astype(np.float16)

                pred = swap_sess.run(
                    None, {target_in_name: target_blob, source_in_name: source_feed}
                )[0][0].astype(np.float32)
                swapped_rgb = np.clip(np.transpose(pred, (1, 2, 0)), 0.0, 1.0) * 255.0
                swapped_bgr_128 = cv2.cvtColor(swapped_rgb.astype(np.uint8), cv2.COLOR_RGB2BGR)

                # Harmonize lighting & shadows with Muse video frame while preserving identity skin tone
                swapped_bgr_128 = match_lab_lighting(swapped_bgr_128, crop_128, mask_128, strength=0.40)

                if gfp_sess is not None:
                    # Warp frame to 512, paste swapped 128 upscaled onto inner face, run GFPGAN 512 HD restoration
                    M_512 = umeyama_2d(smooth_kps, FFHQ_DST_512, True)
                    crop_512_orig = cv2.warpAffine(
                        frame, M_512, (512, 512), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE
                    )
                    swapped_on_512 = cv2.warpAffine(
                        swapped_bgr_128,
                        M_128_to_512,
                        (512, 512),
                        flags=cv2.INTER_CUBIC,
                        borderMode=cv2.BORDER_REPLICATE,
                    )

                    comp_f32 = (
                        swapped_on_512.astype(np.float32) * mask_128_on_512
                        + crop_512_orig.astype(np.float32) * (1.0 - mask_128_on_512)
                    )
                    composite_512 = comp_f32.astype(np.uint8)

                    need_full_gfp = (
                        cached_gfp_delta is None
                        or (frame_idx - last_gfp_frame) >= gfp_stride
                        or mean_shift > face_size_px * 0.05
                    )
                    if need_full_gfp:
                        restored_512 = run_gfpgan_512(gfp_sess, composite_512)
                        cached_gfp_delta = (restored_512.astype(np.float32) - comp_f32) * 0.70
                        cached_key_comp = comp_f32
                        last_gfp_frame = frame_idx
                        final_512 = np.clip(comp_f32 + cached_gfp_delta, 0.0, 255.0).astype(np.uint8)
                    else:
                        # Motion-gated canonical residual transfer: 100% HD pores/eyes + zero lip-sync ghosting
                        diff_map = np.abs(comp_f32 - cached_key_comp).mean(axis=2, keepdims=True)
                        motion_gate = np.clip(1.0 - (diff_map / 24.0), 0.0, 1.0)
                        final_512 = np.clip(comp_f32 + cached_gfp_delta * motion_gate, 0.0, 255.0).astype(
                            np.uint8
                        )

                    inv_frame = cv2.warpAffine(
                        final_512,
                        M_512,
                        (vid_w, vid_h),
                        flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                        borderMode=cv2.BORDER_CONSTANT,
                        borderValue=(0, 0, 0),
                    )
                    inv_mask = cv2.warpAffine(
                        mask_128_on_512[:, :, 0],
                        M_512,
                        (vid_w, vid_h),
                        flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                        borderValue=0.0,
                    )[:, :, None]
                    frame = (
                        inv_frame.astype(np.float32) * inv_mask
                        + frame.astype(np.float32) * (1.0 - inv_mask)
                    ).astype(np.uint8)
                else:
                    # Fast standard mode: crisp Lanczos + unsharp detail boost on 256x256 before inverse warp
                    up_256 = cv2.resize(swapped_bgr_128, (256, 256), interpolation=cv2.INTER_LANCZOS4)
                    blur_256 = cv2.GaussianBlur(up_256, (0, 0), 1.4)
                    sharp_256 = cv2.addWeighted(up_256, 1.32, blur_256, -0.32, 0)
                    M_256 = M_128.copy()
                    M_256 *= 2.0
                    mask_256 = cv2.resize(mask_128[:, :, 0], (256, 256), interpolation=cv2.INTER_LINEAR)

                    inv_frame = cv2.warpAffine(
                        sharp_256,
                        M_256,
                        (vid_w, vid_h),
                        flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                        borderMode=cv2.BORDER_CONSTANT,
                        borderValue=(0, 0, 0),
                    )
                    inv_mask = cv2.warpAffine(
                        mask_256,
                        M_256,
                        (vid_w, vid_h),
                        flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                        borderValue=0.0,
                    )[:, :, None]
                    frame = (
                        inv_frame.astype(np.float32) * inv_mask
                        + frame.astype(np.float32) * (1.0 - inv_mask)
                    ).astype(np.uint8)

                swapped_count += 1
            else:
                prev_kps = None

            writer.write(frame)

            now = time.time()
            if total_frames > 0 and (now - last_report_ts >= 0.45 or frame_idx == total_frames):
                last_report_ts = now
                pct = min(98, max(5, int(round((frame_idx / float(total_frames)) * 92)) + 5))
                emit_json(
                    {
                        "stage": "processing",
                        "frame": frame_idx,
                        "total": total_frames,
                        "swapped": swapped_count,
                        "progress": pct,
                    }
                )
    finally:
        cap.release()
        writer.release()

    try:
        if safe_output_video != args.output and os.path.exists(safe_output_video):
            shutil.copy2(safe_output_video, args.output)
    finally:
        if ascii_tmp_dir:
            shutil.rmtree(ascii_tmp_dir, ignore_errors=True)

    emit_json(
        {
            "ok": True,
            "stage": "done",
            "frames": frame_idx,
            "swapped": swapped_count,
            "progress": 100,
        }
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=["crop-face", "lock-video"])
    parser.add_argument("--source", required=True)
    parser.add_argument("--target", default="")
    parser.add_argument("--output", required=True)
    parser.add_argument("--det-model", required=True)
    parser.add_argument("--arc-model", default="")
    parser.add_argument("--swap-model", default="")
    parser.add_argument("--gfp-model", default="")
    parser.add_argument("--enhance", type=int, default=1)
    args = parser.parse_args()

    try:
        if args.mode == "crop-face":
            mode_crop_face(args)
        else:
            mode_lock_video(args)
    except Exception as exc:
        emit_json({"ok": False, "error": str(exc)})
        sys.exit(1)


if __name__ == "__main__":
    main()
