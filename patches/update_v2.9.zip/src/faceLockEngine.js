const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');
const {
  getFfmpegExecutable,
  runFfmpeg,
  probeMediaFile,
  cropCloseUpPortraitPng,
  ensureUniversalPlayableMp4
} = require('./videoEditor');

const PYTHON_EMBED_URLS = [
  'https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip'
];

const GET_PIP_URLS = [
  'https://bootstrap.pypa.io/get-pip.py'
];

const REQUIRED_MODELS = [
  {
    fileName: 'det_10g.onnx',
    label: 'SCRFD Face Detector (det_10g)',
    minBytes: 15 * 1024 * 1024,
    urls: [
      'https://github.com/facefusion/facefusion-assets/releases/download/models-3.0.0/retinaface_10g.onnx',
      'https://huggingface.co/ApacheOne/insightface/resolve/main/insightface/models/buffalo_l/det_10g.onnx'
    ]
  },
  {
    fileName: 'w600k_r50.onnx',
    label: 'ArcFace 512D Biometric ID (w600k_r50)',
    minBytes: 160 * 1024 * 1024,
    urls: [
      'https://github.com/facefusion/facefusion-assets/releases/download/models-3.0.0/arcface_w600k_r50.onnx',
      'https://huggingface.co/ApacheOne/insightface/resolve/main/insightface/models/buffalo_l/w600k_r50.onnx'
    ]
  },
  {
    fileName: 'inswapper_128_fp16.onnx',
    label: 'INSwapper Biometric Face-Lock (FP16)',
    minBytes: 250 * 1024 * 1024,
    urls: [
      'https://github.com/facefusion/facefusion-assets/releases/download/models-3.0.0/inswapper_128_fp16.onnx',
      'https://huggingface.co/hacksider/deep-live-cam/resolve/main/inswapper_128_fp16.onnx'
    ]
  },
  {
    fileName: 'gfpgan_1.4.onnx',
    label: 'GFPGAN 512px HD Skin & Eye Enhancer',
    minBytes: 310 * 1024 * 1024,
    urls: [
      'https://github.com/facefusion/facefusion-assets/releases/download/models-3.0.0/gfpgan_1.4.onnx',
      'https://huggingface.co/hacksider/deep-live-cam/resolve/main/GFPGANv1.4.onnx'
    ]
  }
];

function downloadFileWithRedirects(url, destPath, onProgress = null, redirectDepth = 0) {
  return new Promise((resolve, reject) => {
    if (redirectDepth > 8) {
      return reject(new Error('Quá nhiều lần chuyển hướng HTTP khi tải gói AI.'));
    }
    const client = url.startsWith('https') ? https : http;
    const req = client.get(
      url,
      {
        headers: {
          'User-Agent': 'MuseFlowStudio-FaceLockInstaller/2.9'
        },
        timeout: 60000
      },
      (res) => {
        const code = res.statusCode || 0;
        if ([301, 302, 303, 307, 308].includes(code) && res.headers.location) {
          res.resume();
          const nextUrl = new URL(res.headers.location, url).toString();
          return resolve(downloadFileWithRedirects(nextUrl, destPath, onProgress, redirectDepth + 1));
        }
        if (code !== 200) {
          res.resume();
          return reject(new Error(`Máy chủ trả về mã HTTP ${code} khi tải ${path.basename(destPath)}.`));
        }

        const totalBytes = Number(res.headers['content-length'] || 0);
        let downloaded = 0;
        let lastEmit = 0;

        const partPath = `${destPath}.part_${Date.now()}`;
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        const fileStream = fs.createWriteStream(partPath);

        res.on('data', (chunk) => {
          downloaded += chunk.length;
          const now = Date.now();
          if (typeof onProgress === 'function' && (now - lastEmit >= 250 || (totalBytes && downloaded >= totalBytes))) {
            lastEmit = now;
            onProgress(downloaded, totalBytes);
          }
        });

        fileStream.on('finish', () => {
          fileStream.close(() => {
            try {
              if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
              fs.renameSync(partPath, destPath);
              resolve(destPath);
            } catch (err) {
              reject(err);
            }
          });
        });

        const cleanupErr = (err) => {
          try {
            fileStream.destroy();
          } catch (_) {}
          try {
            if (fs.existsSync(partPath)) fs.unlinkSync(partPath);
          } catch (_) {}
          reject(err);
        };

        res.on('error', cleanupErr);
        fileStream.on('error', cleanupErr);
        res.pipe(fileStream);
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('Quá thời gian chờ mạng khi tải mô hình AI.'));
    });
    req.on('error', (err) => reject(err));
  });
}

async function downloadFromMirrorList(urls, destPath, minBytes, onProgress) {
  let lastErr = null;
  for (const url of urls) {
    try {
      await downloadFileWithRedirects(url, destPath, onProgress);
      if (fs.existsSync(destPath) && fs.statSync(destPath).size >= minBytes) {
        return destPath;
      }
      throw new Error('Dung lượng file tải về chưa đầy đủ.');
    } catch (err) {
      lastErr = err;
      try {
        if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
      } catch (_) {}
    }
  }
  throw lastErr || new Error(`Không thể tải ${path.basename(destPath)}.`);
}

class FaceLockEngine extends EventEmitter {
  constructor(appRootDir) {
    super();
    this.appRootDir = appRootDir;
    this.runtimeRoot = path.join(appRootDir, 'runtime', 'face_lock');
    this.pythonDir = path.join(this.runtimeRoot, 'python');
    this.pythonExe = path.join(this.pythonDir, 'python.exe');
    this.modelsDir = path.join(this.runtimeRoot, 'models');
    this.readyFlagPath = path.join(this.runtimeRoot, 'ready_flag.json');
    this.workerScriptPath = path.join(appRootDir, 'src', 'face_lock_worker.py');
    this.anchorCacheDir = path.join(appRootDir, 'Project_Data', 'temp_editor', '_face_anchors');

    this.installing = false;
    this.installProgress = 0;
    this.installMessage = '';
    this.installError = null;
    this.installPromise = null;

    this._jobChain = Promise.resolve();
    this._queuedCount = 0;
  }

  _areModelsPresent() {
    for (const m of REQUIRED_MODELS) {
      const fp = path.join(this.modelsDir, m.fileName);
      if (!fs.existsSync(fp)) return false;
      try {
        if (fs.statSync(fp).size < m.minBytes) return false;
      } catch (_) {
        return false;
      }
    }
    return true;
  }

  isInstalled() {
    return (
      fs.existsSync(this.pythonExe) &&
      fs.existsSync(this.readyFlagPath) &&
      fs.existsSync(this.workerScriptPath) &&
      this._areModelsPresent()
    );
  }

  getStatus() {
    const installed = this.isInstalled();
    return {
      installed,
      installing: this.installing,
      installProgress: installed ? 100 : this.installProgress,
      installMessage: installed
        ? '✅ Lõi AI Khóa Mặt Sinh Trắc Học 100% (ONNX + GFPGAN HD) đã sẵn sàng!'
        : this.installMessage || 'Chưa tải gói Lõi AI Hậu kỳ (~780MB • Cài tự động 1 lần)',
      installError: this.installError,
      queuedJobs: this._queuedCount
    };
  }

  _reportInstall(progress, message, extra = {}) {
    this.installProgress = Math.max(0, Math.min(100, Math.round(progress)));
    this.installMessage = message;
    const payload = {
      ...this.getStatus(),
      ...extra
    };
    this.emit('install_progress', payload);
  }

  _runProcess(exe, args, opts = {}) {
    return new Promise((resolve, reject) => {
      const { onStdoutLine, env: customEnv, ...spawnOpts } = opts;
      const proc = spawn(exe, args, {
        windowsHide: true,
        ...spawnOpts,
        env: {
          ...process.env,
          PYTHONIOENCODING: 'utf-8',
          PYTHONUTF8: '1',
          PYTHONDONTWRITEBYTECODE: '1',
          ...(customEnv || {})
        }
      });
      let stdout = '';
      let stderr = '';
      proc.stdout?.on('data', (d) => {
        const s = d.toString('utf8');
        stdout += s;
        if (typeof onStdoutLine === 'function') {
          s.split(/\r?\n/).filter(Boolean).forEach((line) => onStdoutLine(line));
        }
      });
      proc.stderr?.on('data', (d) => {
        stderr += d.toString('utf8');
      });
      proc.on('error', (err) => reject(err));
      proc.on('close', (code) => {
        if (code === 0) {
          resolve({ stdout, stderr });
        } else {
          const tail = (stderr || stdout).split(/\r?\n/).filter(Boolean).slice(-8).join(' | ');
          reject(new Error(tail || `Tiến trình thoát với mã lỗi ${code}`));
        }
      });
    });
  }

  async installRuntime() {
    if (this.isInstalled()) {
      return this.getStatus();
    }
    if (this.installPromise) {
      return this.installPromise;
    }

    this.installing = true;
    this.installError = null;
    this._reportInstall(1, 'Đang khởi tạo thư mục Lõi AI Khóa Mặt 100%...');

    this.installPromise = (async () => {
      try {
        fs.mkdirSync(this.pythonDir, { recursive: true });
        fs.mkdirSync(this.modelsDir, { recursive: true });

        // Bước 1: Cài đặt Portable Python 3.11.9 độc lập (không đụng hệ thống Windows của khách)
        if (!fs.existsSync(this.pythonExe)) {
          this._reportInstall(3, 'Đang tải bộ chạy Python 3.11 Portable (11 MB)...');
          const pyZip = path.join(this.runtimeRoot, 'python_embed.zip');
          await downloadFromMirrorList(PYTHON_EMBED_URLS, pyZip, 8 * 1024 * 1024, (done, total) => {
            if (total > 0) {
              const pct = 3 + (done / total) * 6;
              this._reportInstall(pct, `Đang tải Python Portable: ${(done / 1048576).toFixed(1)} / ${(total / 1048576).toFixed(1)} MB...`);
            }
          });

          this._reportInstall(10, 'Đang giải nén môi trường Python Portable...');
          execFileSync(
            'powershell.exe',
            [
              '-NoProfile',
              '-NonInteractive',
              '-ExecutionPolicy',
              'Bypass',
              '-Command',
              'Expand-Archive -LiteralPath $env:MFS_PY_ZIP -DestinationPath $env:MFS_PY_DIR -Force'
            ],
            {
              env: { ...process.env, MFS_PY_ZIP: pyZip, MFS_PY_DIR: this.pythonDir },
              windowsHide: true,
              timeout: 60000
            }
          );
          try {
            fs.unlinkSync(pyZip);
          } catch (_) {}
        }

        // Bật site-packages trong python311._pth
        const pthFile = path.join(this.pythonDir, 'python311._pth');
        if (fs.existsSync(pthFile)) {
          let pthContent = fs.readFileSync(pthFile, 'utf8');
          pthContent = pthContent.replace(/^#\s*import\s+site/m, 'import site');
          if (!/^\s*import\s+site/m.test(pthContent)) {
            pthContent += '\nimport site\n';
          }
          fs.writeFileSync(pthFile, pthContent, 'utf8');
        }

        // Bước 2: Cài đặt pip nếu chưa có
        const pipExe = path.join(this.pythonDir, 'Scripts', 'pip.exe');
        if (!fs.existsSync(pipExe)) {
          this._reportInstall(13, 'Đang cấu hình trình quản lý thư viện pip...');
          const getPipPath = path.join(this.runtimeRoot, 'get-pip.py');
          await downloadFromMirrorList(GET_PIP_URLS, getPipPath, 1024 * 1024);
          await this._runProcess(this.pythonExe, [getPipPath, '--no-warn-script-location'], {
            cwd: this.pythonDir
          });
          try {
            fs.unlinkSync(getPipPath);
          } catch (_) {}
        }

        // Bước 3: Cài đặt thư viện ONNX Runtime (hỗ trợ DirectML GPU + CPU đa nhân) + OpenCV
        this._reportInstall(18, 'Đang cài đặt thư viện ONNX Runtime DirectML & OpenCV...');
        try {
          await this._runProcess(
            this.pythonExe,
            [
              '-m',
              'pip',
              'install',
              '--no-warn-script-location',
              '--upgrade',
              'numpy<2',
              'opencv-python-headless',
              'onnx',
              'onnxruntime-directml'
            ],
            { cwd: this.pythonDir }
          );
        } catch (_) {
          // Fallback về onnxruntime CPU thuần nếu máy Windows cũ không tương thích gói DirectML
          await this._runProcess(
            this.pythonExe,
            [
              '-m',
              'pip',
              'install',
              '--no-warn-script-location',
              '--upgrade',
              'numpy<2',
              'opencv-python-headless',
              'onnx',
              'onnxruntime'
            ],
            { cwd: this.pythonDir }
          );
        }

        // Bước 4: Tải 4 mô hình AI Sinh Trắc Học Khuôn Mặt & Phục Hồi Da HD
        const basePct = 32;
        const spanPct = 64;
        const totalExpectedBytes = REQUIRED_MODELS.reduce((s, m) => s + m.minBytes, 0);
        let completedModelBytes = 0;

        for (let i = 0; i < REQUIRED_MODELS.length; i++) {
          const m = REQUIRED_MODELS[i];
          const destModelPath = path.join(this.modelsDir, m.fileName);
          if (fs.existsSync(destModelPath) && fs.statSync(destModelPath).size >= m.minBytes) {
            completedModelBytes += m.minBytes;
            const pctDone = basePct + (completedModelBytes / totalExpectedBytes) * spanPct;
            this._reportInstall(pctDone, `Đã có sẵn mô hình ${i + 1}/${REQUIRED_MODELS.length}: ${m.label}`);
            continue;
          }

          await downloadFromMirrorList(m.urls, destModelPath, m.minBytes, (done, total) => {
            const estTotal = total > 0 ? total : m.minBytes;
            const frac = Math.min(1, done / estTotal);
            const overallBytes = completedModelBytes + frac * m.minBytes;
            const pct = basePct + (overallBytes / totalExpectedBytes) * spanPct;
            this._reportInstall(
              pct,
              `Đang tải mô hình (${i + 1}/${REQUIRED_MODELS.length}) ${m.label}: ${(done / 1048576).toFixed(0)}/${(
                estTotal / 1048576
              ).toFixed(0)} MB...`
            );
          });
          completedModelBytes += m.minBytes;
        }

        // Bước 5: Kiểm tra khởi chạy thử nghiệm Python + ONNX Runtime + trích sẵn ma trận emap
        this._reportInstall(97, 'Đang kiểm tra & tối ưu bộ nhớ đệm sinh trắc học...');
        await this._runProcess(
          this.pythonExe,
          [
            '-c',
            [
              'import os, numpy as np, cv2, onnx, onnxruntime as ort;',
              'from onnx import numpy_helper;',
              'p = os.environ["MFS_SWAP_ONNX"];',
              'c = os.environ["MFS_EMAP_NPY"];',
              'm = onnx.load(p);',
              'emap = None;',
              'for init in reversed(m.graph.initializer):',
              '    arr = numpy_helper.to_array(init)',
              '    if arr.shape == (512, 512): emap = arr.astype(np.float32); break',
              'if emap is None: emap = numpy_helper.to_array(m.graph.initializer[-1]).astype(np.float32)',
              'np.save(c, emap);',
              'print("FACELOCK_READY_OK", ort.get_available_providers())'
            ].join('\n')
          ],
          {
            cwd: this.pythonDir,
            env: {
              MFS_SWAP_ONNX: path.join(this.modelsDir, 'inswapper_128_fp16.onnx'),
              MFS_EMAP_NPY: path.join(this.modelsDir, 'inswapper_emap.npy')
            }
          }
        );

        fs.writeFileSync(
          this.readyFlagPath,
          JSON.stringify(
            {
              installedAt: new Date().toISOString(),
              version: '2.9',
              models: REQUIRED_MODELS.map((m) => m.fileName)
            },
            null,
            2
          ),
          'utf8'
        );

        this.installing = false;
        this._reportInstall(100, '✅ Đã cài đặt thành công Lõi AI Khóa Mặt Sinh Trắc Học 100%!');
        return this.getStatus();
      } catch (err) {
        this.installing = false;
        this.installError = err.message;
        this._reportInstall(0, `⚠️ Lỗi cài đặt Lõi AI: ${err.message}`);
        throw err;
      } finally {
        this.installPromise = null;
      }
    })();

    return this.installPromise;
  }

  /**
   * PHƯƠNG ÁN 1: Tạo ảnh Cận Mặt Độ Phân Giải Cao (768x768 PNG không nén) từ ảnh tham chiếu gốc
   * để đính kèm song song làm Mỏ neo sinh trắc học khuôn mặt trên Muse.ai!
   * Hoạt động mượt 100% kể cả khi khách chưa cài gói AI 780MB (tự dùng SCRFD nếu có, hoặc Chrome FaceDetector / Smart Lanczos Crop).
   */
  async prepareCloseUpFaceAnchorPng(sourceImagePath, musePageOptional = null) {
    if (!sourceImagePath || !fs.existsSync(sourceImagePath)) return null;
    const stat = fs.statSync(sourceImagePath);
    const cacheHash = crypto
      .createHash('sha1')
      .update(`${sourceImagePath}::${stat.size}::${stat.mtimeMs}`)
      .digest('hex')
      .slice(0, 14);

    fs.mkdirSync(this.anchorCacheDir, { recursive: true });
    const cachedPng = path.join(this.anchorCacheDir, `FaceAnchor_${cacheHash}.png`);
    if (fs.existsSync(cachedPng) && fs.statSync(cachedPng).size > 2000) {
      return cachedPng;
    }

    // Ưu tiên 1: Nếu trên máy đã có det_10g.onnx + Python -> dò chính xác 100% tọa độ 5 điểm mốc khuôn mặt
    const detModelPath = path.join(this.modelsDir, 'det_10g.onnx');
    if (fs.existsSync(this.pythonExe) && fs.existsSync(detModelPath) && fs.existsSync(this.workerScriptPath)) {
      try {
        let lastJson = null;
        await this._runProcess(
          this.pythonExe,
          [
            this.workerScriptPath,
            '--mode',
            'crop-face',
            '--source',
            sourceImagePath,
            '--output',
            cachedPng,
            '--det-model',
            detModelPath
          ],
          {
            onStdoutLine: (line) => {
              try {
                lastJson = JSON.parse(line);
              } catch (_) {}
            }
          }
        );
        if (lastJson && lastJson.ok && fs.existsSync(cachedPng) && fs.statSync(cachedPng).size > 2000) {
          return cachedPng;
        }
      } catch (_) {}
    }

    // Ưu tiên 2: Thử dùng Chrome Shape Detection API (window.FaceDetector) ngay trên trình duyệt CDP nếu hỗ trợ
    let detectedBox = null;
    if (musePageOptional && !musePageOptional.isClosed() && stat.size < 12 * 1024 * 1024) {
      try {
        const ext = path.extname(sourceImagePath).toLowerCase();
        const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
        const b64 = fs.readFileSync(sourceImagePath).toString('base64');
        detectedBox = await musePageOptional
          .evaluate(
            async ({ dataUrl }) => {
              if (typeof window.FaceDetector !== 'function') return null;
              const img = new Image();
              await new Promise((res, rej) => {
                img.onload = res;
                img.onerror = rej;
                img.src = dataUrl;
              });
              const detector = new window.FaceDetector({ fastMode: false, maxDetectedFaces: 3 });
              const faces = await detector.detect(img);
              if (!faces || faces.length === 0) return null;
              faces.sort(
                (a, b) => b.boundingBox.width * b.boundingBox.height - a.boundingBox.width * a.boundingBox.height
              );
              const bb = faces[0].boundingBox;
              return { x: bb.x, y: bb.y, width: bb.width, height: bb.height };
            },
            { dataUrl: `data:${mime};base64,${b64}` }
          )
          .catch(() => null);
      } catch (_) {}
    }

    // Ưu tiên 3: Cắt phóng Lanczos 768x768 PNG sắc nét qua FFmpeg
    try {
      const out = await cropCloseUpPortraitPng(this.appRootDir, sourceImagePath, cachedPng, detectedBox);
      if (out && fs.existsSync(out) && fs.statSync(out).size > 2000) {
        return out;
      }
    } catch (_) {}

    return null;
  }

  _enqueueVideoLockJob(taskFn) {
    this._queuedCount += 1;
    const next = this._jobChain.then(taskFn, taskFn);
    this._jobChain = next.catch(() => {});
    return next.finally(() => {
      this._queuedCount = Math.max(0, this._queuedCount - 1);
    });
  }

  /**
   * PHƯƠNG ÁN 2: Chạy Hậu kỳ AI Khóa Mặt Sinh Trắc Học 100% (INSwapper + ArcFace 512D + GFPGAN 512px HD)
   * trên toàn bộ các khung hình video đồng thời giữ nguyên 100% âm thanh & khẩu hình miệng nói lời thoại!
   */
  async applyPostRenderFaceLock({
    sourceFacePath,
    targetVideoPath,
    enhanceHd = true,
    onProgress = null
  }) {
    if (!sourceFacePath || !fs.existsSync(sourceFacePath)) {
      throw new Error('Không tìm thấy Ảnh Khuôn Mặt Tham Chiếu để khóa mặt hậu kỳ.');
    }
    if (!targetVideoPath || !fs.existsSync(targetVideoPath)) {
      throw new Error('Không tìm thấy file Video cần khóa mặt.');
    }

    // Nếu người dùng bật Công tắc Khóa mặt hậu kỳ mà chưa bấm tải Lõi AI, tự động tải & cài đặt 1 lần luôn!
    if (!this.isInstalled()) {
      if (typeof onProgress === 'function') {
        onProgress(1, '⬇️ Đang tự động cài đặt Lõi AI Khóa Mặt 100% (chỉ chạy 1 lần đầu)...');
      }
      const onInst = (st) => {
        if (typeof onProgress === 'function' && st.installing) {
          onProgress(st.installProgress, `⬇️ [Cài Lõi AI 1 Lần] ${st.installMessage}`);
        }
      };
      this.on('install_progress', onInst);
      try {
        await this.installRuntime();
      } finally {
        this.off('install_progress', onInst);
      }
    }

    if (this._queuedCount > 0 && typeof onProgress === 'function') {
      onProgress(2, `⏳ Đang chờ lượt xử lý Khóa Mặt AI 100% (Hàng đợi: ${this._queuedCount})...`);
    }

    return this._enqueueVideoLockJob(async () => {
      const workDir = path.join(
        this.appRootDir,
        'Project_Data',
        'temp_editor',
        `facelock_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
      );
      fs.mkdirSync(workDir, { recursive: true });

      const rawSwappedVideo = path.join(workDir, 'swapped_visual.mp4');
      const finalMuxedVideo = path.join(workDir, 'final_facelocked.mp4');

      try {
        if (typeof onProgress === 'function') {
          onProgress(4, '🧬 [Khóa Mặt AI 100%] Đang trích xuất sinh trắc học 512 chiều từ ảnh gốc...');
        }

        const detModel = path.join(this.modelsDir, 'det_10g.onnx');
        const arcModel = path.join(this.modelsDir, 'w600k_r50.onnx');
        const swapModel = path.join(this.modelsDir, 'inswapper_128_fp16.onnx');
        const gfpModel = path.join(this.modelsDir, 'gfpgan_1.4.onnx');

        let workerErr = null;
        await this._runProcess(
          this.pythonExe,
          [
            this.workerScriptPath,
            '--mode',
            'lock-video',
            '--source',
            sourceFacePath,
            '--target',
            targetVideoPath,
            '--output',
            rawSwappedVideo,
            '--det-model',
            detModel,
            '--arc-model',
            arcModel,
            '--swap-model',
            swapModel,
            '--gfp-model',
            gfpModel,
            '--enhance',
            enhanceHd ? '1' : '0'
          ],
          {
            onStdoutLine: (line) => {
              try {
                const msg = JSON.parse(line);
                if (msg.ok === false && msg.error) {
                  workerErr = msg.error;
                } else if (msg.stage === 'processing' && typeof onProgress === 'function') {
                  onProgress(
                    msg.progress,
                    `🧬 [Khóa Mặt AI 100%] Đang khóa mặt khung hình ${msg.frame}/${msg.total} (${msg.progress}%)...`
                  );
                }
              } catch (_) {}
            }
          }
        );

        if (workerErr) {
          throw new Error(workerErr);
        }
        if (!fs.existsSync(rawSwappedVideo) || fs.statSync(rawSwappedVideo).size < 10000) {
          throw new Error('Không tạo được luồng hình ảnh sau khi khóa mặt.');
        }

        if (typeof onProgress === 'function') {
          onProgress(98, '🔊 [Khóa Mặt AI 100%] Đang đồng bộ lại âm thanh gốc & chuẩn hóa MP4...');
        }

        const ffmpegBin = getFfmpegExecutable(this.appRootDir);
        const origInfo = await probeMediaFile(ffmpegBin, targetVideoPath);

        if (origInfo.hasAudio) {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i',
            rawSwappedVideo,
            '-i',
            targetVideoPath,
            '-map',
            '0:v:0',
            '-map',
            '1:a:0',
            '-map_metadata',
            '-1',
            '-vf',
            'setsar=1,format=yuv420p',
            '-af',
            'aresample=44100',
            '-c:v',
            'libx264',
            '-preset',
            'veryfast',
            '-crf',
            '18',
            '-profile:v',
            'main',
            '-level',
            '4.0',
            '-maxrate',
            '8M',
            '-bufsize',
            '16M',
            '-c:a',
            'aac',
            '-b:a',
            '192k',
            '-ar',
            '44100',
            '-ac',
            '2',
            '-shortest',
            '-brand',
            'mp42',
            '-movflags',
            '+faststart',
            finalMuxedVideo
          ]);
        } else {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i',
            rawSwappedVideo,
            '-map_metadata',
            '-1',
            '-vf',
            'setsar=1,format=yuv420p',
            '-c:v',
            'libx264',
            '-preset',
            'veryfast',
            '-crf',
            '18',
            '-profile:v',
            'main',
            '-level',
            '4.0',
            '-maxrate',
            '8M',
            '-bufsize',
            '16M',
            '-brand',
            'mp42',
            '-movflags',
            '+faststart',
            finalMuxedVideo
          ]);
        }

        await ensureUniversalPlayableMp4(this.appRootDir, finalMuxedVideo);
        fs.copyFileSync(finalMuxedVideo, targetVideoPath);

        if (typeof onProgress === 'function') {
          onProgress(100, '✅ Đã khóa chặt khuôn mặt AI 100% khớp ảnh gốc!');
        }

        return targetVideoPath;
      } finally {
        try {
          fs.rmSync(workDir, { recursive: true, force: true });
        } catch (_) {}
      }
    });
  }
}

module.exports = {
  FaceLockEngine,
  REQUIRED_MODELS
};
