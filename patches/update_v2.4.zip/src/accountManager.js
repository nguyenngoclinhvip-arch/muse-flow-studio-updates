const fs = require('fs');
const path = require('path');
const { parseProxyString } = require('./proxyBridge');

function cleanProjectDisplayName(rawName, fallbackIndex = 1) {
  const cleaned = String(rawName || '')
    .replace(/\s*\(Port\s*\d+\)/gi, '')
    .replace(/\s*\(Tài Khoản Mặc Định\)/gi, '')
    .trim();
  return cleaned || `Dự Án #${fallbackIndex}`;
}

function createDefaultRows(count = 10, existingRows = []) {
  const rows = [];
  for (let i = 1; i <= count; i++) {
    const prev = existingRows.find((r) => r.index === i);
    if (prev) {
      const isAvatarGarbage = prev.fileSize && Number(prev.fileSize) < 550000;
      const firstRef = Array.isArray(prev.referenceImages) ? prev.referenceImages[0] || null : null;
      const cleanMsg = String(prev.statusMessage || '')
        .replace(/Sẵn sàng chờ lệnh CDP/gi, 'Sẵn sàng')
        .trim();
      rows.push({
        ...prev,
        index: i,
        status: isAvatarGarbage ? 'idle' : prev.status,
        statusMessage: isAvatarGarbage ? 'Sẵn sàng' : (cleanMsg || 'Sẵn sàng'),
        videoUrl: isAvatarGarbage ? null : prev.videoUrl,
        videoFilePath: isAvatarGarbage ? null : prev.videoFilePath,
        remoteVideoUrl: isAvatarGarbage ? null : prev.remoteVideoUrl,
        fileSize: isAvatarGarbage ? null : prev.fileSize,
        referenceImages: [firstRef]
      });
    } else {
      rows.push({
        id: `row_${i}`,
        index: i,
        referenceImages: [null],
        prompt: '',
        status: 'idle',
        statusMessage: 'Sẵn sàng',
        videoUrl: null,
        videoFilePath: null,
        remoteVideoUrl: null,
        fileSize: null,
        completedAt: null,
        error: null
      });
    }
  }
  return rows;
}

function createDefaultProjectSettings() {
  return {
    duration: '10s',
    aspectRatio: '9:16',
    resolution: '720p',
    cameraMotion: 'Auto',
    transitionEffect: 'fade', // Hiệu ứng chuyển cảnh mượt cho video nối >= 20s
    activeSkillId: '', // Skill AI áp dụng riêng cho dự án này
    autoPrimeSkillInChat: true, // Tự nạp Skill vào đầu phiên chat muse.ai
    nativeAudio: true,
    enableDialogue: false,
    backgroundMode: true,
    concurrency: 6,
    batchMode: 'barrier_6',
    rowCount: 10,
    targetUrl: 'https://muse.ai',
    injectParamsIntoPrompt: true,
    customSelectors: {
      fileInput: '',
      promptInput: '',
      submitButton: '',
      videoElement: ''
    }
  };
}

const VALID_TRANSITIONS = new Set([
  'fade',
  'dissolve',
  'hblur',
  'smoothleft',
  'smoothright',
  'zoomin',
  'circleopen',
  'fadeblack',
  'fadewhite',
  'wipeleft',
  'random',
  'none'
]);

class AccountManager {
  constructor(appRootDir) {
    this.appRootDir = appRootDir;
    this.dataDir = path.join(appRootDir, 'Project_Data');
    this.stateFile = path.join(this.dataDir, 'projects_state.json');
    this.accounts = [];
    this.activeAccountId = 'account_9222';
    this._ensureLoaded();
  }

  _ensureLoaded() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    if (fs.existsSync(this.stateFile)) {
      try {
        const raw = fs.readFileSync(this.stateFile, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.accounts) && parsed.accounts.length > 0) {
          this.accounts = parsed.accounts.map((acc, idx) => {
            const settings = { ...createDefaultProjectSettings(), ...(acc.settings || {}) };
            const validDurations = ['5s', '8s', '10s', '20s', '30s', '40s', '50s', '60s'];
            if (!validDurations.includes(settings.duration)) {
              settings.duration = '10s';
            }
            if (!VALID_TRANSITIONS.has(settings.transitionEffect)) {
              settings.transitionEffect = 'fade';
            }
            // Luôn đảm bảo các tính năng ẩn mặc định bật ổn định
            settings.backgroundMode = true;
            settings.nativeAudio = true;
            settings.injectParamsIntoPrompt = true;
            settings.activeSkillId = typeof settings.activeSkillId === 'string' ? settings.activeSkillId.trim() : '';
            if (settings.autoPrimeSkillInChat === undefined) {
              settings.autoPrimeSkillInChat = true;
            }

            const rowCount = Math.max(1, Math.min(200, Number(settings.rowCount) || 10));
            settings.rowCount = rowCount;
            settings.concurrency = Math.max(1, Math.min(20, Number(settings.concurrency) || 6));

            const rows = createDefaultRows(rowCount, acc.rows || []).map((r) => {
              if (
                ['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(r.status) ||
                (r.status === 'error' &&
                  /Quá thời gian|Timeout|locator\.click|Đã dừng tiến trình/i.test(r.error || r.statusMessage || ''))
              ) {
                return {
                  ...r,
                  status: r.videoUrl ? 'completed' : 'idle',
                  statusMessage: r.videoUrl ? 'Hoàn tất' : 'Sẵn sàng',
                  error: null
                };
              }
              return r;
            });

            const cleanName = cleanProjectDisplayName(acc.name, idx + 1);
            const rawProxy = typeof acc.proxy === 'string' ? acc.proxy.trim() : '';
            let proxyLabel = '';
            try {
              const pInfo = parseProxyString(rawProxy);
              proxyLabel = pInfo ? pInfo.displayLabel : '';
            } catch (_) {}

            const cleanDisp = String(acc.accountInfo?.displayName || cleanName)
              .replace(/\s*\(Port\s*\d+\)/gi, '')
              .trim();
            const cleanSub = String(acc.accountInfo?.emailOrHandle || '')
              .replace(/\s*•?\s*Port\s*\d+/gi, '')
              .replace(/\s*\(Port\s*\d+\)/gi, '')
              .trim();

            return {
              ...acc,
              name: cleanName,
              proxy: rawProxy,
              proxyLabel,
              connected: false,
              loginVerified: Boolean(acc.loginVerified),
              savedAccount: Boolean(acc.savedAccount || acc.loginVerified),
              accountInfo: {
                ...(acc.accountInfo || {}),
                displayName: cleanDisp || cleanName,
                emailOrHandle: cleanSub || (acc.loginVerified ? 'Đã lưu phiên' : 'Chưa đăng nhập'),
                avatarUrl: acc.accountInfo?.avatarUrl || null,
                pageTitle: acc.accountInfo?.pageTitle || '',
                pageUrl: acc.accountInfo?.pageUrl || 'https://muse.ai',
                cookieCount: acc.accountInfo?.cookieCount || 0,
                browserVersion: acc.accountInfo?.browserVersion || '',
                lastConnectedAt: acc.accountInfo?.lastConnectedAt || null
              },
              settings,
              rows
            };
          });
          this.activeAccountId = parsed.activeAccountId || this.accounts[0].id;
          this.save();
          return;
        }
      } catch (err) {
        console.error('Lỗi đọc trạng thái dự án, khởi tạo mặc định:', err.message);
      }
    }

    const defaultAccount = {
      id: 'account_9222',
      name: 'Dự Án #1',
      port: 9222,
      proxy: '',
      proxyLabel: '',
      profileRelativePath: './ChromeProfile_Data',
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: 'Chưa kết nối',
        emailOrHandle: 'Bấm Kết nối để đăng nhập 1 lần',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(10),
      createdAt: new Date().toISOString()
    };

    this.accounts = [defaultAccount];
    this.activeAccountId = defaultAccount.id;
    this.save();
  }

  save() {
    try {
      const payload = {
        activeAccountId: this.activeAccountId,
        updatedAt: new Date().toISOString(),
        accounts: this.accounts
      };
      fs.writeFileSync(this.stateFile, JSON.stringify(payload, null, 2), 'utf8');
    } catch (err) {
      console.error('Không thể lưu trạng thái dự án:', err.message);
    }
  }

  getAllAccounts() {
    return this.accounts;
  }

  getAccount(accountId) {
    return this.accounts.find((a) => a.id === accountId) || null;
  }

  getActiveAccount() {
    return this.getAccount(this.activeAccountId) || this.accounts[0];
  }

  setActiveAccount(accountId) {
    const found = this.getAccount(accountId);
    if (!found) {
      throw new Error(`Không tìm thấy dự án: ${accountId}`);
    }
    this.activeAccountId = found.id;
    this.save();
    return found;
  }

  addAccount({ name, port, proxy }) {
    const rawProxy = typeof proxy === 'string' ? proxy.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsedProxy = parseProxyString(rawProxy);
      proxyLabel = parsedProxy ? parsedProxy.displayLabel : '';
    }

    const usedPorts = new Set(this.accounts.map((a) => Number(a.port)));
    let assignedPort = Number(port);
    if (!assignedPort || assignedPort < 1024 || assignedPort > 65535 || usedPorts.has(assignedPort)) {
      assignedPort = 9222;
      while (usedPorts.has(assignedPort)) {
        assignedPort++;
      }
    }

    const accountNumber = this.accounts.length + 1;
    const cleanName = cleanProjectDisplayName(name, accountNumber);
    const id = `account_${assignedPort}_${Date.now().toString(36)}`;
    const profileRelativePath =
      assignedPort === 9222 ? './ChromeProfile_Data' : `./ChromeProfile_Data_Port_${assignedPort}`;

    const newAcc = {
      id,
      name: cleanName,
      port: assignedPort,
      proxy: rawProxy,
      proxyLabel,
      profileRelativePath,
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: cleanName,
        emailOrHandle: 'Chưa đăng nhập',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(10),
      createdAt: new Date().toISOString()
    };

    this.accounts.push(newAcc);
    this.activeAccountId = newAcc.id;
    this.save();
    return newAcc;
  }

  updateAccountProxy(accountId, rawProxyInput) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    const rawProxy = typeof rawProxyInput === 'string' ? rawProxyInput.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsed = parseProxyString(rawProxy);
      proxyLabel = parsed ? parsed.displayLabel : '';
    }

    const changed = (acc.proxy || '') !== rawProxy;
    acc.proxy = rawProxy;
    acc.proxyLabel = proxyLabel;
    if (changed) {
      acc._proxyChanged = true;
    }
    this.save();
    return { account: acc, changed };
  }

  resetProjectRows(accountId) {
    const acc = this.getAccount(accountId);
    if (!acc) {
      throw new Error('Không tìm thấy dự án cần làm mới.');
    }

    for (const row of acc.rows || []) {
      if (Array.isArray(row.referenceImages)) {
        for (const img of row.referenceImages) {
          if (img && img.filePath && fs.existsSync(img.filePath)) {
            try {
              fs.unlinkSync(img.filePath);
            } catch (_) {}
          }
        }
      }
    }

    const rowCount = Math.max(1, Math.min(200, Number(acc.settings?.rowCount) || 10));
    acc.rows = createDefaultRows(rowCount, []);
    this.save();
    return acc;
  }

  deleteOrResetAccount(accountId, { wipeProfileDir = true } = {}) {
    const idx = this.accounts.findIndex((a) => a.id === accountId);
    if (idx === -1) {
      throw new Error('Không tìm thấy tài khoản cần xóa.');
    }

    const targetAcc = this.accounts[idx];
    const resolvedProfile = path.resolve(this.appRootDir, targetAcc.profileRelativePath);

    if (wipeProfileDir && fs.existsSync(resolvedProfile)) {
      try {
        fs.rmSync(resolvedProfile, { recursive: true, force: true });
      } catch (_) {}
    }

    if (this.accounts.length > 1) {
      this.accounts.splice(idx, 1);
      if (this.activeAccountId === accountId) {
        this.activeAccountId = this.accounts[0].id;
      }
    } else {
      fs.mkdirSync(resolvedProfile, { recursive: true });
      targetAcc.connected = false;
      targetAcc.loginVerified = false;
      targetAcc.savedAccount = false;
      targetAcc.accountInfo = {
        displayName: 'Chưa kết nối',
        emailOrHandle: 'Sẵn sàng đăng nhập tài khoản mới',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      };
    }

    this.save();
    return this.getActiveAccount();
  }

  updateAccountSettings(accountId, partialSettings) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    acc.settings = {
      ...acc.settings,
      ...partialSettings,
      customSelectors: {
        ...(acc.settings.customSelectors || {}),
        ...(partialSettings.customSelectors || {})
      }
    };

    if (partialSettings.transitionEffect !== undefined && !VALID_TRANSITIONS.has(acc.settings.transitionEffect)) {
      acc.settings.transitionEffect = 'fade';
    }

    if (partialSettings.concurrency !== undefined) {
      acc.settings.concurrency = Math.max(1, Math.min(20, Number(partialSettings.concurrency) || 6));
    }

    if (partialSettings.rowCount !== undefined) {
      const targetCount = Math.max(1, Math.min(200, Number(partialSettings.rowCount) || 10));
      acc.settings.rowCount = targetCount;
      acc.rows = createDefaultRows(targetCount, acc.rows);
    }

    this.save();
    return acc;
  }

  updateRow(accountId, rowIndex, patch) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    Object.assign(row, patch);
    this.save();
    return row;
  }

  setRowReferenceImage(accountId, rowIndex, slotIndex, imageMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    const prevImg = Array.isArray(row.referenceImages) ? row.referenceImages[0] : null;
    if (prevImg && prevImg.filePath && (!imageMeta || prevImg.filePath !== imageMeta.filePath)) {
      if (fs.existsSync(prevImg.filePath)) {
        try {
          fs.unlinkSync(prevImg.filePath);
        } catch (_) {}
      }
    }

    row.referenceImages = [imageMeta ? { ...imageMeta, slot: 0 } : null];
    this.save();
    return row;
  }
}

module.exports = {
  AccountManager,
  createDefaultRows,
  createDefaultProjectSettings
};
