const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const TRANSITION_EFFECTS = [
  { id: 'fade', label: 'Mờ dần (Crossfade)' },
  { id: 'dissolve', label: 'Hòa tan (Dissolve)' },
  { id: 'hblur', label: 'Mờ chuyển động (Blur)' },
  { id: 'smoothleft', label: 'Lướt trái mượt' },
  { id: 'smoothright', label: 'Lướt phải mượt' },
  { id: 'zoomin', label: 'Phóng tâm (Zoom In)' },
  { id: 'circleopen', label: 'Mở vòng tròn' },
  { id: 'fadeblack', label: 'Chuyển tối điện ảnh' },
  { id: 'fadewhite', label: 'Chớp sáng (Flash)' },
  { id: 'wipeleft', label: 'Quét ngang' },
  { id: 'random', label: 'Ngẫu nhiên mượt' },
  { id: 'none', label: 'Không hiệu ứng' }
];

const RANDOM_POOL = ['fade', 'dissolve', 'hblur', 'smoothleft', 'smoothright', 'zoomin'];

function getFfmpegExecutable(appRootDir) {
  try {
    const staticPath = require('ffmpeg-static');
    if (staticPath && fs.existsSync(staticPath)) {
      return staticPath;
    }
  } catch (_) {}

  const candidates = [
    path.join(appRootDir, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe'),
    path.join(appRootDir, 'runtime', 'ffmpeg', 'ffmpeg.exe'),
    'ffmpeg'
  ];

  for (const c of candidates) {
    if (c === 'ffmpeg' || fs.existsSync(c)) {
      return c;
    }
  }
  return 'ffmpeg';
}

function runFfmpeg(ffmpegBin, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegBin, args, { windowsHide: true });
    let stderr = '';
    proc.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    proc.on('error', (err) => {
      reject(new Error(`Không thể khởi chạy FFmpeg (${err.message}).`));
    });
    proc.on('close', (code) => {
      if (code === 0) {
        resolve(stderr);
      } else {
        const tail = stderr.split(/\r?\n/).slice(-8).join(' | ');
        reject(new Error(`Lỗi xử lý FFmpeg (code ${code}): ${tail}`));
      }
    });
  });
}

function probeMediaFile(ffmpegBin, filePath) {
  return new Promise((resolve) => {
    const proc = spawn(ffmpegBin, ['-hide_banner', '-i', filePath], { windowsHide: true });
    let stderr = '';
    proc.stderr.on('data', (d) => {
      stderr += d.toString();
    });
    proc.on('error', () => {
      resolve({
        duration: 0,
        width: 720,
        height: 1280,
        hasAudio: false,
        audioSampleRate: 0,
        audioChannels: '',
        bitrateKbps: 0,
        majorBrand: ''
      });
    });
    proc.on('close', () => {
      let duration = 0;
      const durMatch = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/i);
      if (durMatch) {
        duration =
          Number(durMatch[1]) * 3600 +
          Number(durMatch[2]) * 60 +
          parseFloat(durMatch[3]);
      }

      let bitrateKbps = 0;
      const brMatch = stderr.match(/bitrate:\s*(\d+)\s*kb\/s/i);
      if (brMatch) {
        bitrateKbps = Number(brMatch[1]) || 0;
      }

      let majorBrand = '';
      const brandMatch = stderr.match(/major_brand\s*:\s*(\S+)/i);
      if (brandMatch) {
        majorBrand = String(brandMatch[1] || '').trim().toLowerCase();
      }

      let width = 720;
      let height = 1280;
      const resMatch = stderr.match(/Stream\s+#\d+:\d+.*Video:.*?\s(\d{2,5})x(\d{2,5})(?:[\s,]|$)/i);
      if (resMatch) {
        width = Number(resMatch[1]) || 720;
        height = Number(resMatch[2]) || 1280;
      }

      const audioLineMatch = stderr.match(/Stream\s+#\d+:\d+.*Audio:([^\r\n]+)/i);
      const hasAudio = Boolean(audioLineMatch);
      let audioSampleRate = 0;
      let audioChannels = '';
      if (audioLineMatch) {
        const audioLine = audioLineMatch[1];
        const srMatch = audioLine.match(/(\d{4,6})\s*Hz/i);
        if (srMatch) audioSampleRate = Number(srMatch[1]) || 0;
        if (/\bstereo\b|\b2\s*channels\b/i.test(audioLine)) {
          audioChannels = 'stereo';
        } else if (/\bmono\b|\b1\s*channels?\b/i.test(audioLine)) {
          audioChannels = 'mono';
        }
      }

      resolve({
        duration,
        width,
        height,
        hasAudio,
        audioSampleRate,
        audioChannels,
        bitrateKbps,
        majorBrand
      });
    });
  });
}

/**
 * Chuẩn hóa file MP4 đầu ra sang chuẩn quốc tế (mp42 + H.264 yuv420p + AAC 44100Hz Stereo + faststart)
 * giúp mở mượt tức thì trên mọi trình phát Windows (kể cả Windows Media Player 12 cũ & DXVA2), Zalo, CapCut, iPhone.
 */
async function ensureUniversalPlayableMp4(appRootDir, filePath, options = {}) {
  if (!filePath || !fs.existsSync(filePath)) return filePath;
  const origStat = fs.statSync(filePath);
  if (origStat.size < 10000) return filePath;

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, filePath);

  const isMod16 = info.width > 0 && info.height > 0 && info.width % 16 === 0 && info.height % 16 === 0;
  const isReasonableBitrate = !info.bitrateKbps || info.bitrateKbps <= 10500;
  const isStandardAudio = !info.hasAudio || (info.audioSampleRate === 44100 && info.audioChannels === 'stereo');
  const isMp42 = info.majorBrand === 'mp42';

  if (!options.forceReencode && isMp42 && isStandardAudio && isMod16 && isReasonableBitrate) {
    return filePath;
  }

  const tempOut = `${filePath}.norm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.mp4`;

  const runFullCleanEncode = async () => {
    const evenW = Math.max(16, Math.round((info.width || 720) / 16) * 16);
    const evenH = Math.max(16, Math.round((info.height || 1280) / 16) * 16);
    const vf = `scale=${evenW}:${evenH},setsar=1,format=yuv420p`;

    if (info.hasAudio) {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-af', 'aresample=44100',
        '-c:v', 'libx264',
        '-preset', 'superfast',
        '-crf', '19',
        '-profile:v', 'main',
        '-level', '4.0',
        '-maxrate', '8M',
        '-bufsize', '16M',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-ar', '44100',
        '-ac', '2',
        '-brand', 'mp42',
        '-movflags', '+faststart',
        tempOut
      ]);
    } else {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-c:v', 'libx264',
        '-preset', 'superfast',
        '-crf', '19',
        '-profile:v', 'main',
        '-level', '4.0',
        '-maxrate', '8M',
        '-bufsize', '16M',
        '-brand', 'mp42',
        '-movflags', '+faststart',
        tempOut
      ]);
    }
  };

  try {
    if (!options.forceReencode && isMod16 && isReasonableBitrate) {
      try {
        if (info.hasAudio) {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-c:a', 'aac',
            '-b:a', '192k',
            '-ar', '44100',
            '-ac', '2',
            '-brand', 'mp42',
            '-movflags', '+faststart',
            tempOut
          ]);
        } else {
          await runFfmpeg(ffmpegBin, [
            '-y',
            '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-brand', 'mp42',
            '-movflags', '+faststart',
            tempOut
          ]);
        }
      } catch (_) {
        await runFullCleanEncode();
      }
    } else {
      await runFullCleanEncode();
    }

    if (fs.existsSync(tempOut) && fs.statSync(tempOut).size > 10000) {
      fs.renameSync(tempOut, filePath);
    }
  } catch (_) {
    // Giữ nguyên file gốc nếu FFmpeg gặp sự cố ngoài ý muốn
  } finally {
    if (fs.existsSync(tempOut)) {
      try {
        fs.unlinkSync(tempOut);
      } catch (_) {}
    }
  }

  return filePath;
}

function resolveClipFilePath(appRootDir, accountManager, accountId, clip) {
  const acc = accountManager.getAccount(accountId);
  if (clip.rowIndex && acc) {
    const row = acc.rows.find((r) => r.index === Number(clip.rowIndex));
    if (row && row.videoFilePath && fs.existsSync(row.videoFilePath)) {
      return row.videoFilePath;
    }
    if (row && row.videoUrl) {
      const rel = row.videoUrl.split('?')[0].replace(/^\/+/, '');
      if (rel.startsWith('outputs/')) {
        const candidate = path.join(appRootDir, 'Output_Videos', rel.slice('outputs/'.length));
        if (fs.existsSync(candidate)) return candidate;
      }
    }
  }

  if (clip.videoFilePath && fs.existsSync(clip.videoFilePath)) {
    return clip.videoFilePath;
  }

  if (clip.videoUrl) {
    const cleanUrl = clip.videoUrl.split('?')[0].replace(/^\/+/, '');
    if (cleanUrl.startsWith('outputs/')) {
      const candidate = path.join(appRootDir, 'Output_Videos', cleanUrl.slice('outputs/'.length));
      if (fs.existsSync(candidate)) return candidate;
    }
  }

  throw new Error(`Không tìm thấy file video gốc cho ${clip.label || `Hàng #${clip.rowIndex || '?'}`}.`);
}

/**
 * Ghép nhiều đoạn đã chuẩn hóa (cùng khung hình, 30fps, stereo 44.1kHz) kèm hiệu ứng chuyển cảnh mượt xfade + acrossfade
 */
async function mergeNormalizedSegmentsWithTransition(
  ffmpegBin,
  normFiles,
  finalOutputPath,
  transitionEffect = 'fade',
  transitionSec = 0.5
) {
  if (normFiles.length === 1) {
    fs.copyFileSync(normFiles[0], finalOutputPath);
    return finalOutputPath;
  }

  const cleanEffect = String(transitionEffect || 'fade').trim().toLowerCase();
  if (!cleanEffect || cleanEffect === 'none') {
    throw new Error('SKIP_TRANSITION');
  }

  const durations = [];
  for (const nf of normFiles) {
    const info = await probeMediaFile(ffmpegBin, nf);
    durations.push(info.duration > 0.8 ? info.duration : 10);
  }

  const minClipDur = Math.min(...durations);
  const tDur = Math.max(0.25, Math.min(transitionSec, minClipDur * 0.28, 0.7));

  const inputArgs = [];
  const filterParts = [];

  for (let i = 0; i < normFiles.length; i++) {
    inputArgs.push('-i', normFiles[i]);
    filterParts.push(`[${i}:v]settb=AVTB,fps=30,format=yuv420p[v${i}]`);
    filterParts.push(`[${i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo[a${i}]`);
  }

  let cumDuration = durations[0];
  let prevV = 'v0';
  let prevA = 'a0';

  for (let i = 1; i < normFiles.length; i++) {
    const chosenEffect =
      cleanEffect === 'random'
        ? RANDOM_POOL[(i - 1) % RANDOM_POOL.length]
        : RANDOM_POOL.includes(cleanEffect) ||
          ['circleopen', 'fadeblack', 'fadewhite', 'wipeleft'].includes(cleanEffect)
        ? cleanEffect
        : 'fade';

    const offset = Math.max(0.1, cumDuration - tDur);
    const nextV = `vx${i}`;
    const nextA = `ax${i}`;

    filterParts.push(
      `[${prevV}][v${i}]xfade=transition=${chosenEffect}:duration=${tDur.toFixed(3)}:offset=${offset.toFixed(3)}[${nextV}]`
    );
    filterParts.push(`[${prevA}][a${i}]acrossfade=d=${tDur.toFixed(3)}:c1=tri:c2=tri[${nextA}]`);

    cumDuration = offset + durations[i];
    prevV = nextV;
    prevA = nextA;
  }

  const filterComplex = filterParts.join(';');

  await runFfmpeg(ffmpegBin, [
    '-y',
    ...inputArgs,
    '-filter_complex',
    filterComplex,
    '-map',
    `[${prevV}]`,
    '-map',
    `[${prevA}]`,
    '-map_metadata',
    '-1',
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '20',
    '-profile:v',
    'main',
    '-level',
    '4.0',
    '-maxrate',
    '8M',
    '-bufsize',
    '16M',
    '-c:a',
    'aac',
    '-b:a',
    '192k',
    '-ar',
    '44100',
    '-ac',
    '2',
    '-brand',
    'mp42',
    '-movflags',
    '+faststart',
    finalOutputPath
  ]);

  return finalOutputPath;
}

/**
 * Cắt, tách đoạn, chỉnh tốc độ và nối nhiều đoạn video (hỗ trợ hiệu ứng chuyển cảnh mượt)
 */
async function renderTimelineVideo({
  appRootDir,
  accountManager,
  accountId,
  clips,
  outputCustomName,
  aspectMode = 'auto',
  transitionEffect = null,
  saveToRowIndex = null
}) {
  if (!Array.isArray(clips) || clips.length === 0) {
    throw new Error('Danh sách đoạn video cần nối đang trống.');
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const acc = accountManager ? accountManager.getAccount(accountId) : null;

  const outAccountDir = path.join(appRootDir, 'Output_Videos', accountId || 'default');
  const mergedDir = path.join(outAccountDir, 'Merged_CapCut');
  const tempDir = path.join(appRootDir, 'Project_Data', 'temp_editor', `job_${Date.now()}`);

  [outAccountDir, mergedDir, tempDir].forEach((d) => {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  });

  try {
    const resolvedClips = [];
    let totalEffectiveSec = 0;

    for (let i = 0; i < clips.length; i++) {
      const c = clips[i];
      const filePath = resolveClipFilePath(appRootDir, accountManager, accountId, c);
      const info = await probeMediaFile(ffmpegBin, filePath);

      const maxDur = info.duration > 0 ? info.duration : 600;
      const startTime = Math.max(0, Number(c.startTime) || 0);
      const rawEnd = Number(c.endTime);
      const endTime = rawEnd && rawEnd > startTime ? Math.min(rawEnd, maxDur) : maxDur;
      const segDuration = Math.max(0.15, endTime - startTime);
      const speed = Math.max(0.5, Math.min(2.0, Number(c.speed) || 1));
      totalEffectiveSec += segDuration / speed;

      resolvedClips.push({
        index: i,
        filePath,
        info,
        startTime,
        endTime,
        segDuration,
        speed,
        muted: Boolean(c.muted),
        rowIndex: c.rowIndex
      });
    }

    let targetW = resolvedClips[0].info.width || 720;
    let targetH = resolvedClips[0].info.height || 1280;

    if (aspectMode === '9:16') {
      targetW = 720;
      targetH = 1280;
    } else if (aspectMode === '16:9') {
      targetW = 1280;
      targetH = 720;
    } else if (aspectMode === '1:1') {
      targetW = 1088;
      targetH = 1088;
    }

    targetW = Math.max(16, Math.round(targetW / 16) * 16);
    targetH = Math.max(16, Math.round(targetH / 16) * 16);

    const segmentFiles = [];
    for (let i = 0; i < resolvedClips.length; i++) {
      const seg = resolvedClips[i];
      const segOutPath = path.join(tempDir, `seg_${String(i).padStart(3, '0')}.mp4`);

      const setPtsFilter = seg.speed !== 1 ? `setpts=${(1 / seg.speed).toFixed(4)}*PTS,` : '';
      const vFilter = `${setPtsFilter}scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

      const useOriginalAudio = seg.info.hasAudio && !seg.muted;
      const effectiveDuration = seg.segDuration / seg.speed;

      let args = [];
      if (useOriginalAudio) {
        const aFilter = seg.speed !== 1 ? `atempo=${seg.speed.toFixed(2)},aresample=44100` : 'aresample=44100';
        args = [
          '-y',
          '-ss', seg.startTime.toFixed(3),
          '-t', seg.segDuration.toFixed(3),
          '-i', seg.filePath,
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-af', aFilter,
          '-c:v', 'libx264',
          '-preset', 'veryfast',
          '-crf', '20',
          '-profile:v', 'main',
          '-level', '4.0',
          '-maxrate', '8M',
          '-bufsize', '16M',
          '-c:a', 'aac',
          '-b:a', '192k',
          '-ac', '2',
          '-ar', '44100',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          segOutPath
        ];
      } else {
        args = [
          '-y',
          '-ss', seg.startTime.toFixed(3),
          '-t', seg.segDuration.toFixed(3),
          '-i', seg.filePath,
          '-f', 'lavfi',
          '-t', effectiveDuration.toFixed(3),
          '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-map', '0:v:0',
          '-map', '1:a:0',
          '-c:v', 'libx264',
          '-preset', 'veryfast',
          '-crf', '20',
          '-profile:v', 'main',
          '-level', '4.0',
          '-maxrate', '8M',
          '-bufsize', '16M',
          '-c:a', 'aac',
          '-b:a', '192k',
          '-ac', '2',
          '-ar', '44100',
          '-shortest',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          segOutPath
        ];
      }

      await runFfmpeg(ffmpegBin, args);
      segmentFiles.push(segOutPath);
    }

    const safeCustom = String(outputCustomName || '')
      .trim()
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 50);

    const finalFileName = saveToRowIndex
      ? `Row_${String(saveToRowIndex).padStart(2, '0')}_Edited_${Date.now()}.mp4`
      : `${safeCustom || 'MuseFlow_Merged'}_${Date.now()}.mp4`;

    const finalOutputDir = saveToRowIndex ? outAccountDir : mergedDir;
    const finalOutputPath = path.join(finalOutputDir, finalFileName);

    const chosenTransition =
      transitionEffect ||
      (totalEffectiveSec >= 19.5 ? acc?.settings?.transitionEffect || 'fade' : 'none');

    if (segmentFiles.length === 1) {
      fs.copyFileSync(segmentFiles[0], finalOutputPath);
    } else {
      let mergedWithXfade = false;
      if (chosenTransition && chosenTransition !== 'none') {
        try {
          await mergeNormalizedSegmentsWithTransition(
            ffmpegBin,
            segmentFiles,
            finalOutputPath,
            chosenTransition,
            0.5
          );
          mergedWithXfade = fs.existsSync(finalOutputPath) && fs.statSync(finalOutputPath).size > 50000;
        } catch (_) {
          mergedWithXfade = false;
        }
      }

      if (!mergedWithXfade) {
        const concatListPath = path.join(tempDir, 'concat_list.txt');
        const listContent = segmentFiles
          .map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`)
          .join('\n');
        fs.writeFileSync(concatListPath, listContent, 'utf8');

        await runFfmpeg(ffmpegBin, [
          '-y',
          '-f', 'concat',
          '-safe', '0',
          '-i', concatListPath,
          '-map_metadata', '-1',
          '-c', 'copy',
          '-brand', 'mp42',
          '-movflags', '+faststart',
          finalOutputPath
        ]);
      }
    }

    const finalProbe = await probeMediaFile(ffmpegBin, finalOutputPath);
    const stat = fs.statSync(finalOutputPath);

    const publicUrl = saveToRowIndex
      ? `/outputs/${accountId || 'default'}/${finalFileName}`
      : `/outputs/${accountId || 'default'}/Merged_CapCut/${finalFileName}`;

    let updatedRow = null;
    if (saveToRowIndex && accountManager) {
      updatedRow = accountManager.updateRow(accountId, Number(saveToRowIndex), {
        status: 'completed',
        statusMessage: `Đã cắt nối (${finalProbe.duration.toFixed(1)}s)`,
        videoUrl: publicUrl,
        videoFilePath: finalOutputPath
      });
    }

    return {
      ok: true,
      fileName: finalFileName,
      filePath: finalOutputPath,
      publicUrl,
      duration: Number(finalProbe.duration.toFixed(2)),
      width: targetW,
      height: targetH,
      sizeBytes: stat.size,
      clipCount: resolvedClips.length,
      updatedRow
    };
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

/**
 * Trích xuất khung hình cuối cùng của file video để tạo phần nối tiếp
 */
async function extractLastFrameFromVideo(appRootDir, videoFilePath, outputImagePath) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, videoFilePath);
  const seekSec = info.duration > 0.25 ? Math.max(0, info.duration - 0.15) : 0;

  const outDir = path.dirname(outputImagePath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  try {
    await runFfmpeg(ffmpegBin, [
      '-y',
      '-ss', seekSec.toFixed(3),
      '-i', videoFilePath,
      '-frames:v', '1',
      '-q:v', '2',
      outputImagePath
    ]);
  } catch (_) {}

  if (!fs.existsSync(outputImagePath) || fs.statSync(outputImagePath).size < 500) {
    await runFfmpeg(ffmpegBin, [
      '-y',
      '-sseof', '-0.25',
      '-i', videoFilePath,
      '-frames:v', '1',
      '-q:v', '2',
      outputImagePath
    ]);
  }

  return outputImagePath;
}

/**
 * Ghép nối các phần video mở rộng (20s, 30s, 40s, 50s, 60s) kèm chuẩn hóa đồng nhất khung hình + Audio 44.1kHz Stereo
 * Đảm bảo 100% file xuất ra mở mượt trên mọi trình phát Windows (không bao giờ lệch khung hình giữa chừng hay đơ WMP)
 */
async function concatExtendedPartFiles(
  appRootDir,
  partFilePaths,
  finalOutputPath,
  transitionEffect = 'fade'
) {
  if (!Array.isArray(partFilePaths) || partFilePaths.length === 0) {
    throw new Error('Không có file thành phần để nối.');
  }
  if (partFilePaths.length === 1) {
    fs.copyFileSync(partFilePaths[0], finalOutputPath);
    await ensureUniversalPlayableMp4(appRootDir, finalOutputPath);
    return finalOutputPath;
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const tempDir = path.join(
    appRootDir,
    'Project_Data',
    'temp_editor',
    `extend_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
  );
  fs.mkdirSync(tempDir, { recursive: true });

  const cleanEffect = String(transitionEffect || 'fade').trim().toLowerCase();

  try {
    // Luôn chuẩn hóa đồng nhất các phần (cùng độ phân giải chia hết cho 16, Main@L4.0, 30fps, stereo 44.1kHz)
    // để ngăn lỗi đổi độ phân giải giữa chừng (VD: 720x1280 -> 672x1216) và lỗi 24kHz mono làm đơ Windows Media Player
    const firstInfo = await probeMediaFile(ffmpegBin, partFilePaths[0]);
    const targetW = Math.max(16, Math.round((firstInfo.width || 720) / 16) * 16);
    const targetH = Math.max(16, Math.round((firstInfo.height || 1280) / 16) * 16);
    const normFiles = [];

    for (let i = 0; i < partFilePaths.length; i++) {
      const p = partFilePaths[i];
      const info = await probeMediaFile(ffmpegBin, p);
      const normOut = path.join(tempDir, `norm_${i}.mp4`);
      const vFilter = `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

      if (info.hasAudio) {
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p,
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-af', 'aresample=44100',
          '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
          '-profile:v', 'main', '-level', '4.0', '-maxrate', '8M', '-bufsize', '16M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100',
          '-brand', 'mp42',
          normOut
        ]);
      } else {
        const dur = Math.max(1, info.duration || 10);
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p,
          '-f', 'lavfi', '-t', dur.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1',
          '-vf', vFilter,
          '-map', '0:v:0', '-map', '1:a:0',
          '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
          '-profile:v', 'main', '-level', '4.0', '-maxrate', '8M', '-bufsize', '16M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100',
          '-shortest',
          '-brand', 'mp42',
          normOut
        ]);
      }
      normFiles.push(normOut);
    }

    // Áp dụng hiệu ứng chuyển cảnh xfade + acrossfade mượt mà giữa các điểm nối (>= 20s)
    if (cleanEffect && cleanEffect !== 'none') {
      try {
        await mergeNormalizedSegmentsWithTransition(ffmpegBin, normFiles, finalOutputPath, cleanEffect, 0.5);
        if (fs.existsSync(finalOutputPath) && fs.statSync(finalOutputPath).size > 10000) {
          return finalOutputPath;
        }
      } catch (_) {}
    }

    // Khi chọn Không hiệu ứng ("none") hoặc dự phòng: nối từ các mảnh ĐÃ CHUẨN HÓA đồng nhất 100%
    const normListPath = path.join(tempDir, 'norm_list.txt');
    fs.writeFileSync(
      normListPath,
      normFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'),
      'utf8'
    );

    await runFfmpeg(ffmpegBin, [
      '-y', '-f', 'concat', '-safe', '0', '-i', normListPath,
      '-map_metadata', '-1',
      '-c', 'copy',
      '-brand', 'mp42',
      '-movflags', '+faststart',
      finalOutputPath
    ]);

    return finalOutputPath;
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

module.exports = {
  TRANSITION_EFFECTS,
  getFfmpegExecutable,
  probeMediaFile,
  ensureUniversalPlayableMp4,
  renderTimelineVideo,
  extractLastFrameFromVideo,
  concatExtendedPartFiles
};
