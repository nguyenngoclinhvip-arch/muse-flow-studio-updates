const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { WebSocketServer } = require('ws');

const { findChromeExecutable, probeCdpPort, hideChromeWindowByPort } = require('./src/chromeLauncher');
const { AccountManager } = require('./src/accountManager');
const { CdpEngine } = require('./src/cdpEngine');
const { BatchScheduler } = require('./src/batchScheduler');
const { renderTimelineVideo, ensureUniversalPlayableMp4, TRANSITION_EFFECTS } = require('./src/videoEditor');
const { LicenseManager } = require('./src/licenseManager');
const { SkillManager } = require('./src/skillManager');
const { checkForUpdate, performSelfUpdate } = require('./src/autoUpdater');

const APP_ROOT = __dirname;
const APP_VERSION = '2.4';
const PORT = Number(process.env.PORT) || 3888;
const PUBLIC_DIR = path.join(APP_ROOT, 'public');

const CHROME_PROFILE_DIR = path.join(APP_ROOT, 'ChromeProfile_Data');
const UPLOADS_DIR = path.join(APP_ROOT, 'Project_Data', 'uploads');
const OUTPUT_VIDEOS_DIR = path.join(APP_ROOT, 'Output_Videos');

[CHROME_PROFILE_DIR, UPLOADS_DIR, OUTPUT_VIDEOS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

function isFrontendAssetsReady() {
  return (
    fs.existsSync(path.join(PUBLIC_DIR, 'index.html')) &&
    fs.existsSync(path.join(PUBLIC_DIR, 'app.js')) &&
    fs.existsSync(path.join(PUBLIC_DIR, 'styles.css'))
  );
}

function buildMissingAssetsGuideHtml() {
  return `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <title>MUSE FLOW STUDIO ${APP_VERSION} — Hướng Dẫn Giải Nén</title>
  <style>
    body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; background:#0b1120; color:#f1f5f9; font-family:'Segoe UI',system-ui,sans-serif; padding:24px; }
    .card { max-width:620px; background:#111827; border:1px solid #22d3ee55; border-radius:16px; padding:28px 32px; box-shadow:0 20px 50px rgba(0,0,0,.6); }
    h2 { margin:0 0 12px; color:#22d3ee; font-size:22px; }
    p, li { line-height:1.65; color:#cbd5e1; font-size:15px; }
    ol { padding-left:20px; margin:14px 0 18px; }
    code { background:#1e293b; color:#67e8f9; padding:2px 7px; border-radius:6px; }
    .footer { margin-top:16px; font-size:13px; color:#94a3b8; border-top:1px solid #1e293b; padding-top:12px; }
  </style>
</head>
<body>
  <div class="card">
    <h2>⚠️ Bạn chưa giải nén đầy đủ thư mục công cụ!</h2>
    <p>Không tìm thấy giao diện <code>public/index.html</code> tại thư mục chạy hiện tại (thường do mở trực tiếp bên trong cửa sổ WinRAR / File nén hoặc thư mục cũ đã bị xóa).</p>
    <ol>
      <li>Đóng cửa sổ này và tắt WinRAR.</li>
      <li>Bấm <b>Chuột phải</b> vào file <code>MUSE_FLOW_STUDIO_${APP_VERSION}_NGUYEN_LINH_AI.rar</code> (hoặc <code>.zip</code>).</li>
      <li>Chọn <b>"Extract to..." (Giải nén ra thư mục riêng)</b> và chờ giải nén đủ 100%.</li>
      <li>Mở thư mục vừa giải nén ➔ Chạy <code>MUSE FLOW STUDIO ${APP_VERSION}.exe</code>.</li>
    </ol>
    <div class="footer">MUSE FLOW STUDIO v${APP_VERSION} • Nguyễn Linh AI • Hỗ trợ Zalo/SĐT: 0967981918</div>
  </div>
</body>
</html>`;
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Phục vụ trực tiếp các tệp giao diện chính bằng fs.readFileSync để tránh mọi lỗi Cannot GET /
// trên các đường dẫn thư mục khách hàng có ký tự đặc biệt (#, %, dấu chấm, OneDrive, Tiếng Việt)
app.get(['/', '/index.html'], (req, res) => {
  const htmlPath = path.join(PUBLIC_DIR, 'index.html');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  if (fs.existsSync(htmlPath)) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.status(200).send(fs.readFileSync(htmlPath, 'utf8'));
  }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  return res.status(503).send(buildMissingAssetsGuideHtml());
});

app.get('/styles.css', (req, res) => {
  const cssPath = path.join(PUBLIC_DIR, 'styles.css');
  res.setHeader('Cache-Control', 'no-cache');
  if (fs.existsSync(cssPath)) {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    return res.status(200).send(fs.readFileSync(cssPath, 'utf8'));
  }
  return res.status(404).end();
});

app.get('/app.js', (req, res) => {
  const jsPath = path.join(PUBLIC_DIR, 'app.js');
  res.setHeader('Cache-Control', 'no-cache');
  if (fs.existsSync(jsPath)) {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    return res.status(200).send(fs.readFileSync(jsPath, 'utf8'));
  }
  return res.status(404).end();
});

app.get('/api/health', (req, res) => {
  const htmlReady = isFrontendAssetsReady();
  res.status(htmlReady ? 200 : 503).json({
    ok: htmlReady,
    app: 'MUSE_FLOW_STUDIO',
    version: APP_VERSION,
    pid: process.pid,
    port: PORT,
    appRootDir: APP_ROOT,
    htmlReady
  });
});

app.use(express.static(PUBLIC_DIR, { dotfiles: 'allow' }));
app.use('/uploads', express.static(UPLOADS_DIR, { dotfiles: 'allow' }));
app.use('/outputs', express.static(OUTPUT_VIDEOS_DIR, { dotfiles: 'allow' }));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const accId = req.params.accountId || 'default';
    const dest = path.join(UPLOADS_DIR, accId);
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.png') || '.png';
    const safeBase = path
      .basename(file.originalname || 'ref', ext)
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 40);
    const rowTag = req.params.rowIndex ? `R${req.params.rowIndex}` : `BULK_${Math.random().toString(36).slice(2, 6)}`;
    cb(null, `Ref_${rowTag}_${Date.now()}_${safeBase}${ext}`);
  }
});
const upload = multer({ storage });

function broadcast(event, payload) {
  const message = JSON.stringify({ event, payload, timestamp: new Date().toISOString() });
  wss.clients.forEach((client) => {
    if (client.readyState === 1) {
      client.send(message);
    }
  });
}

const licenseManager = new LicenseManager(APP_ROOT);
const skillManager = new SkillManager(APP_ROOT);
const accountManager = new AccountManager(APP_ROOT);
const cdpEngine = new CdpEngine({
  appRootDir: APP_ROOT,
  accountManager,
  skillManager,
  onEvent: (event, payload) => broadcast(event, payload)
});
const batchScheduler = new BatchScheduler({
  accountManager,
  cdpEngine,
  onEvent: (event, payload) => broadcast(event, payload)
});

async function autoConnectSavedAccounts() {
  if (!licenseManager.getLicenseStatus().valid) return;
  for (const acc of accountManager.getAllAccounts()) {
    try {
      const probe = await probeCdpPort(acc.port, 1200);
      if (probe.alive && !acc.proxy) {
        await cdpEngine.connectToRunningChrome(acc.id, probe.versionInfo);
        if (acc.settings?.backgroundMode !== false && acc.loginVerified) {
          hideChromeWindowByPort(acc.port);
        }
      } else if (acc.savedAccount || acc.loginVerified) {
        await cdpEngine.launchAndConnect(acc.id, { forceVisibleWindow: false });
      }
    } catch (_) {}
  }
}

// ============================================================================
// LICENSE & AUTO-PAYMENT ENDPOINTS
// ============================================================================

app.get('/api/license/status', (req, res) => {
  res.json({
    ok: true,
    license: licenseManager.getLicenseStatus()
  });
});

app.post('/api/license/activate', (req, res) => {
  try {
    const { licenseKey } = req.body || {};
    const status = licenseManager.activateLicense(licenseKey);
    broadcast('license_updated', { license: status });
    autoConnectSavedAccounts().catch(() => {});
    res.json({
      ok: true,
      license: status,
      message: `Kích hoạt thành công! Hạn dùng: ${status.expiresAtFormatted}`
    });
  } catch (err) {
    res.status(400).json({
      ok: false,
      error: err.message,
      license: licenseManager.getLicenseStatus()
    });
  }
});

app.post('/api/license/deactivate', (req, res) => {
  const status = licenseManager.deactivateLicense();
  broadcast('license_updated', { license: status });
  res.json({
    ok: true,
    license: status,
    message: 'Đã gỡ mã bản quyền khỏi máy hiện tại.'
  });
});

app.post('/api/license/payment/create-order', async (req, res) => {
  try {
    const { planId } = req.body || {};
    const order = await licenseManager.createPaymentOrder(planId);
    res.json({
      ok: true,
      order
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/license/payment/check', async (req, res) => {
  try {
    const { planId, orderCode } = req.body || {};
    const result = await licenseManager.checkPaymentAndAutoActivate({ planId, orderCode });
    if (result.paid && result.license) {
      broadcast('license_updated', { license: result.license });
      autoConnectSavedAccounts().catch(() => {});
    }
    res.json({
      ok: true,
      ...result
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// ============================================================================
// AUTO-UPDATE (OTA GITHUB) ENDPOINTS
// ============================================================================

app.get('/api/update/check', async (req, res) => {
  try {
    const info = await checkForUpdate(APP_ROOT, APP_VERSION);
    res.json(info);
  } catch (err) {
    res.json({
      ok: false,
      configured: true,
      currentVersion: APP_VERSION,
      updateAvailable: false,
      error: err.message
    });
  }
});

let isApplyingUpdate = false;
app.post('/api/update/apply', async (req, res) => {
  if (isApplyingUpdate) {
    return res.status(409).json({ ok: false, error: 'Đang tiến hành cập nhật phiên bản mới, vui lòng đợi...' });
  }
  isApplyingUpdate = true;
  try {
    const result = await performSelfUpdate(APP_ROOT, APP_VERSION, (stage, message) => {
      broadcast('update_progress', { stage, message });
    });
    res.json(result);
  } catch (err) {
    isApplyingUpdate = false;
    res.status(400).json({ ok: false, error: err.message });
  }
});

// ============================================================================
// REST API ENDPOINTS
// ============================================================================

app.get('/api/state', async (req, res) => {
  try {
    const chromePath = findChromeExecutable();
    const accounts = accountManager.getAllAccounts();
    const activeAccount = accountManager.getActiveAccount();
    const batchStats = batchScheduler.getJobState(activeAccount.id);
    const license = licenseManager.getLicenseStatus();

    res.json({
      ok: true,
      app: 'MUSE_FLOW_STUDIO',
      version: APP_VERSION,
      pid: process.pid,
      htmlReady: isFrontendAssetsReady(),
      license,
      chromePath,
      skills: skillManager.getAllSkills(),
      transitionEffects: TRANSITION_EFFECTS,
      appRootDir: APP_ROOT,
      activeAccountId: activeAccount.id,
      activeAccount,
      accounts: accounts.map((a) => ({
        id: a.id,
        name: a.name,
        port: a.port,
        proxy: a.proxy || '',
        proxyLabel: a.proxyLabel || '',
        activeSkillId: a.settings?.activeSkillId || '',
        profileRelativePath: a.profileRelativePath,
        connected: a.connected,
        loginVerified: a.loginVerified,
        savedAccount: Boolean(a.savedAccount || a.loginVerified),
        accountInfo: a.accountInfo,
        rowCount: a.rows.length,
        completedCount: a.rows.filter((r) => r.status === 'completed').length
      })),
      batchStats
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Middleware bảo vệ bản quyền cho toàn bộ thao tác chạy/cấu hình công cụ
app.use(['/api/accounts', '/api/skills'], (req, res, next) => {
  const lic = licenseManager.getLicenseStatus();
  if (!lic.valid) {
    return res.status(403).json({
      ok: false,
      licenseRequired: true,
      error: lic.reason || 'Hết thời hạn sử dụng. Vui lòng chọn gói bản quyền hoặc nhập Key!',
      license: lic
    });
  }
  next();
});

// ============================================================================
// SKILL AI 3-TRONG-1 ENDPOINTS
// ============================================================================

app.get('/api/skills', (req, res) => {
  res.json({
    ok: true,
    skills: skillManager.getAllSkills()
  });
});

app.post('/api/skills', (req, res) => {
  try {
    const { id, name, summary, instructions } = req.body || {};
    const saved = skillManager.saveSkill({ id, name, summary, instructions });
    const allSkills = skillManager.getAllSkills();
    broadcast('skills_updated', { skills: allSkills });
    res.json({
      ok: true,
      skill: saved,
      skills: allSkills,
      message: `Đã lưu "${saved.name}" vào thư viện Skill!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/skills/import', (req, res) => {
  try {
    const { items } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ ok: false, error: 'Chưa có file hoặc nội dung Skill để nhập.' });
    }
    const importedSkills = [];
    for (const item of items) {
      const added = skillManager.importFromFileOrText({
        fileName: item.fileName || '',
        content: item.content || ''
      });
      importedSkills.push(...added);
    }
    const allSkills = skillManager.getAllSkills();
    broadcast('skills_updated', { skills: allSkills });
    res.json({
      ok: true,
      imported: importedSkills,
      skills: allSkills,
      message: `Đã nhập thành công ${importedSkills.length} Skill vào thư viện!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/skills/restore-defaults', (req, res) => {
  try {
    const { restoredCount, skills } = skillManager.restoreDefaultSkills();
    broadcast('skills_updated', { skills });
    res.json({
      ok: true,
      restoredCount,
      skills,
      message:
        restoredCount > 0
          ? `Đã khôi phục ${restoredCount} bộ Skill mẫu mặc định!`
          : 'Tất cả 4 bộ Skill mẫu đã có sẵn trong thư viện!'
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/skills/:skillId', (req, res) => {
  try {
    const { skillId } = req.params;
    const removed = skillManager.deleteSkill(skillId);
    for (const acc of accountManager.getAllAccounts()) {
      if (acc.settings?.activeSkillId === skillId) {
        accountManager.updateAccountSettings(acc.id, { activeSkillId: '' });
      }
    }
    const allSkills = skillManager.getAllSkills();
    broadcast('skills_updated', { skills: allSkills });
    res.json({
      ok: true,
      skills: allSkills,
      activeAccount: accountManager.getActiveAccount(),
      message: `Đã xóa "${removed.name}" khỏi thư viện Skill.`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/skills/generate-prompts', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { skillId, overwriteExisting } = req.body || {};
    const result = await cdpEngine.generateRowPromptsFromSkill({
      accountId,
      skillId: skillId || null,
      overwriteExisting: Boolean(overwriteExisting)
    });
    res.json({
      ok: true,
      ...result,
      account: accountManager.getAccount(accountId),
      message: `✨ Đã tự động viết xong ${result.generatedCount}/${result.totalTarget} Prompt theo "${result.skillName}"!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/skills/stop-prompts', (req, res) => {
  try {
    const { accountId } = req.params;
    cdpEngine.stopSkillPromptGeneration(accountId);
    res.json({ ok: true, message: 'Đã dừng tiến trình viết Prompt theo Skill.' });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/connect', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { forceVisibleWindow } = req.body || {};
    const acc = accountManager.getAccount(accountId);
    if (!acc) return res.status(404).json({ ok: false, error: 'Không tìm thấy tài khoản.' });

    const showWindow = Boolean(forceVisibleWindow || !acc.loginVerified);

    const result = await cdpEngine.launchAndConnect(accountId, {
      forceVisibleWindow: showWindow
    });

    broadcast('account_connected', {
      accountId,
      account: result.account,
      launchResult: result.launchResult
    });

    res.json({
      ok: true,
      message: result.account.loginVerified
        ? 'Đã kết nối ngầm tài khoản thành công!'
        : 'Đã mở Chrome. Bạn chỉ cần đăng nhập 1 lần để tự động lưu!',
      launchResult: result.launchResult,
      account: result.account
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/proxy', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { proxy } = req.body || {};
    const { account, changed } = accountManager.updateAccountProxy(accountId, proxy);

    if (changed && (account.connected || account.loginVerified)) {
      await cdpEngine.disconnectAndKillAccountChrome(accountId);
      if (account.loginVerified) {
        await cdpEngine.launchAndConnect(accountId, { forceVisibleWindow: false, forceRestart: true }).catch(() => {});
      }
    }

    const updated = accountManager.getAccount(accountId);
    broadcast('accounts_updated', {
      activeAccountId: accountManager.activeAccountId,
      activeAccount: accountManager.getActiveAccount()
    });

    res.json({
      ok: true,
      account: updated,
      message: updated.proxy
        ? `Đã áp dụng Proxy (${updated.proxyLabel}) cho "${updated.name}"!`
        : `Đã gỡ Proxy (dùng mạng trực tiếp) cho "${updated.name}".`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/hide-chrome', (req, res) => {
  try {
    const acc = accountManager.getAccount(req.params.accountId);
    if (!acc) return res.status(404).json({ ok: false, error: 'Không tìm thấy tài khoản.' });
    hideChromeWindowByPort(acc.port);
    res.json({ ok: true, message: 'Đã ẩn cửa sổ Chrome xuống chạy ngầm!' });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/sync-videos', async (req, res) => {
  try {
    const count = await cdpEngine.syncGeneratedVideosFromChat(req.params.accountId);
    res.json({
      ok: true,
      syncedCount: count,
      account: accountManager.getAccount(req.params.accountId),
      message: `Đã đồng bộ ${count} video từ muse.ai!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/reset-account', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { openLoginNow } = req.body || {};

    await cdpEngine.disconnectAndKillAccountChrome(accountId);
    if (typeof cdpEngine.clearAccountVideoCache === 'function') {
      cdpEngine.clearAccountVideoCache(accountId);
    }
    const activeAcc = accountManager.deleteOrResetAccount(accountId, { wipeProfileDir: true });

    if (openLoginNow) {
      await cdpEngine.launchAndConnect(activeAcc.id, { forceVisibleWindow: true });
    }

    broadcast('accounts_updated', {
      activeAccountId: accountManager.activeAccountId,
      activeAccount: accountManager.getActiveAccount()
    });

    res.json({
      ok: true,
      activeAccount: accountManager.getActiveAccount(),
      message: openLoginNow
        ? 'Đã xóa phiên cũ và mở Chrome để đăng nhập tài khoản mới!'
        : 'Đã xóa tài khoản cũ!'
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/reset-project', (req, res) => {
  try {
    const { accountId } = req.params;
    batchScheduler.stopBatch(accountId);
    const updatedAcc = accountManager.resetProjectRows(accountId);
    if (typeof cdpEngine.clearAccountVideoCache === 'function') {
      cdpEngine.clearAccountVideoCache(accountId);
    }
    broadcast('settings_updated', {
      accountId: updatedAcc.id,
      settings: updatedAcc.settings,
      rows: updatedAcc.rows
    });
    res.json({
      ok: true,
      account: updatedAcc,
      message: `Đã làm mới dự án "${updatedAcc.name}"!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/refresh-session', async (req, res) => {
  try {
    const { accountId } = req.params;
    const acc = accountManager.getAccount(accountId);
    if (!acc) return res.status(404).json({ ok: false, error: 'Không tìm thấy tài khoản.' });

    const probe = await probeCdpPort(acc.port, 1500);
    if (probe.alive) {
      await cdpEngine.connectToRunningChrome(acc.id, probe.versionInfo);
    }
    const updated = await cdpEngine.refreshAccountSessionInfo(accountId, true);
    res.json({ ok: true, account: updated });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/accounts/:accountId/inspect-dom', async (req, res) => {
  try {
    const report = await cdpEngine.inspectLiveDom(req.params.accountId);
    res.json({ ok: true, report });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts', async (req, res) => {
  try {
    const { name, port, proxy, autoLaunch } = req.body || {};
    const newAcc = accountManager.addAccount({ name, port, proxy });

    let launchInfo = null;
    if (autoLaunch) {
      const connected = await cdpEngine.launchAndConnect(newAcc.id, { forceVisibleWindow: true });
      launchInfo = connected.launchResult;
    }

    const updatedAcc = accountManager.getAccount(newAcc.id);
    broadcast('accounts_updated', {
      activeAccountId: accountManager.activeAccountId,
      activeAccount: updatedAcc
    });

    res.json({
      ok: true,
      account: updatedAcc,
      launchInfo
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/select', (req, res) => {
  try {
    const { accountId } = req.body;
    const active = accountManager.setActiveAccount(accountId);
    const batchStats = batchScheduler.getJobState(active.id);
    res.json({ ok: true, activeAccount: active, batchStats });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    await cdpEngine.disconnectAndKillAccountChrome(accountId);
    const active = accountManager.deleteOrResetAccount(accountId, { wipeProfileDir: true });
    res.json({ ok: true, activeAccount: active });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/settings', (req, res) => {
  try {
    const updatedAcc = accountManager.updateAccountSettings(req.params.accountId, req.body || {});
    if (updatedAcc.settings?.backgroundMode !== false && updatedAcc.loginVerified) {
      hideChromeWindowByPort(updatedAcc.port);
    }
    broadcast('settings_updated', {
      accountId: updatedAcc.id,
      settings: updatedAcc.settings,
      rows: updatedAcc.rows
    });
    res.json({ ok: true, account: updatedAcc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/rows/:rowIndex', (req, res) => {
  try {
    const { accountId, rowIndex } = req.params;
    const { prompt } = req.body || {};
    const row = accountManager.updateRow(accountId, Number(rowIndex), {
      prompt: typeof prompt === 'string' ? prompt : ''
    });
    res.json({ ok: true, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/rows/bulk-prompts', (req, res) => {
  try {
    const { accountId } = req.params;
    const { prompts } = req.body || {};
    if (!Array.isArray(prompts)) {
      throw new Error('Danh sách prompts không hợp lệ.');
    }

    const acc = accountManager.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    if (prompts.length > acc.rows.length) {
      accountManager.updateAccountSettings(accountId, { rowCount: prompts.length });
    }

    prompts.forEach((text, idx) => {
      const rowIndex = idx + 1;
      accountManager.updateRow(accountId, rowIndex, { prompt: String(text || '').trim() });
    });

    res.json({ ok: true, account: accountManager.getAccount(accountId) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post(
  '/api/accounts/:accountId/rows/bulk-images',
  upload.array('images', 200),
  (req, res) => {
    try {
      const { accountId } = req.params;
      const files = Array.isArray(req.files) ? req.files : [];
      if (files.length === 0) {
        throw new Error('Không nhận được file ảnh nào.');
      }

      const acc = accountManager.getAccount(accountId);
      if (!acc) throw new Error('Không tìm thấy tài khoản.');

      const startRow = Math.max(1, Number(req.body?.startRowIndex) || 1);
      const neededRowCount = Math.min(200, startRow + files.length - 1);

      if (neededRowCount > acc.rows.length) {
        accountManager.updateAccountSettings(accountId, { rowCount: neededRowCount });
      }

      let assignedCount = 0;
      for (let i = 0; i < files.length; i++) {
        const targetRowIndex = startRow + i;
        if (targetRowIndex > 200) break;
        const f = files[i];
        const publicUrl = `/uploads/${accountId}/${f.filename}`;
        const imageMeta = {
          slot: 0,
          fileName: f.originalname,
          savedName: f.filename,
          filePath: f.path,
          publicUrl,
          size: f.size,
          uploadedAt: new Date().toISOString()
        };
        accountManager.setRowReferenceImage(accountId, targetRowIndex, 0, imageMeta);
        assignedCount++;
      }

      const updatedAcc = accountManager.getAccount(accountId);
      broadcast('settings_updated', {
        accountId: updatedAcc.id,
        settings: updatedAcc.settings,
        rows: updatedAcc.rows
      });

      res.json({
        ok: true,
        uploadedCount: assignedCount,
        startRowIndex: startRow,
        endRowIndex: startRow + assignedCount - 1,
        account: updatedAcc,
        message: `Đã thêm ${assignedCount} ảnh (Hàng #${startRow} ➔ #${startRow + assignedCount - 1})!`
      });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message });
    }
  }
);

app.post(
  '/api/accounts/:accountId/rows/:rowIndex/image/:slotIndex',
  upload.single('image'),
  (req, res) => {
    try {
      const { accountId, rowIndex } = req.params;
      if (!req.file) {
        throw new Error('Không nhận được file ảnh.');
      }

      const publicUrl = `/uploads/${accountId}/${req.file.filename}`;
      const imageMeta = {
        slot: 0,
        fileName: req.file.originalname,
        savedName: req.file.filename,
        filePath: req.file.path,
        publicUrl,
        size: req.file.size,
        uploadedAt: new Date().toISOString()
      };

      const row = accountManager.setRowReferenceImage(accountId, Number(rowIndex), 0, imageMeta);
      broadcast('row_updated', { accountId, rowIndex: Number(rowIndex), row });
      res.json({ ok: true, row, imageMeta });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message });
    }
  }
);

app.delete('/api/accounts/:accountId/rows/:rowIndex/image/:slotIndex', (req, res) => {
  try {
    const { accountId, rowIndex, slotIndex } = req.params;
    const acc = accountManager.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error('Không tìm thấy hàng.');

    const existingImg = row.referenceImages?.[Number(slotIndex)];
    if (existingImg && existingImg.filePath && fs.existsSync(existingImg.filePath)) {
      try {
        fs.unlinkSync(existingImg.filePath);
      } catch (_) {}
    }

    const updatedRow = accountManager.setRowReferenceImage(accountId, Number(rowIndex), Number(slotIndex), null);
    broadcast('row_updated', { accountId, rowIndex: Number(rowIndex), row: updatedRow });
    res.json({ ok: true, row: updatedRow });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/rows/:rowIndex/run', async (req, res) => {
  try {
    const { accountId, rowIndex } = req.params;
    batchScheduler.runSingleRow(accountId, Number(rowIndex), false).catch((err) => {
      console.error(`Lỗi chạy hàng #${rowIndex}:`, err.message);
    });
    res.json({
      ok: true,
      message: `Đang chạy Hàng #${rowIndex}!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/rows/:rowIndex/regenerate', async (req, res) => {
  try {
    const { accountId, rowIndex } = req.params;
    batchScheduler.runSingleRow(accountId, Number(rowIndex), true).catch((err) => {
      console.error(`Lỗi tạo lại hàng #${rowIndex}:`, err.message);
    });
    res.json({
      ok: true,
      message: `Đang tạo lại Hàng #${rowIndex}!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/batch/start', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { forceAll } = req.body || {};
    const stats = await batchScheduler.runAllInBatchesOfSix(accountId, { forceAll: Boolean(forceAll) });
    res.json({
      ok: true,
      message: `Đã bắt đầu chạy ${stats.batchSize} luồng (${stats.totalTargetRows} video)!`,
      stats
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/batch/stop', (req, res) => {
  try {
    const stopped = batchScheduler.stopBatch(req.params.accountId);
    res.json({ ok: true, stopped });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/download-video', (req, res) => {
  try {
    const { accountId, rowIndex } = req.query;
    const acc = accountManager.getAccount(accountId);
    if (!acc) return res.status(404).send('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row || !row.videoFilePath || !fs.existsSync(row.videoFilePath)) {
      return res.status(404).send('File video chưa tồn tại trên ổ cứng.');
    }
    res.download(row.videoFilePath, path.basename(row.videoFilePath));
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.post('/api/open-output-folder', (req, res) => {
  try {
    const { accountId, subFolder } = req.body || {};
    let folder = accountId
      ? path.join(OUTPUT_VIDEOS_DIR, accountId)
      : OUTPUT_VIDEOS_DIR;
    if (subFolder) {
      folder = path.join(folder, subFolder);
    }
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
    }
    spawn('explorer.exe', [folder], { detached: true, stdio: 'ignore' }).unref();
    res.json({ ok: true, folder });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

function collectOutputVideos(filterAccountId = '') {
  const results = [];
  if (!fs.existsSync(OUTPUT_VIDEOS_DIR)) return results;

  const accountNameMap = new Map();
  for (const a of accountManager.getAllAccounts()) {
    accountNameMap.set(a.id, a.name);
  }

  const scanDir = (dirPath, relPrefix = '', accId = '') => {
    let entries = [];
    try {
      entries = fs.readdirSync(dirPath, { withFileTypes: true });
    } catch (_) {
      return;
    }
    for (const ent of entries) {
      const fullPath = path.join(dirPath, ent.name);
      const relPath = relPrefix ? `${relPrefix}/${ent.name}` : ent.name;
      if (ent.isDirectory()) {
        const nextAccId = accId || ent.name;
        if (filterAccountId && filterAccountId !== 'all' && !accId && nextAccId !== filterAccountId) {
          continue;
        }
        scanDir(fullPath, relPath, nextAccId);
      } else if (ent.isFile() && ent.name.toLowerCase().endsWith('.mp4') && !ent.name.includes('.norm_')) {
        try {
          const st = fs.statSync(fullPath);
          if (st.size < 1000) continue;
          const encodedRel = relPath
            .split('/')
            .map((seg) => encodeURIComponent(seg))
            .join('/');
          results.push({
            fileName: ent.name,
            accountId: accId || 'root',
            accountName: accountNameMap.get(accId) || accId || 'Output_Videos',
            isMerged: relPath.includes('/Merged_CapCut/'),
            relativePath: relPath,
            publicUrl: `/outputs/${encodedRel}`,
            sizeBytes: st.size,
            createdAt: st.mtime.toISOString()
          });
        } catch (_) {}
      }
    }
  };

  scanDir(OUTPUT_VIDEOS_DIR, '', '');
  results.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return results;
}

app.get('/api/output-videos', (req, res) => {
  try {
    const filterAccountId = String(req.query.accountId || 'all').trim();
    const items = collectOutputVideos(filterAccountId);
    res.json({ ok: true, items });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/open-output-file', (req, res) => {
  try {
    const rawRel = String(req.body?.relativePath || '').replace(/\\/g, '/').replace(/^\/+/, '');
    const resolved = path.resolve(OUTPUT_VIDEOS_DIR, rawRel);
    const baseResolved = path.resolve(OUTPUT_VIDEOS_DIR);
    if (!resolved.toLowerCase().startsWith(baseResolved.toLowerCase()) || !fs.existsSync(resolved)) {
      return res.status(404).json({ ok: false, error: 'Không tìm thấy file video trên ổ cứng.' });
    }
    spawn('explorer.exe', [`/select,${resolved}`], { detached: true, stdio: 'ignore' }).unref();
    res.json({ ok: true, filePath: resolved });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/output-videos/repair', async (req, res) => {
  try {
    const filterAccountId = String(req.body?.accountId || 'all').trim();
    const forceReencode = Boolean(req.body?.forceReencode);
    const items = collectOutputVideos(filterAccountId);
    let repairedCount = 0;
    for (const item of items) {
      const fullPath = path.resolve(OUTPUT_VIDEOS_DIR, item.relativePath);
      if (fs.existsSync(fullPath)) {
        await ensureUniversalPlayableMp4(APP_ROOT, fullPath, { forceReencode });
        repairedCount++;
      }
    }
    res.json({
      ok: true,
      repairedCount,
      items: collectOutputVideos(filterAccountId),
      message: `Đã chuẩn hóa mượt ${repairedCount} video trong Output_Videos!`
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ============================================================================
// CAPCUT-STYLE VIDEO EDITOR & MERGER ENDPOINTS
// ============================================================================

app.post('/api/accounts/:accountId/video-editor/render', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { clips, outputCustomName, aspectMode, transitionEffect, saveToRowIndex } = req.body || {};
    const result = await renderTimelineVideo({
      appRootDir: APP_ROOT,
      accountManager,
      accountId,
      clips,
      outputCustomName,
      aspectMode: aspectMode || 'auto',
      transitionEffect: transitionEffect || null,
      saveToRowIndex: saveToRowIndex ? Number(saveToRowIndex) : null
    });

    if (result.updatedRow) {
      broadcast('row_updated', {
        accountId,
        rowIndex: result.updatedRow.index,
        row: result.updatedRow
      });
    }

    res.json({
      ok: true,
      result,
      message: saveToRowIndex
        ? `Đã lưu vào Hàng #${saveToRowIndex} (${result.duration}s)!`
        : `Đã xuất video nối hoàn chỉnh (${result.duration}s)!`
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/accounts/:accountId/video-editor/history', (req, res) => {
  try {
    const { accountId } = req.params;
    const mergedDir = path.join(OUTPUT_VIDEOS_DIR, accountId, 'Merged_CapCut');
    if (!fs.existsSync(mergedDir)) {
      return res.json({ ok: true, items: [] });
    }
    const files = fs
      .readdirSync(mergedDir)
      .filter((f) => f.toLowerCase().endsWith('.mp4'))
      .map((f) => {
        const full = path.join(mergedDir, f);
        const st = fs.statSync(full);
        return {
          fileName: f,
          filePath: full,
          publicUrl: `/outputs/${accountId}/Merged_CapCut/${f}`,
          sizeBytes: st.size,
          createdAt: st.mtime.toISOString()
        };
      })
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json({ ok: true, items: files });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/download-merged', (req, res) => {
  try {
    const { accountId, fileName } = req.query;
    const safeName = path.basename(String(fileName || ''));
    const fullPath = path.join(OUTPUT_VIDEOS_DIR, String(accountId || 'default'), 'Merged_CapCut', safeName);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).send('Không tìm thấy file video đã nối.');
    }
    res.download(fullPath, safeName);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error(`[MUSE FLOW STUDIO ${APP_VERSION}] Cổng ${PORT} đang được sử dụng bởi tiến trình khác.`);
    process.exit(1);
  }
  console.error(`[MUSE FLOW STUDIO ${APP_VERSION}] Lỗi khởi động máy chủ:`, err);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('==================================================================');
  console.log(`  MUSE FLOW STUDIO ${APP_VERSION} - REAL CDP ENGINE`);
  console.log(`  Studio UI URL : http://127.0.0.1:${PORT}`);
  console.log('==================================================================');
  autoConnectSavedAccounts().catch(() => {});
});
