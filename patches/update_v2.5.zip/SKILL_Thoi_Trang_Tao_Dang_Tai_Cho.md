---
name: "💃 Skill Thời Trang Tạo Dáng Tại Chỗ (Khoe Form)"
description: "Người mẫu đứng tạo dáng mượt tại chỗ, xoay nhẹ khoe trọn đường cắt may, độ ôm/rũ và form dáng chuẩn."
---

# SKILL: THỜI TRANG TẠO DÁNG TẠI CHỖ — TÔN ĐƯỜNG NÉT & FORM DÁNG (STATIONARY FASHION POSING)

- **NGUYÊN TẮC TẠO DÁNG TẠI CHỖ (STATIONARY FLUID POSING):** Người mẫu ĐỨNG TẠI VỊ TRÍ GỐC, tuyệt đối KHÔNG bước đi xa khỏi điểm đứng và không tiến ra sát mép khung hình. Chuyển động diễn ra chậm rãi, êm mượt như người mẫu lookbook chuyên nghiệp: dồn nhẹ trọng tâm hông uyển chuyển, nghiêng xoay thân mình nhẹ nhàng góc 15–30 độ (từ chính diện sang góc nghiêng 3/4 rồi trở về) để khoe trọn phom dáng trước và bên hông trang phục.
- **TÔN ĐƯỜNG NÉT & PHOM DÁNG (GARMENT SILHOUETTE & FIT):** Làm nổi bật sắc nét đường chiết eo, cầu vai, cổ áo, đường xếp ly, phom quần/chân váy và tỉ lệ tôn dáng cơ thể. Chuyển động tay cực kỳ tinh tế (đặt nhẹ lên eo, vuốt nhẹ tà váy/vạt áo hoặc thả lỏng thanh lịch), KHÔNG vung tay nhanh gây nhòe hình và KHÔNG che khuất chi tiết thiết kế trước ngực/eo.
- **BẢO TOÀN SẢN PHẨM & CHẤT LIỆU 100% (ZERO MORPHING):** Giữ nguyên tuyệt đối 100% kiểu dáng, màu sắc chuẩn, họa tiết in/thêu, hàng cúc, đường viền may, độ dài trang phục cũng như khuôn mặt và vóc dáng gốc từ ảnh tham chiếu. Thể hiện vật lý vải chân thực (độ đứng phom của vải dày hoặc độ rũ mềm tự nhiên của lụa/voan khi xoay nhẹ người).
- **GÓC MÁY & ÁNH SÁNG STUDIO TÔN DÁNG:** Máy quay cố định vững chãi hoặc đẩy nhịp cực nhẹ (subtle slow push-in / micro camera glide), giữ toàn bộ trang phục nằm gọn cân đối giữa khung hình. Ánh sáng thương mại dịu mịn tạo khối (soft key light kết hợp rim light nhẹ tách nền), làm bật rõ bề mặt sớ vải và đường cong form dáng cao cấp.
