const http = require('http');
const net = require('net');
const { URL } = require('url');

// Map accountId -> { rawKey, localPort, server }
const activeBridges = new Map();

/**
 * Phân tích chuỗi Proxy đa định dạng:
 * - host:port
 * - host:port:user:pass
 * - user:pass@host:port
 * - http://host:port | http://user:pass@host:port
 * - socks5://host:port | socks5://user:pass@host:port | socks5://host:port:user:pass
 */
function parseProxyString(rawInput) {
  const trimmed = String(rawInput || '').trim();
  if (!trimmed) return null;

  let scheme = 'http';
  let rest = trimmed;

  const schemeMatch = rest.match(/^(https?|socks5h?|socks4):\/\/(.+)$/i);
  if (schemeMatch) {
    scheme = schemeMatch[1].toLowerCase();
    if (scheme === 'socks5h') scheme = 'socks5';
    rest = schemeMatch[2].trim();
  }

  let host = '';
  let port = 0;
  let username = '';
  let password = '';

  if (rest.includes('@')) {
    try {
      const parsed = new URL(`${scheme}://${rest}`);
      host = parsed.hostname;
      port = Number(parsed.port);
      username = decodeURIComponent(parsed.username || '');
      password = decodeURIComponent(parsed.password || '');
    } catch (_) {
      const atIdx = rest.lastIndexOf('@');
      const authPart = rest.slice(0, atIdx);
      const hostPart = rest.slice(atIdx + 1);
      const colonAuth = authPart.indexOf(':');
      if (colonAuth !== -1) {
        username = authPart.slice(0, colonAuth);
        password = authPart.slice(colonAuth + 1);
      } else {
        username = authPart;
      }
      const hp = hostPart.split(':');
      host = hp[0] || '';
      port = Number(hp[1] || 0);
    }
  } else {
    const parts = rest.split(':');
    if (parts.length === 2) {
      host = parts[0].trim();
      port = Number(parts[1].trim());
    } else if (parts.length >= 4) {
      host = parts[0].trim();
      port = Number(parts[1].trim());
      username = parts[2].trim();
      password = parts.slice(3).join(':').trim();
    } else {
      throw new Error(
        'Định dạng Proxy không hợp lệ. Hỗ trợ: ip:port hoặc ip:port:user:pass hoặc http://user:pass@ip:port'
      );
    }
  }

  if (!host || !port || port < 1 || port > 65535 || Number.isNaN(port)) {
    throw new Error(
      'Địa chỉ IP/Host hoặc cổng Proxy không hợp lệ (VD đúng: 103.15.22.10:8080 hoặc 103.15.22.10:8080:user:pass).'
    );
  }

  return {
    raw: trimmed,
    scheme,
    host,
    port,
    username,
    password,
    hasAuth: Boolean(username || password),
    displayLabel: `${scheme.toUpperCase()} ${host}:${port}${username ? ' (Auth)' : ''}`
  };
}

/**
 * Kết nối qua SOCKS5 upstream (có hoặc không có user/pass) trả về socket đã sẵn sàng chuyển tiếp dữ liệu
 */
function connectViaSocks5({ proxyHost, proxyPort, username, password, targetHost, targetPort }) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(proxyPort, proxyHost);
    let settled = false;

    const fail = (err) => {
      if (settled) return;
      settled = true;
      try {
        socket.destroy();
      } catch (_) {}
      reject(err);
    };

    socket.setTimeout(15000, () => fail(new Error('SOCKS5 timeout')));
    socket.once('error', fail);

    socket.once('connect', () => {
      const hasAuth = Boolean(username || password);
      const greeting = hasAuth ? Buffer.from([0x05, 0x02, 0x00, 0x02]) : Buffer.from([0x05, 0x01, 0x00]);
      socket.write(greeting);

      socket.once('data', (res1) => {
        if (!res1 || res1.length < 2 || res1[0] !== 0x05) {
          return fail(new Error('Phản hồi SOCKS5 không hợp lệ'));
        }
        const method = res1[1];
        const sendConnectRequest = () => {
          const hostBuf = Buffer.from(targetHost, 'utf8');
          const portBuf = Buffer.alloc(2);
          portBuf.writeUInt16BE(Number(targetPort), 0);
          const reqBuf = Buffer.concat([
            Buffer.from([0x05, 0x01, 0x00, 0x03, hostBuf.length]),
            hostBuf,
            portBuf
          ]);
          socket.write(reqBuf);

          socket.once('data', (res3) => {
            if (!res3 || res3.length < 2 || res3[1] !== 0x00) {
              return fail(new Error('SOCKS5 từ chối kết nối tới đích'));
            }
            socket.setTimeout(0);
            socket.removeListener('error', fail);
            settled = true;
            resolve(socket);
          });
        };

        if (method === 0x02) {
          const uBuf = Buffer.from(String(username || ''), 'utf8');
          const pBuf = Buffer.from(String(password || ''), 'utf8');
          const authBuf = Buffer.concat([
            Buffer.from([0x01, uBuf.length]),
            uBuf,
            Buffer.from([pBuf.length]),
            pBuf
          ]);
          socket.write(authBuf);
          socket.once('data', (res2) => {
            if (!res2 || res2.length < 2 || res2[1] !== 0x00) {
              return fail(new Error('Sai tài khoản/mật khẩu SOCKS5 Proxy'));
            }
            sendConnectRequest();
          });
        } else if (method === 0x00) {
          sendConnectRequest();
        } else {
          fail(new Error('SOCKS5 yêu cầu phương thức xác thực không hỗ trợ'));
        }
      });
    });
  });
}

/**
 * Tạo cổng cầu nối Proxy nội bộ (127.0.0.1) để tự động đính kèm Username/Password cho Chrome
 * (Tránh hoàn toàn hộp thoại hỏi mật khẩu của Chrome kể cả khi chạy ngầm Headless)
 */
function createLocalAuthProxyBridge(parsedProxy) {
  return new Promise((resolve, reject) => {
    const authHeader =
      'Basic ' + Buffer.from(`${parsedProxy.username}:${parsedProxy.password}`, 'utf8').toString('base64');

    const server = http.createServer((clientReq, clientRes) => {
      clientReq.on('error', () => {});
      clientRes.on('error', () => {});

      if (parsedProxy.scheme.startsWith('socks')) {
        try {
          const targetUrl = new URL(clientReq.url);
          const targetPort = Number(targetUrl.port) || (targetUrl.protocol === 'https:' ? 443 : 80);
          connectViaSocks5({
            proxyHost: parsedProxy.host,
            proxyPort: parsedProxy.port,
            username: parsedProxy.username,
            password: parsedProxy.password,
            targetHost: targetUrl.hostname,
            targetPort
          })
            .then((sock) => {
              sock.on('error', () => {});
              const pathWithQuery = (targetUrl.pathname || '/') + (targetUrl.search || '');
              const headerLines = [`${clientReq.method} ${pathWithQuery} HTTP/${clientReq.httpVersion}`];
              for (let i = 0; i < clientReq.rawHeaders.length; i += 2) {
                const k = clientReq.rawHeaders[i];
                const v = clientReq.rawHeaders[i + 1];
                if (!/^proxy-/i.test(k)) {
                  headerLines.push(`${k}: ${v}`);
                }
              }
              headerLines.push('\r\n');
              sock.write(headerLines.join('\r\n'));
              clientReq.pipe(sock);
              sock.pipe(clientRes.socket || clientRes);
            })
            .catch(() => {
              if (!clientRes.headersSent) {
                clientRes.writeHead(502);
                clientRes.end('Proxy Error');
              }
            });
        } catch (_) {
          clientRes.writeHead(400);
          clientRes.end('Bad Request');
        }
        return;
      }

      const headers = { ...clientReq.headers, 'Proxy-Authorization': authHeader };
      const proxyReq = http.request(
        {
          host: parsedProxy.host,
          port: parsedProxy.port,
          method: clientReq.method,
          path: clientReq.url,
          headers
        },
        (proxyRes) => {
          clientRes.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
          proxyRes.pipe(clientRes);
        }
      );

      proxyReq.on('error', () => {
        if (!clientRes.headersSent) {
          clientRes.writeHead(502);
          clientRes.end('Upstream Proxy Error');
        }
      });

      clientReq.pipe(proxyReq);
    });

    server.on('connect', (req, clientSocket, head) => {
      clientSocket.on('error', () => {});

      const [targetHost, rawPort] = String(req.url || '').split(':');
      const targetPort = Number(rawPort) || 443;

      if (parsedProxy.scheme.startsWith('socks')) {
        connectViaSocks5({
          proxyHost: parsedProxy.host,
          proxyPort: parsedProxy.port,
          username: parsedProxy.username,
          password: parsedProxy.password,
          targetHost,
          targetPort
        })
          .then((upstreamSocket) => {
            upstreamSocket.on('error', () => {
              try { clientSocket.destroy(); } catch (_) {}
            });
            clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
            if (head && head.length > 0) upstreamSocket.write(head);
            upstreamSocket.pipe(clientSocket);
            clientSocket.pipe(upstreamSocket);
          })
          .catch(() => {
            try {
              clientSocket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n');
              clientSocket.destroy();
            } catch (_) {}
          });
        return;
      }

      const upstreamSocket = net.connect(parsedProxy.port, parsedProxy.host, () => {
        const connectLines = [
          `CONNECT ${req.url} HTTP/1.1`,
          `Host: ${req.url}`,
          `Proxy-Authorization: ${authHeader}`,
          'Proxy-Connection: Keep-Alive',
          '\r\n'
        ];
        upstreamSocket.write(connectLines.join('\r\n'));
      });

      upstreamSocket.on('error', () => {
        try {
          clientSocket.destroy();
        } catch (_) {}
      });

      let responseBuffer = Buffer.alloc(0);
      const onData = (chunk) => {
        responseBuffer = Buffer.concat([responseBuffer, chunk]);
        const headerEnd = responseBuffer.indexOf('\r\n\r\n');
        if (headerEnd === -1) {
          if (responseBuffer.length > 16384) {
            upstreamSocket.destroy();
            clientSocket.destroy();
          }
          return;
        }

        upstreamSocket.removeListener('data', onData);
        const headerText = responseBuffer.slice(0, headerEnd).toString('utf8');
        const remainder = responseBuffer.slice(headerEnd + 4);
        const statusLine = headerText.split('\r\n')[0] || '';

        if (/^HTTP\/1\.[01]\s+200\b/i.test(statusLine)) {
          clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
          if (remainder.length > 0) clientSocket.write(remainder);
          if (head && head.length > 0) upstreamSocket.write(head);
          upstreamSocket.pipe(clientSocket);
          clientSocket.pipe(upstreamSocket);
        } else {
          try {
            clientSocket.write('HTTP/1.1 502 Proxy Auth Failed\r\n\r\n');
            clientSocket.destroy();
            upstreamSocket.destroy();
          } catch (_) {}
        }
      };

      upstreamSocket.on('data', onData);
    });

    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      resolve({ server, localPort: addr.port });
    });
  });
}

async function stopProxyBridge(accountId) {
  const existing = activeBridges.get(accountId);
  if (existing) {
    activeBridges.delete(accountId);
    await new Promise((resolve) => {
      try {
        existing.server.close(() => resolve());
      } catch (_) {
        resolve();
      }
    });
  }
}

/**
 * Chuẩn bị tham số --proxy-server cho Chrome của tài khoản cụ thể
 */
async function ensureChromeProxyArg(accountId, rawProxy) {
  const parsed = parseProxyString(rawProxy);
  if (!parsed) {
    await stopProxyBridge(accountId);
    return null;
  }

  if (!parsed.hasAuth) {
    await stopProxyBridge(accountId);
    return `${parsed.scheme}://${parsed.host}:${parsed.port}`;
  }

  const existing = activeBridges.get(accountId);
  if (existing && existing.rawKey === parsed.raw && existing.server.listening) {
    return `http://127.0.0.1:${existing.localPort}`;
  }

  await stopProxyBridge(accountId);
  const { server, localPort } = await createLocalAuthProxyBridge(parsed);
  activeBridges.set(accountId, {
    rawKey: parsed.raw,
    localPort,
    server
  });
  return `http://127.0.0.1:${localPort}`;
}

module.exports = {
  parseProxyString,
  ensureChromeProxyArg,
  stopProxyBridge
};
