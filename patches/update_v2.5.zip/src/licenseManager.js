const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

// RSA-2048 PUBLIC KEY (Chỉ dùng xác thực chữ ký số, tuyệt đối an toàn khi gửi khách)
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxOM87qM+Nt3sxS9Js4/F
eTIxbOCOKfTXKYLgkfgRMWj3Wd7Cwwvrm+JTCLUFYWKFkc+IlfWs4ySbS6+sYB9j
Qe4SFuN5o37U7u+tmKcwkYYeGYJVsrJOTuqG2gyMC9fJ8lu/neaUv1TqcKJenjbo
B2ulvas7J/byVX60QE+y4PtwO0PYez15ANn8muXg7XdgqNJ+wordqVMuWwwKTH4N
LHVn+eMHuDG6H22iuisYZhX39YOwetwEAK/R15t7FCNNXVrkf67ZdHSlqa2HCpo9
+viI4Ep/H5jlQplq+C/ZzLQbBcnLWtwguqmK3szU2KboQ4xnRy/wEaRrFMbbId0p
EwIDAQAB
-----END PUBLIC KEY-----`;

const AUTHOR_NAME = 'Nguyễn Linh AI';
const AUTHOR_PHONE = '0967981918';

// Thời gian dùng thử miễn phí mặc định cho máy mới: 2 ngày (48 giờ)
const FREE_TRIAL_MS = 2 * 24 * 60 * 60 * 1000;
const TRIAL_SECRET_SALT = 'NLAI_MFS2_TRIAL_GUARD_2026_92875666666';
const TRIAL_REG_KEY = 'HKCU\\Software\\Classes\\CLSID\\{9B4F2C81-5E1D-4A73-8C92-1F6D3E8A4B20}';

// Bảng giá chính thức theo yêu cầu
const PRICING_PLANS = [
  {
    id: '1m',
    code: '1M',
    label: '1 Tháng',
    planName: 'Gói 1 Tháng',
    days: 30,
    amount: 150000,
    priceText: '150.000đ',
    shortPrice: '150k'
  },
  {
    id: '3m',
    code: '3M',
    label: '3 Tháng',
    planName: 'Gói 3 Tháng',
    days: 90,
    amount: 350000,
    priceText: '350.000đ',
    shortPrice: '350k'
  },
  {
    id: '6m',
    code: '6M',
    label: '6 Tháng',
    planName: 'Gói 6 Tháng',
    days: 180,
    amount: 600000,
    priceText: '600.000đ',
    shortPrice: '600k'
  },
  {
    id: '1y',
    code: '1Y',
    label: '1 Năm',
    planName: 'Gói 1 Năm',
    days: 365,
    amount: 900000,
    priceText: '900.000đ',
    shortPrice: '900k'
  },
  {
    id: 'lifetime',
    code: 'VV',
    label: 'Vĩnh Viễn',
    planName: 'Gói Vĩnh Viễn',
    days: 0,
    amount: 1200000,
    priceText: '1.200.000đ',
    shortPrice: '1200k',
    popular: true
  }
];

const DEFAULT_PAYMENT_CONFIG = {
  bankId: 'TPB',
  bankName: 'TPBank',
  accountNumber: '92875666666',
  accountHolder: 'Nguyễn Ngọc Linh',
  accountHolderAscii: 'NGUYEN NGOC LINH',
  transferPrefix: 'Chuyen khoan Linh',
  transferDisplayPrefix: 'Chuyển khoản Linh',
  webhookVerifyUrl: ''
};

let cachedHardwareId = null;

function loadPaymentConfig(appRootDir) {
  const cfgPath = path.join(appRootDir, 'src', 'paymentConfig.json');
  try {
    if (fs.existsSync(cfgPath)) {
      const parsed = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      return { ...DEFAULT_PAYMENT_CONFIG, ...parsed };
    }
  } catch (_) {}
  return { ...DEFAULT_PAYMENT_CONFIG };
}

function savePaymentConfig(appRootDir, partialConfig) {
  const cfgPath = path.join(appRootDir, 'src', 'paymentConfig.json');
  const current = loadPaymentConfig(appRootDir);
  const merged = { ...current, ...partialConfig };
  fs.writeFileSync(cfgPath, JSON.stringify(merged, null, 2), 'utf8');
  return merged;
}

/**
 * Lấy Mã Máy (Hardware ID) cố định theo từng máy tính Windows
 */
function getMachineHardwareId() {
  if (cachedHardwareId) return cachedHardwareId;

  const rawParts = [];
  try {
    const regOut = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 3000
    });
    const match = regOut.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    if (match && match[1]) {
      rawParts.push(match[1].trim());
    }
  } catch (_) {}

  const cpus = os.cpus() || [];
  const cpuModel = cpus[0] ? cpus[0].model.trim() : 'GENERIC_CPU';
  rawParts.push(cpuModel);
  rawParts.push(os.platform());
  rawParts.push(os.arch());
  if (rawParts.length === 3) {
    rawParts.push(os.hostname());
  }

  const combined = rawParts.join('|NLAI_SALT_2026|');
  const hashHex = crypto.createHash('sha256').update(combined).digest('hex').toUpperCase();
  cachedHardwareId = `NLAI-${hashHex.slice(0, 4)}-${hashHex.slice(4, 8)}-${hashHex.slice(8, 12)}`;
  return cachedHardwareId;
}

/**
 * Kiểm tra chống sửa/xóa bản quyền thương hiệu Nguyễn Linh AI 0967981918
 */
function verifyBrandIntegrity(appRootDir) {
  try {
    const indexHtmlPath = path.join(appRootDir, 'public', 'index.html');
    if (!fs.existsSync(indexHtmlPath)) {
      return {
        intact: false,
        reason: 'Không tìm thấy file giao diện public/index.html.'
      };
    }
    const html = fs.readFileSync(indexHtmlPath, 'utf8');
    const hasName = html.includes(AUTHOR_NAME);
    const hasPhone = html.includes(AUTHOR_PHONE);

    if (!hasName || !hasPhone) {
      return {
        intact: false,
        reason: `Thông tin bản quyền "${AUTHOR_NAME} • ${AUTHOR_PHONE}" đã bị thay đổi! Vui lòng khôi phục nguyên bản.`
      };
    }
    return { intact: true };
  } catch (err) {
    return {
      intact: false,
      reason: 'Lỗi kiểm tra tính toàn vẹn thương hiệu: ' + err.message
    };
  }
}

function formatDurationCountdown(ms) {
  const safeMs = Math.max(0, Number(ms) || 0);
  const totalSec = Math.floor(safeMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const hh = String(hours).padStart(2, '0');
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  if (days > 0) {
    return `${days}n ${hh}:${mm}:${ss}`;
  }
  return `${hh}:${mm}:${ss}`;
}

/**
 * Ký & xác thực gói dữ liệu Dùng thử 2 ngày theo Mã Máy (chống xóa thư mục để reset giờ dùng thử)
 */
function signTrialRecord(record) {
  const data = `${record.hwid}|${record.startedAt}|${record.expiresAt}|${record.lastSeenAt}`;
  const sig = crypto.createHmac('sha256', TRIAL_SECRET_SALT).update(data).digest('hex');
  return Buffer.from(JSON.stringify({ ...record, sig }), 'utf8').toString('base64');
}

function parseTrialRecord(encoded, expectedHwid) {
  if (!encoded || typeof encoded !== 'string') return null;
  try {
    const obj = JSON.parse(Buffer.from(encoded.trim(), 'base64').toString('utf8'));
    if (!obj || obj.hwid !== expectedHwid || !obj.startedAt || !obj.expiresAt || !obj.sig) {
      return null;
    }
    const data = `${obj.hwid}|${obj.startedAt}|${obj.expiresAt}|${obj.lastSeenAt || obj.startedAt}`;
    const expectedSig = crypto.createHmac('sha256', TRIAL_SECRET_SALT).update(data).digest('hex');
    if (expectedSig !== obj.sig) return null;
    return {
      hwid: obj.hwid,
      startedAt: Number(obj.startedAt),
      expiresAt: Number(obj.expiresAt),
      lastSeenAt: Number(obj.lastSeenAt || obj.startedAt)
    };
  } catch (_) {
    return null;
  }
}

function readTrialFromRegistry(hwid) {
  try {
    const out = execSync(`reg query "${TRIAL_REG_KEY}" /v StateBlob`, {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 2000
    });
    const m = out.match(/StateBlob\s+REG_SZ\s+([^\r\n]+)/i);
    if (m && m[1]) {
      return parseTrialRecord(m[1].trim(), hwid);
    }
  } catch (_) {}
  return null;
}

function writeTrialToRegistry(blob) {
  try {
    execSync(`reg add "${TRIAL_REG_KEY}" /v StateBlob /t REG_SZ /d "${blob}" /f`, {
      stdio: 'ignore',
      timeout: 2000
    });
  } catch (_) {}
}

function getOrInitMachineFreeTrial(hwid, appRootDir) {
  const localAppData = process.env.LOCALAPPDATA || os.homedir();
  const appDataTrialPath = path.join(localAppData, '.nlai_mfs2_trial.dat');
  const projectTrialPath = path.join(appRootDir, 'Project_Data', 'trial_state.dat');

  const records = [];
  const regRec = readTrialFromRegistry(hwid);
  if (regRec) records.push(regRec);

  for (const fp of [appDataTrialPath, projectTrialPath]) {
    try {
      if (fs.existsSync(fp)) {
        const rec = parseTrialRecord(fs.readFileSync(fp, 'utf8'), hwid);
        if (rec) records.push(rec);
      }
    } catch (_) {}
  }

  const now = Date.now();
  let startedAt = now;
  let maxLastSeen = now;

  if (records.length > 0) {
    startedAt = Math.min(...records.map((r) => r.startedAt));
    maxLastSeen = Math.max(now, ...records.map((r) => r.lastSeenAt || r.startedAt));
  }

  const expiresAt = startedAt + FREE_TRIAL_MS;
  const canonical = {
    hwid,
    startedAt,
    expiresAt,
    lastSeenAt: maxLastSeen
  };

  // Lưu đồng bộ vào cả 3 nơi (chỉ ghi lại nếu mới tạo hoặc cách lần ghi trước >= 60s để tối ưu I/O)
  const prevLatest = records.length > 0 ? Math.max(...records.map((r) => r.lastSeenAt || 0)) : 0;
  if (records.length < 3 || now - prevLatest >= 60000) {
    const blob = signTrialRecord(canonical);
    writeTrialToRegistry(blob);
    try {
      fs.writeFileSync(appDataTrialPath, blob, 'utf8');
    } catch (_) {}
    try {
      const pDir = path.dirname(projectTrialPath);
      if (!fs.existsSync(pDir)) fs.mkdirSync(pDir, { recursive: true });
      fs.writeFileSync(projectTrialPath, blob, 'utf8');
    } catch (_) {}
  }

  // Chống lùi giờ đồng hồ máy tính
  const clockTampered = now + 5 * 60 * 1000 < maxLastSeen;
  const effectiveNow = clockTampered ? maxLastSeen : now;
  const remainingMs = Math.max(0, expiresAt - effectiveNow);
  const valid = !clockTampered && remainingMs > 0;

  return {
    valid,
    isTrial: true,
    expired: !valid,
    clockTampered,
    startedAt,
    expiresAtMs: expiresAt,
    expiresAt: new Date(expiresAt).toISOString(),
    expiresAtFormatted: new Date(expiresAt).toLocaleString('vi-VN'),
    remainingMs,
    daysRemaining: valid ? formatDurationCountdown(remainingMs) : 'Đã hết hạn',
    customerName: 'Khách hàng Dùng thử',
    planName: 'Dùng thử Miễn phí (2 Ngày)',
    reason: clockTampered
      ? 'Phát hiện thời gian hệ thống bị lùi lại. Vui lòng chỉnh đúng giờ hoặc kích hoạt Key bản quyền!'
      : valid
      ? 'Đang trong 2 ngày dùng thử miễn phí.'
      : 'Đã hết 2 ngày dùng thử miễn phí. Vui lòng chọn gói bên dưới để kích hoạt tự động hoặc nhập mã Key!'
  };
}

/**
 * Giải mã & kiểm tra chữ ký RSA của License Key
 */
function verifyLicenseKey(keyString, currentHwid) {
  if (!keyString || typeof keyString !== 'string') {
    return { valid: false, reason: 'Chưa nhập mã kích hoạt bản quyền (License Key).' };
  }

  const trimmed = keyString.trim();
  const parts = trimmed.split('.');
  if (parts.length !== 3 || parts[0] !== 'NLKEY') {
    return { valid: false, reason: 'Định dạng License Key không hợp lệ (Phải bắt đầu bằng NLKEY....).' };
  }

  const [, payloadB64, sigB64] = parts;

  try {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(payloadB64);
    verifier.end();

    const sigBuffer = Buffer.from(sigB64, 'base64url');
    const isSignatureValid = verifier.verify(PUBLIC_KEY, sigBuffer);

    if (!isSignatureValid) {
      return { valid: false, reason: 'Chữ ký số License Key không hợp lệ!' };
    }

    const payloadJson = Buffer.from(payloadB64, 'base64url').toString('utf8');
    const payload = JSON.parse(payloadJson);

    const normalizedCurrent = String(currentHwid || '').trim().toUpperCase();
    const normalizedTarget = String(payload.hwid || '').trim().toUpperCase();

    if (normalizedTarget !== 'ALL-MACHINES' && normalizedTarget !== normalizedCurrent) {
      return {
        valid: false,
        reason: `Key này thuộc Mã Máy [${normalizedTarget}], không khớp với máy hiện tại [${normalizedCurrent}].`
      };
    }

    const now = Date.now();
    const exp = Number(payload.exp || 0);
    if (exp > 0 && now > exp) {
      const expDateStr = new Date(exp).toLocaleString('vi-VN');
      return {
        valid: false,
        expired: true,
        isTrial: false,
        expiresAtMs: exp,
        remainingMs: 0,
        reason: `License Key đã hết hạn lúc ${expDateStr}. Vui lòng chọn gói gia hạn bên dưới!`,
        payload
      };
    }

    const remainingMs = exp === 0 ? null : Math.max(0, exp - now);
    const daysRemaining = exp === 0 ? 'Vĩnh viễn' : formatDurationCountdown(remainingMs);

    return {
      valid: true,
      isTrial: false,
      reason: 'Bản quyền chính hãng hợp lệ.',
      daysRemaining,
      remainingMs,
      expiresAtMs: exp === 0 ? 0 : exp,
      expiresAt: exp === 0 ? null : new Date(exp).toISOString(),
      expiresAtFormatted: exp === 0 ? 'Vĩnh viễn (Lifetime)' : new Date(exp).toLocaleString('vi-VN'),
      customerName: payload.customer || 'Khách hàng VIP',
      planName: payload.plan || (exp === 0 ? 'Vĩnh viễn' : 'Theo thời hạn'),
      issuedAt: payload.iat ? new Date(payload.iat).toLocaleString('vi-VN') : '',
      payload
    };
  } catch (err) {
    return {
      valid: false,
      reason: 'Không thể giải mã License Key: ' + err.message
    };
  }
}

class LicenseManager {
  constructor(appRootDir) {
    this.appRootDir = appRootDir;
    this.licenseFilePath = path.join(appRootDir, 'Project_Data', 'license.dat');
  }

  getHardwareId() {
    return getMachineHardwareId();
  }

  getPricingAndBankInfo() {
    const payCfg = loadPaymentConfig(this.appRootDir);
    return {
      plans: PRICING_PLANS,
      bank: {
        bankId: payCfg.bankId,
        bankName: payCfg.bankName,
        accountNumber: payCfg.accountNumber,
        accountHolder: payCfg.accountHolder,
        accountHolderAscii: payCfg.accountHolderAscii,
        transferPrefix: payCfg.transferPrefix,
        transferDisplayPrefix: payCfg.transferDisplayPrefix,
        autoVerifyConfigured: Boolean(payCfg.webhookVerifyUrl && payCfg.webhookVerifyUrl.trim())
      }
    };
  }

  loadSavedKey() {
    try {
      if (fs.existsSync(this.licenseFilePath)) {
        const raw = fs.readFileSync(this.licenseFilePath, 'utf8').trim();
        if (raw) {
          const parsed = JSON.parse(raw);
          return parsed.licenseKey || '';
        }
      }
    } catch (_) {}
    return '';
  }

  saveKey(licenseKey) {
    const dir = path.dirname(this.licenseFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(
      this.licenseFilePath,
      JSON.stringify(
        {
          licenseKey: String(licenseKey || '').trim(),
          activatedAt: new Date().toISOString(),
          hwid: this.getHardwareId()
        },
        null,
        2
      ),
      'utf8'
    );
  }

  getLicenseStatus() {
    const hwid = this.getHardwareId();
    const brandCheck = verifyBrandIntegrity(this.appRootDir);
    const { plans, bank } = this.getPricingAndBankInfo();

    if (!brandCheck.intact) {
      return {
        valid: false,
        tampered: true,
        hwid,
        authorName: AUTHOR_NAME,
        authorPhone: AUTHOR_PHONE,
        plans,
        bank,
        reason: brandCheck.reason
      };
    }

    const savedKey = this.loadSavedKey();
    if (savedKey) {
      const verification = verifyLicenseKey(savedKey, hwid);
      return {
        ...verification,
        hwid,
        authorName: AUTHOR_NAME,
        authorPhone: AUTHOR_PHONE,
        plans,
        bank
      };
    }

    // Nếu chưa có Key trả phí -> Tự động kích hoạt & đếm ngược gói Dùng thử Miễn phí 2 ngày cho máy khách!
    const trialStatus = getOrInitMachineFreeTrial(hwid, this.appRootDir);
    return {
      ...trialStatus,
      hwid,
      authorName: AUTHOR_NAME,
      authorPhone: AUTHOR_PHONE,
      plans,
      bank
    };
  }

  activateLicense(keyString) {
    const hwid = this.getHardwareId();
    const brandCheck = verifyBrandIntegrity(this.appRootDir);
    if (!brandCheck.intact) {
      throw new Error(brandCheck.reason);
    }

    const check = verifyLicenseKey(keyString, hwid);
    if (!check.valid) {
      throw new Error(check.reason);
    }

    this.saveKey(keyString);
    return this.getLicenseStatus();
  }

  deactivateLicense() {
    try {
      if (fs.existsSync(this.licenseFilePath)) {
        fs.unlinkSync(this.licenseFilePath);
      }
    } catch (_) {}
    return this.getLicenseStatus();
  }

  /**
   * Tạo đơn thanh toán VietQR theo gói khách hàng chọn
   */
  async createPaymentOrder(planId) {
    const plan = PRICING_PLANS.find((p) => p.id === planId);
    if (!plan) {
      throw new Error('Gói bản quyền đã chọn không hợp lệ.');
    }

    const hwid = this.getHardwareId();
    const payCfg = loadPaymentConfig(this.appRootDir);

    // Tạo mã đối soát ngắn gọn gắn liền với Mã Máy + Gói (VD: DCF050631M)
    const compactHwid = hwid.replace(/[^A-Z0-9]/g, '').slice(-6);
    const orderCode = `${compactHwid}${plan.code}`;
    const transferContent = `${payCfg.transferPrefix} ${orderCode}`.trim();
    const transferDisplay = `${payCfg.transferDisplayPrefix} ${orderCode}`.trim();

    const qrUrl =
      `https://img.vietqr.io/image/${encodeURIComponent(payCfg.bankId)}-${encodeURIComponent(
        payCfg.accountNumber
      )}-compact2.png` +
      `?amount=${plan.amount}` +
      `&addInfo=${encodeURIComponent(transferContent)}` +
      `&accountName=${encodeURIComponent(payCfg.accountHolderAscii)}`;

    // Đăng ký trước đơn chờ lên Google Apps Script (nếu đã cấu hình URL) để hỗ trợ đối soát tức thì
    const verifyUrl = (payCfg.webhookVerifyUrl || '').trim();
    if (verifyUrl && /^https?:\/\//i.test(verifyUrl)) {
      try {
        const u = new URL(verifyUrl);
        u.searchParams.set('action', 'create_order');
        u.searchParams.set('hwid', hwid);
        u.searchParams.set('planId', plan.id);
        u.searchParams.set('planName', plan.planName);
        u.searchParams.set('days', String(plan.days));
        u.searchParams.set('amount', String(plan.amount));
        u.searchParams.set('orderCode', orderCode);
        await fetch(u.toString(), { method: 'GET', redirect: 'follow' }).catch(() => {});
      } catch (_) {}
    }

    return {
      orderCode,
      hwid,
      plan,
      bankName: payCfg.bankName,
      accountNumber: payCfg.accountNumber,
      accountHolder: payCfg.accountHolder,
      amount: plan.amount,
      amountFormatted: plan.priceText,
      transferContent,
      transferDisplay,
      qrUrl,
      createdAt: Date.now()
    };
  }

  /**
   * Kiểm tra giao dịch chuyển khoản qua Google Apps Script Webhook và tự động kích hoạt Key ngay khi thành công
   */
  async checkPaymentAndAutoActivate({ planId, orderCode }) {
    const plan = PRICING_PLANS.find((p) => p.id === planId);
    if (!plan) {
      throw new Error('Gói kiểm tra không hợp lệ.');
    }

    const hwid = this.getHardwareId();
    const payCfg = loadPaymentConfig(this.appRootDir);
    const verifyUrl = (payCfg.webhookVerifyUrl || '').trim();

    if (!verifyUrl || !/^https?:\/\//i.test(verifyUrl)) {
      return {
        paid: false,
        configured: false,
        message: 'Đang chờ xác nhận giao dịch từ hệ thống ngân hàng...'
      };
    }

    try {
      const u = new URL(verifyUrl);
      u.searchParams.set('action', 'check_order');
      u.searchParams.set('hwid', hwid);
      u.searchParams.set('planId', plan.id);
      u.searchParams.set('planName', plan.planName);
      u.searchParams.set('days', String(plan.days));
      u.searchParams.set('amount', String(plan.amount));
      u.searchParams.set('orderCode', String(orderCode || '').trim());

      const res = await fetch(u.toString(), {
        method: 'GET',
        redirect: 'follow',
        headers: { Accept: 'application/json' }
      });

      const data = await res.json().catch(() => null);
      if (data && data.paid && data.licenseKey) {
        const activatedStatus = this.activateLicense(data.licenseKey);
        return {
          paid: true,
          configured: true,
          licenseKey: data.licenseKey,
          license: activatedStatus,
          message: `Thanh toán thành công! Đã tự động kích hoạt ${plan.planName}.`
        };
      }

      return {
        paid: false,
        configured: true,
        message: (data && data.message) || 'Chưa ghi nhận biến động số dư khớp đơn này, đang tự động kiểm tra...'
      };
    } catch (err) {
      return {
        paid: false,
        configured: true,
        message: 'Đang kết nối cổng đối soát tự động...'
      };
    }
  }
}

module.exports = {
  PUBLIC_KEY,
  LicenseManager,
  PRICING_PLANS,
  loadPaymentConfig,
  savePaymentConfig,
  getMachineHardwareId,
  verifyBrandIntegrity,
  verifyLicenseKey
};
