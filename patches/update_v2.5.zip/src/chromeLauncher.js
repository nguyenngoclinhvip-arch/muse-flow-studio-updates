const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn, execSync } = require('child_process');

// Ghi nhớ cấu hình proxy đang chạy trên từng cổng để tự động khởi động lại Chrome nếu đổi Proxy
const activePortProxyMap = new Map();

/**
 * Tự động dò đường dẫn cài đặt Google Chrome thật trên máy tính Windows
 */
function findChromeExecutable() {
  const candidates = [];

  if (process.env.PROGRAMFILES) {
    candidates.push(path.join(process.env.PROGRAMFILES, 'Google', 'Chrome', 'Application', 'chrome.exe'));
  }
  if (process.env['PROGRAMFILES(X86)']) {
    candidates.push(path.join(process.env['PROGRAMFILES(X86)'], 'Google', 'Chrome', 'Application', 'chrome.exe'));
  }
  if (process.env.LOCALAPPDATA) {
    candidates.push(path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe'));
  }

  candidates.push(
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'D:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'D:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
  );

  for (const candidate of candidates) {
    try {
      if (candidate && fs.existsSync(candidate)) {
        return candidate;
      }
    } catch (_) {}
  }

  const regKeys = [
    'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe',
    'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe',
    'HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe'
  ];

  for (const key of regKeys) {
    try {
      const output = execSync(`reg query "${key}" /ve`, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
      const match = output.match(/REG_SZ\s+(.+\.exe)/i);
      if (match && match[1]) {
        const regPath = match[1].trim().replace(/^"|"$/g, '');
        if (fs.existsSync(regPath)) {
          return regPath;
        }
      }
    } catch (_) {}
  }

  return null;
}

/**
 * Kiểm tra xem cổng CDP đã có phiên Chrome thật đang lắng nghe hay chưa
 */
function probeCdpPort(port = 9222, timeoutMs = 1800) {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/json/version`, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            const data = JSON.parse(raw);
            resolve({ alive: true, versionInfo: data });
          } catch (_) {
            resolve({ alive: false, versionInfo: null });
          }
        } else {
          resolve({ alive: false, versionInfo: null });
        }
      });
    });

    req.on('error', () => resolve({ alive: false, versionInfo: null }));
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      resolve({ alive: false, versionInfo: null });
    });
  });
}

/**
 * Lấy danh sách các tab đang mở từ CDP JSON endpoint
 */
function fetchCdpTargets(port = 9222, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/json/list`, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(raw));
        } catch (_) {
          resolve([]);
        }
      });
    });
    req.on('error', () => resolve([]));
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      resolve([]);
    });
  });
}

/**
 * Đóng tiến trình Chrome đang lắng nghe trên cổng CDP cụ thể
 */
function killChromeByPort(port = 9222) {
  activePortProxyMap.delete(Number(port));
  try {
    const netstatOut = execSync(`netstat -ano | findstr :${port}`, {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore']
    });
    const lines = netstatOut.split(/\r?\n/).filter(Boolean);
    const pids = new Set();
    for (const line of lines) {
      if (line.includes('LISTENING')) {
        const parts = line.trim().split(/\s+/);
        const pid = Number(parts[parts.length - 1]);
        if (pid && pid > 0) pids.add(pid);
      }
    }
    for (const pid of pids) {
      try {
        execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' });
      } catch (_) {}
    }
    return pids.size > 0;
  } catch (_) {
    return false;
  }
}

/**
 * Ẩn cửa sổ Chrome đang mở trên màn hình xuống chạy ngầm hoàn toàn (Win32 SW_HIDE)
 */
function hideChromeWindowByPort(port = 9222) {
  try {
    const netstatOut = execSync(`netstat -ano | findstr :${port}`, {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore']
    });
    const lines = netstatOut.split(/\r?\n/).filter(Boolean);
    let targetPid = null;
    for (const line of lines) {
      if (line.includes('LISTENING')) {
        const parts = line.trim().split(/\s+/);
        const pid = Number(parts[parts.length - 1]);
        if (pid && pid > 0) {
          targetPid = pid;
          break;
        }
      }
    }
    if (!targetPid) return false;

    const psCode = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Hide {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@
Get-Process -Id ${targetPid} -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.MainWindowHandle -ne 0) {
    [Win32Hide]::ShowWindow($_.MainWindowHandle, 0) | Out-Null
  }
}
`;
    spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psCode], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    }).unref();
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Khởi chạy Google Chrome thật hỗ trợ Proxy riêng cho từng tài khoản
 */
async function launchRealChrome({
  appRootDir,
  port = 9222,
  profileRelativePath = './ChromeProfile_Data',
  targetUrl = 'https://muse.ai',
  headless = false,
  proxyServer = null,
  forceRestart = false,
  forceRestartInHeadless = false
}) {
  const chromeExe = findChromeExecutable();
  if (!chromeExe) {
    throw new Error('Không tìm thấy Google Chrome trên máy tính. Vui lòng cài đặt Google Chrome!');
  }

  const resolvedProfileDir = path.resolve(appRootDir, profileRelativePath);
  if (!fs.existsSync(resolvedProfileDir)) {
    fs.mkdirSync(resolvedProfileDir, { recursive: true });
  }

  const normalizedProxy = proxyServer ? String(proxyServer).trim() : '';
  const prevProxy = activePortProxyMap.get(Number(port));
  const proxyChangedOnRunningPort = prevProxy !== undefined && prevProxy !== normalizedProxy;

  if (forceRestart || forceRestartInHeadless || proxyChangedOnRunningPort) {
    killChromeByPort(port);
    await new Promise((r) => setTimeout(r, 800));
  }

  const existing = await probeCdpPort(port);
  if (existing.alive) {
    activePortProxyMap.set(Number(port), normalizedProxy);
    if (headless) {
      hideChromeWindowByPort(port);
    }
    return {
      alreadyRunning: true,
      headless,
      chromeExe,
      port,
      proxyServer: normalizedProxy || null,
      profileRelativePath,
      resolvedProfileDir,
      versionInfo: existing.versionInfo
    };
  }

  const args = [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${resolvedProfileDir}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-blink-features=AutomationControlled',
    '--mute-audio'
  ];

  if (normalizedProxy) {
    args.push(`--proxy-server=${normalizedProxy}`);
    args.push('--proxy-bypass-list=<-loopback>');
  }

  if (headless) {
    args.push(
      '--headless=new',
      '--window-size=1440,960',
      '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    );
  }

  args.push(targetUrl);

  const child = spawn(chromeExe, args, {
    cwd: appRootDir,
    detached: true,
    stdio: 'ignore',
    windowsHide: Boolean(headless)
  });

  child.unref();

  const startTime = Date.now();
  while (Date.now() - startTime < 15000) {
    const check = await probeCdpPort(port, 1000);
    if (check.alive) {
      activePortProxyMap.set(Number(port), normalizedProxy);
      return {
        alreadyRunning: false,
        headless,
        pid: child.pid,
        chromeExe,
        port,
        proxyServer: normalizedProxy || null,
        profileRelativePath,
        resolvedProfileDir,
        versionInfo: check.versionInfo
      };
    }
    await new Promise((r) => setTimeout(r, 400));
  }

  throw new Error('Không thể khởi tạo kết nối Chrome sau 15 giây. Vui lòng thử bấm Kết nối lại.');
}

module.exports = {
  findChromeExecutable,
  probeCdpPort,
  fetchCdpTargets,
  killChromeByPort,
  hideChromeWindowByPort,
  launchRealChrome
};
