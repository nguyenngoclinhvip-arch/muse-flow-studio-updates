const fs = require('fs');
const path = require('path');

const DEFAULT_BUILT_IN_SKILLS = [
  {
    id: 'skill_fashion_stationary_pose',
    name: '💃 Skill Thời Trang Tạo Dáng Tại Chỗ (Khoe Form)',
    summary: 'Người mẫu đứng tạo dáng mượt tại chỗ, xoay nhẹ khoe trọn đường cắt may, độ ôm/rũ và form dáng chuẩn.',
    isBuiltIn: true,
    instructions: [
      '# SKILL: THỜI TRANG TẠO DÁNG TẠI CHỖ — TÔN ĐƯỜNG NÉT & FORM DÁNG (STATIONARY FASHION POSING)',
      '- NGUYÊN TẮC TẠO DÁNG TẠI CHỖ (STATIONARY FLUID POSING): Người mẫu ĐỨNG TẠI VỊ TRÍ GỐC, tuyệt đối KHÔNG bước đi xa khỏi điểm đứng và không tiến ra sát mép khung hình. Chuyển động diễn ra chậm rãi, êm mượt như người mẫu lookbook chuyên nghiệp: dồn nhẹ trọng tâm hông uyển chuyển, nghiêng xoay thân mình nhẹ nhàng góc 15–30 độ (từ chính diện sang góc nghiêng 3/4 rồi trở về) để khoe trọn phom dáng trước và bên hông trang phục.',
      '- TÔN ĐƯỜNG NÉT & PHOM DÁNG (GARMENT SILHOUETTE & FIT): Làm nổi bật sắc nét đường chiết eo, cầu vai, cổ áo, đường xếp ly, phom quần/chân váy và tỉ lệ tôn dáng cơ thể. Chuyển động tay cực kỳ tinh tế (đặt nhẹ lên eo, vuốt nhẹ tà váy/vạt áo hoặc thả lỏng thanh lịch), KHÔNG vung tay nhanh gây nhòe hình và KHÔNG che khuất chi tiết thiết kế trước ngực/eo.',
      '- BẢO TOÀN SẢN PHẨM & CHẤT LIỆU 100% (ZERO MORPHING): Giữ nguyên tuyệt đối 100% kiểu dáng, màu sắc chuẩn, họa tiết in/thêu, hàng cúc, đường viền may, độ dài trang phục cũng như khuôn mặt và vóc dáng gốc từ ảnh tham chiếu. Thể hiện vật lý vải chân thực (độ đứng phom của vải dày hoặc độ rũ mềm tự nhiên của lụa/voan khi xoay nhẹ người).',
      '- GÓC MÁY & ÁNH SÁNG STUDIO TÔN DÁNG: Máy quay cố định vững chãi hoặc đẩy nhịp cực nhẹ (subtle slow push-in / micro camera glide), giữ toàn bộ trang phục nằm gọn cân đối giữa khung hình. Ánh sáng thương mại dịu mịn tạo khối (soft key light kết hợp rim light nhẹ tách nền), làm bật rõ bề mặt sớ vải và đường cong form dáng cao cấp.'
    ].join('\n')
  },
  {
    id: 'skill_fashion_lookbook',
    name: '👗 Skill Thời Trang & Lookbook',
    summary: 'Giữ chuẩn form dáng trang phục 100%, chuyển động người mẫu tự nhiên, ánh sáng tôn chất vải.',
    isBuiltIn: true,
    instructions: [
      '# SKILL: THỜI TRANG & LOOKBOOK CAO CẤP (FASHION SHOWCASE)',
      '- BẢO TOÀN SẢN PHẨM TUYỆT ĐỐI: Giữ nguyên 100% kiểu dáng trang phục, màu sắc, họa tiết, đường may, logo và chất liệu vải từ ảnh tham chiếu. Tuyệt đối không biến dạng cổ áo, tay áo hoặc form quần/váy.',
      '- CHUYỂN ĐỘNG NGƯỜI MẪU: Người mẫu bước đi uyển chuyển tự tin (subtle runway walk), xoay nhẹ thân trên 15-25 độ tinh tế để khoe độ rũ tự nhiên của tà váy/áo theo chuyển động vật lý thật.',
      '- BIỂU CẢM & THẦN THÁI: Khuôn mặt giữ nguyên đường nét gốc, ánh mắt tự nhiên, thần thái sang trọng cuốn hút.',
      '- GÓC MÁY & ÁNH SÁNG: Máy quay gimbal trượt mượt tầm trung đến toàn thân (smooth tracking shot), ánh sáng studio mềm mại hoặc nắng vàng tự nhiên tôn lên bề mặt chất liệu vải sắc nét chuẩn thương mại.'
    ].join('\n')
  },
  {
    id: 'skill_home_appliance',
    name: '🏠 Skill Gia Dụng & Tiện Ích',
    summary: 'Quay cận cảnh công năng sản phẩm gia dụng sắc nét, thao tác sử dụng thực tế, không gian sáng sạch.',
    isBuiltIn: true,
    instructions: [
      '# SKILL: GIA DỤNG & TIỆN ÍCH THÔNG MINH (HOME APPLIANCE DEMO)',
      '- BẢO TOÀN HÌNH KHỐI SẢN PHẨM: Giữ chuẩn xác 100% cấu tạo, tỉ lệ kích thước, nút bấm, nhãn hiệu và màu sắc của thiết bị/đồ gia dụng trong ảnh tham chiếu. Không làm méo cạnh hay thêm chi tiết lạ.',
      '- TRÌNH DIỄN CÔNG NĂNG: Thể hiện rõ hoạt động thực tế mượt mà của sản phẩm (ví dụ: hơi nước bốc nhẹ, đèn báo sáng tinh tế, bàn tay thao tác nhẹ nhàng tự nhiên, sản phẩm vận hành êm ái).',
      '- BỐI CẢNH: Không gian căn hộ/phòng bếp hiện đại, gọn gàng, sang trọng, có chiều sâu hậu cảnh mờ nhẹ (shallow depth of field).',
      '- GÓC MÁY & ÁNH SÁNG: Góc máy thương mại lia chậm từ trung cảnh vào cận cảnh chi tiết đắt giá (smooth push-in), ánh sáng tự nhiên ban ngày trong trẻo làm nổi bật độ hoàn thiện cao cấp.'
    ].join('\n')
  },
  {
    id: 'skill_beauty_cosmetics',
    name: '💄 Skill Mỹ Phẩm & Review Làm Đẹp',
    summary: 'Tôn hiệu ứng bóng mượt bao bì mỹ phẩm, làn da căng mịn tự nhiên, ánh sáng bokeh sang trọng.',
    isBuiltIn: true,
    instructions: [
      '# SKILL: MỸ PHẨM & CHĂM SÓC SẮC ĐẸP (BEAUTY & COSMETICS COMMERCIAL)',
      '- BẢO TOÀN BAO BÌ & NHÃN HIỆU: Giữ nguyên vẹn 100% thiết kế chai/lọ/hộp mỹ phẩm, chữ in trên nhãn, màu sắc dung dịch và đường nét khuôn mặt nhân vật từ ảnh gốc.',
      '- CHUYỂN ĐỘNG TINH TẾ: Cử chỉ cầm sản phẩm thanh thoát hoặc thoa nhẹ nhàng; tạo hiệu ứng phản chiếu ánh sáng lấp lánh trên thân chai thủy tinh/nhựa cao cấp hoặc giọt tinh chất/nước trong suốt mềm mại.',
      '- CHẤT LƯỢNG HÌNH ẢNH: Kết cấu làn da chân thực mịn màng tự nhiên (natural glowing skin texture), không làm giả nhựa.',
      '- GÓC MÁY & ÁNH SÁNG: Chuyển động slow-motion 30fps mượt mà, ống kính macro/portrait xóa phông bokeh dịu mắt, tông màu sạch sáng chuẩn TVC làm đẹp.'
    ].join('\n')
  },
  {
    id: 'skill_cinematic_story',
    name: '🎬 Skill Điện Ảnh & Kể Chuyện',
    summary: 'Phong cách phim điện ảnh 35mm, diễn xuất chiều sâu, ánh sáng khối nghệ thuật và lia máy giàu cảm xúc.',
    isBuiltIn: true,
    instructions: [
      '# SKILL: ĐIỆN ẢNH & KỂ CHUYỆN (CINEMATIC FILMMAKING 35MM)',
      '- ĐỒNG NHẤT NHÂN VẬT & BỐI CẢNH: Giữ xuyên suốt 100% khuôn mặt, trang phục, vóc dáng nhân vật và kiến trúc môi trường từ khung hình tham chiếu.',
      '- DIỄN XUẤT & NHỊP ĐIỆU: Nhân vật diễn xuất tự nhiên có chiều sâu nội tâm (subtle micro-expressions, nhịp thở, ánh nhìn có hướng đích, chuyển động cơ thể liền mạch không giật cục).',
      '- NGÔN NGỮ ĐIỆN ẢNH: Ống kính điện ảnh 35mm anamorphic, độ sâu trường ảnh tự nhiên, ánh sáng tạo khối giàu tương phản nghệ thuật (volumetric lighting, rim light), hiệu ứng hạt không khí/gió nhẹ sống động.',
      '- CHUYỂN ĐỘNG MÁY QUAY: Máy quay dolly/steadicam đi theo chuyển động nhân vật mượt mà, dẫn dắt mạch truyện liên tục.'
    ].join('\n')
  }
];

function parseMarkdownSkillContent(fileName, rawText) {
  const cleanRaw = String(rawText || '').replace(/\r\n/g, '\n').trim();
  if (!cleanRaw) {
    throw new Error('Nội dung file Skill đang trống.');
  }

  let parsedName = '';
  let parsedSummary = '';
  let body = cleanRaw;

  // Hỗ trợ chuẩn SKILL.md có YAML frontmatter (--- name: ... description: ... ---)
  const fmMatch = cleanRaw.match(/^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  if (fmMatch) {
    const fmBlock = fmMatch[1];
    body = (fmMatch[2] || '').trim() || cleanRaw;

    const nameLine = fmBlock.match(/^\s*(?:name|title)\s*:\s*(.+)$/im);
    if (nameLine && nameLine[1]) {
      parsedName = nameLine[1].trim().replace(/^['"]|['"]$/g, '');
    }

    const descLine = fmBlock.match(/^\s*(?:description|summary)\s*:\s*(.+)$/im);
    if (descLine && descLine[1]) {
      parsedSummary = descLine[1].trim().replace(/^['"]|['"]$/g, '');
    }
  }

  // Nếu chưa có tên từ frontmatter, thử lấy tiêu đề Markdown đầu tiên (# Tiêu đề)
  if (!parsedName) {
    const h1Match = body.match(/^\s*#\s+(.+)$/m);
    if (h1Match && h1Match[1]) {
      parsedName = h1Match[1]
        .replace(/^SKILL\s*:\s*/i, '')
        .trim()
        .slice(0, 80);
    }
  }

  // Nếu vẫn chưa có tên, lấy từ tên file
  if (!parsedName && fileName) {
    const base = path.basename(fileName, path.extname(fileName));
    if (base && base.toLowerCase() !== 'skill') {
      parsedName = base.replace(/[_-]+/g, ' ').trim();
    } else {
      parsedName = `Skill Nhập (${new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })})`;
    }
  }

  if (!parsedSummary) {
    const firstNonHeader = body
      .split('\n')
      .map((l) => l.trim())
      .find((l) => l && !l.startsWith('#') && !l.startsWith('---'));
    if (firstNonHeader) {
      parsedSummary = firstNonHeader.replace(/^[-*•]\s*/, '').slice(0, 140);
    }
  }

  return {
    name: parsedName || 'Skill Tùy Chỉnh',
    summary: parsedSummary || 'Bộ quy tắc Skill nhập từ file',
    instructions: body
  };
}

class SkillManager {
  constructor(appRootDir) {
    this.appRootDir = appRootDir;
    this.dataDir = path.join(appRootDir, 'Project_Data');
    this.skillsFile = path.join(this.dataDir, 'skills_library.json');
    this.skills = [];
    this._ensureLoaded();
  }

  _ensureLoaded() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    if (fs.existsSync(this.skillsFile)) {
      try {
        const raw = fs.readFileSync(this.skillsFile, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.skills)) {
          this.skills = parsed.skills.filter((s) => s && s.id && s.name && s.instructions);
          return;
        }
      } catch (_) {}
    }

    const nowIso = new Date().toISOString();
    this.skills = DEFAULT_BUILT_IN_SKILLS.map((s) => ({
      ...s,
      createdAt: nowIso,
      updatedAt: nowIso
    }));
    this.save();
  }

  save() {
    try {
      if (!fs.existsSync(this.dataDir)) {
        fs.mkdirSync(this.dataDir, { recursive: true });
      }
      fs.writeFileSync(
        this.skillsFile,
        JSON.stringify(
          {
            updatedAt: new Date().toISOString(),
            skills: this.skills
          },
          null,
          2
        ),
        'utf8'
      );
    } catch (err) {
      console.error('Không thể lưu thư viện Skill:', err.message);
    }
  }

  getAllSkills() {
    return this.skills;
  }

  getSkillById(skillId) {
    if (!skillId || skillId === 'none') return null;
    return this.skills.find((s) => s.id === skillId) || null;
  }

  saveSkill({ id, name, summary, instructions, isBuiltIn = false }) {
    const cleanName = String(name || '').trim();
    const cleanInstructions = String(instructions || '').trim();
    const cleanSummary = String(summary || '').trim();

    if (!cleanName) {
      throw new Error('Vui lòng nhập Tên Skill!');
    }
    if (!cleanInstructions) {
      throw new Error('Vui lòng nhập Nội dung chỉ dẫn / Quy tắc của Skill!');
    }

    const nowIso = new Date().toISOString();

    if (id) {
      const existingIdx = this.skills.findIndex((s) => s.id === id);
      if (existingIdx !== -1) {
        this.skills[existingIdx] = {
          ...this.skills[existingIdx],
          name: cleanName,
          summary: cleanSummary || cleanInstructions.split('\n')[0].replace(/^[-*#\s]+/, '').slice(0, 140),
          instructions: cleanInstructions,
          updatedAt: nowIso
        };
        this.save();
        return this.skills[existingIdx];
      }
    }

    const newSkill = {
      id: id || `skill_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      name: cleanName,
      summary: cleanSummary || cleanInstructions.split('\n')[0].replace(/^[-*#\s]+/, '').slice(0, 140),
      instructions: cleanInstructions,
      isBuiltIn: Boolean(isBuiltIn),
      createdAt: nowIso,
      updatedAt: nowIso
    };

    this.skills.unshift(newSkill);
    this.save();
    return newSkill;
  }

  importFromFileOrText({ fileName = '', content = '' }) {
    const raw = String(content || '').trim();
    if (!raw) {
      throw new Error('File hoặc nội dung Skill đang trống!');
    }

    const ext = path.extname(fileName || '').toLowerCase();
    const imported = [];

    // Hỗ trợ file .json (1 skill hoặc mảng nhiều skills)
    if (ext === '.json' || (raw.startsWith('{') || raw.startsWith('['))) {
      try {
        const parsedJson = JSON.parse(raw);
        const list = Array.isArray(parsedJson)
          ? parsedJson
          : Array.isArray(parsedJson.skills)
          ? parsedJson.skills
          : [parsedJson];

        for (const item of list) {
          if (!item || typeof item !== 'object') continue;
          const sName = item.name || item.title || 'Skill JSON';
          const sInst = item.instructions || item.content || item.prompt || item.systemPrompt || '';
          const sSum = item.summary || item.description || '';
          if (String(sInst).trim()) {
            imported.push(
              this.saveSkill({
                name: sName,
                summary: sSum,
                instructions: sInst
              })
            );
          }
        }
        if (imported.length > 0) {
          return imported;
        }
      } catch (_) {
        // Nếu không phải JSON hợp lệ thì đọc như Markdown / Text bên dưới
      }
    }

    const parsedMd = parseMarkdownSkillContent(fileName, raw);
    imported.push(this.saveSkill(parsedMd));
    return imported;
  }

  deleteSkill(skillId) {
    const idx = this.skills.findIndex((s) => s.id === skillId);
    if (idx === -1) {
      throw new Error('Không tìm thấy Skill cần xóa.');
    }
    const [removed] = this.skills.splice(idx, 1);
    this.save();
    return removed;
  }

  restoreDefaultSkills() {
    const nowIso = new Date().toISOString();
    let restoredCount = 0;
    for (const def of [...DEFAULT_BUILT_IN_SKILLS].reverse()) {
      const exists = this.skills.some((s) => s.id === def.id);
      if (!exists) {
        this.skills.unshift({
          ...def,
          createdAt: nowIso,
          updatedAt: nowIso
        });
        restoredCount++;
      }
    }
    if (restoredCount > 0) {
      this.save();
    }
    return { restoredCount, skills: this.skills };
  }
}

module.exports = {
  SkillManager,
  DEFAULT_BUILT_IN_SKILLS,
  parseMarkdownSkillContent
};
