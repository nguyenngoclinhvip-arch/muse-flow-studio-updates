const https = require('https');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFileSync, spawn } = require('child_process');
const { PUBLIC_KEY, verifyBrandIntegrity } = require('./licenseManager');

const DEFAULT_UPDATE_CONFIG = {
  githubOwner: '',
  githubRepo: 'muse-flow-studio-updates',
  branch: 'main',
  customManifestUrl: ''
};

// Danh sách thư mục dữ liệu người dùng tuyệt đối KHÔNG BAO GIỜ ghi đè khi Auto-Update
const PROTECTED_TOP_LEVEL_NAMES = new Set([
  'project_data',
  'output_videos',
  'chromeprofile_data',
  'admin_keygen_rieng_cua_ban',
  'ban_phan_phoi_cho_khach_hang',
  'node_modules',
  'runtime',
  '.git'
]);

function isProtectedTopLevel(entryName) {
  const lower = String(entryName || '').toLowerCase();
  if (PROTECTED_TOP_LEVEL_NAMES.has(lower)) return true;
  if (lower.startsWith('chromeprofile_data')) return true;
  return false;
}

function loadUpdateConfig(appRootDir) {
  const cfgPath = path.join(appRootDir, 'src', 'updateConfig.json');
  try {
    if (fs.existsSync(cfgPath)) {
      const parsed = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      return { ...DEFAULT_UPDATE_CONFIG, ...parsed };
    }
  } catch (_) {}
  return { ...DEFAULT_UPDATE_CONFIG };
}

function saveUpdateConfig(appRootDir, partial) {
  const cfgPath = path.join(appRootDir, 'src', 'updateConfig.json');
  const current = loadUpdateConfig(appRootDir);
  const merged = { ...current, ...partial };
  fs.writeFileSync(cfgPath, JSON.stringify(merged, null, 2), 'utf8');
  return merged;
}

/**
 * So sánh phiên bản dạng 2.3 vs 2.4 vs 2.10 vs 2.3.1
 * Trả về: 1 nếu vA > vB, -1 nếu vA < vB, 0 nếu bằng nhau
 */
function compareVersions(vA, vB) {
  const clean = (v) =>
    String(v || '0')
      .trim()
      .replace(/^v/i, '')
      .split(/[^0-9]+/)
      .filter(Boolean)
      .map((n) => Number(n) || 0);

  const a = clean(vA);
  const b = clean(vB);
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const na = a[i] || 0;
    const nb = b[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

function httpGetBuffer(targetUrl, customHeaders = {}, timeoutMs = 15000, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects < 0) {
      return reject(new Error('Quá nhiều lần chuyển hướng (redirect) khi tải dữ liệu cập nhật.'));
    }

    let parsedUrl;
    try {
      parsedUrl = new URL(targetUrl);
    } catch (err) {
      return reject(new Error(`URL cập nhật không hợp lệ: ${targetUrl}`));
    }

    const client = parsedUrl.protocol === 'http:' ? http : https;
    const req = client.get(
      parsedUrl,
      {
        headers: {
          'User-Agent': 'MuseFlowStudio-AutoUpdater/2.3',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Pragma: 'no-cache',
          ...customHeaders
        },
        timeout: timeoutMs
      },
      (res) => {
        const status = res.statusCode || 0;
        if ([301, 302, 303, 307, 308].includes(status) && res.headers.location) {
          res.resume();
          const nextUrl = new URL(res.headers.location, parsedUrl).toString();
          // Không chuyển tiếp header Accept đặc thù của GitHub API sang CDN đích
          return resolve(httpGetBuffer(nextUrl, {}, timeoutMs, maxRedirects - 1));
        }

        if (status < 200 || status >= 300) {
          let errBody = '';
          res.on('data', (d) => {
            if (errBody.length < 512) errBody += d.toString('utf8');
          });
          res.on('end', () => {
            reject(new Error(`HTTP ${status} từ máy chủ cập nhật.`));
          });
          return;
        }

        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => resolve(Buffer.concat(chunks)));
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('Hết thời gian chờ kết nối máy chủ cập nhật.'));
    });
    req.on('error', (err) => reject(err));
  });
}

function buildSignPayload(manifest) {
  return `NLUPD_V1|${String(manifest.version || '').trim()}|${String(manifest.sha256 || '')
    .trim()
    .toLowerCase()}|${String(manifest.patchFile || '').trim()}`;
}

function verifyManifestSignature(manifest) {
  if (!manifest || !manifest.version || !manifest.sha256 || !manifest.signature) {
    return false;
  }
  try {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(buildSignPayload(manifest));
    verifier.end();
    return verifier.verify(PUBLIC_KEY, Buffer.from(manifest.signature, 'base64url'));
  } catch (_) {
    return false;
  }
}

async function fetchRemoteManifest(cfg) {
  const owner = String(cfg.githubOwner || '').trim();
  const repo = String(cfg.githubRepo || 'muse-flow-studio-updates').trim();
  const branch = String(cfg.branch || 'main').trim();
  const customUrl = String(cfg.customManifestUrl || '').trim();

  const candidateUrls = [];
  if (customUrl) {
    candidateUrls.push({
      url: `${customUrl}${customUrl.includes('?') ? '&' : '?'}t=${Date.now()}`,
      headers: {}
    });
  }
  if (owner && repo) {
    // 1. Ưu tiên GitHub Contents API (độ trễ 0 giây ngay sau khi Admin vừa bấm Phát hành!)
    candidateUrls.push({
      url: `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/contents/version.json?ref=${encodeURIComponent(branch)}`,
      headers: { Accept: 'application/vnd.github.raw+json' }
    });
    // 2. Dự phòng GitHub Raw CDN (không giới hạn lượt truy cập khi hàng nghìn máy mở cùng lúc)
    candidateUrls.push({
      url: `https://raw.githubusercontent.com/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/${encodeURIComponent(branch)}/version.json?t=${Date.now()}`,
      headers: {}
    });
  }

  if (candidateUrls.length === 0) {
    return null;
  }

  let lastErr = null;
  for (const cand of candidateUrls) {
    try {
      const buf = await httpGetBuffer(cand.url, cand.headers, 10000);
      const text = buf.toString('utf8').replace(/^\uFEFF/, '').trim();
      const parsed = JSON.parse(text);
      if (parsed && parsed.version) {
        return parsed;
      }
    } catch (err) {
      lastErr = err;
    }
  }

  if (lastErr) throw lastErr;
  return null;
}

/**
 * Kiểm tra xem có bản cập nhật mới hơn currentVersion trên GitHub không
 */
async function checkForUpdate(appRootDir, currentVersion) {
  const cfg = loadUpdateConfig(appRootDir);
  const isConfigured = Boolean(
    (cfg.githubOwner && String(cfg.githubOwner).trim()) ||
      (cfg.customManifestUrl && String(cfg.customManifestUrl).trim())
  );

  if (!isConfigured) {
    return {
      ok: true,
      configured: false,
      currentVersion,
      updateAvailable: false
    };
  }

  const manifest = await fetchRemoteManifest(cfg);
  if (!manifest || !manifest.version) {
    return {
      ok: true,
      configured: true,
      currentVersion,
      updateAvailable: false
    };
  }

  if (!verifyManifestSignature(manifest)) {
    throw new Error('Bản cập nhật trên máy chủ không khớp chữ ký bảo mật Nguyễn Linh AI.');
  }

  const isNewer = compareVersions(manifest.version, currentVersion) > 0;
  return {
    ok: true,
    configured: true,
    currentVersion,
    latestVersion: String(manifest.version).trim(),
    updateAvailable: isNewer,
    title: manifest.title || `Bản cập nhật MUSE FLOW STUDIO v${manifest.version}`,
    changelog: manifest.changelog || '• Nâng cấp tính năng & tối ưu hiệu suất hoạt động ổn định.',
    publishedAt: manifest.publishedAt || null,
    mandatory: Boolean(manifest.mandatory),
    patchSize: Number(manifest.patchSize) || 0,
    manifest
  };
}

function copyDirSafeUpdate(srcDir, destDir, isRootLevel = false) {
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const ent of entries) {
    if (isRootLevel && isProtectedTopLevel(ent.name)) {
      continue;
    }
    const srcPath = path.join(srcDir, ent.name);
    const destPath = path.join(destDir, ent.name);
    if (ent.isDirectory()) {
      copyDirSafeUpdate(srcPath, destPath, false);
    } else if (ent.isFile()) {
      // Giữ lại cấu hình GitHub nếu gói vá vô tình để trống
      if (ent.name === 'updateConfig.json') {
        try {
          const incoming = JSON.parse(fs.readFileSync(srcPath, 'utf8'));
          if (!incoming.githubOwner && fs.existsSync(destPath)) {
            continue;
          }
        } catch (_) {}
      }
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

/**
 * Tải gói bản vá (~200KB) từ GitHub, xác thực chữ ký RSA-2048 + SHA-256,
 * giải nén an toàn (giữ nguyên 100% License, ChromeProfile, Project_Data, Output_Videos)
 * và tự động khởi động lại Server sang phiên bản mới.
 */
async function performSelfUpdate(appRootDir, currentVersion, onProgress = () => {}) {
  onProgress('checking', 'Đang kiểm tra thông tin phiên bản mới trên GitHub...');
  const cfg = loadUpdateConfig(appRootDir);
  const checkRes = await checkForUpdate(appRootDir, currentVersion);

  if (!checkRes.configured) {
    throw new Error('Chưa cấu hình kho cập nhật GitHub.');
  }
  if (!checkRes.updateAvailable || !checkRes.manifest) {
    return {
      ok: true,
      alreadyLatest: true,
      version: currentVersion,
      message: `Bạn đang sử dụng phiên bản mới nhất (v${currentVersion})!`
    };
  }

  const manifest = checkRes.manifest;
  const owner = String(cfg.githubOwner || '').trim();
  const repo = String(cfg.githubRepo || 'muse-flow-studio-updates').trim();
  const branch = String(cfg.branch || 'main').trim();
  const patchFile = String(manifest.patchFile || `update_v${manifest.version}.zip`).trim();

  const downloadCandidates = [];
  if (manifest.patchUrl) {
    downloadCandidates.push({ url: manifest.patchUrl, headers: {} });
  }
  if (owner && repo) {
    downloadCandidates.push({
      url: `https://raw.githubusercontent.com/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/${encodeURIComponent(branch)}/patches/${encodeURIComponent(patchFile)}`,
      headers: {}
    });
    downloadCandidates.push({
      url: `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/contents/patches/${encodeURIComponent(patchFile)}?ref=${encodeURIComponent(branch)}`,
      headers: { Accept: 'application/vnd.github.raw+json' }
    });
  }

  onProgress('downloading', `Đang tải gói nâng cấp v${manifest.version}...`);
  let zipBuffer = null;
  let lastDlErr = null;
  for (const cand of downloadCandidates) {
    try {
      const buf = await httpGetBuffer(cand.url, cand.headers, 45000);
      if (buf && buf.length > 2000) {
        zipBuffer = buf;
        break;
      }
    } catch (err) {
      lastDlErr = err;
    }
  }

  if (!zipBuffer) {
    throw new Error(`Không thể tải gói cập nhật v${manifest.version}: ${lastDlErr ? lastDlErr.message : 'Lỗi kết nối'}`);
  }

  onProgress('verifying', 'Đang xác thực chữ ký bảo mật & độ toàn vẹn gói nâng cấp...');
  const actualSha256 = crypto.createHash('sha256').update(zipBuffer).digest('hex').toLowerCase();
  if (actualSha256 !== String(manifest.sha256 || '').trim().toLowerCase()) {
    throw new Error('Mã kiểm tra SHA-256 của gói tải về không khớp (tệp có thể bị lỗi đường truyền). Vui lòng thử lại!');
  }

  const tempRoot = path.join(appRootDir, 'Project_Data', 'temp_update', `upd_${Date.now()}`);
  const zipPath = path.join(tempRoot, patchFile);
  const stagingDir = path.join(tempRoot, 'staging');
  fs.mkdirSync(stagingDir, { recursive: true });

  try {
    fs.writeFileSync(zipPath, zipBuffer);

    onProgress('extracting', `Đang giải nén và áp dụng phiên bản v${manifest.version}...`);
    execFileSync(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Bypass',
        '-Command',
        'Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::ExtractToDirectory($env:MFS_ZIP_SRC, $env:MFS_ZIP_DST)'
      ],
      {
        env: {
          ...process.env,
          MFS_ZIP_SRC: zipPath,
          MFS_ZIP_DST: stagingDir
        },
        windowsHide: true,
        timeout: 30000
      }
    );

    if (!fs.existsSync(path.join(stagingDir, 'server.js'))) {
      throw new Error('Gói cập nhật không hợp lệ (thiếu server.js).');
    }

    const brandCheck = verifyBrandIntegrity(stagingDir);
    if (!brandCheck.intact) {
      throw new Error('Gói cập nhật không hợp lệ (sai lệch thông tin bản quyền thương hiệu).');
    }

    copyDirSafeUpdate(stagingDir, appRootDir, true);
  } finally {
    try {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    } catch (_) {}
  }

  onProgress('restarting', `Đã cài xong v${manifest.version}! Đang tự động khởi động lại công cụ...`);

  // Tạo tiến trình con tách rời để đợi server cũ đóng cổng 3888 rồi bật lại server.js mới mượt mà
  const helperDir = path.join(appRootDir, 'Project_Data', 'temp_update');
  fs.mkdirSync(helperDir, { recursive: true });
  const helperScriptPath = path.join(helperDir, 'restart_helper.js');

  const helperCode = `
const { spawn } = require('child_process');
const oldPid = Number(process.argv[2]);
const serverJs = process.argv[3];
const appRoot = process.argv[4];

function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (_) {
    return false;
  }
}

(async () => {
  await new Promise((r) => setTimeout(r, 650));
  for (let i = 0; i < 15; i++) {
    if (!isAlive(oldPid)) break;
    if (i === 6) {
      try { process.kill(oldPid); } catch (_) {}
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  const child = spawn(process.execPath, [serverJs], {
    cwd: appRoot,
    detached: true,
    stdio: 'ignore',
    windowsHide: true
  });
  child.unref();
  process.exit(0);
})();
`;
  fs.writeFileSync(helperScriptPath, helperCode, 'utf8');

  const restarter = spawn(
    process.execPath,
    [helperScriptPath, String(process.pid), path.join(appRootDir, 'server.js'), appRootDir],
    {
      cwd: appRootDir,
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    }
  );
  restarter.unref();

  setTimeout(() => {
    process.exit(0);
  }, 450);

  return {
    ok: true,
    restarting: true,
    oldVersion: currentVersion,
    newVersion: String(manifest.version).trim(),
    message: `Đã cập nhật thành công lên v${manifest.version}! Đang tự làm mới giao diện...`
  };
}

module.exports = {
  loadUpdateConfig,
  saveUpdateConfig,
  compareVersions,
  buildSignPayload,
  verifyManifestSignature,
  checkForUpdate,
  performSelfUpdate
};
