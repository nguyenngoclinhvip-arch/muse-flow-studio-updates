const fs = require('fs');
const path = require('path');
const { parseProxyString } = require('./proxyBridge');

function cleanProjectDisplayName(rawName, fallbackIndex = 1) {
  const cleaned = String(rawName || '')
    .replace(/\s*\(Port\s*\d+\)/gi, '')
    .replace(/\s*\(Tài Khoản Mặc Định\)/gi, '')
    .trim();
  return cleaned || `Dự Án #${fallbackIndex}`;
}

const MAX_ROW_REF_IMAGES = 5;

function normalizeRowReferenceImages(rawList) {
  if (!Array.isArray(rawList)) return [null];
  const valid = [];
  for (const item of rawList) {
    if (item && item.filePath && fs.existsSync(item.filePath)) {
      valid.push({
        ...item,
        slot: valid.length
      });
      if (valid.length >= MAX_ROW_REF_IMAGES) break;
    }
  }
  return valid.length > 0 ? valid : [null];
}

function createDefaultRows(count = 10, existingRows = []) {
  const rows = [];
  for (let i = 1; i <= count; i++) {
    const prev = existingRows.find((r) => r.index === i);
    if (prev) {
      const isAvatarGarbage = prev.fileSize && Number(prev.fileSize) < 550000;
      const normalizedRefs = normalizeRowReferenceImages(prev.referenceImages);
      const prevSampleVid =
        prev.sampleVideo && prev.sampleVideo.filePath && fs.existsSync(prev.sampleVideo.filePath)
          ? prev.sampleVideo
          : null;
      const cleanMsg = String(prev.statusMessage || '')
        .replace(/Sẵn sàng chờ lệnh CDP/gi, 'Sẵn sàng')
        .trim();
      rows.push({
        ...prev,
        index: i,
        prompt: typeof prev.prompt === 'string' ? prev.prompt : '',
        dialogue: typeof prev.dialogue === 'string' ? prev.dialogue : '',
        status: isAvatarGarbage ? 'idle' : prev.status,
        statusMessage: isAvatarGarbage ? 'Sẵn sàng' : (cleanMsg || 'Sẵn sàng'),
        videoUrl: isAvatarGarbage ? null : prev.videoUrl,
        videoFilePath: isAvatarGarbage ? null : prev.videoFilePath,
        remoteVideoUrl: isAvatarGarbage ? null : prev.remoteVideoUrl,
        fileSize: isAvatarGarbage ? null : prev.fileSize,
        referenceImages: normalizedRefs,
        sampleVideo: prevSampleVid
      });
    } else {
      rows.push({
        id: `row_${i}`,
        index: i,
        referenceImages: [null],
        sampleVideo: null,
        prompt: '',
        dialogue: '',
        status: 'idle',
        statusMessage: 'Sẵn sàng',
        videoUrl: null,
        videoFilePath: null,
        remoteVideoUrl: null,
        fileSize: null,
        completedAt: null,
        error: null
      });
    }
  }
  return rows;
}

function createDefaultProjectSettings() {
  return {
    duration: '10s',
    aspectRatio: '9:16',
    resolution: '720p',
    cameraMotion: 'Auto',
    transitionEffect: 'fade', // Hiệu ứng chuyển cảnh mượt cho video nối >= 20s
    activeSkillId: '', // Skill AI áp dụng riêng cho dự án này
    autoPrimeSkillInChat: true, // Tự nạp Skill vào đầu phiên chat muse.ai
    sampleVideo: null, // Video mẫu tham chiếu dùng chung cho toàn dự án
    sampleLearnMotion: true, // Học cử chỉ & chuyển động nhân vật từ video mẫu
    sampleLearnCamera: true, // Học góc máy & chuyển động camera từ video mẫu
    sampleLearnScene: true, // Học bối cảnh & ánh sáng từ video mẫu
    cleanChatPerRow: true, // Tự động mở đoạn Chat sạch chống nhiễu nhân vật giữa các hàng
    nativeAudio: true,
    enableDialogue: false,
    voicePreset: 'auto', // Giọng đọc chung áp dụng đồng nhất cho tất cả các hàng
    voiceCustomNote: '', // Ghi chú chất giọng riêng / tốc độ đọc chung cho toàn dự án
    backgroundMode: true,
    concurrency: 6,
    batchMode: 'barrier_6',
    rowCount: 10,
    targetUrl: 'https://muse.ai',
    injectParamsIntoPrompt: true,
    customSelectors: {
      fileInput: '',
      promptInput: '',
      submitButton: '',
      videoElement: ''
    }
  };
}

const VOICE_PRESETS = [
  {
    id: 'auto',
    label: '🎭 Tự động khớp nhân vật trong ảnh',
    directive:
      "Match the speaker's vocal gender, age, and warm natural Vietnamese/script timbre authentically to the character in the reference image, with clear studio articulation and accurate lip-sync."
  },
  {
    id: 'vi_female_north_young',
    label: '👩 Nữ miền Bắc — Trẻ trung, sáng (Review/Shop)',
    directive:
      'Young Northern Vietnamese female voice (22–26 years old, standard Hanoi accent), bright, cheerful, clear, modern fashion & product presenter tone, crisp Vietnamese tonal pronunciation, warm natural smile in the voice.'
  },
  {
    id: 'vi_female_north_warm',
    label: '👩 Nữ miền Bắc — Ấm áp, sang trọng (Cao cấp)',
    directive:
      'Refined Northern Vietnamese female voice (25–32 years old, standard Hanoi accent), warm, velvety, elegant luxury brand & beauty advisor tone, poised conversational pacing and crystal-clear Vietnamese diction.'
  },
  {
    id: 'vi_female_south_sweet',
    label: '👩 Nữ miền Nam — Ngọt ngào, dễ thương',
    directive:
      'Sweet Southern Vietnamese female voice (20–26 years old, natural Saigon accent), gentle, charming, friendly lifestyle & fashion review tone, soft melodic cadence and clear Vietnamese pronunciation.'
  },
  {
    id: 'vi_female_south_energetic',
    label: '👩 Nữ miền Nam — Năng lượng, chốt đơn (Livestream)',
    directive:
      'Upbeat, energetic Southern Vietnamese female voice (22–28 years old, Saigon accent), enthusiastic, persuasive livestream & TikTok shop host tone, lively rhythm with crisp word-by-word articulation.'
  },
  {
    id: 'vi_female_central_gentle',
    label: '👩 Nữ miền Trung — Dịu dàng, sâu lắng',
    directive:
      'Gentle Central Vietnamese / Hue-inspired female voice (22–28 years old), soft, poetic, sincere and warm conversational delivery with clear intelligible Vietnamese words.'
  },
  {
    id: 'vi_male_north_warm',
    label: '👨 Nam miền Bắc — Trầm ấm, lịch lãm',
    directive:
      'Warm baritone Northern Vietnamese male voice (27–35 years old, standard Hanoi accent), trustworthy, gentlemanly, confident expert & business presenter tone, steady studio microphone clarity.'
  },
  {
    id: 'vi_male_north_energetic',
    label: '👨 Nam miền Bắc — Trẻ trung, năng động',
    directive:
      'Dynamic young Northern Vietnamese male voice (22–28 years old, Hanoi accent), engaging, clear, modern product reviewer & creator tone, lively natural pacing.'
  },
  {
    id: 'vi_male_south_friendly',
    label: '👨 Nam miền Nam — Thân thiện, hào sảng',
    directive:
      'Friendly Southern Vietnamese male voice (24–32 years old, natural Saigon accent), warm, open-hearted, relatable advisor & creator tone, clear Vietnamese pronunciation.'
  },
  {
    id: 'vi_mc_professional',
    label: '🎙️ Giọng MC / BTV — Chuẩn mực, tròn vành rõ chữ',
    directive:
      "Professional Vietnamese TV host / MC voice (matching the character's visual gender), broadcast-grade lapel microphone clarity, impeccable Vietnamese tonal articulation, balanced authoritative yet welcoming cadence."
  },
  {
    id: 'vi_storyteller_cinema',
    label: '🎧 Kể chuyện / Podcast — Trầm lắng, giàu cảm xúc',
    directive:
      "Cinematic Vietnamese podcast & storytelling voice (matching the character's visual gender), intimate, emotionally resonant, calm natural breathing pauses, rich studio warmth."
  },
  {
    id: 'en_female_international',
    label: '🌐 Tiếng Anh (Nữ) — Chuẩn Quốc tế tự nhiên',
    directive:
      'Natural American/International English female voice (23–30 years old), warm, articulate commercial presenter tone, native pronunciation and expressive lip-sync.'
  },
  {
    id: 'en_male_international',
    label: '🌐 Tiếng Anh (Nam) — Trầm ấm chuẩn Quốc tế',
    directive:
      'Natural American/International English male voice (26–35 years old), confident, warm baritone presenter tone, native pronunciation and expressive lip-sync.'
  },
  {
    id: 'custom',
    label: '✍️ Tự mô tả chất giọng riêng...',
    directive:
      'Deliver natural, expressive studio-quality human speech strictly following the custom vocal style note below, with clear articulation and synchronized lip movements.'
  }
];

const VALID_VOICE_PRESETS = new Set(VOICE_PRESETS.map((v) => v.id));

function getVoicePresetDirective(voicePreset = 'auto', voiceCustomNote = '') {
  const cleanId = VALID_VOICE_PRESETS.has(voicePreset) ? voicePreset : 'auto';
  const found = VOICE_PRESETS.find((v) => v.id === cleanId) || VOICE_PRESETS[0];
  const note = String(voiceCustomNote || '').trim();
  if (cleanId === 'custom' && note) {
    return `Custom Vocal Persona (${note}) — Studio-clear human voice, natural cadence, accurate tonal pronunciation, and 100% synchronized lip movements.`;
  }
  if (note) {
    return `${found.directive} Additional vocal nuance: ${note}.`;
  }
  return found.directive;
}

const VALID_TRANSITIONS = new Set([
  'fade',
  'dissolve',
  'hblur',
  'smoothleft',
  'smoothright',
  'zoomin',
  'circleopen',
  'fadeblack',
  'fadewhite',
  'wipeleft',
  'random',
  'none'
]);

const VALID_CAMERA_MOTIONS = new Set([
  'Auto',
  'POV',
  'Consistency',
  'Cinematic Pan',
  'Slow Zoom In',
  'Slow Zoom Out',
  'Dynamic Tracking',
  'Orbit 360'
]);

const MIN_DURATION_SEC = 5;
const MAX_DURATION_SEC = 3600; // Tối đa 60 phút (3600s)

function parseDurationSeconds(rawVal, fallbackSec = 10) {
  if (rawVal === null || rawVal === undefined) return fallbackSec;
  const s = String(rawVal).trim().toLowerCase();
  if (!s) return fallbackSec;

  // Hỗ trợ dạng mm:ss (VD: "02:30" -> 150s)
  const colonMatch = s.match(/^(\d+)\s*:\s*(\d{1,2})$/);
  if (colonMatch) {
    const mins = Number(colonMatch[1]) || 0;
    const secs = Number(colonMatch[2]) || 0;
    const total = mins * 60 + secs;
    if (total > 0) {
      return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(total)));
    }
  }

  // Hỗ trợ dạng phút + giây kết hợp (VD: "2p30s", "2m30s", "2 phút 30")
  const comboMatch = s.match(/^(\d+(?:[.,]\d+)?)\s*(?:m|min|mins|p|phut|phút)\s*(\d+)?\s*(?:s|sec|giay|giây)?$/i);
  if (comboMatch) {
    const mins = parseFloat(comboMatch[1].replace(',', '.')) || 0;
    const extraSec = comboMatch[2] ? Number(comboMatch[2]) || 0 : 0;
    const total = mins * 60 + extraSec;
    if (total > 0) {
      return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(total)));
    }
  }

  // Hỗ trợ dạng giây hoặc số thuần (VD: "120s", "120", "90 giay")
  const secMatch = s.match(/^(\d+(?:[.,]\d+)?)\s*(?:s|sec|secs|giay|giây)?$/i);
  if (secMatch) {
    const val = parseFloat(secMatch[1].replace(',', '.'));
    if (Number.isFinite(val) && val > 0) {
      return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(val)));
    }
  }

  const fallbackParsed = parseInt(s, 10);
  if (Number.isFinite(fallbackParsed) && fallbackParsed > 0) {
    return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, fallbackParsed));
  }

  return fallbackSec;
}

function normalizeDurationSetting(rawVal) {
  return `${parseDurationSeconds(rawVal, 10)}s`;
}

class AccountManager {
  constructor(appRootDir) {
    this.appRootDir = appRootDir;
    this.dataDir = path.join(appRootDir, 'Project_Data');
    this.stateFile = path.join(this.dataDir, 'projects_state.json');
    this.accounts = [];
    this.activeAccountId = 'account_9222';
    this._ensureLoaded();
  }

  _ensureLoaded() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    if (fs.existsSync(this.stateFile)) {
      try {
        const raw = fs.readFileSync(this.stateFile, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.accounts) && parsed.accounts.length > 0) {
          this.accounts = parsed.accounts.map((acc, idx) => {
            const settings = { ...createDefaultProjectSettings(), ...(acc.settings || {}) };
            settings.duration = normalizeDurationSetting(settings.duration);
            if (!VALID_TRANSITIONS.has(settings.transitionEffect)) {
              settings.transitionEffect = 'fade';
            }
            if (!VALID_CAMERA_MOTIONS.has(settings.cameraMotion)) {
              settings.cameraMotion = 'Auto';
            }
            if (!VALID_VOICE_PRESETS.has(settings.voicePreset)) {
              settings.voicePreset = 'auto';
            }
            settings.voiceCustomNote =
              typeof settings.voiceCustomNote === 'string' ? settings.voiceCustomNote.trim().slice(0, 300) : '';
            // Luôn đảm bảo các tính năng ẩn mặc định bật ổn định
            settings.backgroundMode = true;
            settings.nativeAudio = true;
            settings.injectParamsIntoPrompt = true;
            settings.activeSkillId = typeof settings.activeSkillId === 'string' ? settings.activeSkillId.trim() : '';
            if (settings.autoPrimeSkillInChat === undefined) {
              settings.autoPrimeSkillInChat = true;
            }
            if (settings.sampleVideo && (!settings.sampleVideo.filePath || !fs.existsSync(settings.sampleVideo.filePath))) {
              settings.sampleVideo = null;
            }
            settings.sampleLearnMotion = settings.sampleLearnMotion !== false;
            settings.sampleLearnCamera = settings.sampleLearnCamera !== false;
            settings.sampleLearnScene = settings.sampleLearnScene !== false;
            settings.cleanChatPerRow = settings.cleanChatPerRow !== false;
            delete settings.masterFaceImage;
            delete settings.strictFaceLock;
            delete settings.multiPartFaceMode;
            delete settings.postFaceLock;
            delete settings.postFaceLockEnhance;

            const rowCount = Math.max(1, Math.min(200, Number(settings.rowCount) || 10));
            settings.rowCount = rowCount;
            settings.concurrency = Math.max(1, Math.min(20, Number(settings.concurrency) || 6));

            const rows = createDefaultRows(rowCount, acc.rows || []).map((r) => {
              if (
                ['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(r.status) ||
                (r.status === 'error' &&
                  /Quá thời gian|Timeout|locator\.click|Đã dừng tiến trình/i.test(r.error || r.statusMessage || ''))
              ) {
                return {
                  ...r,
                  status: r.videoUrl ? 'completed' : 'idle',
                  statusMessage: r.videoUrl ? 'Hoàn tất' : 'Sẵn sàng',
                  error: null
                };
              }
              return r;
            });

            const cleanName = cleanProjectDisplayName(acc.name, idx + 1);
            const rawProxy = typeof acc.proxy === 'string' ? acc.proxy.trim() : '';
            let proxyLabel = '';
            try {
              const pInfo = parseProxyString(rawProxy);
              proxyLabel = pInfo ? pInfo.displayLabel : '';
            } catch (_) {}

            const customLoginName =
              typeof acc.accountInfo?.customLoginName === 'string'
                ? acc.accountInfo.customLoginName.trim().slice(0, 120)
                : '';
            const agentName =
              typeof acc.accountInfo?.agentName === 'string'
                ? acc.accountInfo.agentName.trim().slice(0, 120)
                : '';
            const cleanDisp = String(acc.accountInfo?.displayName || cleanName)
              .replace(/\s*\(Port\s*\d+\)/gi, '')
              .trim();
            const cleanSub = String(acc.accountInfo?.emailOrHandle || '')
              .replace(/\s*•?\s*Port\s*\d+/gi, '')
              .replace(/\s*\(Port\s*\d+\)/gi, '')
              .trim();
            const resolvedLoginName = customLoginName
              ? agentName && !customLoginName.toLowerCase().includes(agentName.toLowerCase())
                ? `${customLoginName} (${agentName})`
                : customLoginName
              : agentName ||
                acc.accountInfo?.loginName ||
                (cleanDisp && !/chưa kết nối|tài khoản muse\.ai đã lưu|đang chờ đăng nhập/i.test(cleanDisp) && cleanDisp !== cleanName
                  ? cleanDisp
                  : acc.loginVerified
                  ? 'Đã đăng nhập Muse.ai'
                  : 'Chưa đăng nhập');

            return {
              ...acc,
              name: cleanName,
              proxy: rawProxy,
              proxyLabel,
              connected: false,
              loginVerified: Boolean(acc.loginVerified),
              savedAccount: Boolean(acc.savedAccount || acc.loginVerified),
              accountInfo: {
                ...(acc.accountInfo || {}),
                displayName: customLoginName ? resolvedLoginName : agentName || cleanDisp || cleanName,
                loginName: resolvedLoginName,
                customLoginName,
                agentName,
                viewerId: typeof acc.accountInfo?.viewerId === 'string' ? acc.accountInfo.viewerId : '',
                tokenUsage:
                  acc.accountInfo?.tokenUsage && typeof acc.accountInfo.tokenUsage === 'object'
                    ? acc.accountInfo.tokenUsage
                    : null,
                emailOrHandle: cleanSub || (acc.loginVerified ? 'Đã lưu phiên' : 'Chưa đăng nhập'),
                avatarUrl: acc.accountInfo?.avatarUrl || null,
                pageTitle: acc.accountInfo?.pageTitle || '',
                pageUrl: acc.accountInfo?.pageUrl || 'https://muse.ai',
                cookieCount: acc.accountInfo?.cookieCount || 0,
                browserVersion: acc.accountInfo?.browserVersion || '',
                lastConnectedAt: acc.accountInfo?.lastConnectedAt || null
              },
              settings,
              rows
            };
          });
          this.activeAccountId = parsed.activeAccountId || this.accounts[0].id;
          this.save();
          return;
        }
      } catch (err) {
        console.error('Lỗi đọc trạng thái dự án, khởi tạo mặc định:', err.message);
      }
    }

    const defaultAccount = {
      id: 'account_9222',
      name: 'Dự Án #1',
      port: 9222,
      proxy: '',
      proxyLabel: '',
      profileRelativePath: './ChromeProfile_Data',
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: 'Chưa kết nối',
        loginName: 'Chưa đăng nhập',
        customLoginName: '',
        agentName: '',
        viewerId: '',
        tokenUsage: null,
        emailOrHandle: 'Bấm Kết nối để đăng nhập 1 lần',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(10),
      createdAt: new Date().toISOString()
    };

    this.accounts = [defaultAccount];
    this.activeAccountId = defaultAccount.id;
    this.save();
  }

  save() {
    try {
      const payload = {
        activeAccountId: this.activeAccountId,
        updatedAt: new Date().toISOString(),
        accounts: this.accounts
      };
      fs.writeFileSync(this.stateFile, JSON.stringify(payload, null, 2), 'utf8');
    } catch (err) {
      console.error('Không thể lưu trạng thái dự án:', err.message);
    }
  }

  getAllAccounts() {
    return this.accounts;
  }

  getAccount(accountId) {
    return this.accounts.find((a) => a.id === accountId) || null;
  }

  getActiveAccount() {
    return this.getAccount(this.activeAccountId) || this.accounts[0];
  }

  setActiveAccount(accountId) {
    const found = this.getAccount(accountId);
    if (!found) {
      throw new Error(`Không tìm thấy dự án: ${accountId}`);
    }
    this.activeAccountId = found.id;
    this.save();
    return found;
  }

  addAccount({ name, port, proxy }) {
    const rawProxy = typeof proxy === 'string' ? proxy.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsedProxy = parseProxyString(rawProxy);
      proxyLabel = parsedProxy ? parsedProxy.displayLabel : '';
    }

    const usedPorts = new Set(this.accounts.map((a) => Number(a.port)));
    let assignedPort = Number(port);
    if (!assignedPort || assignedPort < 1024 || assignedPort > 65535 || usedPorts.has(assignedPort)) {
      assignedPort = 9222;
      while (usedPorts.has(assignedPort)) {
        assignedPort++;
      }
    }

    const accountNumber = this.accounts.length + 1;
    const cleanName = cleanProjectDisplayName(name, accountNumber);
    const id = `account_${assignedPort}_${Date.now().toString(36)}`;
    const profileRelativePath =
      assignedPort === 9222 ? './ChromeProfile_Data' : `./ChromeProfile_Data_Port_${assignedPort}`;

    const newAcc = {
      id,
      name: cleanName,
      port: assignedPort,
      proxy: rawProxy,
      proxyLabel,
      profileRelativePath,
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: cleanName,
        loginName: 'Chưa đăng nhập',
        customLoginName: '',
        agentName: '',
        viewerId: '',
        tokenUsage: null,
        emailOrHandle: 'Chưa đăng nhập',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(10),
      createdAt: new Date().toISOString()
    };

    this.accounts.push(newAcc);
    this.activeAccountId = newAcc.id;
    this.save();
    return newAcc;
  }

  updateAccountProxy(accountId, rawProxyInput) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    const rawProxy = typeof rawProxyInput === 'string' ? rawProxyInput.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsed = parseProxyString(rawProxy);
      proxyLabel = parsed ? parsed.displayLabel : '';
    }

    const changed = (acc.proxy || '') !== rawProxy;
    acc.proxy = rawProxy;
    acc.proxyLabel = proxyLabel;
    if (changed) {
      acc._proxyChanged = true;
    }
    this.save();
    return { account: acc, changed };
  }

  resetProjectRows(accountId) {
    const acc = this.getAccount(accountId);
    if (!acc) {
      throw new Error('Không tìm thấy dự án cần làm mới.');
    }

    for (const row of acc.rows || []) {
      if (Array.isArray(row.referenceImages)) {
        for (const img of row.referenceImages) {
          if (img && img.filePath && fs.existsSync(img.filePath)) {
            try {
              fs.unlinkSync(img.filePath);
            } catch (_) {}
          }
        }
      }
      if (row.sampleVideo && row.sampleVideo.filePath && fs.existsSync(row.sampleVideo.filePath)) {
        try {
          fs.unlinkSync(row.sampleVideo.filePath);
        } catch (_) {}
      }
    }

    const rowCount = Math.max(1, Math.min(200, Number(acc.settings?.rowCount) || 10));
    acc.rows = createDefaultRows(rowCount, []);
    this.save();
    return acc;
  }

  deleteOrResetAccount(accountId, { wipeProfileDir = true } = {}) {
    const idx = this.accounts.findIndex((a) => a.id === accountId);
    if (idx === -1) {
      throw new Error('Không tìm thấy tài khoản cần xóa.');
    }

    const targetAcc = this.accounts[idx];
    const resolvedProfile = path.resolve(this.appRootDir, targetAcc.profileRelativePath);

    if (wipeProfileDir && fs.existsSync(resolvedProfile)) {
      try {
        fs.rmSync(resolvedProfile, { recursive: true, force: true });
      } catch (_) {}
    }

    if (this.accounts.length > 1) {
      this.accounts.splice(idx, 1);
      if (this.activeAccountId === accountId) {
        this.activeAccountId = this.accounts[0].id;
      }
    } else {
      fs.mkdirSync(resolvedProfile, { recursive: true });
      targetAcc.connected = false;
      targetAcc.loginVerified = false;
      targetAcc.savedAccount = false;
      targetAcc.accountInfo = {
        displayName: 'Chưa kết nối',
        loginName: 'Chưa đăng nhập',
        customLoginName: '',
        agentName: '',
        viewerId: '',
        tokenUsage: null,
        emailOrHandle: 'Sẵn sàng đăng nhập tài khoản mới',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      };
    }

    this.save();
    return this.getActiveAccount();
  }

  updateAccountSettings(accountId, partialSettings) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    acc.settings = {
      ...acc.settings,
      ...partialSettings,
      customSelectors: {
        ...(acc.settings.customSelectors || {}),
        ...(partialSettings.customSelectors || {})
      }
    };

    if (partialSettings.duration !== undefined) {
      acc.settings.duration = normalizeDurationSetting(partialSettings.duration);
    }

    if (partialSettings.transitionEffect !== undefined && !VALID_TRANSITIONS.has(acc.settings.transitionEffect)) {
      acc.settings.transitionEffect = 'fade';
    }

    if (partialSettings.cameraMotion !== undefined && !VALID_CAMERA_MOTIONS.has(acc.settings.cameraMotion)) {
      acc.settings.cameraMotion = 'Auto';
    }

    delete acc.settings.masterFaceImage;
    delete acc.settings.strictFaceLock;
    delete acc.settings.multiPartFaceMode;
    delete acc.settings.postFaceLock;
    delete acc.settings.postFaceLockEnhance;

    if (partialSettings.voicePreset !== undefined && !VALID_VOICE_PRESETS.has(acc.settings.voicePreset)) {
      acc.settings.voicePreset = 'auto';
    }

    if (partialSettings.voiceCustomNote !== undefined) {
      acc.settings.voiceCustomNote = String(partialSettings.voiceCustomNote || '').trim().slice(0, 300);
    }

    if (partialSettings.concurrency !== undefined) {
      acc.settings.concurrency = Math.max(1, Math.min(20, Number(partialSettings.concurrency) || 6));
    }

    if (partialSettings.rowCount !== undefined) {
      const targetCount = Math.max(1, Math.min(200, Number(partialSettings.rowCount) || 10));
      acc.settings.rowCount = targetCount;
      acc.rows = createDefaultRows(targetCount, acc.rows);
    }

    if (partialSettings.sampleLearnMotion !== undefined) {
      acc.settings.sampleLearnMotion = Boolean(partialSettings.sampleLearnMotion);
    }
    if (partialSettings.sampleLearnCamera !== undefined) {
      acc.settings.sampleLearnCamera = Boolean(partialSettings.sampleLearnCamera);
    }
    if (partialSettings.sampleLearnScene !== undefined) {
      acc.settings.sampleLearnScene = Boolean(partialSettings.sampleLearnScene);
    }
    if (partialSettings.cleanChatPerRow !== undefined) {
      acc.settings.cleanChatPerRow = Boolean(partialSettings.cleanChatPerRow);
    }

    this.save();
    return acc;
  }

  updateAccountCustomLoginName(accountId, rawLoginName) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    const cleanCustom = typeof rawLoginName === 'string' ? rawLoginName.trim().slice(0, 120) : '';
    const agentName = typeof acc.accountInfo?.agentName === 'string' ? acc.accountInfo.agentName.trim() : '';
    const computedLoginName = cleanCustom
      ? agentName && !cleanCustom.toLowerCase().includes(agentName.toLowerCase())
        ? `${cleanCustom} (${agentName})`
        : cleanCustom
      : agentName || (acc.loginVerified ? 'Đã đăng nhập Muse.ai' : 'Chưa đăng nhập');

    acc.accountInfo = {
      ...(acc.accountInfo || {}),
      customLoginName: cleanCustom,
      loginName: computedLoginName,
      displayName: computedLoginName
    };
    this.save();
    return acc;
  }

  setGlobalSampleVideo(accountId, videoMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');

    const prevVid = acc.settings?.sampleVideo || null;
    if (prevVid && prevVid.filePath && (!videoMeta || prevVid.filePath !== videoMeta.filePath)) {
      if (fs.existsSync(prevVid.filePath)) {
        try {
          fs.unlinkSync(prevVid.filePath);
        } catch (_) {}
      }
    }

    acc.settings.sampleVideo = videoMeta ? { ...videoMeta } : null;
    this.save();
    return acc;
  }

  setRowSampleVideo(accountId, rowIndex, videoMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    const prevVid = row.sampleVideo || null;
    if (prevVid && prevVid.filePath && (!videoMeta || prevVid.filePath !== videoMeta.filePath)) {
      if (fs.existsSync(prevVid.filePath)) {
        try {
          fs.unlinkSync(prevVid.filePath);
        } catch (_) {}
      }
    }

    row.sampleVideo = videoMeta ? { ...videoMeta } : null;
    this.save();
    return row;
  }

  updateRow(accountId, rowIndex, patch) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    Object.assign(row, patch);
    this.save();
    return row;
  }

  setRowReferenceImage(accountId, rowIndex, slotIndex, imageMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    const slot = Math.max(0, Math.min(MAX_ROW_REF_IMAGES - 1, Number(slotIndex) || 0));
    const validList = Array.isArray(row.referenceImages)
      ? row.referenceImages.filter((img) => img && img.filePath && fs.existsSync(img.filePath))
      : [];

    if (!imageMeta) {
      if (slot < validList.length) {
        const removed = validList.splice(slot, 1)[0];
        if (removed && removed.filePath && fs.existsSync(removed.filePath)) {
          try {
            fs.unlinkSync(removed.filePath);
          } catch (_) {}
        }
      }
    } else if (slot < validList.length) {
      const prevImg = validList[slot];
      if (prevImg && prevImg.filePath && prevImg.filePath !== imageMeta.filePath && fs.existsSync(prevImg.filePath)) {
        try {
          fs.unlinkSync(prevImg.filePath);
        } catch (_) {}
      }
      validList[slot] = { ...imageMeta };
    } else if (validList.length < MAX_ROW_REF_IMAGES) {
      validList.push({ ...imageMeta });
    } else {
      const lastIdx = MAX_ROW_REF_IMAGES - 1;
      const prevImg = validList[lastIdx];
      if (prevImg && prevImg.filePath && prevImg.filePath !== imageMeta.filePath && fs.existsSync(prevImg.filePath)) {
        try {
          fs.unlinkSync(prevImg.filePath);
        } catch (_) {}
      }
      validList[lastIdx] = { ...imageMeta };
    }

    row.referenceImages = normalizeRowReferenceImages(validList);
    this.save();
    return row;
  }

  appendRowReferenceImages(accountId, rowIndex, imageMetas = [], { replaceAll = false } = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy tài khoản.');
    const row = acc.rows.find((r) => r.index === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy hàng số ${rowIndex}`);

    let validList = Array.isArray(row.referenceImages)
      ? row.referenceImages.filter((img) => img && img.filePath && fs.existsSync(img.filePath))
      : [];

    const incomingPaths = new Set((imageMetas || []).map((m) => m && m.filePath).filter(Boolean));
    if (replaceAll) {
      for (const oldImg of validList) {
        if (oldImg && oldImg.filePath && !incomingPaths.has(oldImg.filePath) && fs.existsSync(oldImg.filePath)) {
          try {
            fs.unlinkSync(oldImg.filePath);
          } catch (_) {}
        }
      }
      validList = [];
    }

    let addedCount = 0;
    let skippedCount = 0;
    for (const meta of imageMetas || []) {
      if (!meta || !meta.filePath) continue;
      if (validList.length < MAX_ROW_REF_IMAGES) {
        validList.push({ ...meta });
        addedCount++;
      } else {
        skippedCount++;
        if (fs.existsSync(meta.filePath)) {
          try {
            fs.unlinkSync(meta.filePath);
          } catch (_) {}
        }
      }
    }

    row.referenceImages = normalizeRowReferenceImages(validList);
    this.save();
    return {
      row,
      addedCount,
      skippedCount,
      totalOnRow: validList.length,
      maxPerRow: MAX_ROW_REF_IMAGES
    };
  }
}

module.exports = {
  AccountManager,
  MAX_ROW_REF_IMAGES,
  VOICE_PRESETS,
  VALID_VOICE_PRESETS,
  VALID_CAMERA_MOTIONS,
  getVoicePresetDirective,
  normalizeRowReferenceImages,
  createDefaultRows,
  createDefaultProjectSettings,
  parseDurationSeconds,
  normalizeDurationSetting
};
