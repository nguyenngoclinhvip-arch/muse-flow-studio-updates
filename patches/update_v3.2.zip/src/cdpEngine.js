const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright-core');
const {
  launchRealChrome,
  probeCdpPort,
  killChromeByPort,
  hideChromeWindowByPort
} = require('./chromeLauncher');
const {
  ensureChromeProxyArg,
  stopProxyBridge
} = require('./proxyBridge');
const {
  ensureUniversalPlayableMp4,
  extractLastFrameFromVideo,
  concatExtendedPartFiles,
  extractSampleVideoMotionGrid
} = require('./videoEditor');
const { parseDurationSeconds, getVoicePresetDirective } = require('./accountManager');

function formatHumanDurationLabel(sec) {
  const n = Math.max(1, Math.round(Number(sec) || 10));
  if (n < 60) return `${n}s`;
  const mins = Math.floor(n / 60);
  const rem = n % 60;
  return rem === 0 ? `${mins} phút (${n}s)` : `${mins}p${String(rem).padStart(2, '0')}s (${n}s)`;
}

function formatCompactTokens(num) {
  const v = Number(num);
  if (!Number.isFinite(v) || v <= 0) return '0';
  if (v >= 1e12) return `${(v / 1e12).toFixed(2).replace(/\.?0+$/, '')}T`;
  if (v >= 1e9) return `${(v / 1e9).toFixed(2).replace(/\.?0+$/, '')}B`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(2).replace(/\.?0+$/, '')}M`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(1).replace(/\.0$/, '')}K`;
  return Math.round(v).toLocaleString('en-US');
}

function parseHumanTokenString(rawStr) {
  if (!rawStr) return 0;
  const m = String(rawStr).match(/([\d.,]+)\s*([KMBT])?\s*tokens?\s*left/i);
  if (!m) return 0;
  const base = parseFloat(m[1].replace(/,/g, ''));
  if (!Number.isFinite(base) || base <= 0) return 0;
  const unit = (m[2] || '').toUpperCase();
  const mult = unit === 'T' ? 1e12 : unit === 'B' ? 1e9 : unit === 'M' ? 1e6 : unit === 'K' ? 1e3 : 1;
  return base * mult;
}

function extractMuseAgentNameFromTitle(rawTitle) {
  if (!rawTitle || typeof rawTitle !== 'string') return '';
  const m = rawTitle.trim().match(/^Chat\s*[—–-]\s*(.+)$/i);
  if (!m || !m[1]) return '';
  const candidate = m[1].trim();
  if (!candidate || /^(muse|muse\.ai|meta|meta\s*ai|chat|new\s*chat)$/i.test(candidate)) {
    return '';
  }
  return candidate;
}

/**
 * Chuẩn hóa dấu ngoặc kép ("...", “...”, «...») và trích xuất danh sách từng câu thoại nằm trong "..."
 */
function extractQuotedDialogueList(rawText) {
  if (!rawText) return [];
  const normalized = String(rawText)
    .replace(/[“”«»„‟]/g, '"')
    .trim();
  if (!normalized) return [];
  const matches = [];
  const regex = /"([^"]+)"/g;
  let m;
  while ((m = regex.exec(normalized)) !== null) {
    const clean = m[1].replace(/\s+/g, ' ').trim();
    if (clean) {
      matches.push(clean);
    }
  }
  return matches;
}

function countWordsInSpeech(text) {
  const s = String(text || '').trim();
  if (!s) return 0;
  return s.split(/\s+/).filter(Boolean).length;
}

/**
 * Tự động chia đoạn thoại dài không đóng ngoặc kép thành các nhịp câu cân đối (~20-23 chữ / 10s)
 */
function splitLongSpeechIntoChunks(rawText, maxChunks = 1, targetWordsPerChunk = 22) {
  const clean = String(rawText || '')
    .replace(/[“”«»„‟"]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) return [];
  if (maxChunks <= 1) return [clean];

  const atomicUnits = clean
    .split(/(?<=[.!?;|])\s+/)
    .map((u) => u.replace(/^[|]+|[|]+$/g, '').trim())
    .filter(Boolean);

  const refinedUnits = [];
  for (const unit of atomicUnits) {
    if (countWordsInSpeech(unit) > Math.round(targetWordsPerChunk * 1.35) && unit.includes(',')) {
      const subParts = unit
        .split(/(?<=,)\s+/)
        .map((sp) => sp.trim())
        .filter(Boolean);
      refinedUnits.push(...subParts);
    } else {
      refinedUnits.push(unit);
    }
  }

  if (refinedUnits.length === 1 && countWordsInSpeech(refinedUnits[0]) > Math.round(targetWordsPerChunk * 1.3)) {
    const words = refinedUnits[0].split(/\s+/).filter(Boolean);
    const neededChunks = Math.min(maxChunks, Math.max(2, Math.ceil(words.length / targetWordsPerChunk)));
    const perChunk = Math.ceil(words.length / neededChunks);
    const wordChunks = [];
    for (let i = 0; i < words.length; i += perChunk) {
      wordChunks.push(words.slice(i, i + perChunk).join(' '));
    }
    return wordChunks;
  }

  const totalWords = countWordsInSpeech(clean);
  const desiredCount = Math.min(
    maxChunks,
    Math.max(1, Math.min(refinedUnits.length, Math.ceil(totalWords / targetWordsPerChunk)))
  );
  if (desiredCount <= 1) return [clean];

  const idealWords = totalWords / desiredCount;
  const result = [];
  let currentBuf = [];
  let currentWords = 0;

  for (let i = 0; i < refinedUnits.length; i++) {
    const u = refinedUnits[i];
    const w = countWordsInSpeech(u);
    const remainingUnits = refinedUnits.length - i;
    const remainingSlots = desiredCount - result.length;

    if (
      currentBuf.length > 0 &&
      remainingSlots > 1 &&
      (currentWords + w > idealWords * 1.28 || remainingUnits < remainingSlots)
    ) {
      result.push(currentBuf.join(' ').trim());
      currentBuf = [u];
      currentWords = w;
    } else {
      currentBuf.push(u);
      currentWords += w;
    }
  }
  if (currentBuf.length > 0) {
    result.push(currentBuf.join(' ').trim());
  }
  return result;
}

/**
 * Tách từng câu thoại trong "..." (hoặc từng dòng/đoạn) gán riêng chính xác cho từng phân đoạn 10s nối tiếp nhau.
 */
function splitDialogueIntoPartSegments({
  rowDialogue = '',
  rowMotionPrompt = '',
  totalParts = 1,
  enableDialogue = false
}) {
  const partsCount = Math.max(1, Number(totalParts) || 1);
  const rawDlg = String(rowDialogue || '').trim();
  const rawMotion = String(rowMotionPrompt || '').trim();

  let sourceType = 'none';
  let rawUnits = [];

  if (rawDlg) {
    const quotedInDlg = extractQuotedDialogueList(rawDlg);
    if (quotedInDlg.length >= 2) {
      sourceType = 'dialogue_box_quotes';
      rawUnits = quotedInDlg;
    } else if (quotedInDlg.length === 1) {
      const singleQuote = quotedInDlg[0];
      if (partsCount > 1 && countWordsInSpeech(singleQuote) > 28) {
        sourceType = 'dialogue_box_plain';
        rawUnits = splitLongSpeechIntoChunks(singleQuote, partsCount, 22);
      } else {
        sourceType = 'dialogue_box_quotes';
        rawUnits = [singleQuote];
      }
    } else {
      const multiLines = rawDlg
        .split(/\r?\n|\s*\|\|\s*|\s+\|\s+/)
        .map((l) => l.replace(/^(?:phần|part|đoạn|nhịp|p)\s*\d+\s*[:.-]\s*/i, '').trim())
        .filter(Boolean);
      if (multiLines.length >= 2) {
        sourceType = 'dialogue_box_lines';
        rawUnits = multiLines;
      } else {
        sourceType = 'dialogue_box_plain';
        rawUnits =
          partsCount > 1 ? splitLongSpeechIntoChunks(rawDlg, partsCount, 22) : [rawDlg.replace(/\s+/g, ' ').trim()];
      }
    }
  } else if (enableDialogue && rawMotion) {
    const inlineQuotes = extractQuotedDialogueList(rawMotion);
    if (inlineQuotes.length > 0) {
      sourceType = 'motion_inline_quotes';
      if (inlineQuotes.length === 1 && partsCount > 1 && countWordsInSpeech(inlineQuotes[0]) > 28) {
        rawUnits = splitLongSpeechIntoChunks(inlineQuotes[0], partsCount, 22);
      } else {
        rawUnits = inlineQuotes;
      }
    }
  }

  const assigned = new Array(partsCount).fill('');
  if (rawUnits.length === 0) {
    return {
      hasExplicitScript: false,
      sourceType,
      rawUnits: [],
      partScripts: assigned
    };
  }

  if (partsCount === 1) {
    assigned[0] = rawUnits.join(' ').replace(/\s+/g, ' ').trim();
  } else if (rawUnits.length <= partsCount) {
    for (let i = 0; i < rawUnits.length; i++) {
      assigned[i] = rawUnits[i];
    }
  } else {
    for (let p = 0; p < partsCount; p++) {
      const startIdx = Math.floor((p * rawUnits.length) / partsCount);
      const endIdx = Math.floor(((p + 1) * rawUnits.length) / partsCount);
      assigned[p] = rawUnits
        .slice(startIdx, endIdx)
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();
    }
  }

  return {
    hasExplicitScript: assigned.some((s) => Boolean(s)),
    sourceType,
    rawUnits,
    partScripts: assigned
  };
}

function sanitizeSkillInstructionsForDialogue(rawSkillText) {
  return String(rawSkillText || '')
    .replace(/no\s+spoken\s+dialogue/gi, 'natural spoken lip-sync enabled')
    .replace(/character\s+mouth\s+does\s+not\s+move(\s+for\s+talking|\s+for\s+speech)?/gi, 'natural lip-sync articulation')
    .replace(/does\s+not\s+talk\s+or\s+move\s+mouth(\s+for\s+speech)?/gi, 'speaks naturally with synchronized lip movements')
    .replace(/cấm\s+mở\s+miệng(\s+nói\s+chuyện)?/gi, 'mở miệng phát âm tự nhiên khớp lời thoại')
    .replace(/không\s+nói\s+chuyện/gi, 'phát âm rõ lời thoại')
    .replace(/mỉm\s+cười\s+khép\s+môi/gi, 'biểu cảm tự nhiên khớp khẩu hình lời thoại');
}

// Kích thước tối thiểu của video thành phẩm thật (600 KB)
// Video hình thú đeo tai nghe (avatar của Muse.ai) chỉ nặng ~350 KB - 376 KB
const MIN_REAL_VIDEO_BYTES = 600 * 1024;

class CdpEngine {
  constructor({ appRootDir, accountManager, skillManager, onEvent }) {
    this.appRootDir = appRootDir;
    this.accountManager = accountManager;
    this.skillManager = skillManager || null;
    this.onEvent = typeof onEvent === 'function' ? onEvent : () => {};
    // Map accountId -> { browser, context, monitorTimer }
    this.connections = new Map();
    // Khóa tuần tự hóa thao tác gắn file + bấm gửi trên cùng 1 khung chat
    this.submitLocks = new Map();
    // Tập hợp các video đã được nhận bởi các hàng (cách ly theo accountId::stableId)
    this.claimedVideoKeys = new Set();
    // Bộ nhớ đệm lưu video thành phẩm theo từng tài khoản (cách ly tuyệt đối giữa các Chrome Port)
    this.discoveredVideosCache = new Map();
    // Đếm số hàng đang chạy trực tiếp trên từng tài khoản để tránh background monitor tranh chấp
    this.activeExecutions = new Map();
    this.autoCatchRunningSet = new Set();
    // Lưu trạng thái đã nạp Skill vào đầu phiên chat muse.ai cho từng tài khoản
    this.primedAccountSkills = new Map();
    // Bộ điều khiển dừng tiến trình viết Prompt hàng loạt theo Skill
    this.skillPromptAbortControllers = new Map();
    // Bộ nhớ đệm lưu Hồ sơ chuyển động & bối cảnh đã học từ Video mẫu (tránh phân tích lặp lại khi chạy nhiều hàng)
    this.sampleBlueprintCache = new Map();
    this.sampleAnalysisInFlight = new Map();
    this.sampleBlueprintCacheFile = path.join(this.appRootDir, 'Project_Data', 'sample_blueprints_cache.json');
    this._loadSampleBlueprintCache();
    // Đồng bộ thông tin đăng nhập & số dư Token Muse.ai
    this.quotaSyncInFlight = new Map();
    this.lastQuotaSyncAt = new Map();
    // Quản lý phiên Đăng nhập trực tiếp trong App & Popup gọn
    this.popupLoginAccounts = new Set();
    this.inAppLoginContextMap = new Map();
  }

  _loadSampleBlueprintCache() {
    try {
      if (fs.existsSync(this.sampleBlueprintCacheFile)) {
        const parsed = JSON.parse(fs.readFileSync(this.sampleBlueprintCacheFile, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          for (const [k, v] of Object.entries(parsed)) {
            if (v && typeof v === 'object') {
              this.sampleBlueprintCache.set(k, v);
            }
          }
        }
      }
    } catch (_) {}
  }

  _saveSampleBlueprintCache() {
    try {
      const obj = {};
      for (const [k, v] of this.sampleBlueprintCache.entries()) {
        obj[k] = v;
      }
      fs.writeFileSync(this.sampleBlueprintCacheFile, JSON.stringify(obj, null, 2), 'utf8');
    } catch (_) {}
  }

  async _getOrAnalyzeSampleVideoBlueprint(musePage, account, sampleVideo, onProgressMsg = null) {
    if (!sampleVideo || !sampleVideo.filePath || !fs.existsSync(sampleVideo.filePath)) {
      return null;
    }

    const st = fs.statSync(sampleVideo.filePath);
    const cacheKey = `${path.resolve(sampleVideo.filePath).toLowerCase()}|${st.size}|${Math.floor(st.mtimeMs)}`;

    if (this.sampleBlueprintCache.has(cacheKey)) {
      return this.sampleBlueprintCache.get(cacheKey);
    }

    if (this.sampleAnalysisInFlight.has(cacheKey)) {
      if (typeof onProgressMsg === 'function') {
        onProgressMsg(`🎬 Đang đồng bộ hồ sơ chuyển động từ Video mẫu "${sampleVideo.fileName || 'Sample'}"...`);
      }
      return await this.sampleAnalysisInFlight.get(cacheKey);
    }

    const analysisPromise = (async () => {
      const tempGridDir = path.join(this.appRootDir, 'Project_Data', 'temp_editor', 'sample_grids');
      fs.mkdirSync(tempGridDir, { recursive: true });
      const token = Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 4);
      const gridPath = path.join(tempGridDir, `SampleMotionSheet_${token}.jpg`);
      const bpTag = `mfs_sbp_${token}`;
      const doneMarker = `MFS_SBP_DONE_${token}`;
      let dedicatedAnalysisTab = null;

      try {
        if (typeof onProgressMsg === 'function') {
          onProgressMsg(`🎬 Đang trích xuất khung nhịp & học chuyển động từ Video mẫu "${sampleVideo.fileName || 'Sample'}"...`);
        }

        const gridInfo = await extractSampleVideoMotionGrid(this.appRootDir, sampleVideo.filePath, gridPath);

        // Mở tab phụ cách ly hoàn toàn để phân tích Video mẫu rồi đóng ngay,
        // tuyệt đối KHÔNG để khuôn mặt diễn viên trong Video mẫu làm nhiễu luồng Chat tạo video chính!
        let workPage = musePage;
        try {
          dedicatedAnalysisTab = await musePage.context().newPage();
          await dedicatedAnalysisTab
            .goto(account.settings?.targetUrl || 'https://muse.ai', {
              waitUntil: 'domcontentloaded',
              timeout: 35000
            })
            .catch(() => {});
          await dedicatedAnalysisTab
            .waitForSelector('textarea, [contenteditable="true"], [role="textbox"]', { timeout: 9000 })
            .catch(() => {});
          const hasComp = await dedicatedAnalysisTab
            .evaluate(() => Boolean(document.querySelector('textarea, [contenteditable="true"], [role="textbox"]')))
            .catch(() => false);
          if (hasComp) {
            workPage = dedicatedAnalysisTab;
          } else {
            await dedicatedAnalysisTab.close().catch(() => {});
            dedicatedAnalysisTab = null;
          }
        } catch (_) {
          if (dedicatedAnalysisTab) {
            await dedicatedAnalysisTab.close().catch(() => {});
            dedicatedAnalysisTab = null;
          }
        }

        const analyzePrompt = [
          `[TEXT-ONLY MOTION & SCENE BLUEPRINT ANALYZER — ID: ${bpTag}]`,
          `[CRITICAL RULE: DO NOT GENERATE ANY VIDEO OR IMAGE NOW! REPLY WITH PLAIN TEXT ONLY!]`,
          `Attached is a chronological filmstrip (${gridInfo.cols}x${gridInfo.rows} frames, reading left-to-right then top-to-bottom) extracted from a ${gridInfo.durationSec}s Reference Sample Video.`,
          `Your task: Extract ONLY the pure physical choreography, body gestures, camera movement, and background scene/lighting so they can be transferred onto a DIFFERENT character.`,
          `STRICT DECONTAMINATION RULE: DO NOT mention the sample person's face, gender, hair, skin tone, or outfit/clothing details! Refer to the performer generically as "the subject".`,
          ``,
          `Reply in English using EXACTLY these 6 lines (no extra commentary):`,
          `MOTION_BEAT_1: <0%-25% opening stance, body orientation, hand/arm/head gesture & pacing>`,
          `MOTION_BEAT_2: <25%-50% progressive movement, step/turn/weight shift & gesture transition>`,
          `MOTION_BEAT_3: <50%-75% main showcase action, pose dynamics & expressive gesture>`,
          `MOTION_BEAT_4: <75%-100% concluding movement, pose settle & natural finish>`,
          `CAMERA_WORK: <exact shot framing, camera angle/height, and lens movement trajectory (pan/zoom/tracking/static)>`,
          `SCENE_STYLE: <exact background setting/architecture, spatial depth, key/rim lighting direction, color palette & atmosphere>`,
          doneMarker
        ].join('\n');

        if (workPage === musePage) {
          await this._withSubmitLock(account.id, async () => {
            await this._dismissAnyOverlaysAndLightboxes(workPage);
            await this._clearComposerBeforeUpload(workPage);
            await this._uploadReferenceImagesViaCdp(workPage, [gridPath], account.settings?.customSelectors);
            await this._typeAndSubmitPromptViaCdp(workPage, analyzePrompt, bpTag, account.settings?.customSelectors);
          });
        } else {
          await this._dismissAnyOverlaysAndLightboxes(workPage);
          await this._clearComposerBeforeUpload(workPage);
          await this._uploadReferenceImagesViaCdp(workPage, [gridPath], account.settings?.customSelectors);
          await this._typeAndSubmitPromptViaCdp(workPage, analyzePrompt, bpTag, account.settings?.customSelectors);
        }

        let replyText = '';
        let stableText = '';
        let stableSince = Date.now();
        const pollStart = Date.now();

        while (Date.now() - pollStart < 65000) {
          const pollRes = await workPage
            .evaluate(
              ({ tag, marker }) => {
                const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
                let uIdx = -1;
                const tLower = tag.toLowerCase();
                for (let i = allMsgs.length - 1; i >= 0; i--) {
                  if (
                    allMsgs[i].getAttribute('data-message-role') === 'user' &&
                    (allMsgs[i].textContent || '').toLowerCase().includes(tLower)
                  ) {
                    uIdx = i;
                    break;
                  }
                }
                if (uIdx === -1) return { text: '', hasMarker: false };
                const assistantTexts = [];
                for (let j = uIdx + 1; j < allMsgs.length; j++) {
                  if (allMsgs[j].getAttribute('data-message-role') === 'user') break;
                  assistantTexts.push(allMsgs[j].innerText || allMsgs[j].textContent || '');
                }
                const combined = assistantTexts.join('\n').trim();
                return {
                  text: combined,
                  hasMarker: combined.includes(marker) || /SCENE_STYLE\s*:/i.test(combined)
                };
              },
              { tag: bpTag, marker: doneMarker }
            )
            .catch(() => ({ text: '', hasMarker: false }));

          if (pollRes.text) {
            replyText = pollRes.text;
            if (pollRes.hasMarker && replyText.length > 80) {
              await workPage.waitForTimeout(700).catch(() => {});
              break;
            }
            if (replyText !== stableText) {
              stableText = replyText;
              stableSince = Date.now();
            } else if (replyText.length > 100 && Date.now() - stableSince > 3800) {
              break;
            }
          }
          await workPage.waitForTimeout(1000).catch(() => {});
        }

        const extractLine = (label) => {
          const rx = new RegExp(`${label}\\s*:\\s*(.+)`, 'i');
          const m = replyText.match(rx);
          return m ? m[1].replace(new RegExp(doneMarker, 'gi'), '').trim() : '';
        };

        const beats = [
          extractLine('MOTION_BEAT_1'),
          extractLine('MOTION_BEAT_2'),
          extractLine('MOTION_BEAT_3'),
          extractLine('MOTION_BEAT_4')
        ].filter(Boolean);

        const cameraWork = extractLine('CAMERA_WORK');
        const sceneStyle = extractLine('SCENE_STYLE');
        const cleanedFallback = replyText
          .replace(new RegExp(doneMarker, 'gi'), '')
          .replace(/\[TEXT-ONLY[\s\S]*?\]/gi, '')
          .trim()
          .slice(0, 900);

        const blueprint = {
          fileName: sampleVideo.fileName || path.basename(sampleVideo.filePath),
          durationSec: gridInfo.durationSec,
          motionBeats:
            beats.length > 0
              ? beats
              : [
                  cleanedFallback ||
                    'Smooth natural posture transitions, expressive hand and body gestures, and balanced rhythmic pacing.'
                ],
          cameraWork:
            cameraWork ||
            'Steady cinematic framing with smooth, subtle tracking and natural depth-of-field matching the subject motion.',
          sceneStyle:
            sceneStyle ||
            'Cohesive atmospheric setting with flattering directional key light, soft fill, and natural spatial depth.',
          analyzedAt: new Date().toISOString()
        };

        this.sampleBlueprintCache.set(cacheKey, blueprint);
        this._saveSampleBlueprintCache();
        return blueprint;
      } finally {
        if (dedicatedAnalysisTab) {
          try {
            await dedicatedAnalysisTab.close().catch(() => {});
          } catch (_) {}
        }
        try {
          if (fs.existsSync(gridPath)) fs.unlinkSync(gridPath);
        } catch (_) {}
      }
    })();

    this.sampleAnalysisInFlight.set(cacheKey, analysisPromise);
    try {
      return await analysisPromise;
    } finally {
      this.sampleAnalysisInFlight.delete(cacheKey);
    }
  }

  /**
   * Tự động mở Phiên Chat Mới Sạch trên Muse.ai khi an toàn (không có hàng song song khác đang render trên cùng tab)
   * nhằm triệt tiêu 100% hiện tượng "lai nét mặt" từ các ảnh nhân vật ở hàng cũ trong lịch sử hội thoại.
   */
  async _startFreshMuseChatIfSafe(page, account) {
    if (!page || page.isClosed() || !account) return false;
    if (account.settings?.cleanChatPerRow === false) return false;
    // Chỉ mở chat mới khi chỉ có duy nhất 1 hàng đang chạy trên tài khoản này để không ngắt tiến trình render song song
    if ((this.activeExecutions.get(account.id) || 0) > 1) return false;

    try {
      const msgCount = await page
        .evaluate(() => document.querySelectorAll('[data-message-item="true"]').length)
        .catch(() => 0);
      if (msgCount < 2) return false;

      const clickedNewChat = await page
        .evaluate(() => {
          const selectors = [
            '[data-testid="hatch-chat-compose"]',
            'button[aria-label*="New side chat" i]',
            'a[aria-label*="New chat" i]',
            'button[aria-label*="New chat" i]',
            '[data-testid*="new-chat" i]',
            '[data-testid*="create-chat" i]'
          ];
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) {
              el.click();
              return true;
            }
          }
          return false;
        })
        .catch(() => false);

      if (!clickedNewChat) {
        await page
          .goto(account.settings?.targetUrl || 'https://muse.ai', {
            waitUntil: 'domcontentloaded',
            timeout: 25000
          })
          .catch(() => {});
      }

      await page.waitForTimeout(900).catch(() => {});
      await page
        .waitForSelector('textarea, [contenteditable="true"], [role="textbox"]', { timeout: 8000 })
        .catch(() => {});
      this.primedAccountSkills.delete(account.id);
      return true;
    } catch (_) {
      return false;
    }
  }

  _buildSampleVideoTransferBlock(sampleBlueprint, settings = {}, partIdx = 1, totalParts = 1, hasRefImage = false) {
    if (!sampleBlueprint) return '';
    const learnMotion = settings.sampleLearnMotion !== false;
    const learnCamera = settings.sampleLearnCamera !== false;
    const learnScene = settings.sampleLearnScene !== false;

    if (!learnMotion && !learnCamera && !learnScene) {
      return '';
    }

    const lines = [
      `[SAMPLE VIDEO TRANSFER MANDATE — SOURCE: "${sampleBlueprint.fileName}"]`,
      hasRefImage
        ? `• CHARACTER & OUTFIT LOCK (100% STRICT): Keep 100% of the facial identity, hairstyle, body proportions, and exact clothing/garment details from the attached Character Reference Image! NEVER alter the outfit.`
        : ''
    ].filter(Boolean);

    if (learnMotion && Array.isArray(sampleBlueprint.motionBeats) && sampleBlueprint.motionBeats.length > 0) {
      const beats = sampleBlueprint.motionBeats;
      if (totalParts <= 1) {
        lines.push(
          `• LEARNED GESTURE & MOTION CHOREOGRAPHY (REPLICATE CLOSELY): Execute this exact movement progression smoothly from start to finish: ${beats
            .map((b, i) => `(${i + 1}) ${b}`)
            .join(' -> ')}`
        );
      } else {
        const beatIdx = Math.min(beats.length - 1, Math.floor(((partIdx - 1) / totalParts) * beats.length));
        const nextBeatIdx = Math.min(beats.length - 1, Math.floor((partIdx / totalParts) * beats.length));
        const currentBeatText =
          beatIdx === nextBeatIdx
            ? beats[beatIdx]
            : `${beats[beatIdx]} -> transitioning smoothly into: ${beats[nextBeatIdx]}`;
        lines.push(
          `• LEARNED GESTURE & MOTION FOR PART ${partIdx}/${totalParts}: ${currentBeatText} (Full Sample Motion Arc: ${beats.join(
            ' | '
          )})`
        );
      }
    }

    if (learnCamera && sampleBlueprint.cameraWork && (!settings.cameraMotion || settings.cameraMotion === 'Auto')) {
      lines.push(`• LEARNED CAMERA & FRAMING: ${sampleBlueprint.cameraWork}`);
    }

    if (learnScene && sampleBlueprint.sceneStyle) {
      lines.push(
        `• LEARNED SCENE & LIGHTING ATMOSPHERE: Place the character naturally inside this exact setting and lighting style learned from the Sample Video: ${sampleBlueprint.sceneStyle}`
      );
    } else if (!learnScene && hasRefImage) {
      lines.push(
        `• BACKGROUND LOCK (SCENE TRANSFER OFF): Preserve 100% of the original background environment and lighting from the attached Character Reference Image — do NOT replace the background!`
      );
    }

    return lines.join('\n');
  }

  clearAccountVideoCache(accountId) {
    if (!accountId) {
      this.claimedVideoKeys.clear();
      this.discoveredVideosCache.clear();
      this.primedAccountSkills.clear();
      return;
    }
    this.primedAccountSkills.delete(accountId);
    const prefix = `${accountId}::`;
    for (const k of Array.from(this.claimedVideoKeys)) {
      if (k.startsWith(prefix)) this.claimedVideoKeys.delete(k);
    }
    for (const k of Array.from(this.discoveredVideosCache.keys())) {
      if (k.startsWith(prefix)) this.discoveredVideosCache.delete(k);
    }
  }

  _resolveActiveSkill(account, explicitSkill = null) {
    if (explicitSkill && explicitSkill.instructions) {
      return explicitSkill;
    }
    const skillId = account?.settings?.activeSkillId;
    if (skillId && this.skillManager && typeof this.skillManager.getSkillById === 'function') {
      return this.skillManager.getSkillById(skillId);
    }
    return null;
  }

  /**
   * HƯỚNG 3: Tự động nạp quy tắc SKILL.md vào đầu phiên chat muse.ai (1 lần duy nhất cho mỗi Skill)
   * giúp trợ lý muse.ai nắm trọn vẹn phong cách trước khi chạy lô video hoặc viết kịch bản.
   */
  async _ensureSkillPrimedInMuseSession(page, account, activeSkill, onStatusMsg = null) {
    if (!activeSkill || !activeSkill.instructions) return false;
    if (account?.settings?.autoPrimeSkillInChat === false) return false;

    const skillSig = `${activeSkill.id}::${activeSkill.updatedAt || ''}`;
    if (this.primedAccountSkills.get(account.id) === skillSig) {
      return false;
    }

    const marker = `MFS_SKILL_PACK::${activeSkill.id}`;
    const alreadyInDom = await page
      .evaluate((mk) => {
        const userMsgs = Array.from(
          document.querySelectorAll('[data-message-item="true"][data-message-role="user"]')
        );
        return userMsgs.slice(-20).some((el) => (el.textContent || '').includes(mk));
      }, marker)
      .catch(() => false);

    if (alreadyInDom) {
      this.primedAccountSkills.set(account.id, skillSig);
      return false;
    }

    await this._withSubmitLock(account.id, async () => {
      if (this.primedAccountSkills.get(account.id) === skillSig) return;

      if (typeof onStatusMsg === 'function') {
        onStatusMsg(`🧠 Đang nạp "${activeSkill.name}" vào phiên Muse.ai...`);
      }

      const primeTag = `mfs_skill_init_${Date.now().toString(36).slice(-5)}`;
      const primePrompt = [
        `[${marker} — ID: ${primeTag}]`,
        `[SYSTEM SKILL CONFIGURATION — DO NOT GENERATE ANY VIDEO OR IMAGE IN THIS STEP]`,
        `Memorize and strictly apply this Creative Skill Playbook ("${activeSkill.name}") for our upcoming video/script tasks in this session:`,
        `--- BEGIN SKILL.MD ---`,
        String(activeSkill.instructions || '').trim().slice(0, 8500),
        `--- END SKILL.MD ---`,
        `Reply ONLY with one short text confirmation: "SKILL_READY_${primeTag}" and DO NOT render any video yet.`
      ].join('\n');

      await this._clearComposerBeforeUpload(page);
      await this._typeAndSubmitPromptViaCdp(page, primePrompt, primeTag, account.settings?.customSelectors);

      const waitStart = Date.now();
      while (Date.now() - waitStart < 12000) {
        const ackState = await page
          .evaluate((tag) => {
            const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
            const tagLower = tag.toLowerCase();
            let uIdx = -1;
            for (let i = allMsgs.length - 1; i >= 0; i--) {
              if (
                allMsgs[i].getAttribute('data-message-role') === 'user' &&
                (allMsgs[i].textContent || '').toLowerCase().includes(tagLower)
              ) {
                uIdx = i;
                break;
              }
            }
            const after = uIdx !== -1 ? allMsgs.slice(uIdx + 1) : [];
            const assistantAfter = after.filter((el) => el.getAttribute('data-message-role') === 'assistant');
            const lastTxt =
              assistantAfter.length > 0
                ? (assistantAfter[assistantAfter.length - 1].textContent || '').trim()
                : '';
            const hasStopBtn = Boolean(
              document.querySelector(
                'button[aria-label*="Stop" i], button[aria-label*="Cancel" i], [data-testid*="stop" i]'
              )
            );
            return {
              replied: assistantAfter.length > 0 && (lastTxt.toLowerCase().includes(tagLower) || !hasStopBtn),
              hasStopBtn
            };
          }, primeTag)
          .catch(() => ({ replied: false, hasStopBtn: false }));

        if (ackState.replied) break;
        await page.waitForTimeout(600);
      }

      this.primedAccountSkills.set(account.id, skillSig);
    });

    return true;
  }

  stopSkillPromptGeneration(accountId) {
    const ctrl = this.skillPromptAbortControllers.get(accountId);
    if (ctrl) {
      ctrl.abort();
      this.skillPromptAbortControllers.delete(accountId);
      return true;
    }
    return false;
  }

  /**
   * HƯỚNG 2: Dùng Skill + Ảnh tham chiếu trên từng hàng gửi lên muse.ai để AI tự nhìn ảnh
   * và viết kịch bản chuyển động chuẩn điền thẳng vào cột 2. PROMPT CHUYỂN ĐỘNG.
   */
  async generateRowPromptsFromSkill({ accountId, skillId = null, overwriteExisting = false }) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy dự án.');
    }

    if (this.skillPromptAbortControllers.has(account.id)) {
      throw new Error('Dự án đang trong quá trình viết Prompt theo Skill. Vui lòng chờ hoàn tất!');
    }

    const explicitSkill =
      skillId && this.skillManager ? this.skillManager.getSkillById(skillId) : null;
    const activeSkill = this._resolveActiveSkill(account, explicitSkill);
    if (!activeSkill) {
      throw new Error('Vui lòng chọn 1 Skill AI ở cột bên trái trước khi bấm Viết Prompt Theo Skill!');
    }

    const candidateRows = (account.rows || []).filter((r) => {
      const hasImg =
        Array.isArray(r.referenceImages) &&
        r.referenceImages.some((img) => img && img.filePath && fs.existsSync(img.filePath));
      const hasPrompt = Boolean(r.prompt && r.prompt.trim().length > 0);
      if (overwriteExisting) {
        return hasImg || hasPrompt;
      }
      return hasImg && !hasPrompt;
    });

    if (candidateRows.length === 0) {
      const anyRowWithImgOrPrompt = (account.rows || []).some((r) => {
        const hasImg =
          Array.isArray(r.referenceImages) &&
          r.referenceImages.some((img) => img && img.filePath && fs.existsSync(img.filePath));
        return hasImg || Boolean(r.prompt && r.prompt.trim());
      });
      if (anyRowWithImgOrPrompt && !overwriteExisting) {
        throw new Error(
          'Tất cả các hàng có ảnh đều đã có sẵn Prompt! Nếu muốn viết lại đè lên Prompt cũ, hãy chọn ghi đè.'
        );
      }
      throw new Error(
        'Chưa có hàng nào có Ảnh tham chiếu (hoặc gợi ý ngắn)! Hãy thêm ảnh vào các hàng trước.'
      );
    }

    let conn = this.connections.get(account.id);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      await this.launchAndConnect(account.id, { forceVisibleWindow: false });
      conn = this.connections.get(account.id);
    }

    if (account.settings?.backgroundMode !== false) {
      hideChromeWindowByPort(account.port);
    }

    const musePage = await this._getOrCreateMusePage(
      conn.context,
      account.settings?.targetUrl || 'https://muse.ai'
    );

    const authState = await musePage.evaluate(() => {
      const authPane = document.querySelector('[data-testid="native-auth-access-pane"]');
      const loginInput = document.querySelector(
        'input[aria-label*="Mobile number or email" i], input[placeholder*="Mobile number or email" i]'
      );
      const composer = document.querySelector(
        'textarea, [contenteditable="true"], [role="textbox"]:not([aria-label*="Mobile number or email" i])'
      );
      return {
        isLoginGate: Boolean((authPane || loginInput) && !composer)
      };
    });

    if (authState.isLoginGate) {
      throw new Error('Tài khoản chưa đăng nhập muse.ai. Hãy bấm "Kết nối tài khoản" và đăng nhập trước!');
    }

    const abortCtrl = new AbortController();
    this.skillPromptAbortControllers.set(account.id, abortCtrl);
    this.activeExecutions.set(account.id, (this.activeExecutions.get(account.id) || 0) + 1);

    let generatedCount = 0;

    try {
      this.emit('skill_prompt_progress', {
        accountId: account.id,
        running: true,
        completed: 0,
        total: candidateRows.length,
        skillName: activeSkill.name
      });

      await this._ensureSkillPrimedInMuseSession(musePage, account, activeSkill);

      // Chia theo lô thông minh: hàng có >= 2 ảnh (biến hình nhiều bộ đồ) tách riêng 1 hàng/lô để AI nhìn chuẩn từng bộ;
      // hàng 1 ảnh gom tối đa 3 hàng/lô để tốc độ nhanh mà không nhầm thứ tự.
      const chunks = [];
      let currentSingleBatch = [];
      for (const cand of candidateRows) {
        const rowImgs = (cand.referenceImages || []).filter(
          (img) => img && img.filePath && fs.existsSync(img.filePath)
        );
        if (rowImgs.length >= 2) {
          if (currentSingleBatch.length > 0) {
            chunks.push(currentSingleBatch);
            currentSingleBatch = [];
          }
          chunks.push([cand]);
        } else {
          currentSingleBatch.push(cand);
          if (currentSingleBatch.length >= 3) {
            chunks.push(currentSingleBatch);
            currentSingleBatch = [];
          }
        }
      }
      if (currentSingleBatch.length > 0) {
        chunks.push(currentSingleBatch);
      }

      for (const chunk of chunks) {
        if (abortCtrl.signal.aborted) break;

        for (const r of chunk) {
          const updated = this.accountManager.updateRow(account.id, r.index, {
            statusMessage: `🧠 Đang phân tích ảnh & viết Prompt (${activeSkill.name})...`
          });
          this.emit('row_updated', { accountId: account.id, rowIndex: r.index, row: updated });
        }

        const token = Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 4);
        const genTag = `mfs_genp_${token}`;
        const doneMarker = `MFS_GENP_DONE_${token}`;

        const imagePathsToUpload = [];
        const rowDescriptions = [];
        let hasMultiOutfitRowInChunk = false;

        chunk.forEach((r) => {
          const validRowImgs = (r.referenceImages || [])
            .slice(0, 5)
            .filter((img) => img && img.filePath && fs.existsSync(img.filePath));
          const hint = (r.prompt || '').trim();
          if (validRowImgs.length >= 2) {
            hasMultiOutfitRowInChunk = true;
            const slotLabels = validRowImgs.map((img, i) => {
              imagePathsToUpload.push(img.filePath);
              const imgOrder = imagePathsToUpload.length;
              const roleDesc =
                i === 0
                  ? `Gương mặt gốc + Bối cảnh + Bộ trang phục #1`
                  : `Bộ trang phục mới #${i + 1} (biến hình sau cú che quạt/chuyển cảnh)`;
              return `Attached Image #${imgOrder} = ${roleDesc} (${img.savedName || img.fileName})`;
            });
            rowDescriptions.push(
              `- ROW_${r.index} [HÀNG BIẾN HÌNH ${validRowImgs.length} BỘ ĐỒ LIÊN HOÀN]: ${slotLabels.join(' ; ')}${
                hint ? ` | Ý tưởng gốc: "${hint}"` : ''
              }`
            );
          } else if (validRowImgs.length === 1) {
            const validImg = validRowImgs[0];
            imagePathsToUpload.push(validImg.filePath);
            const imgOrder = imagePathsToUpload.length;
            rowDescriptions.push(
              `- ROW_${r.index}: Attached Image #${imgOrder} (${validImg.savedName || validImg.fileName})${
                hint ? ` | Ý tưởng gốc: "${hint}"` : ''
              }`
            );
          } else {
            rowDescriptions.push(`- ROW_${r.index}: Ý tưởng gốc: "${hint}"`);
          }
        });

        const targetDurSec = parseDurationSeconds(account.settings?.duration || '10s', 10);
        const longVideoHint = hasMultiOutfitRowInChunk
          ? ` (Lưu ý: Hàng này đính kèm nhiều bộ trang phục để biến hình liên hoàn — hãy mô tả tuần tự đủ từng Bộ #1 ➔ Bộ cuối bám sát chi tiết từng ảnh đính kèm, ngăn cách rõ từng chặng biến hình bằng từ "rồi", "tiếp theo", "sau đó", giữ nguyên 100% cùng một gương mặt và bối cảnh theo đúng quy tắc Skill)`
          : targetDurSec >= 30
          ? ` (Lưu ý: Dự án đang đặt thời lượng video dài ${formatHumanDurationLabel(
              targetDurSec
            )}, hãy viết mạch hành động chuyển tiếp mượt mà từ 3–5 ý nối nhau bằng từ "rồi", "tiếp theo", "sau đó" để công cụ tự động phân đoạn liền mạch)`
          : ' (dài 2-3 câu, khoảng 35-75 từ, súc tích)';

        const scriptPrompt = [
          `[TEXT-ONLY SCRIPT WRITER — ID: ${genTag}]`,
          `[IMPORTANT: DO NOT GENERATE ANY VIDEO OR IMAGE NOW. REPLY WITH PLAIN TEXT ONLY!]`,
          `Áp dụng nghiêm ngặt bộ quy tắc "${activeSkill.name}":`,
          String(activeSkill.instructions || '').trim().slice(0, 3200),
          ``,
          `Nhiệm vụ: Quan sát kỹ từng ảnh đính kèm / gợi ý theo đúng thứ tự bên dưới và viết cho mỗi hàng 1 câu lệnh Prompt chuyển động quay video bằng tiếng Việt${longVideoHint}, mô tả rõ hành động chủ thể, bảo toàn sản phẩm, góc máy và ánh sáng theo đúng Skill:`,
          ...rowDescriptions,
          ``,
          `ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC (Mỗi hàng đúng 1 dòng, KHÔNG giải thích thừa):`,
          ...chunk.map((r) => `ROW_${r.index}: <nội dung prompt chuyển động chi tiết cho hàng ${r.index}>`),
          doneMarker
        ].join('\n');

        await this._withSubmitLock(account.id, async () => {
          if (abortCtrl.signal.aborted) throw new Error('Đã dừng viết Prompt.');
          await this._dismissAnyOverlaysAndLightboxes(musePage);
          await this._clearComposerBeforeUpload(musePage);
          if (imagePathsToUpload.length > 0) {
            await this._uploadReferenceImagesViaCdp(
              musePage,
              imagePathsToUpload,
              account.settings?.customSelectors
            );
          }
          await this._typeAndSubmitPromptViaCdp(
            musePage,
            scriptPrompt,
            genTag,
            account.settings?.customSelectors
          );
        });

        // Chờ phản hồi văn bản từ Muse.ai
        let replyText = '';
        let stableText = '';
        let stableSince = Date.now();
        const pollStart = Date.now();

        while (Date.now() - pollStart < 75000) {
          if (abortCtrl.signal.aborted) break;

          const pollRes = await musePage
            .evaluate(
              ({ tag, marker }) => {
                const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
                const tagLower = tag.toLowerCase();
                let uIdx = -1;
                for (let i = allMsgs.length - 1; i >= 0; i--) {
                  if (
                    allMsgs[i].getAttribute('data-message-role') === 'user' &&
                    (allMsgs[i].textContent || '').toLowerCase().includes(tagLower)
                  ) {
                    uIdx = i;
                    break;
                  }
                }
                const assistantMsgs = (uIdx !== -1 ? allMsgs.slice(uIdx + 1) : []).filter(
                  (el) => el.getAttribute('data-message-role') === 'assistant'
                );
                const combined = assistantMsgs
                  .map((el) => (el.textContent || '').replace(/^Assistant message:\s*/i, '').trim())
                  .join('\n')
                  .trim();

                const hasStopBtn = Boolean(
                  document.querySelector(
                    'button[aria-label*="Stop" i], button[aria-label*="Cancel" i], [data-testid*="stop" i]'
                  )
                );

                return {
                  text: combined,
                  hasDoneMarker: combined.toUpperCase().includes(marker.toUpperCase()),
                  hasStopBtn
                };
              },
              { tag: genTag, marker: doneMarker }
            )
            .catch(() => ({ text: '', hasDoneMarker: false, hasStopBtn: true }));

          if (pollRes.text) {
            replyText = pollRes.text;
            if (pollRes.hasDoneMarker && !pollRes.hasStopBtn) {
              break;
            }
            if (pollRes.text !== stableText) {
              stableText = pollRes.text;
              stableSince = Date.now();
            } else if (!pollRes.hasStopBtn && pollRes.text.length > 25 && Date.now() - stableSince >= 2600) {
              break;
            }
          }
          await musePage.waitForTimeout(1000);
        }

        // Trích xuất từng dòng ROW_X: ...
        const cleanedLines = String(replyText || '')
          .replace(new RegExp(doneMarker, 'gi'), '')
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean);

        const matchedRowMap = new Map();
        for (const line of cleanedLines) {
          const m = line.match(/^(?:[*#\-\s]*)(?:ROW|HÀNG|HANG)[_\s#-]*0*(\d+)\s*[:\-–]\s*(.+)$/i);
          if (m && m[1] && m[2]) {
            const rNum = Number(m[1]);
            const pVal = m[2].replace(/^["'«]|["'»]$/g, '').replace(/^\*\*|\*\*$/g, '').trim();
            if (pVal.length >= 8) {
              matchedRowMap.set(rNum, pVal);
            }
          }
        }

        // Dự phòng nếu AI đánh số 1., 2., 3. hoặc trả lời 1 đoạn duy nhất khi chunk chỉ có 1 hàng
        if (matchedRowMap.size === 0 && cleanedLines.length > 0) {
          if (chunk.length === 1) {
            const singleClean = cleanedLines
              .filter((l) => !/^(chắc chắn|dưới đây|đây là|ok|tất nhiên)/i.test(l))
              .join(' ')
              .replace(/^1[.)\-:\s]+/, '')
              .trim();
            if (singleClean.length >= 10) {
              matchedRowMap.set(chunk[0].index, singleClean);
            }
          } else {
            let orderIdx = 0;
            for (const line of cleanedLines) {
              const numMatch = line.match(/^(?:[*#\-\s]*)\d+[.)\-:]\s*(.+)$/);
              if (numMatch && numMatch[1] && orderIdx < chunk.length) {
                matchedRowMap.set(chunk[orderIdx].index, numMatch[1].trim());
                orderIdx++;
              }
            }
          }
        }

        for (const r of chunk) {
          const written = matchedRowMap.get(r.index);
          if (written) {
            generatedCount++;
            const updated = this.accountManager.updateRow(account.id, r.index, {
              prompt: written,
              statusMessage: `✨ Đã tạo Prompt (${activeSkill.name})`
            });
            this.emit('row_updated', { accountId: account.id, rowIndex: r.index, row: updated });
          } else {
            const updated = this.accountManager.updateRow(account.id, r.index, {
              statusMessage: 'Sẵn sàng'
            });
            this.emit('row_updated', { accountId: account.id, rowIndex: r.index, row: updated });
          }
        }

        this.emit('skill_prompt_progress', {
          accountId: account.id,
          running: true,
          completed: generatedCount,
          total: candidateRows.length,
          skillName: activeSkill.name
        });
      }

      return {
        generatedCount,
        totalTarget: candidateRows.length,
        skillName: activeSkill.name
      };
    } finally {
      this.skillPromptAbortControllers.delete(account.id);
      const rem = (this.activeExecutions.get(account.id) || 1) - 1;
      if (rem <= 0) {
        this.activeExecutions.delete(account.id);
      } else {
        this.activeExecutions.set(account.id, rem);
      }
      this.emit('skill_prompt_progress', {
        accountId: account.id,
        running: false,
        completed: generatedCount,
        total: candidateRows.length,
        skillName: activeSkill.name
      });
    }
  }

  emit(event, payload) {
    try {
      this.onEvent(event, payload);
    } catch (_) {}
  }

  /**
   * Đảm bảo thao tác đính kèm ảnh + nhập prompt + bấm gửi diễn ra tuần tự từng hàng một,
   * đợi tin nhắn kèm ảnh của hàng trước thực sự được gửi lên khung chat rồi mới gửi hàng tiếp theo.
   */
  async _withSubmitLock(accountId, taskFn, timeoutMs = 120000) {
    const prev = this.submitLocks.get(accountId) || Promise.resolve();
    let release;
    const next = new Promise((resolve) => {
      release = resolve;
    });
    this.submitLocks.set(accountId, prev.then(() => next));
    await prev;
    let timer = null;
    try {
      return await Promise.race([
        taskFn(),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            reject(new Error('Quá thời gian tải ảnh/gửi lệnh (120s) — Đã tự động bỏ qua hàng này để chạy tiếp!'));
          }, timeoutMs);
        })
      ]);
    } finally {
      if (timer) clearTimeout(timer);
      release();
    }
  }

  /**
   * Mở Chrome & Kết nối:
   * - Hỗ trợ chạy ngầm 100% (--headless=new) cho Đăng nhập trực tiếp trong App (forceHeadless = true)
   * - Hỗ trợ khung Popup gọn không thanh địa chỉ (appPopupMode = true) tự đóng chuyển ngầm ngay khi đăng nhập xong
   */
  async launchAndConnect(
    accountId,
    {
      forceVisibleWindow = false,
      appPopupMode = false,
      forceHeadless = false,
      forceRestart = false,
      forceRestartInHeadless = false
    } = {}
  ) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error(`Không tìm thấy tài khoản: ${accountId}`);
    }

    const shouldRunHeadless = Boolean(
      forceHeadless ||
        forceRestartInHeadless ||
        (!forceVisibleWindow &&
          (account.savedAccount || account.loginVerified) &&
          account.settings?.backgroundMode !== false)
    );

    if (forceVisibleWindow && appPopupMode) {
      this.popupLoginAccounts.add(account.id);
    } else if (shouldRunHeadless) {
      this.popupLoginAccounts.delete(account.id);
    }

    const proxyServer = await ensureChromeProxyArg(account.id, account.proxy || '');
    const needRestart = Boolean(forceRestart || account._proxyChanged);
    if (account._proxyChanged || forceRestart || forceRestartInHeadless) {
      delete account._proxyChanged;
      const oldConn = this.connections.get(account.id);
      if (oldConn) {
        if (oldConn.monitorTimer) clearInterval(oldConn.monitorTimer);
        this.connections.delete(account.id);
      }
    }

    // Nếu đang chạy ngầm Headless mà người dùng bấm mở cửa sổ Popup đăng nhập -> dọn connection cũ trước khi đổi chế độ
    if (!shouldRunHeadless) {
      const oldConn = this.connections.get(account.id);
      if (oldConn) {
        const probeBefore = await probeCdpPort(account.port, 800);
        if (probeBefore.alive && /HeadlessChrome/i.test(String(probeBefore.versionInfo?.Browser || ''))) {
          if (oldConn.monitorTimer) clearInterval(oldConn.monitorTimer);
          this.connections.delete(account.id);
        }
      }
    }

    const launchResult = await launchRealChrome({
      appRootDir: this.appRootDir,
      port: account.port,
      profileRelativePath: account.profileRelativePath,
      targetUrl: account.settings?.targetUrl || 'https://muse.ai',
      headless: shouldRunHeadless,
      appPopupMode: Boolean(!shouldRunHeadless && appPopupMode),
      proxyServer,
      forceRestart: needRestart,
      forceRestartInHeadless
    });

    const sessionInfo = await this.connectToRunningChrome(account.id, launchResult.versionInfo);

    if (sessionInfo.loginVerified && !forceVisibleWindow && account.settings?.backgroundMode !== false) {
      hideChromeWindowByPort(account.port);
    }

    return {
      launchResult,
      account: sessionInfo
    };
  }

  async disconnectAndKillAccountChrome(accountId) {
    const account = this.accountManager.getAccount(accountId);
    const conn = this.connections.get(accountId);
    if (conn) {
      if (conn.monitorTimer) clearInterval(conn.monitorTimer);
      try {
        await conn.browser.close();
      } catch (_) {}
      this.connections.delete(accountId);
    }
    await stopProxyBridge(accountId);
    if (account) {
      killChromeByPort(account.port);
      await new Promise((r) => setTimeout(r, 600));
    }
  }

  async connectToRunningChrome(accountId, versionInfo = null) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error(`Không tìm thấy tài khoản: ${accountId}`);

    const existingConn = this.connections.get(account.id);
    if (existingConn && existingConn.browser && existingConn.browser.isConnected()) {
      await this.refreshAccountSessionInfo(account.id);
      return this.accountManager.getAccount(account.id);
    }

    const endpoint = `http://127.0.0.1:${account.port}`;
    const browser = await chromium.connectOverCDP(endpoint, { timeout: 12000 });
    const contexts = browser.contexts();
    const context = contexts.length > 0 ? contexts[0] : await browser.newContext();

    await this._getOrCreateMusePage(context, account.settings?.targetUrl || 'https://muse.ai');

    browser.on('disconnected', () => {
      const conn = this.connections.get(account.id);
      if (conn && conn.monitorTimer) {
        clearInterval(conn.monitorTimer);
      }
      this.connections.delete(account.id);
      // Xóa các blob URL cũ trong cache của tài khoản này vì Chrome đã đóng
      const prefix = `${account.id}::`;
      for (const [k, v] of Array.from(this.discoveredVideosCache.entries())) {
        if (k.startsWith(prefix) && v?.src?.startsWith('blob:')) {
          this.discoveredVideosCache.delete(k);
        }
      }
      account.connected = false;
      this.accountManager.save();
      this.emit('account_status_changed', {
        accountId: account.id,
        connected: false,
        account
      });
    });

    const monitorTimer = setInterval(() => {
      this.refreshAccountSessionInfo(account.id).catch(() => {});
    }, 4000);

    this.connections.set(account.id, {
      browser,
      context,
      monitorTimer,
      versionInfo
    });

    account.connected = true;
    await this.refreshAccountSessionInfo(account.id, true);
    return this.accountManager.getAccount(account.id);
  }

  async _getOrCreateMusePage(context, targetUrl = 'https://muse.ai') {
    const pages = context.pages();
    let musePage = pages.find((p) => !p.isClosed() && p.url().includes('muse.ai'));
    if (musePage) {
      return musePage;
    }

    musePage = pages.find((p) => !p.isClosed() && (p.url() === 'about:blank' || p.url().startsWith('chrome://newtab')));
    if (!musePage) {
      musePage = await context.newPage();
    }

    await musePage.goto(targetUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 45000
    }).catch(() => {});

    return musePage;
  }

  async refreshAccountSessionInfo(accountId, forceEmit = false) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) return null;

    const conn = this.connections.get(accountId);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      const probe = await probeCdpPort(account.port, 1000);
      if (!probe.alive) {
        if (account.connected) {
          account.connected = false;
          this.accountManager.save();
          this.emit('account_status_changed', { accountId: account.id, connected: false, account });
        }
        return account;
      }
      return account;
    }

    try {
      const context = conn.context;
      const pages = context.pages();
      const musePage = pages.find((p) => !p.isClosed() && p.url().includes('muse.ai')) || pages[0];

      let cookies = [];
      try {
        cookies = await context.cookies(['https://muse.ai', 'https://www.muse.ai']);
      } catch (_) {}

      let domInspection = {
        pageTitle: '',
        pageUrl: musePage ? musePage.url() : 'https://muse.ai',
        isLoginScreen: false,
        hasComposer: false,
        extractedUser: null,
        extractedEmail: null,
        avatarUrl: null
      };

      if (musePage && !musePage.isClosed()) {
        try {
          domInspection = await musePage.evaluate(() => {
            const url = window.location.href;
            const title = document.title || '';

            const authPane = document.querySelector('[data-testid="native-auth-access-pane"]');
            const loginInput = document.querySelector(
              'input[aria-label*="Mobile number or email" i], input[placeholder*="Mobile number or email" i], input[type="email"]'
            );
            const composer = document.querySelector(
              'textarea, [contenteditable="true"], [role="textbox"]:not([aria-label*="Mobile number or email" i])'
            );

            const isLoginScreen = Boolean((authPane || loginInput) && !composer);

            let extractedUser = null;
            let extractedEmail = null;
            let avatarUrl = null;

            const profileBtn = document.querySelector(
              '[data-testid*="profile" i], [data-testid*="user" i], [aria-label*="Account" i], [aria-label*="Profile" i]'
            );
            if (profileBtn) {
              const label = profileBtn.getAttribute('aria-label') || profileBtn.textContent || '';
              if (label && label.trim().length > 1 && label.trim().length < 60) {
                extractedUser = label.trim();
              }
            }

            return {
              pageTitle: title,
              pageUrl: url,
              isLoginScreen,
              hasComposer: Boolean(composer),
              extractedUser,
              extractedEmail,
              avatarUrl
            };
          });
        } catch (_) {}
      }

      const hasAuthCookies = cookies.some((c) =>
        /session|token|auth|user|c_user|xs|datr|hatch|muse/i.test(c.name)
      );
      const isLoggedIn = Boolean(
        domInspection.hasComposer ||
        (!domInspection.isLoginScreen && (hasAuthCookies || cookies.length >= 2))
      );

      const prevLoginState = account.loginVerified;
      const prevConnected = account.connected;
      const prevLoginName = account.accountInfo?.loginName || '';

      account.connected = true;
      account.loginVerified = isLoggedIn;
      if (isLoggedIn) {
        account.savedAccount = true;
      }

      // Ưu tiên quét tất cả tab muse.ai đang mở để lấy tên tài khoản/nhân vật từ tiêu đề "Chat — <Tên>"
      let pageTitleAgent = extractMuseAgentNameFromTitle(domInspection.pageTitle);
      if (!pageTitleAgent) {
        for (const p of pages) {
          if (!p || p.isClosed()) continue;
          try {
            const pUrl = p.url() || '';
            if (pUrl.includes('muse.ai')) {
              const pTitle = await p.title().catch(() => '');
              const cand = extractMuseAgentNameFromTitle(pTitle);
              if (cand) {
                pageTitleAgent = cand;
                break;
              }
            }
          } catch (_) {}
        }
      }

      const detectedAgentName = pageTitleAgent || account.accountInfo?.agentName || '';
      const customLoginName =
        typeof account.accountInfo?.customLoginName === 'string' ? account.accountInfo.customLoginName.trim() : '';
      const viewerId = account.accountInfo?.viewerId || '';
      const existingTokenUsage =
        account.accountInfo?.tokenUsage && typeof account.accountInfo.tokenUsage === 'object'
          ? account.accountInfo.tokenUsage
          : null;

      const rawDetectedUser =
        domInspection.extractedEmail || domInspection.extractedUser || detectedAgentName || '';

      const resolvedLoginName = customLoginName
        ? detectedAgentName && !customLoginName.toLowerCase().includes(detectedAgentName.toLowerCase())
          ? `${customLoginName} (${detectedAgentName})`
          : customLoginName
        : rawDetectedUser || (isLoggedIn ? 'Đã đăng nhập Muse.ai' : 'Chưa đăng nhập');

      const statusSubtext = isLoggedIn
        ? `Sẵn sàng chạy ngầm${account.proxyLabel ? ` • ${account.proxyLabel}` : ''}`
        : 'Đăng nhập 1 lần trên Chrome vừa mở';

      account.accountInfo = {
        ...(account.accountInfo || {}),
        displayName: resolvedLoginName,
        loginName: resolvedLoginName,
        customLoginName,
        agentName: detectedAgentName,
        viewerId,
        tokenUsage: existingTokenUsage,
        emailOrHandle: statusSubtext,
        avatarUrl: domInspection.avatarUrl || account.accountInfo?.avatarUrl || null,
        pageTitle: domInspection.pageTitle || 'Chat — Muse',
        pageUrl: domInspection.pageUrl || 'https://muse.ai',
        cookieCount: cookies.length,
        hasComposer: domInspection.hasComposer,
        isLoginScreen: domInspection.isLoginScreen,
        browserVersion: conn.versionInfo?.Browser || 'Google Chrome (CDP)',
        lastConnectedAt: new Date().toISOString()
      };

      this.accountManager.save();

      if (!prevLoginState && isLoggedIn && account.settings?.backgroundMode !== false) {
        const wasPopup = this.popupLoginAccounts.has(account.id);
        this.popupLoginAccounts.delete(account.id);
        setTimeout(async () => {
          hideChromeWindowByPort(account.port);
          // Nếu đăng nhập qua Popup gọn và chưa có luồng chạy nào -> tự động đóng hẳn Popup và chuyển sang chạy ngầm Headless sạch 100%
          if (wasPopup && (this.activeExecutions.get(account.id) || 0) === 0) {
            try {
              await this.launchAndConnect(account.id, {
                forceHeadless: true,
                forceRestartInHeadless: true
              });
              await this.syncAccountQuotaAndProfile(account.id).catch(() => {});
            } catch (_) {}
          } else {
            this.syncAccountQuotaAndProfile(account.id).catch(() => {});
          }
        }, 1400);
      }

      if (forceEmit || prevLoginState !== isLoggedIn || !prevConnected || prevLoginName !== resolvedLoginName) {
        this.emit('account_status_changed', {
          accountId: account.id,
          connected: true,
          loginVerified: isLoggedIn,
          justLoggedIn: !prevLoginState && isLoggedIn,
          account
        });
      }

      if (
        isLoggedIn &&
        musePage &&
        !musePage.isClosed() &&
        (this.activeExecutions.get(account.id) || 0) === 0
      ) {
        this._autoCatchCompletedVideosInBackground(account, musePage, context).catch(() => {});

        const lastQuotaSync = this.lastQuotaSyncAt.get(account.id) || 0;
        if (!existingTokenUsage?.updatedAt || Date.now() - lastQuotaSync > 4 * 60 * 1000) {
          this.syncAccountQuotaAndProfile(account.id).catch(() => {});
        }
      }

      return account;
    } catch (_) {
      return account;
    }
  }

  /**
   * Đọc trạng thái xác thực hiện tại trên trang muse.ai để hiển thị Form Đăng nhập trực tiếp ngay trong phần mềm
   */
  async _readMuseAuthPageState(musePage) {
    if (!musePage || musePage.isClosed()) {
      return {
        step: 'loading',
        isLoggedIn: false,
        heading: 'Đang kết nối Muse.ai...',
        description: '',
        errorText: '',
        isBusy: true
      };
    }

    return await musePage
      .evaluate(() => {
        const isVisible = (el) => {
          if (!el) return false;
          const style = window.getComputedStyle(el);
          if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
          const rect = el.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0;
        };

        const composer = document.querySelector(
          '[data-testid="hatch-chat-compose"], textarea, [contenteditable="true"], [role="textbox"]:not([aria-label*="Mobile number or email" i])'
        );
        if (composer && isVisible(composer)) {
          return {
            step: 'logged_in',
            isLoggedIn: true,
            heading: 'Đã đăng nhập thành công!',
            description: 'Tài khoản Muse.ai đã sẵn sàng hoạt động ngầm 100%.',
            errorText: '',
            isBusy: false
          };
        }

        const authPane =
          document.querySelector('[data-testid="native-auth-access-pane"]') ||
          document.querySelector('form') ||
          document.body;
        const isBusy = authPane?.getAttribute('aria-busy') === 'true';

        const headingEl =
          authPane.querySelector('h1, h2, [role="heading"]') || document.querySelector('h1, h2');
        const heading = (headingEl?.innerText || headingEl?.textContent || '').trim();

        // Trích xuất thông báo lỗi (nếu nhập sai Email / Mật khẩu / OTP)
        let errorText = '';
        const invalidInput = authPane.querySelector('[aria-invalid="true"]');
        if (invalidInput) {
          const descId = invalidInput.getAttribute('aria-describedby');
          if (descId) {
            const errEl = document.getElementById(descId);
            if (errEl && isVisible(errEl)) {
              errorText = (errEl.innerText || errEl.textContent || '').trim();
            }
          }
        }
        if (!errorText) {
          const alertEls = Array.from(
            authPane.querySelectorAll('[role="alert"], [aria-live="polite"], [aria-live="assertive"], p, span, div')
          );
          for (const el of alertEls) {
            if (!isVisible(el)) continue;
            const txt = (el.innerText || el.textContent || '').trim();
            if (
              txt.length > 4 &&
              txt.length < 220 &&
              /invalid|incorrect|wrong|expired|try again|doesn't match|not found|enter a valid|too many|error|couldn't|unable to/i.test(
                txt
              )
            ) {
              errorText = txt;
              break;
            }
          }
        }

        // Mô tả phụ hướng dẫn từ Muse.ai (lọc bỏ câu quảng cáo/SMS mặc định)
        let description = '';
        const paragraphs = Array.from(authPane.querySelectorAll('p')).filter(isVisible);
        for (const p of paragraphs) {
          const t = (p.innerText || p.textContent || '').trim();
          if (
            t &&
            t !== errorText &&
            !/You may receive SMS notifications/i.test(t) &&
            t.length < 260
          ) {
            description = t;
            break;
          }
        }

        // 1. Kiểm tra bước chọn phương thức 2FA (two-factor-method)
        const twoFactorRadios = Array.from(
          authPane.querySelectorAll('input[type="radio"][name="two-factor-method"]')
        );
        if (twoFactorRadios.length > 0) {
          const twoFactorMethods = twoFactorRadios.map((r, idx) => {
            const lbl = r.closest('label') || authPane.querySelector(`label[for="${r.id}"]`);
            return {
              methodId: r.value || String(idx),
              label: (lbl?.innerText || lbl?.textContent || r.value || `Phương thức #${idx + 1}`).trim(),
              checked: Boolean(r.checked)
            };
          });
          return {
            step: 'two_factor_method',
            isLoggedIn: false,
            heading: heading || 'Chọn phương thức xác minh 2 bước',
            description,
            errorText,
            twoFactorMethods,
            isBusy
          };
        }

        // 2. Kiểm tra bước nhập mã OTP / Mã xác nhận 6 số / 2FA code
        const allInputs = Array.from(authPane.querySelectorAll('input')).filter(isVisible);
        const otpSingleInput = allInputs.find((inp) => {
          const al = (inp.getAttribute('aria-label') || '').toLowerCase();
          const ph = (inp.getAttribute('placeholder') || '').toLowerCase();
          const ac = (inp.getAttribute('autocomplete') || '').toLowerCase();
          const im = (inp.getAttribute('inputmode') || '').toLowerCase();
          return (
            ac === 'one-time-code' ||
            al.includes('6-digit') ||
            al.includes('security code') ||
            al.includes('confirmation code') ||
            al === 'code' ||
            ph.includes('confirmation code') ||
            ph === 'code' ||
            (im === 'numeric' && inp.type !== 'password' && !al.includes('mobile') && !al.includes('email'))
          );
        });
        const splitOtpInputs = allInputs.filter(
          (inp) =>
            inp.maxLength === 1 ||
            /digit\s*\d/i.test(inp.getAttribute('aria-label') || '')
        );

        const allButtons = Array.from(authPane.querySelectorAll('button, [role="button"]')).filter(isVisible);
        const canResendCode = allButtons.some((b) =>
          /resend|send.*again|new code|get.*code|try another way/i.test(
            (b.innerText || b.getAttribute('aria-label') || '').trim()
          )
        );

        if (otpSingleInput || splitOtpInputs.length >= 4) {
          return {
            step: 'otp',
            isLoggedIn: false,
            heading: heading || 'Nhập mã xác thực bảo mật',
            description:
              description || 'Nhập mã xác thực 6 chữ số vừa được Muse.ai gửi tới Email / Số điện thoại của bạn.',
            errorText,
            canResendCode,
            isSplitOtp: splitOtpInputs.length >= 4,
            isBusy
          };
        }

        // 3. Kiểm tra bước nhập Mật khẩu (Password)
        const passwordInput = allInputs.find((inp) => inp.type === 'password');
        if (passwordInput) {
          const isCreateNewPwd =
            (passwordInput.getAttribute('autocomplete') || '').toLowerCase() === 'new-password';
          const canSwitchToOtp = allButtons.some((b) =>
            /forgot password|use.*code|login code|try another way|send.*code/i.test(
              (b.innerText || b.getAttribute('aria-label') || '').trim()
            )
          );
          return {
            step: 'password',
            isCreateNewPassword: isCreateNewPwd,
            isLoggedIn: false,
            heading: heading || (isCreateNewPwd ? 'Tạo mật khẩu mới' : 'Nhập mật khẩu tài khoản'),
            description,
            errorText,
            canSwitchToOtp,
            isBusy
          };
        }

        // 4. Kiểm tra trường hợp tài khoản mới chưa đăng ký (hiện First name / Last name)
        const nameFields = document.querySelector('[data-testid="native-auth-name-fields"]');
        if (nameFields && isVisible(nameFields)) {
          return {
            step: 'challenge',
            isLoggedIn: false,
            heading: heading || 'Hoàn tất hồ sơ tài khoản mới lần đầu',
            description:
              'Email/SĐT này chưa tạo tài khoản Muse.ai trước đây. Hãy bấm nút "Mở Khung Đăng Nhập Nhanh (Popup Gọn)" bên dưới để điền Họ Tên & Ngày sinh trong 10 giây!',
            errorText,
            isBusy
          };
        }

        // 5. Kiểm tra bước nhập Email hoặc Số điện thoại (Mobile number or email)
        const identifierInput = allInputs.find((inp) => {
          const al = (inp.getAttribute('aria-label') || '').toLowerCase();
          const ph = (inp.getAttribute('placeholder') || '').toLowerCase();
          const ac = (inp.getAttribute('autocomplete') || '').toLowerCase();
          return (
            al.includes('mobile number or email') ||
            ph.includes('mobile number or email') ||
            al.includes('email') ||
            ph.includes('email') ||
            inp.type === 'email' ||
            ac.includes('username')
          );
        });

        if (identifierInput) {
          return {
            step: 'identifier',
            isLoggedIn: false,
            currentIdentifier: identifierInput.value || '',
            heading: heading || 'Đăng nhập Muse.ai trực tiếp',
            description,
            errorText,
            isBusy
          };
        }

        // 6. Kiểm tra màn hình Tài khoản đã lưu ("Use another account" / "Continue as...")
        const useAnotherBtn = allButtons.find((b) =>
          /use another account|switch account|log into another/i.test(
            (b.innerText || b.getAttribute('aria-label') || '').trim()
          )
        );
        if (useAnotherBtn) {
          const continueBtn = allButtons.find(
            (b) => b !== useAnotherBtn && /continue|log in/i.test((b.innerText || '').trim())
          );
          return {
            step: 'saved_account',
            isLoggedIn: false,
            savedAccountLabel: (continueBtn?.innerText || 'Tiếp tục với tài khoản đã lưu').trim(),
            heading: heading || 'Phát hiện tài khoản trên phiên này',
            description,
            errorText,
            isBusy
          };
        }

        // Nếu đang tải trang lần đầu hoặc bước xác minh đặc biệt (Passkey / Captcha)
        const hasAuthSection = Boolean(document.querySelector('[data-testid="native-auth-access-pane"]'));
        return {
          step: hasAuthSection ? 'challenge' : 'loading',
          isLoggedIn: false,
          heading: heading || (hasAuthSection ? 'Bước xác minh bổ sung từ Muse.ai' : 'Đang tải trang Muse.ai...'),
          description: hasAuthSection
            ? description ||
              'Tài khoản yêu cầu xác minh trực quan. Bạn chỉ cần bấm "Mở Khung Đăng Nhập Nhanh (Popup Gọn)" bên dưới để xác nhận 1 chạm!'
            : '',
          errorText,
          isBusy
        };
      })
      .catch(() => ({
        step: 'loading',
        isLoggedIn: false,
        heading: 'Đang đồng bộ trang...',
        description: '',
        errorText: '',
        isBusy: true
      }));
  }

  async _fillMuseAuthInput(musePage, selectorList, value) {
    const cleanVal = String(value ?? '');
    for (const sel of selectorList) {
      const loc = musePage.locator(sel).first();
      const count = await loc.count().catch(() => 0);
      if (count > 0 && (await loc.isVisible().catch(() => false))) {
        await loc.click({ timeout: 3000 }).catch(() => {});
        await musePage.keyboard.press('Control+A').catch(() => {});
        await musePage.keyboard.press('Backspace').catch(() => {});
        await loc.fill(cleanVal).catch(async () => {
          await musePage.keyboard.type(cleanVal, { delay: 25 });
        });
        // Đảm bảo React 19 state cập nhật 100%
        const actual = await loc.inputValue().catch(() => '');
        if (actual !== cleanVal) {
          await loc.evaluate((el, v) => {
            const proto = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
            if (proto && proto.set) {
              proto.set.call(el, v);
            } else {
              el.value = v;
            }
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }, cleanVal);
        }
        return true;
      }
    }
    return false;
  }

  async _clickMuseAuthPrimarySubmit(musePage) {
    const clicked = await musePage
      .evaluate(() => {
        const pane =
          document.querySelector('[data-testid="native-auth-access-pane"]') ||
          document.querySelector('form') ||
          document.body;
        const submitBtn =
          pane.querySelector('button[type="submit"]:not([disabled])') ||
          Array.from(pane.querySelectorAll('button:not([disabled]), [role="button"]')).find((b) =>
            /^(continue|log\s*in|sign\s*in|confirm|verify|submit|next)$/i.test(
              (b.innerText || b.textContent || '').trim()
            )
          );
        if (submitBtn) {
          submitBtn.click();
          return true;
        }
        return false;
      })
      .catch(() => false);

    if (!clicked) {
      await musePage.keyboard.press('Enter').catch(() => {});
    }
  }

  /**
   * Khởi tạo ngầm 100% (không mở cửa sổ Chrome) và kiểm tra bước đăng nhập hiện tại của Muse.ai
   */
  async inspectInAppLoginState(accountId, { resetToStart = false } = {}) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy tài khoản.');

    let conn = this.connections.get(account.id);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      await this.launchAndConnect(account.id, {
        forceVisibleWindow: false,
        forceHeadless: true
      });
      conn = this.connections.get(account.id);
    }

    const targetUrl = account.settings?.targetUrl || 'https://muse.ai';
    const musePage = await this._getOrCreateMusePage(conn.context, targetUrl);

    if (resetToStart || !musePage.url().includes('muse.ai')) {
      await musePage.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 35000 }).catch(() => {});
    }

    // Chờ trang render xong form đăng nhập hoặc khung chat (tối đa 7s)
    let authState = await this._readMuseAuthPageState(musePage);
    const waitStart = Date.now();
    while (authState.step === 'loading' && Date.now() - waitStart < 7000) {
      await musePage.waitForTimeout(450);
      authState = await this._readMuseAuthPageState(musePage);
    }

    // Nếu nút "Log in" ở góc trên đang che form (hiếm gặp), tự bấm để lộ native-auth-access-pane
    if (authState.step === 'loading') {
      await musePage
        .evaluate(() => {
          const btn = Array.from(document.querySelectorAll('button, a')).find((b) =>
            /^log\s*in$/i.test((b.innerText || '').trim())
          );
          if (btn) btn.click();
        })
        .catch(() => {});
      await musePage.waitForTimeout(800);
      authState = await this._readMuseAuthPageState(musePage);
    }

    await this.refreshAccountSessionInfo(account.id, true);
    if (authState.step === 'logged_in') {
      await this.syncAccountQuotaAndProfile(account.id).catch(() => {});
    }

    const savedCtx = this.inAppLoginContextMap.get(account.id);
    return {
      state: {
        ...authState,
        rememberedIdentifier: savedCtx?.identifier || authState.currentIdentifier || ''
      },
      account: this.accountManager.getAccount(account.id)
    };
  }

  /**
   * Thực thi từng bước Đăng nhập trực tiếp ngay trong phần mềm (Email/SĐT -> OTP 6 số / Mật khẩu / 2FA)
   */
  async submitInAppLoginStep(accountId, payload = {}) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy tài khoản.');

    let conn = this.connections.get(account.id);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      await this.launchAndConnect(account.id, {
        forceVisibleWindow: false,
        forceHeadless: true
      });
      conn = this.connections.get(account.id);
    }

    const targetUrl = account.settings?.targetUrl || 'https://muse.ai';
    const musePage = await this._getOrCreateMusePage(conn.context, targetUrl);
    const action = String(payload.action || '').trim();

    if (action === 'back_to_start') {
      return await this.inspectInAppLoginState(account.id, { resetToStart: true });
    }

    const beforeState = await this._readMuseAuthPageState(musePage);
    if (beforeState.step === 'logged_in') {
      await this.refreshAccountSessionInfo(account.id, true);
      await this.syncAccountQuotaAndProfile(account.id).catch(() => {});
      return {
        state: beforeState,
        account: this.accountManager.getAccount(account.id)
      };
    }

    if (action === 'use_another_account') {
      await musePage
        .evaluate(() => {
          const btn = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) =>
            /use another account|switch account|log into another/i.test(
              (b.innerText || b.getAttribute('aria-label') || '').trim()
            )
          );
          if (btn) btn.click();
        })
        .catch(() => {});
      await musePage.waitForTimeout(900);
      return await this.inspectInAppLoginState(account.id);
    }

    if (action === 'continue_saved_account') {
      await musePage
        .evaluate(() => {
          const pane = document.querySelector('[data-testid="native-auth-access-pane"]') || document.body;
          const btns = Array.from(pane.querySelectorAll('button, [role="button"]'));
          const cont = btns.find(
            (b) =>
              !/use another account/i.test((b.innerText || '').trim()) &&
              /continue|log\s*in/i.test((b.innerText || '').trim())
          );
          if (cont) cont.click();
        })
        .catch(() => {});
    } else if (action === 'submit_identifier') {
      const identifier = String(payload.identifier || '').trim();
      if (!identifier) {
        throw new Error('Vui lòng nhập Email hoặc Số điện thoại đăng nhập Muse.ai!');
      }
      this.inAppLoginContextMap.set(account.id, { identifier });

      if (beforeState.step === 'saved_account') {
        await musePage
          .evaluate(() => {
            const btn = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) =>
              /use another account|switch account|log into another/i.test((b.innerText || '').trim())
            );
            if (btn) btn.click();
          })
          .catch(() => {});
        await musePage.waitForTimeout(700);
      }

      const filled = await this._fillMuseAuthInput(
        musePage,
        [
          '[data-testid="native-auth-access-pane"] input[aria-label*="Mobile number or email" i]',
          '[data-testid="native-auth-access-pane"] input[placeholder*="Mobile number or email" i]',
          'input[aria-label*="Mobile number or email" i]',
          'input[placeholder*="Mobile number or email" i]',
          '[data-testid="native-auth-access-pane"] input[type="email"]',
          '[data-testid="native-auth-access-pane"] input:not([type="hidden"]):not([type="password"])'
        ],
        identifier
      );

      if (!filled) {
        throw new Error('Không tìm thấy ô nhập Email trên trang Muse.ai. Hãy bấm Làm mới hoặc mở Khung Popup Gọn!');
      }

      await this._clickMuseAuthPrimarySubmit(musePage);
    } else if (action === 'submit_password') {
      const password = String(payload.password || '');
      if (!password) {
        throw new Error('Vui lòng nhập Mật khẩu tài khoản!');
      }
      const filled = await this._fillMuseAuthInput(
        musePage,
        [
          '[data-testid="native-auth-access-pane"] input[type="password"]',
          'input[type="password"]'
        ],
        password
      );
      if (!filled) {
        throw new Error('Không tìm thấy ô Mật khẩu trên trang Muse.ai.');
      }
      await this._clickMuseAuthPrimarySubmit(musePage);
    } else if (action === 'request_otp_instead') {
      await musePage
        .evaluate(() => {
          const pane = document.querySelector('[data-testid="native-auth-access-pane"]') || document.body;
          const btn = Array.from(pane.querySelectorAll('button, a, [role="button"]')).find((b) =>
            /forgot password|use.*code|login code|try another way|send.*code/i.test(
              (b.innerText || b.getAttribute('aria-label') || '').trim()
            )
          );
          if (btn) btn.click();
        })
        .catch(() => {});
      await musePage.waitForTimeout(1300);

      // Nếu chuyển sang màn hình nhập lại Email nhận mã khôi phục -> tự điền Email vừa nhập & bấm gửi luôn!
      const midState = await this._readMuseAuthPageState(musePage);
      const savedIdentifier =
        String(payload.identifier || '').trim() || this.inAppLoginContextMap.get(account.id)?.identifier || '';
      if (midState.step === 'identifier' && savedIdentifier) {
        await this._fillMuseAuthInput(
          musePage,
          [
            'input[aria-label*="Mobile number or email" i]',
            'input[placeholder*="Mobile number or email" i]',
            '[data-testid="native-auth-access-pane"] input'
          ],
          savedIdentifier
        );
        await this._clickMuseAuthPrimarySubmit(musePage);
      }
    } else if (action === 'submit_otp') {
      const rawCode = String(payload.code || '').replace(/\s+/g, '').trim();
      if (!rawCode) {
        throw new Error('Vui lòng nhập mã xác thực bảo mật!');
      }

      if (beforeState.isSplitOtp) {
        const firstBox = musePage
          .locator('[data-testid="native-auth-access-pane"] input')
          .first();
        await firstBox.click({ timeout: 3000 }).catch(() => {});
        for (let i = 0; i < 8; i++) {
          await musePage.keyboard.press('Backspace').catch(() => {});
        }
        await musePage.keyboard.type(rawCode, { delay: 45 });
      } else {
        const filled = await this._fillMuseAuthInput(
          musePage,
          [
            'input[autocomplete="one-time-code"]',
            'input[aria-label*="6-digit" i]',
            'input[aria-label*="security code" i]',
            'input[aria-label*="Confirmation code" i]',
            'input[aria-label="Code" i]',
            '[data-testid="native-auth-access-pane"] input[inputmode="numeric"]',
            '[data-testid="native-auth-access-pane"] input:not([type="hidden"])'
          ],
          rawCode
        );
        if (!filled) {
          await musePage.keyboard.type(rawCode, { delay: 45 });
        }
      }

      await musePage.waitForTimeout(450);
      await this._clickMuseAuthPrimarySubmit(musePage);
    } else if (action === 'resend_code') {
      await musePage
        .evaluate(() => {
          const pane = document.querySelector('[data-testid="native-auth-access-pane"]') || document.body;
          const btn = Array.from(pane.querySelectorAll('button, a, [role="button"]')).find((b) =>
            /resend|send.*again|new code|get.*code/i.test(
              (b.innerText || b.getAttribute('aria-label') || '').trim()
            )
          );
          if (btn) btn.click();
        })
        .catch(() => {});
      await musePage.waitForTimeout(1500);
      return await this.inspectInAppLoginState(account.id);
    } else if (action === 'select_2fa_method') {
      const methodId = String(payload.methodId || '');
      await musePage
        .evaluate((mId) => {
          const radios = Array.from(
            document.querySelectorAll('input[type="radio"][name="two-factor-method"]')
          );
          const target = radios.find((r) => r.value === mId) || radios[0];
          if (target) {
            const lbl = target.closest('label') || target;
            lbl.click();
          }
        }, methodId)
        .catch(() => {});
      await musePage.waitForTimeout(350);
      await this._clickMuseAuthPrimarySubmit(musePage);
    } else {
      throw new Error(`Thao tác đăng nhập không hợp lệ: ${action}`);
    }

    // Chờ Muse.ai phản hồi chuyển bước hoặc báo lỗi (tối đa 10 giây)
    let afterState = await this._readMuseAuthPageState(musePage);
    const pollStart = Date.now();
    while (Date.now() - pollStart < 10000) {
      await musePage.waitForTimeout(420);
      afterState = await this._readMuseAuthPageState(musePage);
      if (afterState.step === 'logged_in') break;
      if (afterState.errorText && !afterState.isBusy) break;
      if (afterState.step !== beforeState.step && afterState.step !== 'loading' && !afterState.isBusy) {
        break;
      }
    }

    // Nếu vừa đăng nhập thành công -> Lưu luôn Email đăng nhập (nếu chưa đặt tên riêng) & đồng bộ số dư Token ngay!
    if (afterState.step === 'logged_in') {
      const rememberedId = this.inAppLoginContextMap.get(account.id)?.identifier || '';
      if (rememberedId && !account.accountInfo?.customLoginName) {
        this.accountManager.updateAccountCustomLoginName(account.id, rememberedId);
      }
      await this.refreshAccountSessionInfo(account.id, true);
      await this.syncAccountQuotaAndProfile(account.id).catch(() => {});
    } else {
      await this.refreshAccountSessionInfo(account.id, false);
    }

    const savedCtx = this.inAppLoginContextMap.get(account.id);
    return {
      state: {
        ...afterState,
        rememberedIdentifier: savedCtx?.identifier || afterState.currentIdentifier || ''
      },
      account: this.accountManager.getAccount(account.id)
    };
  }

  /**
   * Mở Khung Đăng Nhập Nhanh (Popup gọn --app=https://muse.ai cỡ 480x700 ở giữa màn hình, không lộ thanh địa chỉ/tab Chrome)
   * và tự động đóng chuyển về chạy ngầm ngay khi phát hiện đăng nhập hoàn tất!
   */
  async openCompactLoginPopup(accountId) {
    const res = await this.launchAndConnect(accountId, {
      forceVisibleWindow: true,
      appPopupMode: true,
      forceHeadless: false
    });
    return res;
  }

  /**
   * Đồng bộ trực tiếp Tên đăng nhập + Số Token đã sử dụng + Số Token còn lại từ Muse.ai (Settings -> General)
   * trên một tab nền riêng biệt rồi tự đóng ngay, tuyệt đối KHÔNG làm gián đoạn tab Chat tạo video chính.
   */
  async syncAccountQuotaAndProfile(accountId, { forceConnect = false } = {}) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy tài khoản.');
    }

    if (this.quotaSyncInFlight.has(account.id)) {
      return await this.quotaSyncInFlight.get(account.id);
    }

    const syncTask = (async () => {
      let conn = this.connections.get(account.id);
      if (!conn || !conn.browser || !conn.browser.isConnected()) {
        const probe = await probeCdpPort(account.port, 1200);
        if (probe.alive || forceConnect) {
          await this.launchAndConnect(account.id, { forceVisibleWindow: false, forceHeadless: true });
          conn = this.connections.get(account.id);
        } else {
          throw new Error(
            `Tài khoản "${account.name}" chưa kết nối Chrome. Hãy bấm nút Kết Nối Chrome trước!`
          );
        }
      }

      if (!conn || !conn.context) {
        throw new Error('Không thể truy cập phiên Chrome của tài khoản.');
      }

      let tempPage = null;
      try {
        // Kiểm tra tiêu đề các tab đang mở sẵn để lấy nhanh tên tài khoản (VD: "Chat — Bé Mít")
        let detectedAgent = account.accountInfo?.agentName || '';
        for (const p of conn.context.pages()) {
          if (!p || p.isClosed()) continue;
          try {
            if ((p.url() || '').includes('muse.ai')) {
              const t = await p.title().catch(() => '');
              const cand = extractMuseAgentNameFromTitle(t);
              if (cand) {
                detectedAgent = cand;
                break;
              }
            }
          } catch (_) {}
        }

        tempPage = await conn.context.newPage();
        await tempPage
          .goto(account.settings?.targetUrl || 'https://muse.ai', {
            waitUntil: 'domcontentloaded',
            timeout: 30000
          })
          .catch(() => {});

        await tempPage
          .waitForSelector(
            'textarea, [contenteditable="true"], [role="textbox"], [data-testid="native-auth-access-pane"]',
            { timeout: 6500 }
          )
          .catch(() => {});
        await tempPage.waitForTimeout(1200).catch(() => {});

        const pageMeta = await tempPage
          .evaluate(() => {
            const authPane = document.querySelector('[data-testid="native-auth-access-pane"]');
            const loginInput = document.querySelector(
              'input[aria-label*="Mobile number or email" i], input[placeholder*="Mobile number or email" i], input[type="email"]'
            );
            const composer = document.querySelector(
              'textarea, [contenteditable="true"], [role="textbox"]:not([aria-label*="Mobile number or email" i])'
            );
            const html = document.documentElement ? document.documentElement.innerHTML : '';
            const viewerMatch = html.match(/"viewerId"\s*:\s*"(\d+)"/);
            return {
              isLoginScreen: Boolean((authPane || loginInput) && !composer),
              hasComposer: Boolean(composer),
              title: document.title || '',
              viewerId: viewerMatch ? viewerMatch[1] : ''
            };
          })
          .catch(() => ({ isLoginScreen: false, hasComposer: false, title: '', viewerId: '' }));

        if (pageMeta.isLoginScreen) {
          this.lastQuotaSyncAt.set(account.id, Date.now());
          if (forceConnect) {
            throw new Error('Tài khoản chưa đăng nhập vào muse.ai. Hãy đăng nhập trên cửa sổ Chrome trước!');
          }
          return account;
        }

        const candFromTempTitle = extractMuseAgentNameFromTitle(pageMeta.title);
        if (candFromTempTitle) {
          detectedAgent = candFromTempTitle;
        }

        // Mở hộp thoại Settings (Phím tắt chuẩn Control+, trên Muse.ai, dự phòng bấm nút More -> Settings)
        await tempPage.keyboard.press('Control+,').catch(() => {});
        let hasSettingsDialog = await tempPage
          .waitForSelector('[role="dialog"]', { timeout: 2200 })
          .then(() => true)
          .catch(() => false);

        if (!hasSettingsDialog) {
          const moreBtn = tempPage
            .locator('[data-testid="hatch-dock-more"], button[aria-label="More"], button[aria-label*="More" i]')
            .first();
          if ((await moreBtn.count().catch(() => 0)) > 0) {
            await moreBtn.click({ force: true, timeout: 2000 }).catch(() => {});
            await tempPage.waitForTimeout(400).catch(() => {});
            const settingsItem = tempPage
              .locator('[role="menuitem"]:has-text("Settings"), button:has-text("Settings")')
              .first();
            if ((await settingsItem.count().catch(() => 0)) > 0) {
              await settingsItem.click({ force: true, timeout: 2000 }).catch(() => {});
              hasSettingsDialog = await tempPage
                .waitForSelector('[role="dialog"]', { timeout: 2500 })
                .then(() => true)
                .catch(() => false);
            }
          }
        }

        await tempPage.waitForTimeout(450).catch(() => {});

        const rawQuotaData = await tempPage
          .evaluate(() => {
            const dlg = document.querySelector('[role="dialog"]');
            if (!dlg) return null;

            let monthlyUsage = null;
            let purchasedUsage = null;
            let subtext = '';

            const allNodes = [dlg, ...Array.from(dlg.querySelectorAll('*'))];
            for (const el of allNodes) {
              const keys = Object.keys(el);
              for (const k of keys) {
                if (!k.startsWith('__reactFiber$') && !k.startsWith('__reactProps$')) continue;
                let cur = el[k];
                let depth = 0;
                while (cur && depth < 10) {
                  const p = cur.memoizedProps || cur.pendingProps || cur;
                  if (p && typeof p === 'object') {
                    if (p.monthlyUsage && !monthlyUsage) {
                      monthlyUsage = {
                        state: p.monthlyUsage.state || '',
                        label: p.monthlyUsage.label || '',
                        usedPercent:
                          typeof p.monthlyUsage.usedPercent === 'number' ? p.monthlyUsage.usedPercent : null,
                        valueLabel: p.monthlyUsage.valueLabel || ''
                      };
                    }
                    if (p.purchasedUsage && !purchasedUsage) {
                      purchasedUsage = {
                        label: p.purchasedUsage.label || '',
                        valueLabel: p.purchasedUsage.valueLabel || '',
                        balance:
                          typeof p.purchasedUsage.balance === 'number' ? p.purchasedUsage.balance : null,
                        total: typeof p.purchasedUsage.total === 'number' ? p.purchasedUsage.total : null
                      };
                    }
                    if (typeof p.subtext === 'string' && /reset|limit|plan|token/i.test(p.subtext) && !subtext) {
                      subtext = p.subtext.trim();
                    }
                  }
                  cur = cur.return;
                  depth++;
                }
              }
            }

            return {
              dialogText: (dlg.innerText || '').trim(),
              monthlyUsage,
              purchasedUsage,
              subtext
            };
          })
          .catch(() => null);

        // Nếu chưa bắt được tên nhân vật/tài khoản từ tiêu đề tab, đọc nhanh từ tab Wallet trong Settings ("allow <Name> to make secure purchases")
        if (!detectedAgent && hasSettingsDialog) {
          const walletAgent = await tempPage
            .evaluate(async () => {
              const dlg = document.querySelector('[role="dialog"]');
              if (!dlg) return '';
              const tabs = Array.from(dlg.querySelectorAll('button, [role="tab"]'));
              const walletBtn = tabs.find((b) => /^wallet$/i.test((b.textContent || '').trim()));
              if (!walletBtn) return '';
              walletBtn.click();
              await new Promise((r) => setTimeout(r, 350));
              const txt = dlg.innerText || '';
              const m = txt.match(/allow\s+(.+?)\s+to\s+make\s+secure\s+purchases/i);
              return m && m[1] ? m[1].trim() : '';
            })
            .catch(() => '');
          if (walletAgent) {
            detectedAgent = walletAgent;
          }
        }

        const prevTokenUsage = account.accountInfo?.tokenUsage || null;
        const prevScale = Number(prevTokenUsage?.scaleFactor) || 25;
        let tokenUsage = prevTokenUsage;

        if (rawQuotaData) {
          const mu = rawQuotaData.monthlyUsage;
          const pu = rawQuotaData.purchasedUsage;
          const dlgTxt = rawQuotaData.dialogText || '';

          const planLabel = mu?.label || 'Muse Plan';
          const weeklyUsedPercent =
            typeof mu?.usedPercent === 'number'
              ? Math.min(100, Math.max(0, Math.round(mu.usedPercent)))
              : (() => {
                  const m = dlgTxt.match(/(?:Free|Pro|Plus|Max)\s+plan[\s\S]{0,60}?(\d+)%\s*used/i);
                  return m ? Number(m[1]) : null;
                })();
          const weeklyResetText =
            rawQuotaData.subtext ||
            (() => {
              const m = dlgTxt.match(/Weekly limit resets[^\n]+/i);
              return m ? m[0].trim() : '';
            })();

          if (pu && typeof pu.total === 'number' && pu.total > 0) {
            const rawBalance = Math.max(0, Number(pu.balance) || 0);
            const rawTotal = Math.max(1, Number(pu.total) || 1);
            const parsedLeft = parseHumanTokenString(pu.valueLabel || '');
            let scaleFactor = prevScale;
            if (parsedLeft > 0 && rawBalance > 0) {
              const ratio = parsedLeft / rawBalance;
              const rounded = Math.round(ratio);
              scaleFactor =
                rounded >= 1 && Math.abs(ratio - rounded) / ratio < 0.1 ? rounded : ratio;
            }

            const tokensTotalExact = Math.round(rawTotal * scaleFactor);
            const tokensRemainingExact = Math.round(rawBalance * scaleFactor);
            const tokensUsedExact = Math.max(0, tokensTotalExact - tokensRemainingExact);
            const tokensUsedPercent = Math.min(
              100,
              Math.max(0, Math.round(((rawTotal - rawBalance) / rawTotal) * 100))
            );
            const tokensRemainingPercent = Math.max(0, 100 - tokensUsedPercent);

            tokenUsage = {
              hasTokenPool: true,
              planLabel,
              weeklyUsedPercent,
              weeklyValueLabel: mu?.valueLabel || (weeklyUsedPercent !== null ? `${weeklyUsedPercent}% used` : ''),
              weeklyResetText,
              tokensUsedExact,
              tokensRemainingExact,
              tokensTotalExact,
              tokensUsedFormatted: formatCompactTokens(tokensUsedExact),
              tokensRemainingFormatted: formatCompactTokens(tokensRemainingExact),
              tokensTotalFormatted: formatCompactTokens(tokensTotalExact),
              tokensUsedPercent,
              tokensRemainingPercent,
              rawValueLabel: pu.valueLabel || '',
              scaleFactor,
              updatedAt: new Date().toISOString()
            };
          } else {
            const textPoolMatch = dlgTxt.match(
              /Additional\s+tokens[\s\S]{0,80}?(\d+)%\s*used\s*\(([^)]*tokens?\s*left)\)/i
            );
            if (textPoolMatch) {
              const usedPct = Math.min(100, Math.max(0, Number(textPoolMatch[1]) || 0));
              const remPct = Math.max(1, 100 - usedPct);
              const remExact = Math.round(parseHumanTokenString(textPoolMatch[2]));
              const totalExact = remExact > 0 ? Math.round(remExact / (remPct / 100)) : 0;
              const usedExact = Math.max(0, totalExact - remExact);

              tokenUsage = {
                hasTokenPool: true,
                planLabel,
                weeklyUsedPercent,
                weeklyValueLabel: mu?.valueLabel || (weeklyUsedPercent !== null ? `${weeklyUsedPercent}% used` : ''),
                weeklyResetText,
                tokensUsedExact: usedExact,
                tokensRemainingExact: remExact,
                tokensTotalExact: totalExact,
                tokensUsedFormatted: formatCompactTokens(usedExact),
                tokensRemainingFormatted: formatCompactTokens(remExact),
                tokensTotalFormatted: formatCompactTokens(totalExact),
                tokensUsedPercent: usedPct,
                tokensRemainingPercent: Math.max(0, 100 - usedPct),
                rawValueLabel: `${usedPct}% used (${textPoolMatch[2]})`,
                scaleFactor: prevScale,
                updatedAt: new Date().toISOString()
              };
            } else if (weeklyUsedPercent !== null) {
              const weeklyRemPct = Math.max(0, 100 - weeklyUsedPercent);
              tokenUsage = {
                hasTokenPool: false,
                planLabel,
                weeklyUsedPercent,
                weeklyValueLabel: mu?.valueLabel || `${weeklyUsedPercent}% used`,
                weeklyResetText,
                tokensUsedExact: null,
                tokensRemainingExact: null,
                tokensTotalExact: null,
                tokensUsedFormatted: `${weeklyUsedPercent}% gói tuần`,
                tokensRemainingFormatted: `${weeklyRemPct}% gói tuần`,
                tokensTotalFormatted: '100% gói tuần',
                tokensUsedPercent: weeklyUsedPercent,
                tokensRemainingPercent: weeklyRemPct,
                rawValueLabel: mu?.valueLabel || `${weeklyUsedPercent}% used`,
                scaleFactor: prevScale,
                updatedAt: new Date().toISOString()
              };
            }
          }
        }

        const customLoginName =
          typeof account.accountInfo?.customLoginName === 'string'
            ? account.accountInfo.customLoginName.trim()
            : '';
        const finalAgentName = detectedAgent || account.accountInfo?.agentName || '';
        const finalViewerId =
          pageMeta.viewerId && pageMeta.viewerId !== '0'
            ? pageMeta.viewerId
            : account.accountInfo?.viewerId || '';

        const resolvedLoginName = customLoginName
          ? finalAgentName && !customLoginName.toLowerCase().includes(finalAgentName.toLowerCase())
            ? `${customLoginName} (${finalAgentName})`
            : customLoginName
          : finalAgentName || 'Đã đăng nhập Muse.ai';

        account.connected = true;
        account.loginVerified = true;
        account.savedAccount = true;
        account.accountInfo = {
          ...(account.accountInfo || {}),
          displayName: resolvedLoginName,
          loginName: resolvedLoginName,
          customLoginName,
          agentName: finalAgentName,
          viewerId: finalViewerId,
          tokenUsage,
          lastConnectedAt: new Date().toISOString()
        };

        this.lastQuotaSyncAt.set(account.id, Date.now());
        this.accountManager.save();
        this.emit('account_status_changed', {
          accountId: account.id,
          connected: true,
          loginVerified: true,
          account
        });

        return account;
      } finally {
        if (tempPage && !tempPage.isClosed()) {
          await tempPage.close().catch(() => {});
        }
      }
    })();

    this.quotaSyncInFlight.set(account.id, syncTask);
    try {
      return await syncTask;
    } finally {
      this.quotaSyncInFlight.delete(account.id);
    }
  }

  /**
   * Tự động bắt và lưu các video thành phẩm vừa xuất hiện trên Muse.ai về đúng hàng (chỉ chạy khi không có lệnh đang thực thi)
   */
  async _autoCatchCompletedVideosInBackground(account, page, context) {
    if (this.autoCatchRunningSet.has(account.id)) return;
    if ((this.activeExecutions.get(account.id) || 0) > 0) return;
    this.autoCatchRunningSet.add(account.id);
    try {
      const items = await this._extractValidAttachmentVideosFromDom(page, account.id);
      if (!items || items.length === 0) return;

      const outputAccountDir = path.join(this.appRootDir, 'Output_Videos', account.id);
      for (const item of items) {
        if ((this.activeExecutions.get(account.id) || 0) > 0) break;
        if (this.claimedVideoKeys.has(item.key)) continue;
        // Bỏ qua các mảnh phụ _p1, _p2 của video dài để không ghi đè video ngắn vào hàng
        if (this._parsePartNumberFromAriaLabel(item.ariaLabel) !== null) continue;
        const parsedRowNum = this._parseRowNumberFromAriaLabel(item.ariaLabel);
        if (!parsedRowNum || parsedRowNum < 1 || parsedRowNum > account.rows.length) continue;

        const row = account.rows.find((r) => r.index === parsedRowNum);
        if (row && !row.videoUrl && ['error', 'idle'].includes(row.status)) {
          this.claimedVideoKeys.add(item.key);
          if (!fs.existsSync(outputAccountDir)) {
            fs.mkdirSync(outputAccountDir, { recursive: true });
          }
          const fileName = `MuseFlow_AutoRow${parsedRowNum}_${Date.now()}.mp4`;
          const destFilePath = path.join(outputAccountDir, fileName);
          await this._downloadVideoViaCdp(page, context, item.src, destFilePath, item);
          let stat = fs.statSync(destFilePath);
          if (stat.size >= MIN_REAL_VIDEO_BYTES) {
            await ensureUniversalPlayableMp4(this.appRootDir, destFilePath);
            stat = fs.statSync(destFilePath);
            const publicVideoUrl = `/outputs/${account.id}/${fileName}`;
            const updatedRow = this.accountManager.updateRow(account.id, parsedRowNum, {
              status: 'completed',
              statusMessage: `Hoàn tất! Đã tự động nhận video Hàng #${parsedRowNum} (${(
                stat.size /
                (1024 * 1024)
              ).toFixed(2)} MB)`,
              videoUrl: publicVideoUrl,
              videoFilePath: destFilePath,
              remoteVideoUrl: item.src,
              fileSize: stat.size,
              completedAt: new Date().toISOString(),
              error: null
            });
            this.emit('row_updated', { accountId: account.id, rowIndex: parsedRowNum, row: updatedRow });
          }
        }
      }
    } catch (_) {
    } finally {
      this.autoCatchRunningSet.delete(account.id);
    }
  }

  async inspectLiveDom(accountId) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy tài khoản.');

    const conn = this.connections.get(accountId);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      throw new Error(`Chưa kết nối Chrome trên Port ${account.port}.`);
    }

    const page = await this._getOrCreateMusePage(conn.context, account.settings?.targetUrl || 'https://muse.ai');
    return await page.evaluate(() => {
      const videoAttachments = Array.from(
        document.querySelectorAll('[data-testid="hatch-chat-attachment-presentation-video"]')
      ).map((el) => {
        const wrapper = el.querySelector('[data-hatch-video-wrapper="true"]');
        const video = el.querySelector('video');
        const msg = el.closest('[data-message-id]');
        return {
          messageId: msg ? msg.getAttribute('data-message-id') : null,
          ariaLabel: wrapper ? wrapper.getAttribute('aria-label') : null,
          videoSrc:
            (wrapper && wrapper.getAttribute('data-hatch-video-src')) ||
            (video && (video.currentSrc || video.src)) ||
            null,
          width: video ? video.videoWidth : 0,
          height: video ? video.videoHeight : 0,
          duration: video ? video.duration : 0
        };
      });

      return {
        url: window.location.href,
        title: document.title,
        generatedVideoAttachmentsCount: videoAttachments.length,
        generatedVideoAttachments: videoAttachments
      };
    });
  }

  /**
   * Trích xuất số thứ tự hàng (Row Index) từ tên file video trong aria-label của Muse.ai
   * Ví dụ: "Open animated video mfs_row07_a1b2.mp4" -> 7
   *        "Open animated video row03_jeans.mp4" -> 3
   */
  _parseRowNumberFromAriaLabel(ariaLabel) {
    if (!ariaLabel || typeof ariaLabel !== 'string') return null;
    const mfsMatch = ariaLabel.match(/mfs_row0*(\d+)(?:_|\.|\b)/i);
    if (mfsMatch && mfsMatch[1]) {
      return Number(mfsMatch[1]);
    }
    const rowMatch = ariaLabel.match(/(?:^|\s|_)row[-_]?0*(\d+)(?:_|\.|\b)/i);
    if (rowMatch && rowMatch[1]) {
      return Number(rowMatch[1]);
    }
    const numMp4Match = ariaLabel.match(/(?:video\s+|\/|^)0*(\d{1,3})\.mp4\b/i);
    if (numMp4Match && numMp4Match[1]) {
      return Number(numMp4Match[1]);
    }
    return null;
  }

  _parsePartNumberFromAriaLabel(ariaLabel) {
    if (!ariaLabel || typeof ariaLabel !== 'string') return null;
    const mfsPart = ariaLabel.match(/mfs_row\d+_p0*(\d+)(?:_|\.|\b)/i);
    if (mfsPart && mfsPart[1]) {
      return Number(mfsPart[1]);
    }
    const genericPart = ariaLabel.match(/(?:^|[_-\s])(?:part|phan)[-_]?0*(\d+)(?:_|\.|\b)/i);
    if (genericPart && genericPart[1]) {
      return Number(genericPart[1]);
    }
    return null;
  }

  /**
   * Đồng bộ các video thành phẩm thật đã tạo trên muse.ai về ĐÚNG hàng tương ứng
   */
  async syncGeneratedVideosFromChat(accountId) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy tài khoản.');

    let conn = this.connections.get(account.id);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      await this.launchAndConnect(account.id, { forceVisibleWindow: false });
      conn = this.connections.get(account.id);
    }

    const page = await this._getOrCreateMusePage(conn.context, account.settings?.targetUrl || 'https://muse.ai');
    const items = await this._extractValidAttachmentVideosFromDom(page, account.id);
    if (items.length === 0) {
      throw new Error('Chưa tìm thấy video thành phẩm nào trong đoạn chat muse.ai hiện tại.');
    }

    const outputAccountDir = path.join(this.appRootDir, 'Output_Videos', account.id);
    if (!fs.existsSync(outputAccountDir)) {
      fs.mkdirSync(outputAccountDir, { recursive: true });
    }

    let syncedCount = 0;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      // Ưu tiên khớp đúng số thứ tự hàng ghi trong tên file (VD: mfs_row07_... -> Hàng #7)
      const parsedRowNum = this._parseRowNumberFromAriaLabel(item.ariaLabel);
      const targetRowIndex =
        parsedRowNum && parsedRowNum >= 1 && parsedRowNum <= account.rows.length
          ? parsedRowNum
          : i + 1;

      if (targetRowIndex > account.rows.length) continue;

      const fileName = `MuseFlow_Synced_Row${targetRowIndex}_${Date.now()}.mp4`;
      const destFilePath = path.join(outputAccountDir, fileName);

      await this._downloadVideoViaCdp(page, conn.context, item.src, destFilePath, item);
      let stat = fs.statSync(destFilePath);

      if (stat.size >= MIN_REAL_VIDEO_BYTES) {
        await ensureUniversalPlayableMp4(this.appRootDir, destFilePath);
        stat = fs.statSync(destFilePath);
        const publicVideoUrl = `/outputs/${account.id}/${fileName}`;
        const updatedRow = this.accountManager.updateRow(account.id, targetRowIndex, {
          status: 'completed',
          statusMessage: `Đã đồng bộ đúng video Hàng #${targetRowIndex} (${(stat.size / (1024 * 1024)).toFixed(2)} MB)`,
          videoUrl: publicVideoUrl,
          videoFilePath: destFilePath,
          remoteVideoUrl: item.src,
          fileSize: stat.size,
          completedAt: new Date().toISOString(),
          error: null
        });
        this.emit('row_updated', { accountId: account.id, rowIndex: targetRowIndex, row: updatedRow });
        syncedCount++;
      } else {
        try {
          fs.unlinkSync(destFilePath);
        } catch (_) {}
      }
    }

    return syncedCount;
  }

  /**
   * Thực thi thật 100% 1 hàng tạo video trên Chrome chạy ngầm:
   * - Đảm bảo ảnh tham chiếu của Hàng #N được tải lên hoàn tất và gửi đi trong 1 tin nhắn riêng biệt kèm mã định danh mfs_rowXX_XXXX
   * - Khi nhận kết quả, KHỚP CHÍNH XÁC 100% mã mfs_rowXX_XXXX của Hàng #N, tuyệt đối không lấy nhầm video của hàng khác!
   */
  async executeRow({ accountId, rowIndex, onStatusUpdate, abortSignal }) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy tài khoản thực thi.');
    }

    let conn = this.connections.get(account.id);
    if (!conn || !conn.browser || !conn.browser.isConnected()) {
      await this.launchAndConnect(account.id, { forceVisibleWindow: false });
      conn = this.connections.get(account.id);
    }

    if (account.settings?.backgroundMode !== false) {
      hideChromeWindowByPort(account.port);
    }

    const row = account.rows.find((r) => r.index === Number(rowIndex));
    if (!row) {
      throw new Error(`Không tìm thấy hàng số ${rowIndex}`);
    }

    const rawValidImages = (row.referenceImages || [])
      .slice(0, 5)
      .filter((img) => img && img.filePath && fs.existsSync(img.filePath));

    const validImages = rawValidImages;

    const rowSampleVid =
      row.sampleVideo && row.sampleVideo.filePath && fs.existsSync(row.sampleVideo.filePath)
        ? row.sampleVideo
        : null;
    const globalSampleVid =
      account.settings?.sampleVideo &&
      account.settings.sampleVideo.filePath &&
      fs.existsSync(account.settings.sampleVideo.filePath)
        ? account.settings.sampleVideo
        : null;
    const anySampleLearnOn =
      account.settings?.sampleLearnMotion !== false ||
      account.settings?.sampleLearnCamera !== false ||
      account.settings?.sampleLearnScene !== false;
    const effectiveSampleVideo = anySampleLearnOn ? rowSampleVid || globalSampleVid : null;

    const hasRowPrompt = Boolean(row.prompt && row.prompt.trim());
    const hasRowDialogue = Boolean(row.dialogue && row.dialogue.trim());

    if (!hasRowPrompt && !hasRowDialogue && validImages.length === 0 && !effectiveSampleVideo) {
      throw new Error(
        `Hàng #${rowIndex}: Vui lòng thêm Ảnh tham chiếu, Video mẫu, Prompt chuyển động hoặc Lời thoại!`
      );
    }

    const reportStatus = (status, statusMessage, extra = {}) => {
      this.accountManager.updateRow(account.id, rowIndex, {
        status,
        statusMessage,
        ...extra
      });
      const latestRow = this.accountManager.getAccount(account.id).rows.find((r) => r.index === Number(rowIndex));
      if (typeof onStatusUpdate === 'function') {
        onStatusUpdate(latestRow);
      }
      this.emit('row_updated', {
        accountId: account.id,
        rowIndex,
        row: latestRow
      });
    };

    this.activeExecutions.set(account.id, (this.activeExecutions.get(account.id) || 0) + 1);

    try {
      reportStatus('connecting', `[Chạy Ngầm CDP] Đang chuẩn bị gửi Hàng #${rowIndex}...`, {
        error: null
      });

      const context = conn.context;
      const musePage = await this._getOrCreateMusePage(context, account.settings?.targetUrl || 'https://muse.ai');

      if (abortSignal?.aborted) {
        throw new Error('Đã hủy lệnh theo yêu cầu người dùng.');
      }

      const authState = await musePage.evaluate(() => {
        const authPane = document.querySelector('[data-testid="native-auth-access-pane"]');
        const loginInput = document.querySelector(
          'input[aria-label*="Mobile number or email" i], input[placeholder*="Mobile number or email" i]'
        );
        const composer = document.querySelector(
          'textarea, [contenteditable="true"], [role="textbox"]:not([aria-label*="Mobile number or email" i])'
        );
        return {
          isLoginGate: Boolean((authPane || loginInput) && !composer),
          hasComposer: Boolean(composer)
        };
      });

      if (authState.isLoginGate) {
        throw new Error(
          `Tài khoản chưa đăng nhập vào muse.ai. Hãy bấm nút "1. Đăng Nhập & Lưu Tài Khoản" trên thanh công cụ!`
        );
      }

      // Kiểm tra thời lượng yêu cầu: nếu chọn 20s, 30s, 40s, 50s, 60s -> Tự động chạy nối tiếp nhiều phần (10s/phần) từ khung hình cuối
      const settings = account.settings || {};

      // Cách ly luồng Chat sạch (Clean Isolated Chat) khi an toàn để không bị lai nét mặt từ các hàng trước đó
      await this._startFreshMuseChatIfSafe(musePage, account);

      const activeSkill = this._resolveActiveSkill(account);
      if (activeSkill) {
        await this._ensureSkillPrimedInMuseSession(musePage, account, activeSkill, (msg) => {
          reportStatus('connecting', msg);
        });
      }

      let sampleBlueprint = null;
      if (effectiveSampleVideo) {
        sampleBlueprint = await this._getOrAnalyzeSampleVideoBlueprint(
          musePage,
          account,
          effectiveSampleVideo,
          (msg) => reportStatus('connecting', msg)
        );
      }

      const requestedSec = parseDurationSeconds(settings.duration || '10s', 10);
      const humanDurLabel = formatHumanDurationLabel(requestedSec);
      const totalParts = requestedSec > 10 ? Math.ceil(requestedSec / 10) : 1;
      const getPartDurationStr = (pIdx) => {
        if (totalParts <= 1) return `${requestedSec}s`;
        if (pIdx < totalParts) return '10s';
        const remSec = requestedSec - (totalParts - 1) * 10;
        if (remSec <= 6) return '5s';
        if (remSec <= 8) return '8s';
        return '10s';
      };

      const rowDialoguePlan = splitDialogueIntoPartSegments({
        rowDialogue: row.dialogue || '',
        rowMotionPrompt: row.prompt || '',
        totalParts,
        enableDialogue: Boolean(settings.enableDialogue)
      });
      const hasSpokenDialogueForConcat = Boolean(settings.enableDialogue && rowDialoguePlan.hasExplicitScript);

      const rowPad = String(rowIndex).padStart(2, '0');
      const outputAccountDir = path.join(this.appRootDir, 'Output_Videos', account.id);
      const tempPartsDir = path.join(this.appRootDir, 'Project_Data', 'temp_editor', `row_${rowIndex}_${Date.now()}`);
      [outputAccountDir, tempPartsDir].forEach((d) => {
        if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
      });

      const finalFileName = `MuseFlow_Row${rowIndex}_${requestedSec}s_${Date.now()}.mp4`;
      const destFilePath = path.join(outputAccountDir, finalFileName);
      const publicVideoUrl = `/outputs/${account.id}/${finalFileName}`;

      const partFilePaths = [];
      const usedRemoteSrcs = new Set();
      const originIdentityImage = validImages.length > 0 ? validImages[0] : null;
      const hasCharacterReference = Boolean(
        originIdentityImage && originIdentityImage.filePath && fs.existsSync(originIdentityImage.filePath)
      );
      const isMultiImageRow = rawValidImages.length >= 2;
      const combinedWipeText = [row.prompt || '', activeSkill?.name || '', activeSkill?.instructions || ''].join(' ');
      const isPropWipeTransition =
        isMultiImageRow ||
        /quạt|fan\s*wipe|lens\s*wipe|prop\s*wipe|che\s*ống\s*kính|che\s*kín\s*ống\s*kính|biến\s*hình|thay\s*đồ|thay\s*nhiều\s*bộ|glow[\s-]*up/i.test(
          combinedWipeText
        );

      const getPartOutfitRange = (pIdx) => {
        if (validImages.length === 0) return { startIdx: -1, endIdx: -1 };
        if (totalParts <= 1 || validImages.length === 1) {
          return { startIdx: 0, endIdx: validImages.length - 1 };
        }
        const startIdx = Math.min(
          validImages.length - 1,
          Math.floor(((pIdx - 1) * validImages.length) / totalParts)
        );
        const endIdx = Math.min(
          validImages.length - 1,
          Math.max(startIdx, Math.floor((pIdx * validImages.length) / totalParts) - 1)
        );
        return { startIdx, endIdx };
      };

      let currentImagesForPart = validImages;
      let lastRemoteVideoUrl = null;

      try {
        for (let partIdx = 1; partIdx <= totalParts; partIdx++) {
          if (abortSignal?.aborted) {
            throw new Error('Đã hủy lệnh theo yêu cầu người dùng.');
          }

          const curRange = getPartOutfitRange(partIdx);
          const prevRange = partIdx > 1 ? getPartOutfitRange(partIdx - 1) : curRange;
          const nextRange = partIdx < totalParts ? getPartOutfitRange(partIdx + 1) : curRange;
          const didSwitchNewOutfit =
            isMultiImageRow && partIdx > 1 && curRange.endIdx > 0 && curRange.startIdx > prevRange.endIdx;
          const willChangeOutfitNextPart =
            isMultiImageRow && partIdx < totalParts && nextRange.startIdx > curRange.endIdx;
          const nextOutfitNumber = willChangeOutfitNextPart ? nextRange.startIdx + 1 : null;

          const outfitBadgeLabel =
            isMultiImageRow && curRange.startIdx >= 0
              ? curRange.startIdx === curRange.endIdx
                ? ` • Bộ #${curRange.startIdx + 1}/${validImages.length}`
                : ` • Bộ #${curRange.startIdx + 1}➔#${curRange.endIdx + 1}/${validImages.length}`
              : '';
          const partSpeechPreview =
            settings.enableDialogue && rowDialoguePlan.partScripts[partIdx - 1]
              ? rowDialoguePlan.partScripts[partIdx - 1]
              : '';
          const dialogueBadgeLabel = partSpeechPreview
            ? ` • 🎙️ "${partSpeechPreview.slice(0, 24)}${partSpeechPreview.length > 24 ? '…' : ''}"`
            : '';
          const partLabel =
            totalParts > 1
              ? ` (Phần ${partIdx}/${totalParts}${outfitBadgeLabel}${dialogueBadgeLabel} • Mục tiêu ${humanDurLabel})`
              : isMultiImageRow
              ? ` (${validImages.length} ảnh biến hình${dialogueBadgeLabel})`
              : dialogueBadgeLabel
              ? ` (${dialogueBadgeLabel.replace(/^\s*•\s*/, '')})`
              : '';
          const partSettings = {
            ...settings,
            duration: getPartDurationStr(partIdx)
          };

          if (partIdx === 1) {
            if (totalParts <= 1) {
              currentImagesForPart = validImages.map((img, idx) => ({
                ...img,
                role: idx === 0 ? 'primary_identity_and_outfit1' : 'extra_outfit',
                outfitNumber: idx + 1
              }));
            } else {
              const p1Count = Math.max(1, curRange.endIdx + 1);
              currentImagesForPart = validImages.slice(0, p1Count).map((img, idx) => ({
                ...img,
                role: idx === 0 ? 'primary_identity_and_outfit1' : 'extra_outfit',
                outfitNumber: idx + 1
              }));
            }
          }

          if (partIdx > 1 && partFilePaths.length > 0) {
            const prevVideoFile = partFilePaths[partFilePaths.length - 1];

            if (hasCharacterReference) {
              // ĐỒNG NHẤT NHÂN VẬT TUYỆT ĐỐI CHO VIDEO DÀI >= 20s:
              // 1. Đính kèm ẢNH THAM CHIẾU NHÂN VẬT GỐC ở vị trí #1 (ƯU TIÊN SỐ 1 TUYỆT ĐỐI để khóa 100% khuôn mặt & nhân vật không bị biến đổi)
              // 2. Đính kèm KHUNG HÌNH CUỐI của Phần (partIdx - 1) ở vị trí #2 làm tham chiếu nối tiếp tư thế/chuyển động/bối cảnh mượt mà
              const origExt = path.extname(originIdentityImage.filePath) || '.jpg';
              const primaryCharName = `1_PRIMARY_CHARACTER_REFERENCE_Row${rowPad}${origExt}`;
              const primaryCharPath = path.join(tempPartsDir, primaryCharName);
              const lastFrameName = `2_CONTINUATION_LAST_FRAME_Row${rowPad}_FromPart${partIdx - 1}.png`;
              const lastFramePath = path.join(tempPartsDir, lastFrameName);

              reportStatus(
                'uploading',
                isMultiImageRow && curRange.endIdx > 0
                  ? `[Đồng nhất Nhân Vật ${humanDurLabel}] Đang ưu tiên Ảnh gốc nhân vật (#1) + Khung cuối Phần ${
                      partIdx - 1
                    } (#2) + Bộ đồ #${curRange.startIdx + 1} cho Phần ${partIdx}/${totalParts}...`
                  : `[Đồng nhất Nhân Vật ${humanDurLabel}] Đang ưu tiên Ảnh gốc nhân vật (#1) + nối tiếp Khung cuối Phần ${
                      partIdx - 1
                    } (#2) cho Phần ${partIdx}/${totalParts}...`
              );

              await extractLastFrameFromVideo(this.appRootDir, prevVideoFile, lastFramePath);

              const primaryRole =
                isMultiImageRow && curRange.endIdx > 0
                  ? 'primary_character_face_priority'
                  : 'primary_character_priority';

              currentImagesForPart = [];
              try {
                fs.copyFileSync(originIdentityImage.filePath, primaryCharPath);
                currentImagesForPart.push({
                  filePath: primaryCharPath,
                  savedName: primaryCharName,
                  fileName: primaryCharName,
                  role: primaryRole,
                  outfitNumber: 1
                });
              } catch (_) {
                currentImagesForPart.push({
                  ...originIdentityImage,
                  savedName: primaryCharName,
                  fileName: primaryCharName,
                  role: primaryRole,
                  outfitNumber: 1
                });
              }

              currentImagesForPart.push({
                filePath: lastFramePath,
                savedName: lastFrameName,
                fileName: lastFrameName,
                role: 'continuation_last_frame'
              });

              if (isMultiImageRow && curRange.endIdx > 0) {
                const firstNewIdx = Math.max(1, curRange.startIdx);
                for (let oIdx = firstNewIdx; oIdx <= curRange.endIdx; oIdx++) {
                  const targetOutfitImg = validImages[oIdx];
                  if (!targetOutfitImg || !targetOutfitImg.filePath || !fs.existsSync(targetOutfitImg.filePath)) continue;
                  const outExt = path.extname(targetOutfitImg.filePath) || '.jpg';
                  const attachNum = currentImagesForPart.length + 1;
                  const outfitCopyName = `${attachNum}_TargetNewOutfit_Set${oIdx + 1}_Row${rowPad}${outExt}`;
                  const outfitCopyPath = path.join(tempPartsDir, outfitCopyName);
                  try {
                    fs.copyFileSync(targetOutfitImg.filePath, outfitCopyPath);
                    currentImagesForPart.push({
                      filePath: outfitCopyPath,
                      savedName: outfitCopyName,
                      fileName: outfitCopyName,
                      role: 'target_outfit',
                      outfitNumber: oIdx + 1
                    });
                  } catch (_) {
                    currentImagesForPart.push({
                      ...targetOutfitImg,
                      role: 'target_outfit',
                      outfitNumber: oIdx + 1
                    });
                  }
                }
              }
            } else {
              const lastFrameName = `1_StartFrame_Row${rowPad}_FromPart${partIdx - 1}.png`;
              const lastFramePath = path.join(tempPartsDir, lastFrameName);
              reportStatus(
                'uploading',
                `[Nối đuôi ${humanDurLabel}] Đang trích khung cuối từ Phần ${partIdx - 1} cho Phần ${partIdx}/${totalParts}...`
              );
              await extractLastFrameFromVideo(this.appRootDir, prevVideoFile, lastFramePath);

              currentImagesForPart = [
                {
                  filePath: lastFramePath,
                  savedName: lastFrameName,
                  fileName: lastFrameName,
                  role: 'continuation_last_frame_only'
                }
              ];
            }
          }

          const maxPartAttempts = totalParts > 1 ? 2 : 1;
          let partCompleted = false;
          let lastPartError = null;

          for (let partAttempt = 1; partAttempt <= maxPartAttempts; partAttempt++) {
            if (abortSignal?.aborted) {
              throw new Error('Đã hủy lệnh theo yêu cầu người dùng.');
            }

            const runToken = Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 4);
            const uniqueRunTag =
              totalParts > 1
                ? `mfs_row${rowPad}_p${partIdx}_${runToken}`
                : `mfs_row${rowPad}_${runToken}`;

            let baselineAttachmentKeys = new Set();

            const finalPrompt = this._buildFinalPrompt({
              userPrompt: row.prompt,
              rowDialogue: row.dialogue || '',
              settings: partSettings,
              validImages: currentImagesForPart,
              rowIndex,
              uniqueRunTag,
              partIdx,
              totalParts,
              requestedSec,
              activeSkill,
              sampleBlueprint,
              multiOutfitContext: {
                isMultiImageRow,
                hasCharacterReference,
                totalOutfits: validImages.length,
                curOutfitStart: curRange.startIdx + 1,
                curOutfitEnd: curRange.endIdx + 1,
                isPropWipeTransition,
                preparePropWipeAtEnd: willChangeOutfitNextPart,
                nextOutfitNumber,
                didSwitchNewOutfit
              }
            });

            const submitPartToMuse = async (isRetry = false) => {
              await this._withSubmitLock(account.id, async () => {
                if (abortSignal?.aborted) throw new Error('Đã hủy lệnh.');

                await this._dismissAnyOverlaysAndLightboxes(musePage);

                if (!isRetry) {
                  const beforeItems = await this._extractValidAttachmentVideosFromDom(musePage, account.id);
                  baselineAttachmentKeys = new Set(beforeItems.map((it) => it.key));
                }

                await this._clearComposerBeforeUpload(musePage);

                if (currentImagesForPart.length > 0) {
                  reportStatus(
                    'uploading',
                    `[Chạy Ngầm] Đang tải ảnh tham chiếu Hàng #${rowIndex}${partLabel}${
                      isRetry || partAttempt > 1 ? ' (Gửi lại)' : ''
                    }...`
                  );
                  const imageFilePaths = currentImagesForPart.map((img) => img.filePath);
                  await this._uploadReferenceImagesViaCdp(musePage, imageFilePaths, settings.customSelectors);
                }

                reportStatus(
                  'submitting',
                  `[Chạy Ngầm] Đang gửi lệnh Hàng #${rowIndex}${partLabel} (Mã: ${uniqueRunTag}.mp4)...`
                );

                await this._typeAndSubmitPromptViaCdp(musePage, finalPrompt, uniqueRunTag, settings.customSelectors);
              });
            };

            let capturedVideo = null;
            try {
              await submitPartToMuse(false);

              reportStatus(
                'rendering',
                `[Chạy Ngầm] Đang chờ Muse.ai render Hàng #${rowIndex}${partLabel}...`
              );

              capturedVideo = await this._waitForGeneratedVideoViaCdp({
                page: musePage,
                accountId: account.id,
                baselineAttachmentKeys,
                usedRemoteSrcs,
                rowIndex,
                partIdx,
                totalParts,
                uniqueRunTag,
                abortSignal,
                resubmitPromptFn: async () => {
                  await submitPartToMuse(true);
                },
                onLiveStatus: (liveText, elapsedSec) => {
                  reportStatus(
                    'rendering',
                    liveText
                      ? `[Hàng #${rowIndex}${partLabel} • ${elapsedSec}s] ${liveText}`
                      : `[Chạy Ngầm • ${elapsedSec}s] Đang render Hàng #${rowIndex}${partLabel}...`
                  );
                }
              });

              const partVideoPath =
                totalParts === 1
                  ? destFilePath
                  : path.join(tempPartsDir, `part_${partIdx}_a${partAttempt}_${Date.now()}.mp4`);

              reportStatus(
                'downloading',
                `[Chạy Ngầm] Đã nhận xong Phần ${partIdx}/${totalParts} của Hàng #${rowIndex}! Đang tải về...`
              );

              await this._downloadVideoViaCdp(musePage, conn.context, capturedVideo.src, partVideoPath, {
                ...capturedVideo,
                uniqueRunTag
              });

              if (!fs.existsSync(partVideoPath) || fs.statSync(partVideoPath).size < MIN_REAL_VIDEO_BYTES) {
                throw new Error(`File tải về của Phần ${partIdx}/${totalParts} không hợp lệ hoặc bị rỗng.`);
              }

              if (totalParts === 1) {
                await ensureUniversalPlayableMp4(this.appRootDir, partVideoPath);
              }

              lastRemoteVideoUrl = capturedVideo.src;
              usedRemoteSrcs.add(capturedVideo.src);
              partFilePaths.push(partVideoPath);
              partCompleted = true;

              if (totalParts > 1) {
                if (partFilePaths.length >= 2) {
                  const isIntermediateLongPreview = partIdx < totalParts && totalParts > 3;
                  await concatExtendedPartFiles(
                    this.appRootDir,
                    partFilePaths,
                    destFilePath,
                    settings.transitionEffect || 'fade',
                    {
                      cacheDir: tempPartsDir,
                      fastPreviewOnly: isIntermediateLongPreview,
                      hasSpokenDialogue: hasSpokenDialogueForConcat
                    }
                  );
                  const currentStat = fs.statSync(destFilePath);
                  if (partIdx < totalParts) {
                    reportStatus(
                      'rendering',
                      `Đã ghép ${partIdx}/${totalParts} phần (${(currentStat.size / (1024 * 1024)).toFixed(
                        1
                      )} MB) — Đang tạo tiếp Phần ${partIdx + 1}/${totalParts} (${humanDurLabel})...`,
                      {
                        videoUrl: `${publicVideoUrl}?v=${partIdx}`,
                        videoFilePath: destFilePath
                      }
                    );
                  }
                } else if (partIdx < totalParts) {
                  const p1Stat = fs.statSync(partVideoPath);
                  reportStatus(
                    'rendering',
                    `Đã hoàn tất Phần 1/${totalParts} (${(p1Stat.size / (1024 * 1024)).toFixed(
                      1
                    )} MB) — Đang tạo tiếp Phần 2/${totalParts} (${humanDurLabel})...`
                  );
                }
              }

              break;
            } catch (attemptErr) {
              lastPartError = attemptErr;
              if (capturedVideo) {
                if (capturedVideo.src) usedRemoteSrcs.add(capturedVideo.src);
                if (capturedVideo.key) this.discoveredVideosCache.delete(capturedVideo.key);
              }

              const errMsg = String(attemptErr?.message || '');
              const isNonRetryable =
                abortSignal?.aborted ||
                /đã hủy|đã dừng|chưa đăng nhập|bị chặn|safety\s*filter|policy\s*violation/i.test(errMsg);

              if (partAttempt < maxPartAttempts && !isNonRetryable) {
                reportStatus(
                  'rendering',
                  `[Tự động phục hồi] Phần ${partIdx}/${totalParts} gặp lỗi tạm thời (${errMsg.slice(
                    0,
                    65
                  )}) — Đang thử lại Phần ${partIdx}/${totalParts}...`
                );
                await musePage.waitForTimeout(2000).catch(() => {});
                continue;
              }
              break;
            }
          }

          if (!partCompleted) {
            if (partFilePaths.length > 0 && !abortSignal?.aborted) {
              await concatExtendedPartFiles(
                this.appRootDir,
                partFilePaths,
                destFilePath,
                settings.transitionEffect || 'fade',
                {
                  cacheDir: tempPartsDir,
                  fastPreviewOnly: false,
                  hasSpokenDialogue: hasSpokenDialogueForConcat
                }
              );
              if (fs.existsSync(destFilePath)) {
                const partialStat = fs.statSync(destFilePath);
                reportStatus(
                  'completed',
                  `Hoàn tất ${partFilePaths.length}/${totalParts} phần (~${partFilePaths.length * 10}s / ${humanDurLabel} • ${(
                    partialStat.size /
                    (1024 * 1024)
                  ).toFixed(2)} MB) — Phần ${partIdx} dừng sớm: ${lastPartError?.message || 'Không rõ lỗi'}`,
                  {
                    videoUrl: publicVideoUrl,
                    videoFilePath: destFilePath,
                    remoteVideoUrl: lastRemoteVideoUrl,
                    fileSize: partialStat.size,
                    completedAt: new Date().toISOString(),
                    error: null
                  }
                );
                return this.accountManager.getAccount(account.id).rows.find((r) => r.index === Number(rowIndex));
              }
            }
            throw lastPartError || new Error(`Không thể hoàn tất Phần ${partIdx}/${totalParts}.`);
          }
        }

        const stat = fs.statSync(destFilePath);
        const doneMsg =
          totalParts > 1
            ? `Hoàn tất video dài ${humanDurLabel} (${totalParts} phần • ${(stat.size / (1024 * 1024)).toFixed(2)} MB)!`
            : `Hoàn tất! Video Hàng #${rowIndex} đã lưu (${(stat.size / (1024 * 1024)).toFixed(2)} MB)`;

        reportStatus('completed', doneMsg, {
          videoUrl: `${publicVideoUrl}?v=${Date.now()}`,
          videoFilePath: destFilePath,
          remoteVideoUrl: lastRemoteVideoUrl,
          fileSize: stat.size,
          completedAt: new Date().toISOString(),
          error: null
        });

        return this.accountManager.getAccount(account.id).rows.find((r) => r.index === Number(rowIndex));
      } finally {
        try {
          fs.rmSync(tempPartsDir, { recursive: true, force: true });
        } catch (_) {}
      }
    } catch (err) {
      reportStatus('error', `Lỗi CDP: ${err.message}`, {
        error: err.message
      });
      throw err;
    } finally {
      const rem = (this.activeExecutions.get(account.id) || 1) - 1;
      if (rem <= 0) {
        this.activeExecutions.delete(account.id);
        // Tự động cập nhật lại số dư Token sau khi hoàn tất lượt tạo video
        this.syncAccountQuotaAndProfile(account.id).catch(() => {});
      } else {
        this.activeExecutions.set(account.id, rem);
      }
    }
  }

  /**
   * Tự động đóng và vô hiệu hóa vĩnh viễn mọi lớp phủ phóng to video ([data-hatch-media-lightbox="true"],
   * [role="dialog"][data-state="open"]) trên muse.ai để KHÔNG BAO GIỜ chặn thao tác nhập/gửi lệnh.
   */
  async _dismissAnyOverlaysAndLightboxes(page) {
    try {
      const hadOverlay = await page
        .evaluate(() => {
          // 1. Tiêm CSS vĩnh viễn ngăn lớp phủ media lightbox chặn con trỏ chuột
          if (!document.getElementById('mfs-disable-lightbox-style')) {
            const style = document.createElement('style');
            style.id = 'mfs-disable-lightbox-style';
            style.textContent = `
              [data-hatch-media-lightbox="true"],
              [data-pel-impression="media_viewer_impression"] {
                display: none !important;
                visibility: hidden !important;
                pointer-events: none !important;
                opacity: 0 !important;
                z-index: -9999 !important;
              }
            `;
            (document.head || document.documentElement).appendChild(style);
          }

          // 2. Tìm và đóng/gỡ bỏ mọi lightbox hoặc modal dialog đang mở che khuất ô textarea
          const lightboxes = Array.from(
            document.querySelectorAll(
              '[data-hatch-media-lightbox="true"], [data-pel-impression="media_viewer_impression"], [role="dialog"][data-state="open"]'
            )
          );

          let dismissed = false;
          for (const dlg of lightboxes) {
            // Bấm nút Close bên trong dialog nếu có
            const closeBtn = dlg.querySelector(
              'button[aria-label*="Close" i], button[aria-label*="Đóng" i], [data-testid*="close" i]'
            );
            if (closeBtn) {
              try {
                closeBtn.click();
              } catch (_) {}
            }
            // Nếu là media lightbox hoặc dialog phủ toàn màn hình (fixed inset-0), gỡ khỏi DOM để giải phóng hoàn toàn
            const cls = String(dlg.className || '');
            if (
              dlg.hasAttribute('data-hatch-media-lightbox') ||
              dlg.getAttribute('data-pel-impression') === 'media_viewer_impression' ||
              (cls.includes('fixed') && cls.includes('inset-0'))
            ) {
              try {
                dlg.remove();
              } catch (_) {
                dlg.style.setProperty('display', 'none', 'important');
                dlg.style.setProperty('pointer-events', 'none', 'important');
              }
              dismissed = true;
            }
          }

          // Đảm bảo body không bị khóa pointer-events bởi Radix Dialog
          if (document.body && document.body.style.pointerEvents === 'none') {
            document.body.style.pointerEvents = 'auto';
          }

          return dismissed;
        })
        .catch(() => false);

      if (hadOverlay) {
        await page.keyboard.press('Escape').catch(() => {});
        await page.waitForTimeout(150);
      }
    } catch (_) {}
  }

  /**
   * Làm sạch khung nhập chat và các file đính kèm còn sót trước khi tải ảnh của hàng mới
   * (Thực thi trực tiếp trong DOM để không bao giờ bị lỗi timeout khi click)
   */
  async _clearComposerBeforeUpload(page) {
    try {
      await this._dismissAnyOverlaysAndLightboxes(page);
      await page
        .evaluate(() => {
          const removeBtns = Array.from(
            document.querySelectorAll(
              'form button[aria-label*="Remove" i], form button[aria-label*="Delete" i], [data-testid*="remove-attachment" i], button[aria-label*="Remove attachment" i], button[aria-label*="Delete attachment" i]'
            )
          );
          for (const btn of removeBtns) {
            try {
              btn.click();
            } catch (_) {}
          }
        })
        .catch(() => {});
    } catch (_) {}
  }

  /**
   * Quét DOM muse.ai và trích xuất các video thành phẩm thật (> 600KB) nằm trong
   * [data-testid="hatch-chat-attachment-presentation-video"], đồng thời lưu vào bộ nhớ đệm discoveredVideosCache
   * tách biệt hoàn toàn theo từng tài khoản (accountId) và miễn nhiễm khi Muse.ai xoay vòng blob: URL.
   */
  async _extractValidAttachmentVideosFromDom(page, accountId = 'default') {
    const scopePrefix = `${accountId}::`;
    const liveItems = await page.evaluate(async (minBytes) => {
      const results = [];
      const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
      const containers = Array.from(
        document.querySelectorAll(
          '[data-testid="hatch-chat-attachment-presentation-video"], [data-hatch-video-wrapper="true"]'
        )
      );

      const seenSrc = new Set();
      const msgAttCounter = new Map();

      for (const c of containers) {
        if (
          c.hasAttribute('data-hatch-avatar-layer') ||
          c.getAttribute('data-hatch-media-owner') === 'avatar-layer' ||
          c.querySelector('[data-hatch-media-owner="avatar-layer"]')
        ) {
          continue;
        }

        const wrapper = c.hasAttribute('data-hatch-video-wrapper')
          ? c
          : c.querySelector('[data-hatch-video-wrapper="true"]');
        const videoEl = c.querySelector('video');

        if (videoEl) {
          if (
            videoEl.hasAttribute('data-hatch-avatar-layer') ||
            videoEl.getAttribute('data-hatch-media-owner') === 'avatar-layer' ||
            videoEl.getAttribute('aria-hidden') === 'true'
          ) {
            continue;
          }
        }

        const src =
          (wrapper && wrapper.getAttribute('data-hatch-video-src')) ||
          (videoEl && (videoEl.currentSrc || videoEl.src)) ||
          '';

        if (!src || seenSrc.has(src)) continue;
        if (
          src.includes('hatch_connecting') ||
          src.includes('hatch_working') ||
          src.includes('og-video') ||
          src.includes('/videos/avatars/')
        ) {
          continue;
        }

        let blobSize = 0;
        if (src.startsWith('blob:')) {
          try {
            const res = await fetch(src);
            const blob = await res.blob();
            blobSize = blob.size;
            if (blobSize < minBytes) {
              continue;
            }
          } catch (_) {
            continue;
          }
        }

        seenSrc.add(src);
        const msgEl = c.closest('[data-message-item="true"], [data-message-id]');
        const messageId = msgEl ? msgEl.getAttribute('data-message-id') || '' : '';
        const ariaLabel = wrapper
          ? wrapper.getAttribute('aria-label') || ''
          : c.getAttribute('aria-label') || '';

        const domMsgIndex = msgEl ? allMsgs.indexOf(msgEl) : -1;
        let precedingUserText = '';
        if (domMsgIndex > 0) {
          for (let k = domMsgIndex - 1; k >= 0; k--) {
            if (allMsgs[k].getAttribute('data-message-role') === 'user') {
              precedingUserText = (allMsgs[k].textContent || '').slice(0, 800);
              break;
            }
          }
        }

        const attIdx = msgAttCounter.get(messageId || '__nomsg__') || 0;
        msgAttCounter.set(messageId || '__nomsg__', attIdx + 1);

        let stableId;
        if (messageId && ariaLabel) {
          stableId = `${messageId}::${ariaLabel}`;
        } else if (messageId) {
          stableId = `${messageId}::att${attIdx}`;
        } else if (ariaLabel) {
          stableId = `nomsg::${ariaLabel}`;
        } else {
          stableId = src;
        }

        results.push({
          stableId,
          messageId,
          ariaLabel,
          src,
          size: blobSize,
          domMsgIndex,
          precedingUserText
        });
      }

      return results;
    }, MIN_REAL_VIDEO_BYTES);

    const liveScopedKeys = new Set();
    for (const item of liveItems) {
      const scopedKey = `${scopePrefix}${item.stableId}`;
      liveScopedKeys.add(scopedKey);
      // Luôn cập nhật src mới nhất để khi React xoay vòng blob: URL không bị mất liên kết hoặc sinh key trùng lặp
      this.discoveredVideosCache.set(scopedKey, {
        ...item,
        key: scopedKey
      });
    }

    // Dọn dẹp các blob: URL ngoài màn hình đã bị trình duyệt thu hồi (revoked) để không bao giờ gây lỗi Failed to fetch
    const offscreenBlobEntries = [];
    for (const [k, val] of this.discoveredVideosCache.entries()) {
      if (
        k.startsWith(scopePrefix) &&
        !liveScopedKeys.has(k) &&
        val &&
        typeof val.src === 'string' &&
        val.src.startsWith('blob:')
      ) {
        offscreenBlobEntries.push({ key: k, src: val.src });
      }
    }

    if (offscreenBlobEntries.length > 0) {
      const deadKeys = await page
        .evaluate(
          async ({ entries, minBytes }) => {
            const dead = [];
            for (const entry of entries) {
              try {
                const r = await fetch(entry.src);
                const b = await r.blob();
                if (!b || b.size < minBytes) dead.push(entry.key);
              } catch (_) {
                dead.push(entry.key);
              }
            }
            return dead;
          },
          { entries: offscreenBlobEntries, minBytes: MIN_REAL_VIDEO_BYTES }
        )
        .catch(() => []);

      for (const dk of deadKeys) {
        this.discoveredVideosCache.delete(dk);
      }
    }

    const accountVideos = [];
    for (const [k, val] of this.discoveredVideosCache.entries()) {
      if (k.startsWith(scopePrefix)) {
        accountVideos.push(val);
      }
    }
    return accountVideos;
  }

  /**
   * Tải lên ảnh tham chiếu của hàng hiện tại và ĐỢI ảnh tải lên hoàn tất trên khung soạn thảo.
   * LƯU Ý QUAN TRỌNG: Tuyệt đối KHÔNG dùng selector '[data-testid*="attach" i]' vì nó trùng với
   * '[data-testid="hatch-chat-attachment-presentation-video"]' (bấm vào sẽ mở phóng to video làm che khung chat!).
   */
  async _uploadReferenceImagesViaCdp(page, filePaths, customSelectors = {}) {
    await this._dismissAnyOverlaysAndLightboxes(page);

    const setFilesSmartOnLocator = async (inputLocator, paths) => {
      if (paths.length <= 1) {
        await inputLocator.setInputFiles(paths);
        return;
      }
      const isMulti = await inputLocator.evaluate((el) => Boolean(el.multiple)).catch(() => false);
      if (isMulti) {
        await inputLocator.setInputFiles(paths);
      } else {
        for (const fp of paths) {
          await inputLocator.setInputFiles(fp);
          await page.waitForTimeout(550);
        }
      }
    };

    const customFileSel = customSelectors?.fileInput?.trim();
    if (customFileSel) {
      const count = await page.locator(customFileSel).count().catch(() => 0);
      if (count > 0) {
        await setFilesSmartOnLocator(page.locator(customFileSel).first(), filePaths);
        await this._waitForAttachmentUploadReady(page);
        return true;
      }
    }

    // Ưu tiên số 1: Gán trực tiếp vào thẻ input[type="file"] nếu đã tồn tại sẵn trong DOM (hỗ trợ cả đính kèm kép 2 ảnh nối tiếp + khóa mặt)
    const directFileInput = page.locator('input[type="file"]').first();
    if ((await directFileInput.count().catch(() => 0)) > 0) {
      try {
        await setFilesSmartOnLocator(directFileInput, filePaths);
        await this._waitForAttachmentUploadReady(page);
        return true;
      } catch (_) {}
    }

    // Ưu tiên số 2: Bấm nút đính kèm file trong vùng soạn thảo (chỉ chọn thẻ button, tuyệt đối không chọn thẻ video attachment)
    const attachSelectors = [
      'form button[aria-label="Attach file"]',
      'button[aria-label="Attach file"]',
      'form button[aria-label*="attach" i]',
      'button[aria-label*="attach file" i]',
      'form button[aria-label*="upload" i]',
      'form button[aria-label*="add" i]'
    ];

    for (const sel of attachSelectors) {
      const btn = page.locator(sel).first();
      if ((await btn.count().catch(() => 0)) > 0 && (await btn.isVisible().catch(() => false))) {
        try {
          const [fileChooser] = await Promise.all([
            page.waitForEvent('filechooser', { timeout: 3500 }),
            btn.click({ force: true, timeout: 2500 })
          ]);
          if (fileChooser) {
            if (fileChooser.isMultiple()) {
              await fileChooser.setFiles(filePaths);
            } else {
              await fileChooser.setFiles(filePaths[0]);
              for (let i = 1; i < filePaths.length; i++) {
                const [nextChooser] = await Promise.all([
                  page.waitForEvent('filechooser', { timeout: 3500 }),
                  btn.click({ force: true, timeout: 2500 })
                ]);
                await nextChooser.setFiles(filePaths[i]);
              }
            }
            await this._waitForAttachmentUploadReady(page);
            return true;
          }
        } catch (_) {
          if ((await page.locator('input[type="file"]').count().catch(() => 0)) > 0) {
            try {
              await page.locator('input[type="file"]').first().setInputFiles(filePaths);
              await this._waitForAttachmentUploadReady(page);
              return true;
            } catch (_) {}
          }
        }
      }
    }

    // Ưu tiên số 3: Truyền trực tiếp dữ liệu ảnh qua sự kiện Clipboard Paste / Drag & Drop trong DOM
    const filesPayload = filePaths.map((fp) => {
      const buffer = fs.readFileSync(fp);
      const ext = path.extname(fp).toLowerCase();
      const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
      return {
        name: path.basename(fp),
        mime,
        base64: buffer.toString('base64')
      };
    });

    await page.evaluate(async (filesData) => {
      const target =
        document.querySelector('textarea:not([disabled])') ||
        document.querySelector('textarea') ||
        document.querySelector('[contenteditable="true"]') ||
        document.querySelector('[role="textbox"]') ||
        document.body;
      if (!target) return;
      try {
        target.focus();
      } catch (_) {}

      const dt = new DataTransfer();
      for (const item of filesData) {
        const binStr = atob(item.base64);
        const bytes = new Uint8Array(binStr.length);
        for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
        dt.items.add(new File([bytes], item.name, { type: item.mime }));
      }

      target.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
      target.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
    }, filesPayload);

    await this._waitForAttachmentUploadReady(page);
    return true;
  }

  /**
   * Đợi cho đến khi ảnh tham chiếu vừa chọn được tải lên xong trên khung soạn thảo (không còn spinner tải ảnh)
   */
  async _waitForAttachmentUploadReady(page) {
    await page.waitForTimeout(1800);
    const startWait = Date.now();
    while (Date.now() - startWait < 12000) {
      const isUploading = await page
        .evaluate(() => {
          // Kiểm tra xem trong vùng composer còn thanh tiến trình upload ảnh hay không
          const spinners = document.querySelectorAll(
            'form [role="progressbar"], [data-testid*="upload-progress" i], [data-testid*="loading" i]'
          );
          return spinners.length > 0;
        })
        .catch(() => false);
      if (!isUploading) break;
      await page.waitForTimeout(500);
    }
    await page.waitForTimeout(600);
  }

  /**
   * Tạo cấu trúc phân đoạn mạch lạc, liên tục cho video dài (20s, 30s, 40s, 50s, 60s)
   * Giúp video không bị phân mảnh thành các đoạn 10s độc lập rời rạc,
   * mà có mạch truyện thống nhất từ giây đầu tiên đến giây cuối cùng!
   */
  _buildCameraMotionDirective(cameraMotion, partIdx = 1, totalParts = 1) {
    const mode = String(cameraMotion || 'Auto').trim();
    if (!mode || mode === 'Auto') return '';

    switch (mode) {
      case 'POV':
        return [
          `[CAMERA ANGLE & PERSPECTIVE: FIRST-PERSON POV (POINT OF VIEW)]`,
          `• Shoot strictly from an authentic first-person eye-level POV perspective as seen directly through the viewer's own eyes standing naturally in front of (or interacting directly with) the character.`,
          `• Maintain natural human eye-level height, realistic spatial proximity, direct eye-line engagement, and organic handheld micro-presence without disorienting camera shake.`
        ].join('\n');

      case 'Consistency':
        return [
          `[CAMERA ANGLE & FRAMING: 100% LOCKED CAMERA CONSISTENCY${
            totalParts > 1 ? ` — IDENTICAL ACROSS ALL ${totalParts} SEGMENTS` : ''
          }]`,
          `• Lock 100% fixed camera angle, exact eye-level height, constant lens focal length, and constant subject-to-camera framing distance from 0.0s to the final frame${
            totalParts > 1 ? ` (matching Segment #1's exact framing 1:1)` : ''
          }.`,
          `• ZERO random zoom-in or zoom-out, ZERO sudden close-up cropping, ZERO angle switching, and ZERO Dutch tilt drift!`
        ].join('\n');

      case 'Cinematic Pan':
        return `[CAMERA MOTION: CINEMATIC PAN] Execute a smooth, stabilized horizontal cinematic pan across the scene while keeping the character cleanly framed without facial distortion.`;

      case 'Slow Zoom In':
        return `[CAMERA MOTION: SLOW ZOOM IN] Execute a gentle, controlled slow push-in / dolly-in toward the character at steady cinematic speed without wide-angle lens distortion.`;

      case 'Slow Zoom Out':
        return `[CAMERA MOTION: SLOW ZOOM OUT] Execute a smooth, controlled slow pull-back / dolly-out revealing the character and surrounding scene harmoniously.`;

      case 'Dynamic Tracking':
        return `[CAMERA MOTION: DYNAMIC TRACKING] Smoothly track alongside the character's movement on a stabilized gimbal, keeping balanced framing throughout.`;

      case 'Orbit 360':
        return `[CAMERA MOTION: ORBITAL ARC] Smoothly arc/orbit around the subject with stabilized cinematic motion while preserving 100% character identity and scene consistency.`;

      default:
        return '';
    }
  }

  _generateProgressivePartPrompt(
    userPrompt,
    partIdx,
    totalParts,
    requestedSec,
    enableDialogue,
    activeSkill = null,
    multiOutfitContext = null,
    dialogueContext = null
  ) {
    const rawOriginal = (userPrompt || '').trim();
    const mCtx = multiOutfitContext || {};
    const dCtx = dialogueContext || {};
    const isMultiOutfit = Boolean(mCtx.isMultiImageRow);
    const hasCharacterReference = Boolean(mCtx.hasCharacterReference);
    const isPropWipe = Boolean(mCtx.isPropWipeTransition);
    const preparePropWipeAtEnd = Boolean(mCtx.preparePropWipeAtEnd);
    const didSwitchNewOutfit = Boolean(mCtx.didSwitchNewOutfit);

    const dialoguePlan = dCtx.dialoguePlan || { hasExplicitScript: false, sourceType: 'none', partScripts: [] };
    const voiceDirective =
      dCtx.voiceDirective ||
      getVoicePresetDirective('auto', '');
    const partDurSec = Math.max(5, Math.min(10, Number(dCtx.partDurationSec) || 10));
    const safeEndSec = Math.max(3.6, partDurSec - 0.6).toFixed(1);

    const partSpeechText =
      enableDialogue && dialoguePlan.hasExplicitScript
        ? String(dialoguePlan.partScripts[partIdx - 1] || '').trim()
        : '';

    const motionAsksForSpeech =
      enableDialogue &&
      !dialoguePlan.hasExplicitScript &&
      /nói|thoại|chia\s*sẻ|giới\s*thiệu|thuyết\s*minh|\bmc\b|kể\s*chuyện|tâm\s*sự|chào|hát|phỏng\s*vấn|review|speak|talk|say|dialogue|monologue|narrat|greet/i.test(
        rawOriginal
      );

    const isSpeakingInThisPart = Boolean(partSpeechText || motionAsksForSpeech);

    // Nếu câu thoại nằm trực tiếp trong ô Prompt chuyển động (cú pháp cũ) của video nhiều phần,
    // lọc bỏ nội dung trong "..." khỏi cốt truyện hình ảnh chung để Phần 2/3 không bao giờ lặp lại câu của Phần 1!
    const raw =
      totalParts > 1 && dialoguePlan.sourceType === 'motion_inline_quotes'
        ? rawOriginal
            .replace(/[“”«»„‟]/g, '"')
            .replace(/"[^"]+"/g, '[spoken segment line]')
            .trim()
        : rawOriginal;

    const presenterMotionFallback =
      'Natural, lifelike on-camera speaker & presenter performance: maintain warm eye contact with the camera, authentic facial micro-expressions, natural breathing, and poised subtle hand gestures synchronized with the spoken dialogue while preserving 100% reference outfit and scene fidelity.';

    const skillFallbackAction = activeSkill
      ? `Analyze the attached reference image(s) and execute the exact visual direction, product fidelity, lighting, and camera movement specified in Skill "${activeSkill.name}".`
      : isSpeakingInThisPart
      ? presenterMotionFallback
      : 'Smooth cinematic motion, natural lighting, and high-fidelity details.';

    const buildPartDialogueBlock = () => {
      if (!enableDialogue) {
        return 'Character Voice / Dialogue: DISABLED. Pure ambient environmental sound and cinematic background score. No spoken dialogue, character mouth does not move for talking.';
      }
      if (dialoguePlan.hasExplicitScript) {
        if (partSpeechText) {
          const continuityVoiceNote =
            totalParts > 1 && partIdx > 1
              ? ` Maintain 100% identical speaker vocal cords, timbre, pitch, regional accent, and studio microphone space as Part ${
                  partIdx - 1
                }.`
              : '';
          return [
            `[MANDATORY SPOKEN DIALOGUE & LIP-SYNC — PART ${partIdx}/${totalParts} ONLY]`,
            `• Character Voice / Dialogue: ENABLED (Native Lip-Synced Speech).`,
            `• SHARED PROJECT VOICE PROFILE: ${voiceDirective}${continuityVoiceNote}`,
            `• EXACT VERBATIM SPOKEN SCRIPT FOR THIS ${partDurSec}s SEGMENT ONLY: "${partSpeechText}"`,
            `• STRICT SPEECH & ANTI-REPEAT RULES: The character MUST visibly speak ONLY the exact text inside quotation marks above word-for-word with accurate pronunciation and natural lip-sync articulation. DO NOT add extra filler words, DO NOT improvise other sentences, and NEVER repeat dialogue from earlier or later parts. Begin speaking naturally around 0.2s and finish the final syllable cleanly by ~${safeEndSec}s, leaving a gentle ~0.5s natural smile/breath at the ${partDurSec}.0s boundary so no word is ever cut off mid-syllable.`
          ].join('\n');
        }
        return `Character Voice / Dialogue (Part ${partIdx}/${totalParts}): SILENT SHOWCASE SEGMENT. All scripted lines were completed in earlier segments — in this segment, the character does NOT speak and MUST NOT repeat any earlier dialogue; keep a warm, natural closed-lip smile with smooth ambient sound.`;
      }
      if (motionAsksForSpeech) {
        return partIdx === 1 || totalParts <= 1
          ? `Character Voice / Dialogue: ENABLED. Shared Project Voice Profile: ${voiceDirective} The character speaks natural, authentic dialogue matching the scene with synchronized lip movements.`
          : `Character Voice / Dialogue: ENABLED. Shared Project Voice Profile: ${voiceDirective} Seamlessly continue speaking without repeating Part ${
              partIdx - 1
            }'s words, maintaining 100% matched vocal tone, pitch, and synchronized lip movements.`;
      }
      return 'Character Voice / Dialogue: NO SCRIPT ENTERED FOR THIS ROW — Pure ambient environmental audio and background music only. Character smiles naturally without random talking.';
    };

    if (totalParts <= 1) {
      return {
        taskType: isMultiOutfit
          ? `MULTI-OUTFIT PROP-WIPE TRANSITION SCENE (${mCtx.totalOutfits} OUTFITS IN ${requestedSec}s)`
          : 'STANDALONE SCENE',
        segmentTitle: isMultiOutfit
          ? `MULTI-OUTFIT SEAMLESS TRANSITION (${mCtx.totalOutfits} OUTFITS • ${requestedSec}s)`
          : `STANDALONE SCENE (${requestedSec}s)`,
        narrativeContent: raw || skillFallbackAction,
        momentumRule: isMultiOutfit
          ? `Smoothly showcase Outfit #1 and execute crisp prop/hand-fan lens-wipe transition(s) to reveal all ${mCtx.totalOutfits} attached reference outfits in exact order while keeping 100% identical model face and background scene.`
          : 'Create a complete, beautifully paced cinematic video from start to finish.',
        dialogueInstruction: buildPartDialogueBlock(),
        isSpeakingInThisPart
      };
    }

    const startSec = (partIdx - 1) * 10;
    const endSec = Math.min(requestedSec, partIdx * 10);
    const formatMinSec = (sec) => {
      const m = Math.floor(sec / 60);
      const s = sec % 60;
      return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    };
    const timecode = `Timeframe: [${formatMinSec(startSec)} - ${formatMinSec(endSec)} of ${formatMinSec(requestedSec)} continuous film]`;

    // Phân tích câu trong prompt của người dùng nếu có nhiều vế hành động
    const clauses = raw
      ? raw
          .split(/(?:\. |\n+|; |,\s*(?:rồi|sau đó|tiếp theo|kế tiếp|then|after that|next|finally)\s*)/i)
          .map((s) => s.trim())
          .filter(Boolean)
      : [];

    let segmentFocus = '';
    const progressRatio = totalParts > 1 ? (partIdx - 1) / (totalParts - 1) : 0;
    const outfitPhaseNote =
      isMultiOutfit && mCtx.curOutfitStart
        ? mCtx.curOutfitStart === mCtx.curOutfitEnd
          ? ` — Outfit #${mCtx.curOutfitStart} of ${mCtx.totalOutfits}`
          : ` — Outfits #${mCtx.curOutfitStart} to #${mCtx.curOutfitEnd} of ${mCtx.totalOutfits}`
        : '';
    const actStageLabel =
      (progressRatio < 0.25
        ? 'Act I (Opening & Establishing Movement)'
        : progressRatio < 0.78
        ? 'Act II (Progressive Action & Visual Showcase)'
        : 'Act III (Climactic Motion & Graceful Resolution)') + outfitPhaseNote;

    if (clauses.length >= totalParts) {
      segmentFocus = `Current Progression Focus (${actStageLabel}): ${clauses[partIdx - 1]}`;
    } else if (clauses.length > 1) {
      const mappedIdx = Math.min(
        clauses.length - 1,
        Math.floor(((partIdx - 1) / totalParts) * clauses.length)
      );
      segmentFocus = `Current Progression Focus (${actStageLabel} — Beat ${mappedIdx + 1}/${clauses.length}): ${
        clauses[mappedIdx]
      }`;
    } else {
      segmentFocus = `Story Action (${actStageLabel}): ${raw || skillFallbackAction}`;
    }

    let roleTitle = '';
    let momentumRule = '';
    const lastFrameAttachLabel = hasCharacterReference ? 'Attached Image #2' : 'Attached Image #1';
    const explicitlyWantsBackTurn =
      /quay\s*lưng|xoay\s*lưng|xoay\s*360|xoay\s*vòng|bước\s*đi\s*xa|nhìn\s*ra\s*sau|back\s*view|turn\s*around|turn\s*away/i.test(
        raw
      );
    const propWipeEndMandate = preparePropWipeAtEnd
      ? ` PROP / HAND-FAN LENS-WIPE OUT-TRANSITION AT END OF CLIP: During the final 0.6s–0.8s (around 09.2s–10.0s), have the model step/lean playfully closer and sweep the open hand fan / prop (or hand lens-wipe per Skill/prompt) straight across to completely cover 95%–100% of the camera lens at the final frame, setting up a seamless instant transformation into Outfit #${
          mCtx.nextOutfitNumber || (mCtx.curOutfitEnd || 1) + 1
        } in Part ${partIdx + 1}!`
      : '';
    const propWipeInMandate = didSwitchNewOutfit
      ? ` INSTANT NEW OUTFIT REVEAL FROM LENS-WIPE AT 00.0s: Start directly from ${lastFrameAttachLabel} (the prop/fan covering the lens at the end of Part ${
          partIdx - 1
        }); within the first 0.5s–0.8s, smoothly pull the fan/prop away from the lens to immediately reveal the EXACT SAME character from Attached Image #1 wearing 100% exact NEW Target Outfit #${
          mCtx.curOutfitStart
        } in the exact same background scene, then pull camera back smoothly to showcase the full head-to-toe silhouette!`
      : '';
    const faceBoundaryGuard =
      !explicitlyWantsBackTurn && !isPropWipe && !preparePropWipeAtEnd && partIdx < totalParts
        ? ` FACIAL IDENTITY GUARD AT 10s BOUNDARY: Ensure that approaching the 09.3s–10.0s mark, the character keeps their face clearly visible toward the camera (front or flattering 3/4 angle — DO NOT end this part with the character turned completely away or hiding their face), preserving 100% facial continuity into Part ${
            partIdx + 1
          }.`
        : '';

    const characterPriorityNote = hasCharacterReference
      ? ` MANDATORY CHARACTER PRIORITY: Attached Image #1 (Uploaded Character Reference) HAS #1 ABSOLUTE PRIORITY for 100% of the character's face, eyes, nose, mouth, hairstyle, body proportions, and identity — NEVER let the character drift or change! Use ${lastFrameAttachLabel} (final frame of Part ${
          partIdx - 1
        }) strictly for seamless starting pose, motion, framing, and scene continuity at 00.0s.`
      : '';

    if (partIdx === 1) {
      roleTitle = `PHASE 1/${totalParts} — OPENING INITIATION & CHARACTER IDENTITY ANCHOR (${timecode})`;
      momentumRule =
        'CRITICAL FORWARD MOMENTUM MANDATE: This is Part 1 of an unbroken ' +
        requestedSec +
        '-second continuous sequence. Lock 100% to the character identity in Attached Image #1 and initiate the action with natural fluid pacing. ' +
        (preparePropWipeAtEnd
          ? 'Showcase Outfit #1 clearly from full-body to medium shot, then execute the lens-wipe occlusion right at the end boundary.' +
            propWipeEndMandate
          : 'DO NOT slow down, do NOT freeze, and do NOT wrap up or conclude the action at the 10-second mark. Keep the subject in active, fluid, ongoing motion right through the 10.0-second boundary so it continues seamlessly into Part 2.' +
            faceBoundaryGuard);
    } else if (partIdx === totalParts) {
      roleTitle = `FINAL PHASE ${partIdx}/${totalParts} — CHARACTER-LOCKED CONTINUATION & RESOLUTION (${timecode})`;
      momentumRule =
        `CRITICAL CONTINUITY & CHARACTER LOCK MANDATE: Pick up IMMEDIATELY at 00.0s from the exact starting body pose, camera framing, and spatial position of ${lastFrameAttachLabel} (the final frame of Part ${
          partIdx - 1
        }) with ZERO JUMP CUTS and DO NOT restart the action from the beginning.` +
        characterPriorityNote +
        propWipeInMandate +
        ` Continue the motion trajectory fluidly and bring the entire ${requestedSec}-second sequence to its natural, radiant final pose while keeping 100% the exact character from Attached Image #1.`;
    } else {
      roleTitle = `PHASE ${partIdx}/${totalParts} — CHARACTER-LOCKED SEAMLESS PROGRESSION (${timecode})`;
      momentumRule =
        `CRITICAL CONTINUITY & CHARACTER LOCK MANDATE: Pick up IMMEDIATELY at 00.0s from the exact starting body pose, camera framing, and spatial position of ${lastFrameAttachLabel} (the final frame of Part ${
          partIdx - 1
        }) with ZERO JUMP CUTS.` +
        characterPriorityNote +
        propWipeInMandate +
        ' Carry the ongoing momentum forward and advance the showcase fluidly.' +
        (preparePropWipeAtEnd ? propWipeEndMandate : faceBoundaryGuard);
    }

    const dialogueInstruction = buildPartDialogueBlock();

    return {
      taskType: isMultiOutfit
        ? `CONTINUOUS MULTI-OUTFIT TRANSITION SEQUENCE (PART ${partIdx}/${totalParts}${outfitPhaseNote})`
        : hasCharacterReference
        ? `CHARACTER-LOCKED CONTINUOUS MULTI-SEGMENT SEQUENCE (PART ${partIdx}/${totalParts})`
        : `CONTINUOUS ONE-SHOT FILM SEQUENCE (PART ${partIdx}/${totalParts})`,
      segmentTitle: roleTitle,
      narrativeContent: `OVERALL UNIFIED VISUAL ARC: ${raw || skillFallbackAction}\n${segmentFocus}`,
      momentumRule,
      dialogueInstruction,
      isSpeakingInThisPart
    };
  }

  /**
   * Tạo lệnh Prompt chỉ định rõ:
   * 1. Đồng nhất nhân vật tuyệt đối với Ảnh tham chiếu gốc (#1 ưu tiên tuyệt đối) + nối tiếp mượt từ Khung hình cuối video trước (#2) cho video dài >= 20s
   * 2. Tách từng câu lời thoại "..." gán riêng cho đúng từng phân đoạn 10s + khóa giọng đọc chung từ Sidebar
   * 3. Hỗ trợ góc máy POV, Góc máy đồng nhất (Consistency) và các chuyển động camera chuyên sâu
   * 4. Áp dụng quy tắc Skill AI nếu dự án đang bật Skill (tự động mở khóa khẩu hình nếu hàng có lời thoại)
   * 5. Đặt tên file video xuất ra chính xác là ${uniqueRunTag}.mp4
   */
  _buildFinalPrompt(
    userPrompt,
    settings,
    validImages,
    rowIndex,
    uniqueRunTag,
    partIdx = 1,
    totalParts = 1,
    requestedSec = 10,
    activeSkill = null
  ) {
    let p = userPrompt;
    let rawDialogue = '';
    let s = settings;
    let imgs = validImages;
    let rIdx = rowIndex;
    let tag = uniqueRunTag;
    let pIdx = partIdx;
    let tParts = totalParts;
    let reqSec = requestedSec;
    let skill = activeSkill;
    let sBlueprint = null;
    let mCtx = null;

    if (typeof userPrompt === 'object' && userPrompt !== null && userPrompt.userPrompt !== undefined) {
      p = userPrompt.userPrompt;
      rawDialogue = userPrompt.rowDialogue || '';
      s = userPrompt.settings || {};
      imgs = userPrompt.validImages || [];
      rIdx = userPrompt.rowIndex;
      tag = userPrompt.uniqueRunTag;
      pIdx = userPrompt.partIdx || 1;
      tParts = userPrompt.totalParts || 1;
      reqSec = userPrompt.requestedSec || 10;
      skill = userPrompt.activeSkill || null;
      sBlueprint = userPrompt.sampleBlueprint || null;
      mCtx = userPrompt.multiOutfitContext || null;
    }

    const cleanPrompt = (p || '').trim();
    const rowPad = String(rIdx).padStart(2, '0');
    const imageNames = imgs.map((img) => img.savedName || img.fileName).join(', ');
    const enableDialogue = Boolean(s.enableDialogue);

    const dialoguePlan = splitDialogueIntoPartSegments({
      rowDialogue: rawDialogue,
      rowMotionPrompt: cleanPrompt,
      totalParts: tParts,
      enableDialogue
    });
    const voiceDirective = getVoicePresetDirective(s.voicePreset, s.voiceCustomNote);
    const partDurationSec = parseDurationSeconds(s.duration || '10s', 10);

    const effectiveUserAction =
      cleanPrompt ||
      (sBlueprint && s.sampleLearnMotion !== false && Array.isArray(sBlueprint.motionBeats)
        ? `Perform the learned sample video choreography smoothly and naturally: ${sBlueprint.motionBeats.join(' -> ')}`
        : '');

    const partInfo = this._generateProgressivePartPrompt(
      effectiveUserAction,
      pIdx,
      tParts,
      reqSec,
      enableDialogue,
      skill,
      mCtx,
      {
        dialoguePlan,
        voiceDirective,
        partDurationSec
      }
    );

    const sampleTransferBlock = this._buildSampleVideoTransferBlock(
      sBlueprint,
      s,
      pIdx,
      tParts,
      imgs.length > 0
    );

    const cameraMotionBlock = this._buildCameraMotionDirective(s.cameraMotion, pIdx, tParts);

    const targetOutfitImgs = imgs.filter((it) => it && it.role === 'target_outfit');
    const extraOutfitImgs = imgs.filter((it) => it && it.role === 'extra_outfit');
    const hasPrimaryCharPriority = imgs.some((it) => it && it.role === 'primary_character_priority');
    const hasPrimaryCharFacePriority = imgs.some((it) => it && it.role === 'primary_character_face_priority');
    const hasContinuationLastFrame = imgs.some((it) => it && it.role === 'continuation_last_frame');

    let skillDirectiveBlock = '';
    if (skill && skill.instructions) {
      const rawInst = String(skill.instructions).trim().slice(0, 3200);
      const preparedInst = partInfo.isSpeakingInThisPart
        ? sanitizeSkillInstructionsForDialogue(rawInst)
        : rawInst;
      const dialogueOverrideBanner = partInfo.isSpeakingInThisPart
        ? `\n[DIALOGUE OVERRIDE ON SKILL]: Spoken dialogue & lip-sync are ACTIVE for this segment — keep 100% of this Skill's visual choreography, character consistency, and garment fidelity, while allowing natural lip-synced speech!`
        : '';
      skillDirectiveBlock = `[ACTIVE CREATIVE SKILL: ${skill.name}]\nStrictly enforce all rules of this Skill:${dialogueOverrideBanner}\n${preparedInst}`;
    }

    const specs = [];
    if (s.aspectRatio) specs.push(`Aspect Ratio: ${s.aspectRatio}`);
    if (s.duration) specs.push(`Duration: ${s.duration}`);
    if (s.resolution) specs.push(`Resolution: ${s.resolution}`);
    if (s.cameraMotion && s.cameraMotion !== 'Auto') {
      specs.push(`Camera Motion: ${s.cameraMotion}`);
    }
    if (s.nativeAudio) {
      specs.push('Audio: Native synchronized sound');
    }

    let characterConsistencyBlock = '';
    if (imgs.length > 0) {
      if (pIdx > 1 && (hasPrimaryCharPriority || hasPrimaryCharFacePriority) && hasContinuationLastFrame) {
        characterConsistencyBlock = [
          `[ABSOLUTE CHARACTER CONSISTENCY & DUAL-REFERENCE PRIORITY — PART ${pIdx}/${tParts}]`,
          `• PRIORITY #1 (HIGHEST MANDATORY LOCK) -> ATTACHED IMAGE #1 (${
            imgs[0].savedName || imgs[0].fileName
          }): You MUST prioritize Attached Image #1 above all else for 100% of the character's identity, exact face structure, eyes, nose, mouth, jawline, hairstyle, and body proportions${
            hasPrimaryCharPriority ? ', as well as exact outfit details' : ''
          }! The character MUST NEVER change, morph, or drift away from Attached Image #1. Whenever Attached Image #2 has any motion blur, compression, or slight facial softening from Part ${
            pIdx - 1
          }, ALWAYS restore and lock 100% to the crisp original character in Attached Image #1!`,
          `• PRIORITY #2 (POSE, MOTION & SCENE CONTINUATION) -> ATTACHED IMAGE #2 (${
            imgs[1].savedName || imgs[1].fileName
          }): Use Attached Image #2 (the final frame of Part ${
            pIdx - 1
          }) strictly as the starting body posture, spatial position, camera framing, and background scene continuation at 00.0s so Part ${pIdx} connects seamlessly to Part ${
            pIdx - 1
          } without jump cuts — NEVER let Image #2 alter or degrade Image #1's character identity!`
        ].join('\n');
      } else {
        characterConsistencyBlock = `[CHARACTER REFERENCE CONSISTENCY]: Preserve 100% identical character identity, facial features (eyes, nose, mouth, jawline), hairstyle, body proportions, and outfit fidelity from Attached Image #1 (${
          imgs[0].savedName || imgs[0].fileName
        }) across the entire clip without character drift or replacement.`;
      }
    }

    let imageInstruction = '';
    if (imgs.length > 0) {
      if (pIdx > 1) {
        if (hasPrimaryCharPriority && hasContinuationLastFrame && imgs.length >= 2) {
          imageInstruction = [
            `STRICT DUAL-REFERENCE HIERARCHY (CHARACTER REFERENCE #1 PRIORITY + LAST FRAME #2 CONTINUATION):`,
            `• ATTACHED IMAGE #1 (${imgs[0].savedName || imgs[0].fileName}) = #1 MANDATORY MASTER CHARACTER REFERENCE (HIGHEST PRIORITY): Lock 100% identical character face, facial features, hairstyle, body proportions, and exact outfit to Image #1 so the character NEVER changes compared to the uploaded reference photo.`,
            `• ATTACHED IMAGE #2 (${imgs[1].savedName || imgs[1].fileName}) = #2 CONTINUATION LAST FRAME FROM PART ${
              pIdx - 1
            }: Start Frame 00.0s seamlessly from the exact body pose, spatial position, camera framing, and background environment of Image #2 with ZERO jump cuts, while keeping 100% of the character's face and identity locked to Image #1.`,
            `• Do NOT use any unrelated images from earlier chat messages.`
          ].join('\n');
        } else if (hasPrimaryCharFacePriority && hasContinuationLastFrame && targetOutfitImgs.length > 0) {
          const targetLines = targetOutfitImgs.map((tImg) => {
            const posIdx = imgs.indexOf(tImg) + 1;
            return `• ATTACHED IMAGE #${posIdx} (${tImg.savedName || tImg.fileName}) = 100% MANDATORY NEW OUTFIT #${
              tImg.outfitNumber || posIdx - 1
            } FOR THIS PART: As soon as the prop/fan lens-wipe clears (or throughout this segment), the character MUST be wearing 100% exact garment design, color, fabric texture, neckline, skirt/pants silhouette, accessories, and footwear from Image #${posIdx}! Zero garment morphing!`;
          });
          imageInstruction = [
            `STRICT MULTI-OUTFIT TRANSFORMATION ANCHORS (CHARACTER #1 PRIORITY + LAST FRAME #2 + NEW OUTFIT #3+):`,
            `• ATTACHED IMAGE #1 (${imgs[0].savedName || imgs[0].fileName}) = #1 MANDATORY MASTER CHARACTER IDENTITY LOCK (HIGHEST PRIORITY): Lock 100% identical facial features (eyes, nose, smile, hairstyle, body proportions) and background scene to Image #1 so the model NEVER changes — IMPORTANT: DO NOT reuse the old clothes from Image #1 in this part!`,
            `• ATTACHED IMAGE #2 (${imgs[1].savedName || imgs[1].fileName}) = #2 CONTINUATION LAST FRAME AT 00.0s: Begin seamlessly from the exact pose / prop-wipe frame at the end of Part ${
              pIdx - 1
            } shown in Image #2 with ZERO jump cuts.`,
            ...targetLines
          ]
            .filter(Boolean)
            .join('\n');
        } else {
          imageInstruction = `STRICT CONTINUATION FROM PREVIOUS PART: The attached image (${imageNames}) is the exact final frame of Part ${
            pIdx - 1
          }. Start Frame 00.0s seamlessly from this exact pose, camera framing, and scene with ZERO jump cuts.`;
        }
      } else if (extraOutfitImgs.length > 0) {
        const extraLines = extraOutfitImgs.map((exImg) => {
          const posIdx = imgs.indexOf(exImg) + 1;
          return `• ATTACHED IMAGE #${posIdx} (${exImg.savedName || exImg.fileName}) = TARGET OUTFIT / REFERENCE #${
            exImg.outfitNumber || posIdx
          }: Transition smoothly (via hand-fan / prop lens-wipe or seamless transition per prompt/Skill) into 100% exact garment design, color, silhouette, and accessories of Image #${posIdx}!`;
        });
        imageInstruction = [
          `STRICT MULTI-REFERENCE / MULTI-OUTFIT SEQUENCE (${imgs.length} ATTACHED IMAGES IN THIS MESSAGE ONLY):`,
          `• ATTACHED IMAGE #1 (${imgs[0].savedName || imgs[0].fileName}) = #1 MASTER CHARACTER IDENTITY + SCENE BACKGROUND + OPENING OUTFIT #1: Start in Outfit #1 while locking 100% identical character face and identity across the entire clip.`,
          ...extraLines,
          `• Do NOT use any images from earlier chat messages.`
        ]
          .filter(Boolean)
          .join('\n');
      } else {
        imageInstruction = `STRICT CHARACTER REFERENCE ANCHOR: Use ONLY the Reference Image attached in THIS message (${imageNames}) — preserve 100% identical character face, hairstyle, body proportions, exact outfit, and background environment! Do NOT use images from earlier or later messages.`;
      }
    }

    const continuityBlock =
      tParts > 1
        ? hasPrimaryCharFacePriority && targetOutfitImgs.length > 0
          ? `[STRICT MULTI-OUTFIT CONTINUITY & CHARACTER PRIORITY]\n• 100% identical character face and body proportions locked strictly to Attached Image #1, continuing seamlessly from Attached Image #2 (end of Part ${
              pIdx - 1
            }), now wearing the exact new target outfit from Attached Image #3+.\n• ${partInfo.momentumRule}`
          : hasPrimaryCharPriority && hasContinuationLastFrame
          ? `[STRICT MULTI-SEGMENT CONTINUITY WITH #1 CHARACTER PRIORITY]\n• 100% identical character face, hairstyle, body proportions, and outfit locked strictly to Attached Image #1 (Uploaded Character Reference), while continuing motion & pose seamlessly from Attached Image #2 (final frame of Part ${
              pIdx - 1
            }).\n• ${partInfo.momentumRule}`
          : `[STRICT MULTI-SEGMENT FILM CONTINUITY]\n• Continuous one-shot sequence maintaining consistent character, clothing, and scene.\n• ${partInfo.momentumRule}`
        : '';

    const filenameInstruction = `REQUIRED OUTPUT FILENAME: You MUST save and attach the generated video directly in chat with the exact filename "${tag}.mp4" (NEVER rename it to "${rowPad}.mp4" or "row${rowPad}.mp4").`;
    const errorInstruction = `ERROR RULE: If this request (${tag}) is blocked by safety filter or fails to generate, immediately reply with "MFS_ERROR_${tag}" and skip it.`;

    const sections = [
      `[TASK ROW #${rowPad} — ID: ${tag}]`,
      `[${partInfo.taskType}]`,
      characterConsistencyBlock,
      cameraMotionBlock,
      skillDirectiveBlock,
      sampleTransferBlock,
      `=== ${partInfo.segmentTitle} ===`,
      partInfo.narrativeContent,
      continuityBlock,
      partInfo.dialogueInstruction,
      imageInstruction,
      `[${specs.join(' | ')}]`,
      filenameInstruction,
      errorInstruction
    ].filter(Boolean);

    return sections.join('\n');
  }

  /**
   * Nhập prompt, bấm nút gửi và ĐỢI cho đến khi tin nhắn kèm ảnh của hàng này thực sự xuất hiện trong lịch sử chat
   * trước khi cho phép hàng tiếp theo gắn ảnh mới!
   * CƠ CHẾ CHỐNG LỖI TIMEOUT 100%:
   * - Tuyệt đối KHÔNG dùng `composerLocator.click({ timeout: 5000 })` (vốn bị kẹt nếu có lớp phủ dialog/lightbox).
   * - Truyền trực tiếp nội dung Prompt vào React state của ô textarea qua DOM `HTMLTextAreaElement.prototype.value` setter,
   *   kết hợp `fill(..., { force: true })` và kích hoạt nút Gửi trực tiếp trong DOM.
   */
  async _typeAndSubmitPromptViaCdp(page, promptText, uniqueRunTag, customSelectors = {}) {
    await this._dismissAnyOverlaysAndLightboxes(page);

    const customPromptSel = customSelectors?.promptInput?.trim();
    const promptSelectors = [
      customPromptSel,
      'textarea:not([disabled])',
      'textarea',
      '[contenteditable="true"][role="textbox"]',
      '[contenteditable="true"]',
      '[role="textbox"]:not([aria-label*="Mobile number or email" i])'
    ].filter(Boolean);

    // Đợi tối đa 10 giây nếu ô nhập đang tạm thời bị vô hiệu hóa hoặc chưa render xong
    let foundComposer = false;
    const findStart = Date.now();
    while (Date.now() - findStart < 10000) {
      await this._dismissAnyOverlaysAndLightboxes(page);
      foundComposer = await page
        .evaluate((selectors) => {
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) return true;
          }
          return false;
        }, promptSelectors)
        .catch(() => false);
      if (foundComposer) break;
      await page.waitForTimeout(300);
    }

    if (!foundComposer) {
      throw new Error('Không tìm thấy ô nhập Prompt trên muse.ai.');
    }

    // Bước 1: Điền trực tiếp nội dung Prompt bằng DOM Native Value Setter (chuẩn React 18) — KHÔNG BAO GIỜ BỊ CHẶN BỞI POINTER EVENTS
    const filledViaDom = await page
      .evaluate(
        ({ selectors, text }) => {
          let target = null;
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) {
              target = el;
              break;
            }
          }
          if (!target) return false;

          if (target.disabled) {
            target.disabled = false;
          }
          try {
            target.focus();
          } catch (_) {}

          const tag = (target.tagName || '').toLowerCase();
          if (tag === 'textarea' || tag === 'input') {
            const proto = tag === 'textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
            const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
            if (nativeSetter) {
              nativeSetter.call(target, text);
            } else {
              target.value = text;
            }
            target.dispatchEvent(new Event('input', { bubbles: true }));
            target.dispatchEvent(new Event('change', { bubbles: true }));
            return true;
          }

          // Trường hợp contenteditable
          target.textContent = text;
          target.dispatchEvent(new InputEvent('input', { bubbles: true, data: text }));
          target.dispatchEvent(new Event('change', { bubbles: true }));
          return true;
        },
        { selectors: promptSelectors, text: promptText }
      )
      .catch(() => false);

    // Bước 2: Dự phòng bằng Playwright fill({ force: true }) nếu ô textarea vẫn chưa nhận đủ chữ
    const verifyHasText = await page
      .evaluate((selectors) => {
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (el) {
            const val = el.value !== undefined ? el.value : el.textContent || '';
            if (val && val.trim().length > 5) return true;
          }
        }
        return false;
      }, promptSelectors)
      .catch(() => false);

    if (!filledViaDom || !verifyHasText) {
      for (const sel of promptSelectors) {
        const loc = page.locator(sel).first();
        if ((await loc.count().catch(() => 0)) > 0) {
          try {
            await loc.fill(promptText, { force: true, timeout: 4000 });
            break;
          } catch (_) {}
        }
      }
    }

    await page.waitForTimeout(450);

    // Bước 3: Kích hoạt nút Gửi (Send) trực tiếp qua DOM click + force click (không bao giờ bị chặn bởi lớp phủ)
    const customSubmitSel = customSelectors?.submitButton?.trim();
    const submitSelectors = [
      customSubmitSel,
      'form button[aria-label*="send" i]:not([disabled])',
      'button[aria-label*="send" i]:not([disabled])',
      'form button[aria-label*="submit" i]:not([disabled])',
      'button[aria-label*="submit" i]:not([disabled])',
      '[data-testid*="send" i]:not([disabled])',
      'form button[type="submit"]:not([disabled])',
      'button[type="submit"]:not([disabled])'
    ].filter(Boolean);

    const tryTriggerSend = async () => {
      await this._dismissAnyOverlaysAndLightboxes(page);

      // Ưu tiên 1: Click trực tiếp trên phần tử nút Send trong DOM (bỏ qua hoàn toàn hit-testing tọa độ chuột)
      const domClicked = await page
        .evaluate((selectors) => {
          for (const sel of selectors) {
            const btn = document.querySelector(sel);
            if (btn && !btn.disabled) {
              try {
                btn.click();
                return true;
              } catch (_) {}
            }
          }
          return false;
        }, submitSelectors)
        .catch(() => false);

      if (domClicked) return true;

      // Ưu tiên 2: Click với { force: true }
      for (const sel of submitSelectors) {
        const btn = page.locator(sel).first();
        if ((await btn.count().catch(() => 0)) > 0) {
          try {
            await btn.click({ force: true, timeout: 2000 });
            return true;
          } catch (_) {}
        }
      }
      return false;
    };

    let clickedSubmit = false;
    const waitSendStart = Date.now();
    while (Date.now() - waitSendStart < 10000 && !clickedSubmit) {
      clickedSubmit = await tryTriggerSend();
      if (!clickedSubmit) {
        await page.waitForTimeout(350);
      }
    }

    if (!clickedSubmit) {
      await page.keyboard.press('Enter').catch(() => {});
    }

    // ĐỢI XÁC NHẬN: Tin nhắn chứa mã uniqueRunTag đã thực sự được đẩy vào luồng chat
    let sentConfirmed = false;
    let retriedSendCount = 0;
    const confirmStart = Date.now();
    while (Date.now() - confirmStart < 15000) {
      sentConfirmed = await page
        .evaluate((tag) => {
          const userMsgs = Array.from(
            document.querySelectorAll('[data-message-item="true"][data-message-role="user"]')
          );
          return userMsgs.some((el) => (el.textContent || '').includes(tag));
        }, uniqueRunTag)
        .catch(() => false);

      if (sentConfirmed) {
        break;
      }

      // Nếu sau 3.5 giây hoặc 7.5 giây tin nhắn vẫn nằm trong ô nhập chưa bay lên khung chat, tự động điền lại & bấm gửi lại
      if (
        (retriedSendCount === 0 && Date.now() - confirmStart > 3500) ||
        (retriedSendCount === 1 && Date.now() - confirmStart > 7500)
      ) {
        retriedSendCount++;
        await page
          .evaluate(
            ({ selectors, text }) => {
              for (const sel of selectors) {
                const el = document.querySelector(sel);
                if (el && (el.tagName || '').toLowerCase() === 'textarea') {
                  if (!el.value || !el.value.trim()) {
                    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
                    if (setter) setter.call(el, text);
                    else el.value = text;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                  }
                  try {
                    el.focus();
                    el.dispatchEvent(
                      new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })
                    );
                  } catch (_) {}
                  break;
                }
              }
            },
            { selectors: promptSelectors, text: promptText }
          )
          .catch(() => {});

        const ok = await tryTriggerSend();
        if (!ok) {
          await page.keyboard.press('Enter').catch(() => {});
        }
      }
      await page.waitForTimeout(400);
    }

    if (!sentConfirmed) {
      await this._clearComposerBeforeUpload(page);
      throw new Error('Không gửi được lệnh lên khung chat Muse.ai (ảnh hoặc kết nối bị từ chối). Đã bỏ qua!');
    }

    // Nghỉ 2 giây giữa 2 lần gửi để server Muse.ai tách biệt hoàn toàn từng tin nhắn và ảnh đính kèm
    await page.waitForTimeout(2000);
  }

  /**
   * Kiểm tra trực tiếp trên DOM của Muse.ai xem Hàng #rowIndex có bị báo lỗi / bị chặn nội dung /
   * hoặc Muse.ai đã kết thúc đợt xử lý mà bỏ trống hàng này hay không.
   */
  async _checkRowFailedInDom(page, rowIndex, uniqueRunTag, elapsedSec) {
    return await page
      .evaluate(
        ({ rowIndex, rowPad, uniqueRunTag, elapsedSec }) => {
          const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
          const tagLower = uniqueRunTag.toLowerCase();

          // Tìm vị trí tin nhắn user của hàng này
          let userMsgIndex = -1;
          for (let i = allMsgs.length - 1; i >= 0; i--) {
            if (
              allMsgs[i].getAttribute('data-message-role') === 'user' &&
              (allMsgs[i].textContent || '').toLowerCase().includes(tagLower)
            ) {
              userMsgIndex = i;
              break;
            }
          }

          const assistantMsgsAfter = (userMsgIndex !== -1 ? allMsgs.slice(userMsgIndex + 1) : allMsgs.slice(-15)).filter(
            (el) => el.getAttribute('data-message-role') === 'assistant'
          );

          const rowTokens = [
            tagLower,
            `mfs_row${rowPad}`,
            `row${rowPad}`,
            `row_${rowPad}`,
            `row-${rowPad}`,
            `row ${rowPad}`,
            `row ${rowIndex}`,
            `hàng ${rowIndex}`,
            `hàng #${rowIndex}`,
            `hàng ${rowPad}`
          ];

          for (const msgEl of assistantMsgsAfter) {
            const rawText = (msgEl.textContent || '').replace(/^Assistant message:\s*/i, '').trim();
            if (!rawText) continue;
            const lower = rawText.toLowerCase();

            // 1. Mã lỗi chuẩn MFS_ERROR_${uniqueRunTag}
            if (
              lower.includes(`mfs_error_${tagLower}`) ||
              lower.includes(`mfs_error_mfs_row${rowPad}`) ||
              lower.includes(`error_row_${rowPad}`)
            ) {
              return {
                failed: true,
                reason: `Muse.ai báo lỗi không tạo được video cho Hàng #${rowIndex} (${rawText.slice(0, 110)})`
              };
            }

            // Loại bỏ các câu phủ định an toàn như "không clip nào bị chặn", "không bị chặn", "0 bị chặn"
            const sanitized = lower
              .replace(/không\s+(có\s+)?(clip|video|hàng|row|bản)?\s*(nào\s+)?(bị\s+chặn|bị\s+lỗi|lỗi)/gi, '')
              .replace(/chưa\s+có\s+(clip|video)\s+nào\s+bị\s+chặn/gi, '')
              .replace(/\b0\s+(clip\s+|video\s+)?bị\s+chặn/gi, '')
              .replace(/no\s+(clip|video|row)s?\s+(were\s+|was\s+)?(blocked|failed)/gi, '');

            // Tách thành từng mệnh đề để kiểm tra chính xác
            const clauses = sanitized.split(/[.;\n—]+/);
            for (const clause of clauses) {
              const mentionsThisRow =
                rowTokens.some((tok) => clause.includes(tok)) ||
                new RegExp(`\\b(số|row)\\s*0*${rowIndex}\\b`, 'i').test(clause);

              if (!mentionsThisRow) continue;

              // Nếu mệnh đề đang báo hàng này "đang chạy" thì bỏ qua
              if (/đang\s+chạy|đang\s+tạo|đang\s+xử\s+lý|still\s+running|in\s+progress/i.test(clause)) {
                continue;
              }

              const hasFailKeyword =
                /bị\s+chặn|không\s+tạo\s+được|không\s+thể\s+tạo|bị\s+lỗi|gặp\s+lỗi|thất\s+bại|vẫn\s+trống|số\s+trống|từ\s+chối|vi\s+phạm|chưa\s+qua|blocked|failed|unable\s+to|cannot\s+generate|can't\s+generate|couldn't\s+generate|policy\s+violation|safety\s+filter/i.test(
                  clause
                );

              if (hasFailKeyword) {
                return {
                  failed: true,
                  reason: `Video Hàng #${rowIndex} bị chặn hoặc báo lỗi trên Muse.ai: "${rawText.slice(0, 110)}"`
                };
              }
            }

            // Kiểm tra cấu trúc tổng kết của Muse.ai: "Bị chặn 2: row02 ... và row05"
            const blockedSectionMatch = sanitized.match(/bị\s+chặn[^.;\n]*/i);
            if (blockedSectionMatch) {
              const blockedSegment = blockedSectionMatch[0];
              const hitInBlocked =
                rowTokens.some((tok) => blockedSegment.includes(tok)) ||
                new RegExp(`\\b0*${rowIndex}\\b`).test(blockedSegment);
              if (hitInBlocked) {
                return {
                  failed: true,
                  reason: `Video Hàng #${rowIndex} bị chặn trên Muse.ai: "${blockedSegment.slice(0, 100)}"`
                };
              }
            }
          }

          // Kiểm tra trạng thái hoạt động của Muse.ai (để biết Muse.ai còn đang render hay đã nghỉ hoàn toàn)
          const hasWorkingVideo = Array.from(document.querySelectorAll('video')).some((v) => {
            const s = v.currentSrc || v.src || '';
            return s.includes('hatch_working') || s.includes('hatch_connecting');
          });
          const hasStopBtn = Boolean(
            document.querySelector(
              'button[aria-label*="Stop" i], button[aria-label*="Cancel" i], [data-testid*="stop" i]'
            )
          );
          const lastAssistantText =
            assistantMsgsAfter.length > 0
              ? (assistantMsgsAfter[assistantMsgsAfter.length - 1].textContent || '').trim()
              : '';

          // Kiểm tra xem tin nhắn cuối cùng sau hàng này có phải là thông báo đã kết thúc cả đợt ("Tổng kết đợt", "hết đợt này") không
          const batchSummaryDone =
            elapsedSec >= 35 &&
            /tổng\s+kết\s+đợt|hết\s+đợt\s+này|đợt\s+tạo\s+video\s+vừa\s+rồi\s+đã\s+xong|đợt\s+này\s+đẹp/i.test(
              lastAssistantText
            );

          return {
            failed: false,
            isActivelyWorking: hasWorkingVideo || hasStopBtn,
            lastAssistantText: lastAssistantText.slice(0, 140),
            msgCountAfter: assistantMsgsAfter.length,
            batchSummaryDone
          };
        },
        {
          rowIndex: Number(rowIndex),
          rowPad: String(rowIndex).padStart(2, '0'),
          uniqueRunTag,
          elapsedSec
        }
      )
      .catch(() => ({ failed: false, isActivelyWorking: true, lastAssistantText: '', msgCountAfter: 0 }));
  }

  /**
   * Chờ đợi video thành phẩm thật xuất hiện trong [data-testid="hatch-chat-attachment-presentation-video"]
   * QUY TẮC KHỚP THỨ TỰ & CHỐNG LỖI TIMEOUT 100%:
   * - Hàng #rowIndex CHỈ nhận đúng video mang mã `uniqueRunTag` hoặc chỉ số hàng `rowIndex`.
   * - Nếu Muse.ai báo chặn nội dung (safety filter), lập tức báo lỗi đỏ và BỎ QUA để chạy hàng tiếp theo.
   * - Nếu Muse.ai bị nghẽn/quên lệnh mà đứng im (không báo chặn nhưng chưa trả video), công cụ TỰ ĐỘNG GỬI LẠI LỆNH
   *   (tối đa 2 lần) thay vì báo lỗi Timeout!
   */
  async _waitForGeneratedVideoViaCdp({
    page,
    accountId = 'default',
    baselineAttachmentKeys,
    usedRemoteSrcs = new Set(),
    rowIndex,
    partIdx = 1,
    totalParts = 1,
    uniqueRunTag,
    abortSignal,
    resubmitPromptFn,
    onLiveStatus
  }) {
    const startTime = Date.now();
    const maxWaitMs = 45 * 60 * 1000;
    let lastDomSignature = '';
    let lastDomChangeTime = Date.now();
    let batchSummarySeenAt = null;
    let autoResubmitCount = 0;
    const tagLower = String(uniqueRunTag || '').toLowerCase();

    while (Date.now() - startTime < maxWaitMs) {
      if (abortSignal?.aborted) {
        throw new Error('Đã dừng tiến trình theo lệnh người dùng.');
      }

      const elapsedSec = Math.floor((Date.now() - startTime) / 1000);

      const currentAttachments = await this._extractValidAttachmentVideosFromDom(page, accountId);
      const newUnclaimed = currentAttachments.filter(
        (item) =>
          !baselineAttachmentKeys.has(item.key) &&
          !this.claimedVideoKeys.has(item.key) &&
          !(usedRemoteSrcs && usedRemoteSrcs.has(item.src))
      );

      if (newUnclaimed.length > 0) {
        const userTagMsgIndex = await page
          .evaluate((tLower) => {
            const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
            for (let i = allMsgs.length - 1; i >= 0; i--) {
              if (
                allMsgs[i].getAttribute('data-message-role') === 'user' &&
                (allMsgs[i].textContent || '').toLowerCase().includes(tLower)
              ) {
                return i;
              }
            }
            return -1;
          }, tagLower)
          .catch(() => -1);

        // 1. Khớp chính xác tuyệt đối theo uniqueRunTag (VD: mfs_row01_p2_k9x2)
        let matched = newUnclaimed.find((it) =>
          (it.ariaLabel || '').toLowerCase().includes(tagLower)
        );

        // 2. Khớp trực tiếp video phản hồi ngay bên dưới tin nhắn user chứa mã uniqueRunTag (kể cả khi Muse.ai đặt tên file khác)
        if (!matched) {
          matched = newUnclaimed.find((it) => {
            const pText = (it.precedingUserText || '').toLowerCase();
            if (!pText || !pText.includes(tagLower)) return false;
            const parsedRow = this._parseRowNumberFromAriaLabel(it.ariaLabel);
            if (parsedRow !== null && parsedRow !== Number(rowIndex)) return false;
            const parsedPart = this._parsePartNumberFromAriaLabel(it.ariaLabel);
            if (totalParts > 1 && parsedPart !== null && parsedPart !== Number(partIdx)) return false;
            return true;
          });
        }

        // 3. Khớp dự phòng theo số hàng rowIndex — kiểm tra chặt số phần (partIdx) và vị trí tin nhắn sau lệnh gửi hiện tại
        if (!matched) {
          matched = newUnclaimed.find((it) => {
            const parsedRow = this._parseRowNumberFromAriaLabel(it.ariaLabel);
            if (parsedRow !== Number(rowIndex)) return false;
            const parsedPart = this._parsePartNumberFromAriaLabel(it.ariaLabel);
            if (totalParts > 1 && parsedPart !== null && parsedPart !== Number(partIdx)) {
              return false;
            }
            if (userTagMsgIndex !== -1 && it.domMsgIndex !== -1 && it.domMsgIndex <= userTagMsgIndex) {
              return false;
            }
            return true;
          });
        }

        if (matched) {
          this.claimedVideoKeys.add(matched.key);
          return matched;
        }
      }

      // Kiểm tra xem video Hàng #rowIndex có bị báo lỗi / bị chặn trên Muse.ai hay không
      const domCheck = await this._checkRowFailedInDom(page, rowIndex, uniqueRunTag, elapsedSec);
      if (domCheck.failed) {
        throw new Error(domCheck.reason || `Video Hàng #${rowIndex} bị lỗi trên Muse.ai — Đã tự động bỏ qua!`);
      }

      // Nếu Muse.ai đã in thông báo tổng kết xong đợt hoặc đứng im hoàn toàn không render nữa mà chưa có video của hàng này:
      // Tự động gửi lại lệnh (auto-retry) lên đến 2 lần để không bao giờ bị lỗi Timeout!
      const isBatchIdleWithoutVideo =
        (domCheck.batchSummaryDone && batchSummarySeenAt && Date.now() - batchSummarySeenAt >= 8000) ||
        (!domCheck.isActivelyWorking && elapsedSec >= 75 && Date.now() - lastDomChangeTime >= 50000);

      if (domCheck.batchSummaryDone) {
        if (!batchSummarySeenAt) {
          batchSummarySeenAt = Date.now();
        }
      } else {
        batchSummarySeenAt = null;
      }

      const currentSig = `${currentAttachments.length}::${domCheck.msgCountAfter}::${domCheck.lastAssistantText}`;
      if (currentSig !== lastDomSignature || domCheck.isActivelyWorking) {
        lastDomSignature = currentSig;
        lastDomChangeTime = Date.now();
      }

      if (isBatchIdleWithoutVideo) {
        if (typeof resubmitPromptFn === 'function' && autoResubmitCount < 2) {
          autoResubmitCount++;
          batchSummarySeenAt = null;
          lastDomChangeTime = Date.now();
          if (typeof onLiveStatus === 'function') {
            onLiveStatus(
              `Muse.ai tạm nghỉ chưa trả video — Đang tự động gửi lại lệnh Hàng #${rowIndex} (Lần ${autoResubmitCount}/2)...`,
              elapsedSec
            );
          }
          try {
            await resubmitPromptFn();
            lastDomChangeTime = Date.now();
            continue;
          } catch (_) {}
        }

        throw new Error(
          `Muse.ai từ chối hoặc bỏ qua tạo video cho Hàng #${rowIndex} sau ${autoResubmitCount + 1} lần gửi — Đã tự động bỏ qua!`
        );
      }

      if (typeof onLiveStatus === 'function') {
        const cleanText = (domCheck.lastAssistantText || '').slice(0, 95);
        onLiveStatus(cleanText, elapsedSec);
      }

      await page.waitForTimeout(2000);
    }

    throw new Error(
      `Video Hàng #${rowIndex} (${uniqueRunTag}) không phản hồi từ Muse.ai — Đã tự động bỏ qua!`
    );
  }

  /**
   * Tải video từ Chrome CDP với cơ chế tự phục hồi 4 lớp:
   * - Nếu blob: URL vừa bị React xoay vòng/làm mới (gây Failed to fetch), tự động truy vấn lại DOM sống
   *   theo messageId / ariaLabel / uniqueRunTag để lấy URL mới nhất (blob: hoặc https:) và tải tiếp không gián đoạn!
   */
  async _downloadVideoViaCdp(page, context, videoUrl, destFilePath, matchMeta = null) {
    let currentUrl = String(videoUrl || '').trim();
    let lastErr = null;

    for (let attempt = 1; attempt <= 4; attempt++) {
      if (currentUrl.startsWith('blob:')) {
        const evalResult = await page
          .evaluate(async (blobUrl) => {
            try {
              const res = await fetch(blobUrl);
              if (!res.ok) {
                return { ok: false, error: `HTTP ${res.status}` };
              }
              const blob = await res.blob();
              const base64 = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                  const result = reader.result || '';
                  resolve(result.includes(',') ? result.split(',')[1] : result);
                };
                reader.onerror = () => reject(new Error('FileReader error'));
                reader.readAsDataURL(blob);
              });
              return { ok: true, base64, size: blob.size };
            } catch (err) {
              return { ok: false, error: err && err.message ? err.message : String(err) };
            }
          }, currentUrl)
          .catch((e) => ({ ok: false, error: e.message }));

        if (evalResult && evalResult.ok && evalResult.base64) {
          const buf = Buffer.from(evalResult.base64, 'base64');
          if (buf.length > 10000) {
            fs.writeFileSync(destFilePath, buf);
            return destFilePath;
          }
          lastErr = new Error(`Dữ liệu blob quá nhỏ (${buf.length} bytes)`);
        } else {
          lastErr = new Error(evalResult?.error || 'Failed to fetch blob URL');
        }
      } else if (currentUrl) {
        try {
          const response = await context.request.get(currentUrl, { timeout: 120000 });
          if (response.ok()) {
            const buffer = await response.body();
            if (buffer.length > 10000) {
              fs.writeFileSync(destFilePath, buffer);
              return destFilePath;
            }
          }
          lastErr = new Error(`HTTP ${response.status()} khi tải ${currentUrl}`);
        } catch (reqErr) {
          lastErr = reqErr;
          // Dự phòng tải trực tiếp trong ngữ cảnh trang trình duyệt nếu request ngoài thiếu cookie
          const fallbackEval = await page
            .evaluate(async (remoteUrl) => {
              try {
                const res = await fetch(remoteUrl, { credentials: 'include' });
                if (!res.ok) return { ok: false };
                const blob = await res.blob();
                const base64 = await new Promise((resolve, reject) => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    const r = reader.result || '';
                    resolve(r.includes(',') ? r.split(',')[1] : r);
                  };
                  reader.onerror = reject;
                  reader.readAsDataURL(blob);
                });
                return { ok: true, base64 };
              } catch (_) {
                return { ok: false };
              }
            }, currentUrl)
            .catch(() => ({ ok: false }));

          if (fallbackEval && fallbackEval.ok && fallbackEval.base64) {
            const buf = Buffer.from(fallbackEval.base64, 'base64');
            if (buf.length > 10000) {
              fs.writeFileSync(destFilePath, buf);
              return destFilePath;
            }
          }
        }
      }

      // Nếu lần thử này thất bại, chờ 700ms và quét lại DOM sống để lấy blob:/https: URL mới nhất của đúng video này
      if (attempt < 4) {
        await page.waitForTimeout(700).catch(() => {});
        if (matchMeta && (matchMeta.messageId || matchMeta.ariaLabel || matchMeta.uniqueRunTag)) {
          const refreshedSrc = await page
            .evaluate((meta) => {
              const allMsgs = Array.from(document.querySelectorAll('[data-message-item="true"]'));
              if (allMsgs.length > 0) {
                try {
                  allMsgs[allMsgs.length - 1].scrollIntoView({ block: 'end' });
                } catch (_) {}
              }

              const containers = Array.from(
                document.querySelectorAll(
                  '[data-testid="hatch-chat-attachment-presentation-video"], [data-hatch-video-wrapper="true"]'
                )
              );

              const tagLower = String(meta.uniqueRunTag || '').toLowerCase();
              const targetLabel = String(meta.ariaLabel || '').toLowerCase();

              for (const c of containers) {
                const wrapper = c.hasAttribute('data-hatch-video-wrapper')
                  ? c
                  : c.querySelector('[data-hatch-video-wrapper="true"]');
                const videoEl = c.querySelector('video');
                const src =
                  (wrapper && wrapper.getAttribute('data-hatch-video-src')) ||
                  (videoEl && (videoEl.currentSrc || videoEl.src)) ||
                  '';
                if (
                  !src ||
                  src.includes('hatch_connecting') ||
                  src.includes('hatch_working') ||
                  src.includes('/videos/avatars/')
                ) {
                  continue;
                }

                const msgEl = c.closest('[data-message-item="true"], [data-message-id]');
                const msgId = msgEl ? msgEl.getAttribute('data-message-id') || '' : '';
                const label = (
                  wrapper ? wrapper.getAttribute('aria-label') || '' : c.getAttribute('aria-label') || ''
                ).toLowerCase();

                if (meta.messageId && msgId === meta.messageId) {
                  if (!targetLabel || label === targetLabel) return src;
                }
                if (tagLower && label.includes(tagLower)) {
                  return src;
                }
                if (targetLabel && label === targetLabel) {
                  return src;
                }
                if (tagLower && msgEl) {
                  const idx = allMsgs.indexOf(msgEl);
                  if (idx > 0) {
                    for (let k = idx - 1; k >= 0; k--) {
                      if (allMsgs[k].getAttribute('data-message-role') === 'user') {
                        if ((allMsgs[k].textContent || '').toLowerCase().includes(tagLower)) {
                          return src;
                        }
                        break;
                      }
                    }
                  }
                }
              }
              return '';
            }, matchMeta)
            .catch(() => '');

          if (refreshedSrc) {
            currentUrl = refreshedSrc;
            if (matchMeta.key && this.discoveredVideosCache.has(matchMeta.key)) {
              const cached = this.discoveredVideosCache.get(matchMeta.key);
              this.discoveredVideosCache.set(matchMeta.key, { ...cached, src: refreshedSrc });
            }
          }
        }
      }
    }

    throw lastErr || new Error(`Không thể tải video từ ${currentUrl}`);
  }
}

module.exports = {
  CdpEngine,
  extractQuotedDialogueList,
  splitLongSpeechIntoChunks,
  splitDialogueIntoPartSegments
};
